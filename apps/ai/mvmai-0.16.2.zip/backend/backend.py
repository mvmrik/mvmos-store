"""
mvmAI backend — OpenAI-compatible chat proxy + policy-gated shell execution.

All known providers (Gemini, OpenAI, Groq, OpenRouter, Qwen, DeepSeek, Mistral,
Ollama) expose an OpenAI-compatible /chat/completions endpoint, so a single
adapter serves them all. The provider config and API key live in the app's own
SQLite DB (apps/mvmai/data.db, cfg table) — the key is read server-side and is
never sent back to the browser.
"""

import asyncio
import base64
import contextvars
import hashlib
import json
import logging
import os
import pwd
import re
import shlex
import shutil
import signal
import sqlite3
import subprocess
import sys
import tempfile
import time
import threading
import uuid
from glob import glob

import httpx
from fastapi import APIRouter, Depends, Header
from fastapi.responses import JSONResponse
from pydantic import BaseModel

get_current_session = sys.modules["backend.auth"].get_current_session

router = APIRouter(prefix="/api/mvmai", tags=["mvmai"])

# Path to this app's own SQLite DB (shared with the frontend mvmOS.db('mvmai'))
_DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "..", "apps", "mvmai", "data.db")

# ── Known providers — all OpenAI-compatible ─────────────────────────────────────
PROVIDERS = {
    "gemini":     {"name": "Google Gemini", "base_url": "https://generativelanguage.googleapis.com/v1beta/openai/", "needs_key": True,  "default_model": "gemini-2.0-flash"},
    "openai":     {"name": "OpenAI",         "base_url": "https://api.openai.com/v1/",                              "needs_key": True,  "default_model": "gpt-4o-mini"},
    "groq":       {"name": "Groq",           "base_url": "https://api.groq.com/openai/v1/",                         "needs_key": True,  "default_model": "llama-3.3-70b-versatile"},
    "openrouter": {"name": "OpenRouter",     "base_url": "https://openrouter.ai/api/v1/",                           "needs_key": True,  "default_model": "openai/gpt-4o-mini"},
    "deepseek":   {"name": "DeepSeek",       "base_url": "https://api.deepseek.com/",                               "needs_key": True,  "default_model": "deepseek-chat"},
    "qwen":       {"name": "Qwen (DashScope)","base_url": "https://dashscope-intl.aliyuncs.com/compatible-mode/v1/", "needs_key": True, "default_model": "qwen-plus"},
    "mistral":    {"name": "Mistral",        "base_url": "https://api.mistral.ai/v1/",                              "needs_key": True,  "default_model": "mistral-small-latest"},
    "ollama":     {"name": "Ollama (local)", "base_url": "http://localhost:11434/v1/",                              "needs_key": False, "default_model": "llama3.1"},
    "custom":     {"name": "Custom",         "base_url": "",                                                        "needs_key": True,  "default_model": ""},
}

# ── Dangerous command patterns ──────────────────────────────────────────────────
_DANGER = [
    r"\brm\s+-[a-z]*[rf]",          # rm -rf / rm -fr / rm -r
    r"\bmkfs\b", r"\bwipefs\b", r"\bfdisk\b", r"\bparted\b", r"\bsgdisk\b",
    r"\bdd\s+.*\bof=/dev/",          # dd to a device
    r">\s*/dev/sd", r">\s*/dev/nvme", r">\s*/dev/vd",
    r"\bshutdown\b", r"\breboot\b", r"\bpoweroff\b", r"\bhalt\b", r"\binit\s+[06]\b",
    r":\(\)\s*\{",                   # fork bomb
    r"\bchmod\s+-R\s+777\s+/(\s|$)", r"\bchown\s+-R\s+.*\s+/(\s|$)",
    r"\buserdel\b", r"\bdeluser\b",
    r"\brm\s+-[a-z]*\s+/(\s|$)", r"\brm\s+-[a-z]*\s+/\*",
    r">\s*/etc/", r"\bmv\b.*\s+/etc/",
]


def _is_dangerous(cmd: str) -> bool:
    c = cmd.strip()
    return any(re.search(p, c) for p in _DANGER)


# ── cfg helpers (read/write the app's own data.db) ──────────────────────────────
def _read_cfg() -> dict:
    cfg = {}
    if not os.path.isfile(_DB_PATH):
        return cfg
    try:
        conn = sqlite3.connect(_DB_PATH)
        for key, value in conn.execute("SELECT key, value FROM cfg"):
            try:
                import json as _json
                cfg[key] = _json.loads(value)
            except Exception:
                cfg[key] = value
        conn.close()
    except Exception:
        pass
    return cfg


def _write_cfg(key: str, value) -> None:
    """Used by the public-page router (apps/mvmai/api.py) to persist the
    admin-only pub_exec_* toggle — the desktop app writes its own exec_* keys
    directly via mvmOS.db('mvmai') from the frontend, bypassing this backend
    entirely, same as every other desktop setting."""
    conn = sqlite3.connect(_DB_PATH)
    conn.execute("CREATE TABLE IF NOT EXISTS cfg (key TEXT PRIMARY KEY, value TEXT)")
    conn.execute("INSERT OR REPLACE INTO cfg (key, value) VALUES (?, ?)", (key, json.dumps(value)))
    conn.commit()
    conn.close()


# ── AI Projects (admin-only; never exposed through the generic, un-gated
#    /api/plugins/mvmai/db proxy — a project's `path` is exactly what /exec
#    scopes shell access to, so it gets its own admin-gated table) ─────────────

def _projects_db():
    conn = sqlite3.connect(_DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute(
        "CREATE TABLE IF NOT EXISTS ai_projects ("
        "id TEXT PRIMARY KEY, name TEXT NOT NULL, path TEXT NOT NULL, created_at INTEGER NOT NULL)"
    )
    # additive migration — same reasoning as pub_sessions.project_id in api.py
    cols = {row[1] for row in conn.execute("PRAGMA table_info(ai_projects)")}
    if "instructions" not in cols:
        conn.execute("ALTER TABLE ai_projects ADD COLUMN instructions TEXT NOT NULL DEFAULT ''")
    if "instructions_file" not in cols:
        conn.execute("ALTER TABLE ai_projects ADD COLUMN instructions_file TEXT NOT NULL DEFAULT ''")
    if "last_used_at" not in cols:
        conn.execute("ALTER TABLE ai_projects ADD COLUMN last_used_at REAL")
    return conn


_PROJECT_COLUMNS = "id, name, path, instructions, instructions_file, created_at, last_used_at"


def list_projects() -> list:
    with _projects_db() as conn:
        rows = conn.execute(
            f"SELECT {_PROJECT_COLUMNS} FROM ai_projects ORDER BY COALESCE(last_used_at,created_at) DESC, name COLLATE NOCASE"
        ).fetchall()
    return [dict(row) for row in rows]


def _get_project(project_id: str):
    if not project_id:
        return None
    with _projects_db() as conn:
        row = conn.execute(
            f"SELECT {_PROJECT_COLUMNS} FROM ai_projects WHERE id = ?", (project_id,)
        ).fetchone()
    return dict(row) if row else None


def create_project(name: str, path: str = "", instructions: str = "", instructions_file: str = "") -> dict:
    """A project's folder is optional — without one it's just a named group of
    chats sharing the same instructions, no file tree / git status / shell cwd."""
    name = (name or "").strip()
    if not name:
        raise ValueError("Project name is required")
    path = (path or "").strip()
    if path:
        path = os.path.realpath(path)
        if not os.path.isdir(path):
            raise ValueError(f"Not a directory: {path}")
    instructions_file = _project_rules_file(instructions_file, path)
    project_id = uuid.uuid4().hex
    used_at = time.time()
    now = int(used_at)
    with _projects_db() as conn:
        conn.execute(
            "INSERT INTO ai_projects (id, name, path, created_at, instructions, instructions_file, last_used_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (project_id, name, path, now, (instructions or "").strip(), instructions_file, used_at),
        )
    return _get_project(project_id)


def _project_rules_file(path, project_path=""):
    path = (path or "").strip()
    if not path:
        return ""
    if not os.path.isabs(path) and project_path:
        path = os.path.join(project_path, path)
    path = os.path.realpath(path)
    if not os.path.isfile(path):
        raise ValueError(f"File not found: {path}")
    return path


def touch_project(project_id: str):
    with _projects_db() as conn:
        conn.execute("UPDATE ai_projects SET last_used_at=? WHERE id=?", (time.time(), project_id))


def update_project(project_id: str, name: str = None, path: str = None,
                    instructions: str = None, instructions_file: str = None) -> dict:
    """PATCH semantics: a field left as None is untouched; an empty string clears it."""
    project = _get_project(project_id)
    if not project:
        raise ValueError("Project not found")
    fields = {}
    if name is not None:
        name = name.strip()
        if not name:
            raise ValueError("Project name is required")
        fields["name"] = name
    if path is not None:
        path = path.strip()
        if path:
            path = os.path.realpath(path)
            if not os.path.isdir(path):
                raise ValueError(f"Not a directory: {path}")
        fields["path"] = path
    if instructions is not None:
        fields["instructions"] = instructions.strip()
    if instructions_file is not None:
        fields["instructions_file"] = _project_rules_file(instructions_file, fields.get("path", project["path"]))
    if fields:
        with _projects_db() as conn:
            conn.execute(
                "UPDATE ai_projects SET " + ", ".join(f"{k} = ?" for k in fields) + " WHERE id = ?",
                (*fields.values(), project_id),
            )
    return _get_project(project_id)


def delete_project(project_id: str) -> None:
    with _projects_db() as conn:
        conn.execute("DELETE FROM ai_projects WHERE id = ?", (project_id,))


def resolve_project_cwd(project_id: str | None) -> str | None:
    """Turn a client-sent project_id into a trusted cwd — never trust a raw
    path from the client, only ids the admin already registered server-side."""
    project = _get_project(project_id)
    return project["path"] if project and project.get("path") else None


def project_context_block(project: dict) -> str:
    """Text describing a project's working directory + custom instructions,
    inserted into the system prompt ahead of anything the admin asked this turn."""
    if project.get("path"):
        parts = [
            f"You are currently working inside project '{project['name']}' at {project['path']}. "
            "Shell commands, file reads and file edits should target this directory unless the "
            "user clearly asks otherwise."
        ]
    else:
        parts = [f"You are currently assisting within project '{project['name']}' (it has no working directory set)."]
    instr_file = (project.get("instructions_file") or "").strip()
    if instr_file:
        try:
            with open(instr_file, "r", encoding="utf-8", errors="replace") as fh:
                content = fh.read()
            parts.append(f"Project instructions file ({instr_file}):\n{content}")
        except Exception as exc:
            parts.append(f"(Could not read project instructions file {instr_file}: {exc})")
    instr_text = (project.get("instructions") or "").strip()
    if instr_text:
        parts.append(f"Project-specific instructions from the admin:\n{instr_text}")
    return "\n\n".join(parts)


def project_git_status(path: str) -> dict:
    if not path or not os.path.isdir(path):
        return {"is_repo": False}
    path = os.path.realpath(path)
    repo_root = path
    while not os.path.exists(os.path.join(repo_root, ".git")):
        parent = os.path.dirname(repo_root)
        if parent == repo_root:
            return {"is_repo": False}
        repo_root = parent

    def _git(args):
        # Trust only this explicitly selected project, never all repositories.
        return subprocess.run(["git", "-c", "safe.directory=" + repo_root, "-C", path] + args,
                              capture_output=True, text=True, timeout=15,
                              env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"})

    try:
        repo = _git(["rev-parse", "--show-toplevel"])
        if repo.returncode:
            return {"is_repo": False, "error": repo.stderr.strip()}
        branch_r = _git(["symbolic-ref", "--quiet", "--short", "HEAD"])
        if branch_r.returncode:
            branch_r = _git(["rev-parse", "--short", "HEAD"])
        status_r = _git(["status", "--porcelain=v1", "-z", "--untracked-files=all", "--", "."])
        if branch_r.returncode or status_r.returncode:
            return {"is_repo": True, "branch": branch_r.stdout.strip(),
                    "error": (branch_r.stderr + status_r.stderr).strip()}
        result = {"is_repo": True, "branch": branch_r.stdout.strip(),
                  "added": [], "modified": [], "deleted": [], "untracked": []}
        prefix = os.path.relpath(path, repo.stdout.strip())
        entries = iter(status_r.stdout.split("\0"))
        for entry in entries:
            if len(entry) < 4:
                continue
            code, name = entry[:2], entry[3:]
            if "R" in code or "C" in code:
                next(entries, None)  # The following NUL field is the old name.
            if prefix != ".":
                name = os.path.relpath(name, prefix)
            key = "untracked" if code == "??" else "deleted" if "D" in code else "added" if "A" in code else "modified"
            result[key].append(name)
        return result
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"is_repo": False, "error": str(exc)}


def _resolve_provider(cfg: dict):
    """Return (base_url, api_key, model) from saved config."""
    pid = cfg.get("provider", "gemini")
    meta = PROVIDERS.get(pid, PROVIDERS["custom"])
    base_url = cfg.get("base_url") or meta["base_url"]
    if base_url and not base_url.endswith("/"):
        base_url += "/"
    # per-provider key (api_key_gemini, api_key_groq…) takes priority over legacy api_key
    api_key = cfg.get(f"api_key_{pid}") or cfg.get("api_key", "")
    model = cfg.get("model") or meta["default_model"]
    return pid, base_url, api_key, model


# ── Tool definition exposed to the model ────────────────────────────────────────
_TOOLS = [{
    "type": "function",
    "function": {
        "name": "run_command",
        "description": "Execute a shell command on the Linux server and return its stdout, stderr and exit code. Use this whenever you need to inspect, configure or modify the system. Commands run with the privileges of the logged-in mvmOS user.",
        "parameters": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "The shell command to run."},
                "reason": {"type": "string", "description": "A short, human-readable explanation of why you are running this command."},
            },
            "required": ["command"],
        },
    },
}]

_SERVER_TOOL_NAMES = {"run_command", "inspect_server"}
# CLIs that can continue one session of their own from turn to turn.
_RESUMABLE_CLIS = {"claude-cli", "gemini-cli", "codex-cli"}
_CHAT_ID_RE = re.compile(r"[0-9a-f]{32}")
_SESSION_ID_RE = re.compile(r"[0-9a-fA-F-]{8,64}")
# What the CLIs say when the session they are asked to continue does not exist.
_SESSION_LOST_RE = re.compile(
    r"no conversation found|no rollout found|session .{0,60}not found|not found.{0,40}session|"
    r"invalid session identifier|error resuming session|no sessions found", re.I)
# CLI chat folders and the sessions the CLIs keep about them.
_CHATS_DIR = os.path.join(os.path.realpath(os.path.dirname(_DB_PATH)), ".runtime", "chats")


def forget_cli_chat(chat_id: str, user: str | None = None) -> None:
    """Remove what a deleted chat left behind: its working folder and the
    Claude session files kept for that folder."""
    if not _CHAT_ID_RE.fullmatch(str(chat_id or "")):
        return
    folder = os.path.join(_CHATS_DIR, chat_id)
    if user:
        projects = os.path.join(_home_for(user), ".claude", "projects", re.sub(r"[^a-zA-Z0-9]", "-", folder))
        shutil.rmtree(projects, ignore_errors=True)
    shutil.rmtree(folder, ignore_errors=True)

_IMAGE_CLIS = {"claude-cli", "codex-cli"}
# CLIs that carry their own shell/file/web tools and can use them in full access.
_NATIVE_TOOL_CLIS = {"claude-cli", "gemini-cli", "codex-cli"}

_INSPECT_TOOL = {
    "type": "function",
    "function": {
        "name": "inspect_server",
        "description": "Run any shell command needed to inspect the server. Read-only rule: never use it to change server state.",
        "parameters": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "Any command that only reads or inspects server state."},
                "reason": {"type": "string", "description": "A short explanation of what is being inspected."},
            },
            "required": ["command"],
        },
    },
}


def _apps_hub_user(token: str | None):
    hub = sys.modules.get("backend.apphub")
    return hub.get_pub_session(token) if hub and token else None


def _is_apps_hub_admin(token: str | None) -> bool:
    user = _apps_hub_user(token)
    return bool(user and user.get("is_admin"))


def _server_tools(is_admin: bool, exec_enabled: bool) -> list:
    if not is_admin:
        return []
    return list(_TOOLS) if exec_enabled else [_INSPECT_TOOL]


def _access_prompt(is_admin: bool, exec_enabled: bool, project: dict = None) -> str:
    if not is_admin:
        return (
            "You are a general AI assistant. You have no access to this server, its files, "
            "shell, environment, configuration, databases, services, or private data. Never "
            "claim that you inspected or can inspect them. Only use explicitly provided app "
            "API tools, if any; those are scoped to the current user's own data."
        )
    if exec_enabled:
        prompt = (
            "You are mvmAI assisting an Apps Hub administrator. You may inspect the server with "
            "inspect_server and may request shell execution with run_command. Use tools when a "
            "server fact is needed; do not invent server state."
        )
    else:
        prompt = (
            "You are mvmAI assisting a trusted Apps Hub administrator with server access. READ-ONLY "
            "RULE: use inspect_server and commands only to inspect the server. Do not create, edit, "
            "delete, install, restart, stop, or otherwise change anything. Do not invent server state."
        )
    if project:
        prompt += "\n\n" + project_context_block(project)
    return prompt


def _trusted_messages(messages: list, access_prompt: str) -> list:
    """Discard caller-supplied system roles and install the access policy here."""
    out = [{"role": "system", "content": access_prompt}]
    for message in messages:
        role = message.get("role")
        if role == "summary" and message.get("content"):
            out.append({"role": "user", "content": f"[Conversation summary]:\n{message['content']}"})
        elif role in ("user", "assistant", "tool"):
            clean = {key: message[key] for key in ("role", "content", "tool_calls", "tool_call_id", "name") if key in message}
            out.append(clean)
    return out


def _run_readonly_command(command: str, cwd: str | None = None) -> dict:
    cmd = command.strip()
    if not cmd:
        raise ValueError("Empty command")
    try:
        proc = subprocess.run(["/bin/bash", "-lc", cmd], capture_output=True, text=True, timeout=120, cwd=cwd)
        return {"stdout": proc.stdout[-20000:], "stderr": proc.stderr[-20000:], "code": proc.returncode}
    except subprocess.TimeoutExpired:
        return {"stdout": "", "stderr": "Read-only command timed out after 120s", "code": 124}


# ── Endpoints ───────────────────────────────────────────────────────────────────
@router.get("/providers")
async def list_providers(session=Depends(get_current_session)):
    out = [{"id": k, **{x: v[x] for x in ("name", "base_url", "needs_key", "default_model")}} for k, v in PROVIDERS.items()]
    return JSONResponse({"providers": out})


@router.get("/status")
async def status(session=Depends(get_current_session)):
    """Report current config without leaking the key."""
    cfg = _read_cfg()
    pid, base_url, api_key, model = _resolve_provider(cfg)
    return JSONResponse({
        "provider": pid,
        "model": model,
        "base_url": base_url,
        "has_key": bool(api_key) or not PROVIDERS.get(pid, {}).get("needs_key", True),
        "exec_enabled": bool(cfg.get("exec_enabled")),
        "exec_auto": bool(cfg.get("exec_auto")),
    })


@router.get("/access")
async def access(x_pub_token: str = Header(default=None), session=Depends(get_current_session)):
    user = _apps_hub_user(x_pub_token)
    return JSONResponse({"apps_hub_logged_in": bool(user), "is_admin": bool(user and user.get("is_admin"))})


@router.post("/migrate-history")
async def migrate_history(x_pub_token: str = Header(default=None), session=Depends(get_current_session)):
    """Move legacy shared desktop chats into the signed-in admin's Apps Hub history.

    Legacy chats have no owner field, so only an Apps Hub admin may claim them.
    Stable prefixed ids make the migration idempotent on every desktop launch.
    """
    user = _apps_hub_user(x_pub_token)
    if not user:
        return JSONResponse({"error": "apps_hub_login_required"}, status_code=401)
    if not user.get("is_admin"):
        return JSONResponse({"ok": True, "migrated": 0})
    migrated = 0
    with sqlite3.connect(_DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        tables = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {"sessions", "messages", "pub_sessions", "pub_messages"}.issubset(tables):
            return JSONResponse({"ok": True, "migrated": 0})
        for legacy in conn.execute("SELECT id,title,created_at,updated_at FROM sessions ORDER BY created_at"):
            target_id = f"desktop-{legacy['id']}"
            existing = conn.execute("SELECT user_id FROM pub_sessions WHERE id=?", (target_id,)).fetchone()
            if existing:
                continue
            conn.execute(
                "INSERT INTO pub_sessions (id,user_id,title,created_at,updated_at) VALUES (?,?,?,?,?)",
                (target_id, user["id"], legacy["title"] or "New chat", legacy["created_at"] or 0, legacy["updated_at"] or 0),
            )
            rows = conn.execute("SELECT role,content FROM messages WHERE session_id=? ORDER BY id", (legacy["id"],)).fetchall()
            for seq, row in enumerate(rows):
                try:
                    message = json.loads(row["content"])
                except Exception:
                    message = {"role": row["role"], "content": row["content"]}
                conn.execute(
                    "INSERT INTO pub_messages (session_id,role,content,tool_call_id,tool_calls,seq) VALUES (?,?,?,?,?,?)",
                    (
                        target_id,
                        message.get("role") or row["role"],
                        message.get("content"),
                        message.get("tool_call_id"),
                        json.dumps(message.get("tool_calls")) if message.get("tool_calls") else None,
                        seq,
                    ),
                )
            migrated += 1
        conn.commit()
    return JSONResponse({"ok": True, "migrated": migrated})


class ModelsRequest(BaseModel):
    provider: str = ""
    api_key: str = ""
    base_url: str = ""


@router.post("/models")
async def list_models(body: ModelsRequest, session=Depends(get_current_session)):
    """Fetch available models from the configured (or provided) provider."""
    cfg = _read_cfg()
    pid = body.provider or cfg.get("provider", "gemini")
    meta = PROVIDERS.get(pid, PROVIDERS["custom"])
    base_url = body.base_url or cfg.get("base_url") or meta["base_url"]
    if base_url and not base_url.endswith("/"):
        base_url += "/"
    api_key = body.api_key or cfg.get(f"api_key_{pid}") or cfg.get("api_key", "")

    if not base_url:
        return JSONResponse({"error": "No base URL — pick a provider first."}, status_code=400)

    headers = {}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    url = base_url + "models"
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(url, headers=headers)
        if r.status_code >= 400:
            try:
                detail = r.json().get("error", {}).get("message") or r.text[:300]
            except Exception:
                detail = r.text[:300]
            return JSONResponse({"error": f"Provider error ({r.status_code}): {detail}"}, status_code=r.status_code)
        data = r.json()
        # Standard OpenAI format: {"data": [{"id": "model-name", ...}]}
        models = sorted([m["id"] for m in data.get("data", []) if m.get("id")])
        return JSONResponse({"models": models})
    except httpx.ConnectError:
        return JSONResponse({"error": f"Cannot reach {base_url}"}, status_code=502)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=502)


class ChatRequest(BaseModel):
    messages: list
    tools_enabled: bool = True
    project_id: str | None = None


@router.post("/chat")
async def chat(body: ChatRequest, x_pub_token: str = Header(default=None), session=Depends(get_current_session)):
    cfg = _read_cfg()
    pid, base_url, api_key, model = _resolve_provider(cfg)
    if not base_url:
        return JSONResponse({"error": "No provider configured. Open settings and pick a provider."}, status_code=400)
    if PROVIDERS.get(pid, {}).get("needs_key", True) and not api_key:
        return JSONResponse({"error": "No API key set. Open settings and enter your API key."}, status_code=400)

    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    url = base_url + "chat/completions"

    exec_enabled = bool(cfg.get("exec_enabled"))
    is_admin = _is_apps_hub_admin(x_pub_token)
    project = _get_project(body.project_id) if is_admin else None
    tools = _server_tools(is_admin, exec_enabled) if body.tools_enabled else []
    messages = _trusted_messages(body.messages, _access_prompt(is_admin, exec_enabled, project))

    async def _post(with_tools: bool):
        p = {"model": model, "messages": messages}
        if with_tools:
            p["tools"] = tools
            p["tool_choice"] = "auto"
        async with httpx.AsyncClient(timeout=120) as client:
            return await client.post(url, headers=headers, json=p)

    try:
        r = await _post(bool(tools))
        # some models/providers don't support tool use — retry without tools
        if r.status_code == 404 and tools and "tool" in r.text.lower():
            r = await _post(False)
    except httpx.ConnectError:
        return JSONResponse({"error": f"Cannot reach provider at {base_url}"}, status_code=502)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=502)

    if r.status_code >= 400:
        detail = r.text
        try:
            j = r.json()
            detail = j.get("error", {}).get("message") or j.get("error") or detail
        except Exception:
            pass
        return JSONResponse({"error": f"Provider error ({r.status_code}): {detail}"}, status_code=r.status_code)

    try:
        data = r.json()
        msg = data["choices"][0]["message"]
    except Exception:
        return JSONResponse({"error": "Unexpected provider response"}, status_code=502)
    return JSONResponse({"message": msg})


class ExecRequest(BaseModel):
    command: str
    confirmed: bool = False
    project_id: str | None = None


@router.post("/exec")
async def exec_command(body: ExecRequest, x_pub_token: str = Header(default=None), session=Depends(get_current_session)):
    if not _is_apps_hub_admin(x_pub_token):
        return JSONResponse({"error": "forbidden"}, status_code=403)
    cfg = _read_cfg()
    exec_enabled = bool(cfg.get("exec_enabled"))
    exec_auto = bool(cfg.get("exec_auto"))
    cmd = body.command.strip()
    if not cmd:
        return JSONResponse({"error": "Empty command"}, status_code=400)

    if not exec_enabled:
        return JSONResponse({
            "blocked": True,
            "is_dangerous": False,
            "reason": "Command execution is turned off. Turn it on from the exec toggle in the chat sidebar.",
        })

    danger = _is_dangerous(cmd)
    needs_confirm = not exec_auto
    if needs_confirm and not body.confirmed:
        return JSONResponse({"pending": True, "is_dangerous": danger})

    # Run with the privileges of the logged-in mvmOS user, exactly like the core
    # terminal (backend/terminal.py): uvicorn is root so it can drop down to the
    # session's effective_user via runuser. Never run app commands as root unless
    # the user actually logged in as root.
    eu = (session or {}).get("effective_user", "root")
    needs_sudo = os.geteuid() != 0

    project_cwd = resolve_project_cwd(body.project_id)
    # `runuser -l`/`sudo runuser -l` simulate a fresh login and land in the
    # target user's home regardless of subprocess's own cwd — a plain cwd=
    # override is silently ignored for those two branches, so the only
    # reliable way to scope the command to a project is to cd inside it.
    run_cmd = f"cd {shlex.quote(project_cwd)} && {cmd}" if project_cwd else cmd

    if needs_sudo:
        wrapped = ["sudo", "runuser", "-l", eu, "-c", run_cmd]
    elif eu and eu != "root":
        wrapped = ["runuser", "-l", eu, "-c", run_cmd]
    else:
        wrapped = ["/bin/bash", "-lc", run_cmd]
    try:
        home = pwd.getpwnam(eu).pw_dir
    except KeyError:
        home = "/root"

    try:
        proc = await asyncio.to_thread(
            subprocess.run,
            wrapped, capture_output=True, text=True, timeout=120,
            cwd=project_cwd or home, env={**os.environ, "HOME": home, "USER": eu, "LOGNAME": eu},
        )
        return JSONResponse({
            "stdout": proc.stdout[-20000:],
            "stderr": proc.stderr[-20000:],
            "code": proc.returncode,
            "is_dangerous": danger,
        })
    except subprocess.TimeoutExpired:
        return JSONResponse({"stdout": "", "stderr": "Command timed out after 120s", "code": 124, "is_dangerous": danger})
    except Exception as e:
        return JSONResponse({"stdout": "", "stderr": str(e), "code": 1, "is_dangerous": danger})


class InspectRequest(BaseModel):
    command: str
    reason: str = ""
    project_id: str | None = None


@router.post("/inspect")
async def inspect_server(body: InspectRequest, x_pub_token: str = Header(default=None), session=Depends(get_current_session)):
    if not _is_apps_hub_admin(x_pub_token):
        return JSONResponse({"error": "forbidden"}, status_code=403)
    try:
        result = await asyncio.to_thread(_run_readonly_command, body.command, resolve_project_cwd(body.project_id))
        return JSONResponse({"result": result})
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)


# ── Projects (admin-only) ────────────────────────────────────────────────────

class ProjectCreateBody(BaseModel):
    name: str
    path: str = ""
    instructions: str = ""
    instructions_file: str = ""


class ProjectUpdateBody(BaseModel):
    name: str | None = None
    path: str | None = None
    instructions: str | None = None
    instructions_file: str | None = None


@router.get("/projects")
async def projects_list(x_pub_token: str = Header(default=None), session=Depends(get_current_session)):
    if not _is_apps_hub_admin(x_pub_token):
        return JSONResponse({"error": "forbidden"}, status_code=403)
    return JSONResponse({"projects": list_projects()})


@router.post("/projects")
async def projects_create(body: ProjectCreateBody, x_pub_token: str = Header(default=None), session=Depends(get_current_session)):
    if not _is_apps_hub_admin(x_pub_token):
        return JSONResponse({"error": "forbidden"}, status_code=403)
    try:
        project = create_project(body.name, body.path, body.instructions, body.instructions_file)
    except ValueError as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)
    return JSONResponse({"project": project})


@router.patch("/projects/{project_id}")
async def projects_update(project_id: str, body: ProjectUpdateBody, x_pub_token: str = Header(default=None), session=Depends(get_current_session)):
    if not _is_apps_hub_admin(x_pub_token):
        return JSONResponse({"error": "forbidden"}, status_code=403)
    try:
        project = update_project(project_id, body.name, body.path, body.instructions, body.instructions_file)
    except ValueError as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)
    return JSONResponse({"project": project})


@router.delete("/projects/{project_id}")
async def projects_delete(project_id: str, x_pub_token: str = Header(default=None), session=Depends(get_current_session)):
    if not _is_apps_hub_admin(x_pub_token):
        return JSONResponse({"error": "forbidden"}, status_code=403)
    delete_project(project_id)
    return JSONResponse({"ok": True})


@router.get("/projects/{project_id}/git-status")
async def projects_git_status(project_id: str, x_pub_token: str = Header(default=None), session=Depends(get_current_session)):
    if not _is_apps_hub_admin(x_pub_token):
        return JSONResponse({"error": "forbidden"}, status_code=403)
    project = _get_project(project_id)
    if not project:
        return JSONResponse({"error": "Project not found"}, status_code=404)
    return JSONResponse(await asyncio.to_thread(project_git_status, project["path"]))


@router.get("/browse")
async def browse_dirs(path: str = "/", x_pub_token: str = Header(default=None), session=Depends(get_current_session)):
    if not _is_apps_hub_admin(x_pub_token):
        return JSONResponse({"error": "forbidden"}, status_code=403)
    target = os.path.realpath(path or "/")
    if not os.path.isdir(target):
        return JSONResponse({"error": "Not a directory"}, status_code=400)
    try:
        dirs, files = [], []
        for name in sorted(os.listdir(target)):
            if name.startswith("."):
                continue
            full = os.path.join(target, name)
            if os.path.isdir(full):
                dirs.append(name)
            elif os.path.isfile(full):
                files.append(name)
    except PermissionError:
        return JSONResponse({"error": "Permission denied"}, status_code=403)
    parent = os.path.dirname(target.rstrip("/")) or "/"
    return JSONResponse({"path": target, "parent": parent if target != "/" else None, "dirs": dirs, "files": files})


# ── CLI providers ────────────────────────────────────────────────────────────────
CLI_PROVIDERS = [
    # Claude CLI has no command that lists models, but it takes these aliases,
    # which always point at the newest model of each family.
    {"id": "claude-cli",  "name": "Claude CLI",  "cmd": "claude",  "args": ["--print"], "supports_model": True,  "model_choices": ["fable", "opus", "sonnet", "haiku"]},
    {"id": "gemini-cli",  "name": "Gemini CLI",  "cmd": "gemini",  "args": ["--prompt"], "supports_model": True,  "model_choices": []},
    {"id": "ollama-cli",  "name": "Ollama CLI",  "cmd": "ollama",  "args": ["run"],      "supports_model": True,  "model_choices": [], "model_discovery": "ollama"},
    {"id": "sgpt-cli",    "name": "shell-gpt",   "cmd": "sgpt",    "args": [],           "supports_model": False, "model_hint": "", "model_choices": []},
    {"id": "aichat-cli",  "name": "aichat",      "cmd": "aichat",  "args": [],           "supports_model": False, "model_hint": "", "model_choices": []},
    {"id": "llm-cli",     "name": "llm",         "cmd": "llm",     "args": [],           "supports_model": False, "model_hint": "", "model_choices": []},
    {"id": "gpt4all-cli", "name": "GPT4All CLI", "cmd": "gpt4all", "args": [],           "supports_model": False, "model_hint": "", "model_choices": []},
    {"id": "codex-cli",   "name": "Codex CLI",   "cmd": "codex",   "args": [],           "supports_model": True,  "model_choices": [], "model_discovery": "codex"},
    {"id": "mods-cli",    "name": "mods",        "cmd": "mods",    "args": [],           "supports_model": False, "model_hint": "", "model_choices": []},
    {"id": "tgpt-cli",    "name": "tgpt",        "cmd": "tgpt",    "args": [],           "supports_model": False, "model_hint": "", "model_choices": []},
]


# CLI providers only understand plain text, so the centrally authorized tool
# list is described in the prompt and a fenced reply block is translated back
# into the same tool-call shape used by HTTP providers.
_CLI_TOOL_CALL_RE = re.compile(r"```mvmai_tool_call\s*\n(.*?)```", re.DOTALL)


def _cli_tool_instructions(tools: list) -> str:
    lines = ["You can call the following tools:"]
    for spec in tools:
        fn = spec["function"]
        props = (fn.get("parameters") or {}).get("properties") or {}
        args_desc = ", ".join(f"{k} ({v.get('type', 'string')})" for k, v in props.items())
        lines.append(f"- {fn['name']}: {fn['description']} Arguments: {args_desc}.")
    lines.append(
        "To call it, output ONLY a fenced code block labeled mvmai_tool_call containing a JSON "
        "object with \"name\" and \"arguments\" keys, e.g.:\n"
        "```mvmai_tool_call\n{\"name\": \"tool_name\", \"arguments\": {}}\n```\n"
        "When the request needs several calls that do not depend on each other's results, such as "
        "adding several entries, put one such block per call in the same reply, so the user reviews "
        "and saves them together instead of one reply at a time. "
        "Only include those blocks when you actually want to call a tool. Otherwise just answer normally in plain text."
    )
    return "\n".join(lines)


def _resolve_os_user(explicit: str | None) -> str:
    """Return the OS username whose home/PATH/credentials CLI providers
    should run with. The backend service runs as root, but the authenticated
    mvmOS session can explicitly belong to root or to a non-root OS user. Its
    user must always win so CLI discovery, credentials and execution all use
    the same account that logged into the desktop.

    Prefers an explicit OS session (the caller's own mvmOS desktop login,
    passed in as `session["effective_user"]`); falls back to the machine's
    primary human login only when no OS session is available, since
    installations are typically single-user.
    """
    if explicit:
        return explicit
    try:
        candidates = sorted(
            (u for u in pwd.getpwall() if u.pw_uid >= 1000 and u.pw_shell not in ("/usr/sbin/nologin", "/bin/false", "")),
            key=lambda u: u.pw_uid,
        )
        if candidates:
            return candidates[0].pw_name
    except Exception:
        pass
    return "root"


def _home_for(eu: str) -> str:
    try:
        return pwd.getpwnam(eu).pw_dir
    except KeyError:
        return "/root"


# The chat turn a CLI process belongs to, so the user's Stop can kill it:
# a dict {"procs": [...], "stopped": bool} set by the caller of the turn.
CHAT_TURN = contextvars.ContextVar("mvmai_chat_turn", default=None)


def kill_process(proc) -> None:
    """Kill a CLI process together with everything it started."""
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError, OSError):
        pass


def _run_turn_process(cmd, input=None, timeout=None, output_callback=None, **kw):
    """subprocess.run for a chat turn's CLI, in its own process group and
    registered with the turn, so Stop ends it instead of letting it finish."""
    kw.pop("capture_output", None)
    turn = CHAT_TURN.get()
    with subprocess.Popen(cmd, stdin=subprocess.PIPE if input is not None else subprocess.DEVNULL,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True, **kw) as proc:
        if turn is not None:
            turn["procs"].append(proc)
            if turn.get("stopped"):
                kill_process(proc)
        if output_callback is None and turn is None:
            try:
                out, err = proc.communicate(input, timeout=timeout)
            except subprocess.TimeoutExpired:
                kill_process(proc)
                proc.communicate()
                raise
        else:
            # Drain both pipes concurrently, retaining the complete output for
            # the existing reply parser while an optional observer sees lines.
            chunks = {"stdout": [], "stderr": []}
            def read_pipe(stream, name):
                for line in iter(stream.readline, "" if kw.get("text") else b""):
                    chunks[name].append(line)
                    if turn is not None and name == "stdout":
                        turn["activity_seq"] = turn.get("activity_seq", 0) + 1
                        turn["last_activity"] = time.monotonic()
                    if output_callback is None:
                        continue
                    try:
                        output_callback({"type": "output", "stream": name, "text": line})
                    except Exception:
                        logging.getLogger(__name__).exception("mvmAI output observer failed")
            readers = [threading.Thread(target=read_pipe, args=(getattr(proc, name), name), daemon=True)
                       for name in ("stdout", "stderr")]
            for reader in readers:
                reader.start()
            try:
                if input is not None:
                    try:
                        proc.stdin.write(input)
                        proc.stdin.close()
                    except BrokenPipeError:
                        pass
                proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                kill_process(proc)
                proc.wait()
                raise
            finally:
                for reader in readers:
                    reader.join()
            empty = "" if kw.get("text") else b""
            out, err = (empty.join(chunks[name]) for name in ("stdout", "stderr"))
        return subprocess.CompletedProcess(cmd, proc.returncode, out, err)


def _wrap_as_user(argv: list[str], eu: str) -> list[str]:
    """Prefix argv to run as OS user `eu`, dropping root the same way /exec
    does — `runuser` needs root itself, hence the `sudo` branch when this
    process isn't already root. Uses direct argv (no `-l`, no shell `-c`)
    so an arbitrary chat prompt in argv never passes through a shell."""
    if not eu or eu == "root":
        return argv
    if os.geteuid() == 0:
        return ["runuser", "-u", eu, "--"] + argv
    return ["sudo", "runuser", "-u", eu, "--"] + argv


def _cli_search_path(home: str) -> str:
    """Return PATH plus common per-user CLI install locations.

    Services do not load interactive shell startup files, so tools installed by
    Codex, npm, nvm, pnpm, Bun, Volta, asdf, or mise may be available in a
    terminal but absent from the service's PATH.
    """
    env_paths = [
        os.environ.get("NVM_BIN"),
        os.environ.get("PNPM_HOME"),
        os.path.join(os.environ["BUN_INSTALL"], "bin") if os.environ.get("BUN_INSTALL") else None,
        os.path.join(os.environ["VOLTA_HOME"], "bin") if os.environ.get("VOLTA_HOME") else None,
        os.path.join(os.environ["NPM_CONFIG_PREFIX"], "bin") if os.environ.get("NPM_CONFIG_PREFIX") else None,
    ]
    user_paths = [
        os.path.join(home, ".local", "bin"),
        os.path.join(home, "bin"),
        os.path.join(home, ".npm-global", "bin"),
        os.path.join(home, ".local", "share", "pnpm"),
        os.path.join(home, ".bun", "bin"),
        os.path.join(home, ".volta", "bin"),
        os.path.join(home, ".asdf", "shims"),
        os.path.join(home, ".local", "share", "mise", "shims"),
    ]
    nvm_paths = sorted(glob(os.path.join(home, ".nvm", "versions", "node", "*", "bin")), reverse=True)
    system_paths = os.environ.get("PATH", "").split(os.pathsep)

    # Keep the first occurrence so an explicitly configured PATH still wins.
    return os.pathsep.join(dict.fromkeys(p for p in system_paths + env_paths + user_paths + nvm_paths if p))


def _which(cmd: str, home: str) -> str | None:
    try:
        return shutil.which(cmd, path=_cli_search_path(home))
    except Exception:
        return None


def _linux_accounts() -> list[str]:
    """Real OS accounts a CLI chat may run as: root plus the login users."""
    names = ["root"]
    try:
        names.extend(
            u.pw_name for u in sorted(pwd.getpwall(), key=lambda item: item.pw_uid)
            if 1000 <= u.pw_uid < 60000 and not u.pw_shell.endswith(("nologin", "false")) and u.pw_shell
        )
    except Exception:
        pass
    return list(dict.fromkeys(names))


def _cli_user_candidates(explicit: str | None = None, configured: str | None = None) -> list[str]:
    """Return real OS accounts that may own a shared CLI login."""
    names = [configured, "root", explicit] + _linux_accounts()
    return list(dict.fromkeys(name for name in names if name))


def _cli_is_logged_in(provider: dict, cmd_bin: str, eu: str, home: str) -> bool | None:
    """Check login state without reading or copying credential files."""
    auth_args = {
        "claude-cli": ["auth", "status"],
        "codex-cli": ["login", "status"],
    }.get(provider["id"])
    if auth_args is None:
        return None
    try:
        proc = subprocess.run(
            _wrap_as_user([cmd_bin] + auth_args, eu), capture_output=True, text=True, timeout=10,
            env={**os.environ, "HOME": home, "USER": eu, "LOGNAME": eu, "PATH": _cli_search_path(home)},
        )
        return proc.returncode == 0
    except Exception:
        return False


def _resolve_cli_runtime(provider: dict, explicit: str | None = None, persist: bool = False):
    """Resolve the CLI executable and the OS account it runs as.

    The account chosen for this CLI in the mvmAI settings (`cli_user_<id>`)
    wins, so desktop and public-page chats always run as the same account no
    matter who is logged in where. Without a choice, the mvmOS session's
    account (`explicit`) is used, and when there is no session either (a pure
    Apps Hub visitor) the chat runs as root. Nothing is detected or stored
    automatically.
    """
    configured = _read_cfg().get(f"cli_user_{provider['id']}")
    if not (isinstance(configured, str) and configured in _linux_accounts()):
        configured = None
    eu = configured or explicit or "root"
    users = _cli_user_candidates(eu)
    own_bins = {u: _which(provider["cmd"], _home_for(u)) for u in users}
    any_bin = next((cmd for cmd in own_bins.values() if cmd), None)
    if not any_bin:
        return None
    return (eu, _home_for(eu), own_bins.get(eu) or any_bin)


def _read_cli_usage(provider: str, user: str, home: str, cmd_bin: str,
                    force: bool = False, model: str = ""):
    """Read the selected Linux account's limits outside public-app isolation."""
    from backend.app_isolation import release
    with release():
        from backend.apps.mvmai.usage import read_usage
        return read_usage(sys.modules[__name__], provider, user, home, cmd_bin, force, model)


def _discover_cli_models(provider: dict, cmd_bin: str, eu: str, home: str) -> list[str]:
    discovery = provider.get("model_discovery")
    env = {**os.environ, "HOME": home, "USER": eu, "LOGNAME": eu, "PATH": _cli_search_path(home)}
    try:
        if discovery == "codex":
            proc = subprocess.run(
                _wrap_as_user([cmd_bin, "debug", "models"], eu),
                capture_output=True, text=True, timeout=15, env=env,
            )
            if proc.returncode != 0:
                return []
            data = json.loads(proc.stdout)
            return list(dict.fromkeys(
                model["slug"] for model in data.get("models", [])
                if model.get("slug") and model.get("visibility") != "hide"
            ))
        if discovery == "ollama":
            proc = subprocess.run(
                _wrap_as_user([cmd_bin, "list"], eu),
                capture_output=True, text=True, timeout=10, env=env,
            )
            if proc.returncode != 0:
                return []
            lines = [line.split() for line in proc.stdout.splitlines() if line.strip()]
            return list(dict.fromkeys(parts[0] for parts in lines if parts and parts[0].upper() != "NAME"))
    except Exception:
        pass
    return [] if discovery else list(provider.get("model_choices") or [])


def _detected_cli_providers(eu: str):
    detected = []
    for provider in CLI_PROVIDERS:
        runtime = _resolve_cli_runtime(provider, eu)
        if not runtime:
            continue
        cli_user, home, cmd_bin = runtime
        item = dict(provider)
        item["model_choices"] = _discover_cli_models(provider, cmd_bin, cli_user, home)
        item["models_dynamic"] = bool(provider.get("model_discovery"))
        item.pop("model_discovery", None)
        detected.append(item)
    return detected


# CLIs with no auth-status command keep their login in a folder of the
# account's home; only its presence is checked, never its contents.
_CLI_HOME_MARKER = {"gemini-cli": ".gemini"}


def _cli_usable_accounts() -> dict:
    """For each CLI provider, the OS accounts it can really run as: the CLI
    is installed for the account and, where the CLI can tell, logged in."""
    from concurrent.futures import ThreadPoolExecutor
    accounts = _linux_accounts()
    jobs = []
    for provider in CLI_PROVIDERS:
        for eu in accounts:
            home = _home_for(eu)
            cmd_bin = _which(provider["cmd"], home)
            if cmd_bin:
                jobs.append((provider, eu, home, cmd_bin))
    with ThreadPoolExecutor(max_workers=8) as pool:
        states = list(pool.map(lambda j: _cli_is_logged_in(j[0], j[3], j[1], j[2]), jobs))
    out = {provider["id"]: [] for provider in CLI_PROVIDERS}
    for (provider, eu, home, _bin), state in zip(jobs, states):
        if state is None and provider["id"] in _CLI_HOME_MARKER:
            state = os.path.isdir(os.path.join(home, _CLI_HOME_MARKER[provider["id"]]))
        if state is not False:
            out[provider["id"]].append(eu)
    return out


@router.get("/cli-users")
async def cli_users(session=Depends(get_current_session)):
    return JSONResponse({"users": _linux_accounts(), "by_cli": await asyncio.to_thread(_cli_usable_accounts)})


@router.get("/cli-providers")
async def cli_providers(session=Depends(get_current_session)):
    eu = _resolve_os_user(session.get("effective_user"))
    return JSONResponse({"cli_providers": await asyncio.to_thread(_detected_cli_providers, eu)})


class CliChatRequest(BaseModel):
    provider_id: str
    messages: list
    # None = read the saved model from cfg (desktop chat, unchanged
    # behavior); an explicit value (including "") lets a caller like the
    # public-page chat pass an already-resolved model without it being
    # silently overwritten by the desktop's own saved model for a
    # different provider.
    model: str | None = None
    # Retained for compatibility with older frontends; access is resolved
    # exclusively from the Apps Hub token and this value is never trusted.
    offer_run_command: bool = False


async def _run_cli_chat(
    body: CliChatRequest,
    tools: list,
    is_admin: bool,
    exec_enabled: bool,
    exec_auto: bool = False,
    identity_prompt: str = "",
    project: dict = None,
    session: dict | None = None,
    extra_prompt: str = "",
    images: list | None = None,
    cli_resume: dict | None = None,
    output_callback=None,
):
    images = images or []
    provider = next((p for p in CLI_PROVIDERS if p["id"] == body.provider_id), None)
    if not provider:
        return JSONResponse({"error": f"Unknown CLI provider: {body.provider_id}"}, status_code=400)
    runtime = await asyncio.to_thread(_resolve_cli_runtime, provider, (session or {}).get("effective_user"), persist=True)
    if not runtime:
        return JSONResponse({"error": f"'{provider['cmd']}' not found in PATH"}, status_code=400)
    eu, home, cmd_bin = runtime

    # A chat that gives a cli_resume keeps one CLI session of its own and
    # continues it every turn, so only the new messages travel instead of the
    # whole conversation, and the CLI keeps what it read and did itself.
    # {"chat_id": hex id of the chat, "session_id": the CLI's session or None
    # for the first turn, "user": OS account it belongs to, "policy": hash of
    # the instructions the CLI last got}.
    persist = bool(cli_resume) and body.provider_id in _RESUMABLE_CLIS and bool(_CHAT_ID_RE.fullmatch(str(cli_resume.get("chat_id") or "")))
    resume_id = str(cli_resume.get("session_id") or "") if persist else ""
    if resume_id and (cli_resume.get("user") != eu or not _SESSION_ID_RE.fullmatch(resume_id)):
        return JSONResponse({"error": "The CLI session belongs to another account.", "session_lost": True}, status_code=409)

    # Build trusted system instructions separately from conversation history.
    # The AI CLI is an installation-wide provider and can run under a
    # different OS account than the current mvmOS user. Never let its native
    # tools inherit that account's server privileges; all server operations go
    # through mvmAI's policy-gated transport endpoints instead.
    # The one exception is an administrator who chose automatic execution:
    # that already runs every command unasked, so a CLI with tools of its own
    # gets all of them, unsandboxed, instead of the one-command text protocol.
    full_access = is_admin and exec_enabled and exec_auto and body.provider_id in _NATIVE_TOOL_CLIS
    prompt_tools = [t for t in tools if t["function"]["name"] not in _SERVER_TOOL_NAMES] if full_access else list(tools)
    access_prompt = _access_prompt(is_admin, exec_enabled)
    if identity_prompt:
        access_prompt += " " + identity_prompt
    if full_access:
        access_prompt = (
            "You are mvmAI assisting the server's administrator, who gave you full, unrestricted "
            f"access to this computer as the Linux user {eu}. Use your own built-in tools directly "
            "and as often as needed: run shell commands, read, create and edit files, search, and "
            "fetch web pages. Do not ask for permission and do not hand commands to the user to run; "
            "do the work yourself, inspect before changing, avoid unrelated changes, and finish the "
            "task within this turn, then report what you did."
        )
    elif is_admin:
        access_prompt = "You are mvmAI assisting a trusted Apps Hub administrator. "
        if exec_enabled and exec_auto:
            access_prompt += (
                "AUTO MODE: native server tools are disabled. Request each server operation with the "
                "supplied run_command transport block; mvmAI executes it automatically. Inspect before "
                "modifying and avoid unrelated changes. Your own CLI's built-in sandbox/shell tool "
                "reports read-only or unavailable by design — that is expected and does not mean you "
                "lack execution capability. The run_command transport block is your real and only "
                "execution channel here, works every turn including after a conversation summary, "
                "and stays available for the rest of this session. Never tell the user you lack access "
                "or suggest restarting or starting a new chat; just keep using run_command."
            )
        elif exec_enabled:
            access_prompt += (
                "CONFIRMATION MODE: native server tools are disabled. For every server operation, "
                "including inspection, return the supplied run_command transport block and wait "
                "for its result. The block is a response protocol, not a native tool. Never merely "
                "suggest a command for the user to run. Your own CLI's built-in sandbox/shell tool "
                "reports read-only or unavailable by design — that is expected and does not mean you "
                "lack execution capability. The run_command transport block is your real and only "
                "execution channel here, works every turn including after a conversation summary, "
                "and stays available for the rest of this session. Never tell the user you lack access "
                "or suggest restarting or starting a new chat; just keep using run_command."
            )
        else:
            access_prompt += (
                "READ-ONLY RULE: native server tools are disabled. Use the supplied inspect_server "
                "transport block for inspection. Do not create, edit, delete, install, restart, stop, "
                "or otherwise change anything."
            )
    system_parts = [access_prompt]
    if prompt_tools:
        system_parts.append(_cli_tool_instructions(prompt_tools))
    conversation_parts = []
    for m in body.messages:
        role = m.get("role", "")
        content = m.get("content") or ""
        if not isinstance(content, str):
            continue
        if role == "user":
            conversation_parts.append(f"[User]: {content}")
        elif role == "assistant":
            conversation_parts.append(f"[Assistant]: {content}")
        elif role == "tool":
            conversation_parts.append(f"[Tool result]: {content}")
    if identity_prompt:
        system_parts.append(
            "Current public branding rule: "
            f"{identity_prompt} This is the product identity required for the user-facing response."
        )
    if is_admin and not full_access:
        if exec_enabled and exec_auto:
            current_mode = "AUTO"
        elif exec_enabled:
            current_mode = "CONFIRMATION"
        else:
            current_mode = "READ-ONLY"
        system_parts.append(
            f"Current mvmAI mode: {current_mode}. "
            "Do not describe the CLI's internal sandbox or approval setting as the mvmAI mode. "
            "In CONFIRMATION mode, request each server operation with the mvmai_tool_call response "
            "protocol; mvmAI itself shows the command to the user and collects confirmation."
        )
    project_prompt = project_context_block(project) if project else ""
    if project_prompt:
        system_parts.append(project_prompt)
    if extra_prompt:
        system_parts.append(extra_prompt)
    if is_admin and not full_access and body.provider_id == "claude-cli":
        system_parts.append(
            "You also have a Read tool, which only reads. Use it to open files, images and PDFs the "
            "user attached, including those inside an unpacked archive. It never changes anything."
        )
    if is_admin:
        system_parts.append(
            "To give the user a file to download, put an existing file's absolute path alone on a line "
            "as [[file:/absolute/path]] in your reply. The chat turns it into a download button. "
            "Create or find the file first; the path must be a real file."
        )
    else:
        system_parts.append(
            "To give the user a text file to download (CSV, JSON, Markdown or plain text), write its "
            "content in a fenced code block whose info string is file:<name.ext>, for example "
            "```file:results.csv. The chat turns it into a download button. You cannot create other files."
        )
    if images and body.provider_id not in _IMAGE_CLIS:
        system_parts.append(
            f"The user attached {len(images)} image(s) that this assistant cannot see. Say so plainly "
            "and ask them to describe the content or use a provider that accepts images."
        )
        images = []
    system_prompt = "\n\n".join(system_parts)
    conversation_prompt = "\n".join(conversation_parts) or "[User]: Continue."
    prompt = f"[System instructions]\n{system_prompt}\n\n[Conversation]\n{conversation_prompt}"
    policy = hashlib.sha256(system_prompt.encode("utf-8")).hexdigest()[:16]
    if resume_id and body.provider_id != "claude-cli":
        # Claude is given the instructions again by its own flag every turn;
        # the others only have them inside the first message, so they are
        # repeated here only when something in them changed (mode, language).
        prompt = ((f"[Project instructions]\n{project_prompt}\n\n" if project_prompt else "") + conversation_prompt) if cli_resume.get("policy") == policy else (
            f"[System instructions, updated]\n{system_prompt}\n\n[New messages]\n{conversation_prompt}")

    pid = body.provider_id
    stream_output = output_callback is not None or CHAT_TURN.get() is not None
    model = body.model if body.model is not None else _read_cfg().get("model")
    # A full-access turn is a whole task done in one go, not a single reply.
    cli_timeout = 1800 if full_access else 120
    try:
        # App isolation only permits an app backend to write inside its own
        # directory. Keep the short-lived CLI workspace there instead of the
        # system /tmp directory; TemporaryDirectory still removes it after
        # every request.
        runtime_dir = os.path.dirname(_CHATS_DIR)
        os.makedirs(runtime_dir, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="mvmai-chat-", dir=runtime_dir) as workdir:
            # A project's own folder is the real working directory when one is
            # set — the throwaway workdir above still holds the sandbox policy
            # file, but the CLI itself should read/edit the admin's real files.
            chat_dir = None
            if persist:
                # The CLI keeps its session per working folder, so a chat
                # that continues one needs a folder that stays.
                chat_dir = os.path.join(runtime_dir, "chats", cli_resume["chat_id"])
                os.makedirs(chat_dir, exist_ok=True)
                if eu != "root":
                    try:
                        pw = pwd.getpwnam(eu)
                        os.chown(chat_dir, pw.pw_uid, pw.pw_gid)
                    except Exception:
                        pass
            effective_dir = project["path"] if project and project.get("path") else (home if full_access and os.path.isdir(home) else (chat_dir or workdir))
            new_session = str(uuid.uuid4()) if persist and not resume_id and pid != "codex-cli" else ""
            extra_env = {}
            policy_path = os.path.join(workdir, "deny-tools.toml")
            with open(policy_path, "w", encoding="utf-8") as handle:
                handle.write('[[rule]]\ntoolName = "*"\ndecision = "deny"\npriority = 999\n')
            if eu != "root":
                # The CLI process below runs as `eu`, not root — hand it
                # ownership of the throwaway workdir so it can actually read
                # deny-tools.toml (and write into its own cwd) there.
                try:
                    pw = pwd.getpwnam(eu)
                    os.chown(workdir, pw.pw_uid, pw.pw_gid)
                    os.chown(policy_path, pw.pw_uid, pw.pw_gid)
                except Exception:
                    pass
            stdin_input = None
            if pid == "claude-cli":
                # A long conversation can push system_prompt/conversation_prompt
                # well past the kernel's ~128KB single-argv-string limit
                # (MAX_ARG_STRLEN), making execve() fail with E2BIG before the
                # CLI even starts. Route both through a file and stdin instead,
                # which have no such size cap.
                system_prompt_path = os.path.join(workdir, "system-prompt.txt")
                with open(system_prompt_path, "w", encoding="utf-8") as handle:
                    handle.write(system_prompt)
                if eu != "root":
                    try:
                        os.chown(system_prompt_path, pwd.getpwnam(eu).pw_uid, pwd.getpwnam(eu).pw_gid)
                    except Exception:
                        pass
                if full_access:
                    # Keep Claude's own system prompt, which teaches it its
                    # tools, and add mvmAI's on top. As root the CLI refuses
                    # to skip permissions unless told it is sandboxed.
                    safety_args = ["--dangerously-skip-permissions", "--append-system-prompt-file", system_prompt_path]
                    if eu == "root":
                        extra_env["IS_SANDBOX"] = "1"
                else:
                    # An administrator can always have attached files and images
                    # opened, whatever the mode: Read only reads.
                    safety_args = ["--safe-mode", "--tools", "Read" if is_admin else "", "--system-prompt-file", system_prompt_path]
                session_args = ["--no-session-persistence"]
                if persist:
                    session_args = ["--resume", resume_id] if resume_id else ["--session-id", new_session]
                cmd = [cmd_bin] + (["--model", model] if model else []) + safety_args + ["--disable-slash-commands"] + session_args + ["--print"]
                if (persist or stream_output) and not images:
                    cmd += ["--output-format", "stream-json", "--verbose", "--include-partial-messages"] if stream_output else ["--output-format", "json"]
                stdin_input = conversation_prompt
                if images:
                    # Images travel in the message itself (stream-json input),
                    # so no file tool is needed to see them.
                    blocks = []
                    for url in images:
                        head, _, data = url.partition(",")
                        blocks.append({"type": "image", "source": {"type": "base64", "media_type": head[5:].split(";")[0], "data": data}})
                    blocks.append({"type": "text", "text": conversation_prompt})
                    cmd += ["--input-format", "stream-json", "--output-format", "stream-json", "--verbose"]
                    if stream_output:
                        cmd += ["--include-partial-messages"]
                    stdin_input = json.dumps({"type": "user", "message": {"role": "user", "content": blocks}}) + "\n"
            elif pid == "gemini-cli":
                safety_args = ["--yolo"] if full_access else ["--admin-policy", policy_path]
                session_args = []
                if persist:
                    session_args = ["--resume", resume_id] if resume_id else ["--session-id", new_session]
                cmd = [cmd_bin] + (["--model", model] if model else []) + safety_args + session_args + ["--prompt", prompt]
            elif pid == "ollama-cli":
                cmd = [cmd_bin, "run", model or "llama3.1", prompt]
            elif pid == "codex-cli":
                # Same E2BIG risk as claude-cli above — `codex exec` reads its
                # prompt from stdin when no positional argument is given, so
                # route it there instead of argv.
                if full_access:
                    safety_args = ["--dangerously-bypass-approvals-and-sandbox", "-c", 'web_search="live"']
                elif resume_id:
                    # `codex exec resume` has no --sandbox flag; the same
                    # setting is given as a config override instead.
                    safety_args = ["-c", 'sandbox_mode="read-only"', "-c", 'web_search="disabled"', "-c", "features.shell_tool=false"]
                else:
                    safety_args = ["--sandbox", "read-only", "-c", 'web_search="disabled"', "-c", "features.shell_tool=false"]
                if resume_id:
                    cmd = [cmd_bin, "exec", "resume", "--skip-git-repo-check", "--json"] + safety_args + (["--model", model] if model else [])
                else:
                    cmd = [cmd_bin, "exec", "--skip-git-repo-check", "-C", effective_dir] + (["--json"] if persist or stream_output else []) + safety_args + (["--model", model] if model else [])
                for n, url in enumerate(images):
                    head, _, data = url.partition(",")
                    img_path = os.path.join(workdir, f"image-{n + 1}." + ("jpg" if "jpeg" in head else head[11:].split(";")[0]))
                    with open(img_path, "wb") as handle:
                        handle.write(base64.b64decode(data))
                    if eu != "root":
                        try:
                            os.chown(img_path, pwd.getpwnam(eu).pw_uid, pwd.getpwnam(eu).pw_gid)
                        except Exception:
                            pass
                    cmd += ["-i", img_path]
                if resume_id:
                    cmd += [resume_id, "-"]
                stdin_input = prompt
            else:
                cmd = [cmd_bin] + provider["args"] + [prompt]
            if output_callback:
                try:
                    output_callback({"type": "session", "provider": pid, "session_id": resume_id or new_session,
                                     "resumed": bool(resume_id)})
                except Exception:
                    logging.getLogger(__name__).exception("mvmAI output observer failed")
            proc = await asyncio.to_thread(
                _run_turn_process,
                _wrap_as_user(cmd, eu), input=stdin_input, capture_output=True, text=True, timeout=cli_timeout, cwd=effective_dir, output_callback=output_callback,
                env={**os.environ, "HOME": home, "USER": eu, "LOGNAME": eu, "PATH": _cli_search_path(home), **extra_env},
            )
        raw_out = proc.stdout.strip()
        if proc.returncode != 0 and resume_id and _SESSION_LOST_RE.search(f"{proc.stderr}\n{raw_out}"):
            return JSONResponse({"error": "The CLI session is gone.", "session_lost": True}, status_code=409)
        model_used = ""
        codex_thread = ""
        if pid == "codex-cli" and (persist or stream_output):
            # --json prints one event per line: the thread id once, then every
            # message the agent wrote; the answer is the last one.
            answer, failure = None, ""
            for line in raw_out.splitlines():
                try:
                    event = json.loads(line)
                except Exception:
                    continue
                kind = event.get("type")
                if kind == "thread.started":
                    codex_thread = event.get("thread_id") or ""
                elif kind == "item.completed" and (event.get("item") or {}).get("type") == "agent_message":
                    answer = event["item"].get("text") or ""
                elif kind in ("error", "turn.failed"):
                    failure = event.get("message") or (event.get("error") or {}).get("message") or failure
            if answer is None and proc.returncode != 0:
                err = failure or proc.stderr.strip() or f"exit code {proc.returncode}"
                logging.getLogger(__name__).error("mvmai CLI provider %s failed (exit %s): %s", pid, proc.returncode, err)
                return JSONResponse({"error": err}, status_code=502)
            content = (answer or "").strip()
        elif pid == "claude-cli" and (images or persist or stream_output):
            # json / stream-json: the answer is the "result" entry, which also
            # names the model that really answered.
            result = None
            for chunk in ([raw_out] if not images and not stream_output else raw_out.splitlines()):
                try:
                    event = json.loads(chunk)
                except Exception:
                    continue
                for item in (event if isinstance(event, list) else [event]):
                    if isinstance(item, dict) and item.get("type") == "result":
                        result = item
            if result is None and proc.returncode != 0:
                err = proc.stderr.strip() or raw_out or f"exit code {proc.returncode}"
                logging.getLogger(__name__).error("mvmai CLI provider %s failed (exit %s): %s", pid, proc.returncode, err)
                return JSONResponse({"error": err}, status_code=502)
            if result is not None and result.get("is_error") and proc.returncode != 0 and not (result.get("result") or "").strip():
                return JSONResponse({"error": proc.stderr.strip() or f"exit code {proc.returncode}"}, status_code=502)
            content = ((result or {}).get("result") or "").strip()
            usage = (result or {}).get("modelUsage") or {}
            if usage:
                model_used = max(usage, key=lambda name: (usage[name] or {}).get("costUSD") or 0)
        else:
            if proc.returncode != 0 and not raw_out:
                err = proc.stderr.strip() or f"exit code {proc.returncode}"
                logging.getLogger(__name__).error("mvmai CLI provider %s failed (exit %s): %s", pid, proc.returncode, err)
                return JSONResponse({"error": err}, status_code=502)
            content = raw_out

        def _reply(payload: dict):
            sid = resume_id or new_session or codex_thread
            if persist and sid:
                payload["cli_state"] = {
                    "session_id": sid, "user": eu, "policy": policy,
                    "model_used": model_used or str((cli_resume or {}).get("model_used") or ""),
                }
            return JSONResponse(payload)

        if prompt_tools:
            valid_names = {spec["function"]["name"] for spec in prompt_tools}
            calls = []
            for m in _CLI_TOOL_CALL_RE.finditer(content):
                try:
                    parsed = json.loads(m.group(1))
                    name = str(parsed.get("name") or "")
                    arguments = parsed.get("arguments") or {}
                except Exception:
                    continue
                if name in valid_names:
                    calls.append({
                        "id": f"cli-call-{len(calls) + 1}",
                        "type": "function",
                        "function": {"name": name, "arguments": json.dumps(arguments)},
                    })
            if calls:
                rest = _CLI_TOOL_CALL_RE.sub("", content).strip()
                return _reply({"content": rest or None, "tool_calls": calls})
        return _reply({"content": content})
    except subprocess.TimeoutExpired:
        return JSONResponse({"error": f"CLI timed out after {cli_timeout}s"}, status_code=504)
    except Exception as e:
        logging.getLogger(__name__).error("mvmai CLI provider %s raised: %s", pid, e)
        return JSONResponse({"error": str(e)}, status_code=502)


@router.post("/cli-chat")
async def cli_chat(body: CliChatRequest, x_pub_token: str = Header(default=None), session=Depends(get_current_session)):
    cfg = _read_cfg()
    is_admin = _is_apps_hub_admin(x_pub_token)
    exec_enabled = bool(cfg.get("exec_enabled"))
    exec_auto = bool(cfg.get("exec_auto"))
    return await _run_cli_chat(body, _server_tools(is_admin, exec_enabled), is_admin, exec_enabled, exec_auto, session=session)
