"""
YourSQL — MySQL manager backend for mvmOS.
Routes: /api/apps/yoursql/...
Uses the mysql CLI instead of pymysql — works on any machine without extra dependencies.
"""

import json
import os
import subprocess
import sqlite3
import sys

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel
from typing import Optional

get_current_session = sys.modules["backend.auth"].get_current_session

router = APIRouter(prefix="/api/apps/yoursql")
router._app_backend = "yoursql"

# App-own SQLite DB — stored in apps/yoursql/data.db
_DB_PATH = os.path.join(
    os.path.dirname(sys.modules["backend.db"].APPS_DIR),
    "apps", "yoursql", "data.db"
)


def _app_conn():
    conn = sqlite3.connect(_DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS connections (
            id TEXT PRIMARY KEY,
            user TEXT NOT NULL,
            name TEXT NOT NULL,
            host TEXT NOT NULL DEFAULT 'localhost',
            port INTEGER NOT NULL DEFAULT 3306,
            db_user TEXT NOT NULL,
            password TEXT NOT NULL DEFAULT '',
            database TEXT NOT NULL DEFAULT '',
            created_at INTEGER DEFAULT (strftime('%s','now'))
        )
    """)
    conn.commit()
    return conn


# ── MySQL CLI helper ──────────────────────────────────────────────────────────

def _mysql_args(cfg: dict, database: str = None) -> list:
    """Build mysql CLI argument list from connection config."""
    args = [
        "mysql",
        f"-h{cfg['host']}",
        f"-P{cfg['port']}",
        f"-u{cfg['user']}",
        f"-p{cfg['password']}",
        "--batch",
        "--skip-column-names",
        "--default-character-set=utf8mb4",
    ]
    if database:
        args.append(database)
    return args


def _run_mysql(cfg: dict, sql: str, database: str = None) -> str:
    """Run a SQL statement via mysql CLI and return raw output."""
    args = _mysql_args(cfg, database)
    r = subprocess.run(
        args,
        input=sql,
        capture_output=True,
        text=True,
        timeout=30,
    )
    if r.returncode != 0:
        err = r.stderr.strip()
        # Strip the "mysql: [Warning] Using a password..." line
        lines = [l for l in err.splitlines() if "Using a password" not in l]
        raise HTTPException(400, "\n".join(lines) or err)
    return r.stdout


def _run_mysql_json(cfg: dict, sql: str, database: str = None) -> list:
    """Run SQL and return list of dicts (tab-separated output with header)."""
    args = _mysql_args(cfg, database)
    # Use --column-names to get header row
    args = [a for a in args if a != "--skip-column-names"]
    r = subprocess.run(
        args,
        input=sql,
        capture_output=True,
        text=True,
        timeout=30,
    )
    if r.returncode != 0:
        err = r.stderr.strip()
        lines = [l for l in err.splitlines() if "Using a password" not in l]
        raise HTTPException(400, "\n".join(lines) or err)

    lines = r.stdout.splitlines()
    if not lines:
        return []
    columns = lines[0].split("\t")
    rows = []
    for line in lines[1:]:
        if not line:
            continue
        values = line.split("\t")
        row = {}
        for i, col in enumerate(columns):
            v = values[i] if i < len(values) else ""
            row[col] = None if v == "NULL" else v
        rows.append(row)
    return rows


def _run_mysql_write(cfg: dict, sql: str, database: str = None) -> int:
    """Run a write SQL statement and return affected rows."""
    args = _mysql_args(cfg, database)
    r = subprocess.run(
        args,
        input=sql,
        capture_output=True,
        text=True,
        timeout=30,
    )
    if r.returncode != 0:
        err = r.stderr.strip()
        lines = [l for l in err.splitlines() if "Using a password" not in l]
        raise HTTPException(400, "\n".join(lines) or err)
    # mysql outputs "Query OK, N rows affected"
    for line in r.stderr.splitlines():
        if "rows affected" in line or "row affected" in line:
            try:
                return int(line.split()[2])
            except Exception:
                pass
    return 0


def _escape(val) -> str:
    """Escape a value for use in SQL string."""
    if val is None:
        return "NULL"
    s = str(val).replace("\\", "\\\\").replace("'", "\\'")
    return f"'{s}'"


# ── Connections ───────────────────────────────────────────────────────────────

def _get_connections(user: str) -> list:
    with _app_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM connections WHERE user=? ORDER BY created_at", (user,)
        ).fetchall()
    return [dict(r) for r in rows]


def _get_conn_by_id(user: str, conn_id: str) -> dict:
    with _app_conn() as conn:
        row = conn.execute(
            "SELECT * FROM connections WHERE id=? AND user=?", (conn_id, user)
        ).fetchone()
    if not row:
        raise HTTPException(404, "Connection not found")
    return dict(row)


def _get_conn_config(user: str, conn_id: str) -> dict:
    c = _get_conn_by_id(user, conn_id)
    c["user"] = c.get("db_user", c.get("user", ""))
    return c


@router.get("/connections")
def list_connections(session=Depends(get_current_session)):
    conns = _get_connections(session["effective_user"])
    safe = [{k: v for k, v in c.items() if k != "password"} for c in conns]
    return JSONResponse(safe)


class ConnectionBody(BaseModel):
    id: Optional[str] = None
    name: str
    host: str = "localhost"
    port: int = 3306
    user: str
    password: str
    database: str = ""


@router.post("/connections")
def save_connection(body: ConnectionBody, session=Depends(get_current_session)):
    import uuid
    user = session["effective_user"]
    conn_id = body.id or str(uuid.uuid4())[:8]
    password = body.password
    if not password and body.id:
        try:
            existing = _get_conn_by_id(user, conn_id)
            password = existing["password"]
        except HTTPException:
            pass
    with _app_conn() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO connections (id, user, name, host, port, db_user, password, database)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (conn_id, user, body.name, body.host, body.port, body.user, password, body.database))
    return {"ok": True, "id": conn_id}


@router.delete("/connections/{conn_id}")
def delete_connection(conn_id: str, session=Depends(get_current_session)):
    user = session["effective_user"]
    with _app_conn() as conn:
        conn.execute("DELETE FROM connections WHERE id=? AND user=?", (conn_id, user))
    return {"ok": True}


# ── MySQL queries ─────────────────────────────────────────────────────────────

@router.get("/databases")
def list_databases(conn_id: str, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], conn_id)
    try:
        output = _run_mysql(cfg, "SHOW DATABASES;")
        dbs = [line for line in output.splitlines() if line]
        return JSONResponse(dbs)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))


@router.get("/tables")
def list_tables(conn_id: str, database: str, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], conn_id)
    try:
        output = _run_mysql(cfg, f"SHOW TABLES;", database=database)
        tables = [line for line in output.splitlines() if line]
        return JSONResponse(tables)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))


class QueryBody(BaseModel):
    conn_id: str
    database: str = ""
    sql: str
    limit: int = 500
    offset: int = 0


@router.post("/query")
def run_query(body: QueryBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        sql = body.sql.strip()
        is_select = sql.upper().startswith(("SELECT", "SHOW", "DESCRIBE", "EXPLAIN"))
        db = body.database or None
        if is_select:
            rows = _run_mysql_json(cfg, sql, database=db)
            columns = list(rows[0].keys()) if rows else []
            return JSONResponse({"columns": columns, "rows": rows, "affected": None})
        else:
            affected = _run_mysql_write(cfg, sql, database=db)
            return JSONResponse({"columns": [], "rows": [], "affected": affected})
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))


class UpdateRowBody(BaseModel):
    conn_id: str
    database: str
    table: str
    where: dict
    updates: dict


@router.post("/update-row")
def update_row(body: UpdateRowBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        set_parts = [f"`{c}`={_escape(v)}" for c, v in body.updates.items()]
        where_parts = [f"`{c}`={_escape(v)}" for c, v in body.where.items()]
        sql = f"UPDATE `{body.table}` SET {', '.join(set_parts)} WHERE {' AND '.join(where_parts)};"
        affected = _run_mysql_write(cfg, sql, database=body.database)
        return {"ok": True, "affected": affected}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))


class InsertRowBody(BaseModel):
    conn_id: str
    database: str
    table: str
    values: dict


@router.post("/insert-row")
def insert_row(body: InsertRowBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        cols = list(body.values.keys())
        vals = [_escape(v) for v in body.values.values()]
        col_str = ", ".join([f"`{c}`" for c in cols])
        sql = f"INSERT INTO `{body.table}` ({col_str}) VALUES ({', '.join(vals)});"
        _run_mysql_write(cfg, sql, database=body.database)
        # Get last insert id
        rows = _run_mysql_json(cfg, "SELECT LAST_INSERT_ID() as id;", database=body.database)
        last_id = rows[0]["id"] if rows else None
        return {"ok": True, "id": last_id}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))


class BulkDeleteBody(BaseModel):
    conn_id: str
    database: str
    table: str
    mode: str = "page"
    where_rows: Optional[list] = None


@router.post("/bulk-delete")
def bulk_delete(body: BulkDeleteBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        deleted = 0
        if body.mode == "all":
            deleted = _run_mysql_write(cfg, f"DELETE FROM `{body.table}`;", database=body.database)
        elif body.where_rows:
            for where_dict in body.where_rows:
                where_parts = [f"`{c}`={_escape(v)}" for c, v in where_dict.items()]
                sql = f"DELETE FROM `{body.table}` WHERE {' AND '.join(where_parts)};"
                deleted += _run_mysql_write(cfg, sql, database=body.database)
        return {"ok": True, "affected": deleted}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))


class BulkUpdateBody(BaseModel):
    conn_id: str
    database: str
    table: str
    updates: dict
    mode: str = "page"
    where_rows: Optional[list] = None


@router.post("/bulk-update")
def bulk_update(body: BulkUpdateBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        set_parts = []
        for col, op_dict in body.updates.items():
            operation = op_dict.get("op", "set") if isinstance(op_dict, dict) else "set"
            val = op_dict.get("value") if isinstance(op_dict, dict) else op_dict
            if operation == "set_null" or (operation == "set" and val is None):
                set_parts.append(f"`{col}`=NULL")
            elif operation == "set":
                set_parts.append(f"`{col}`={_escape(val)}")
            elif operation == "increment":
                set_parts.append(f"`{col}`=`{col}`+{_escape(val)}")
            elif operation == "decrement":
                set_parts.append(f"`{col}`=`{col}`-{_escape(val)}")
        if not set_parts:
            raise HTTPException(400, "No operations")
        total_affected = 0
        if body.mode == "all":
            sql = f"UPDATE `{body.table}` SET {', '.join(set_parts)};"
            total_affected = _run_mysql_write(cfg, sql, database=body.database)
        elif body.where_rows:
            for where_dict in body.where_rows:
                where_parts = [f"`{c}`={_escape(v)}" for c, v in where_dict.items()]
                sql = f"UPDATE `{body.table}` SET {', '.join(set_parts)} WHERE {' AND '.join(where_parts)};"
                total_affected += _run_mysql_write(cfg, sql, database=body.database)
        return {"ok": True, "affected": total_affected}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))


def _build_where_cli(filters, search=None, search_cols=None):
    """Build WHERE clause from filter list for CLI queries."""
    parts = []
    if search and search_cols:
        parts.append("(" + " OR ".join([f"`{c}` LIKE '%{search}%'" for c in search_cols]) + ")")
    OP_MAP = {
        '=': '`{col}`={val}',
        '!=': '`{col}`!={val}',
        '<': '`{col}`<{val}',
        '>': '`{col}`>{val}',
        '<=': '`{col}`<={val}',
        '>=': '`{col}`>={val}',
        'LIKE': '`{col}` LIKE {val}',
        'NOT LIKE': '`{col}` NOT LIKE {val}',
        'LIKE %%': '`{col}` LIKE \'%{raw}%\'',
        'REGEXP': '`{col}` REGEXP {val}',
        'IS NULL': '`{col}` IS NULL',
        'IS NOT NULL': '`{col}` IS NOT NULL',
    }
    for f in (filters or []):
        col = f.get('col') if isinstance(f, dict) else f.col
        op = f.get('op') if isinstance(f, dict) else f.op
        val = f.get('val', '') if isinstance(f, dict) else getattr(f, 'val', '')
        if op not in OP_MAP:
            continue
        tpl = OP_MAP[op]
        if op == 'LIKE %%':
            parts.append(tpl.format(col=col, raw=val.replace("'", "\\'")))
        elif op in ('IS NULL', 'IS NOT NULL'):
            parts.append(tpl.format(col=col))
        else:
            parts.append(tpl.format(col=col, val=_escape(val)))
    return ("WHERE " + " AND ".join(parts)) if parts else ""


class TableDataBody(BaseModel):
    conn_id: str
    database: str
    table: str
    limit: int = 100
    offset: int = 0
    search: str = ""
    order_by: str = ""
    order_dir: str = "ASC"
    filters: Optional[list] = None
    sort: Optional[list] = None


@router.post("/table-data")
def get_table_data(body: TableDataBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        search_cols = []
        if body.search:
            cols_rows = _run_mysql_json(cfg, f"DESCRIBE `{body.table}`;", database=body.database)
            search_cols = [c["Field"] for c in cols_rows if any(t in c["Type"].lower() for t in ["char", "text", "varchar"])]

        where = _build_where_cli(body.filters, body.search, search_cols)

        count_rows = _run_mysql_json(cfg, f"SELECT COUNT(*) as cnt FROM `{body.table}` {where};", database=body.database)
        total = int(count_rows[0]["cnt"]) if count_rows else 0

        order_parts = []
        if body.sort:
            for s in body.sort:
                col = s.get('col') if isinstance(s, dict) else s.col
                dir_ = "DESC" if (s.get('dir') if isinstance(s, dict) else s.dir).upper() == "DESC" else "ASC"
                order_parts.append(f"`{col}` {dir_}")
        elif body.order_by:
            dir_ = "DESC" if body.order_dir.upper() == "DESC" else "ASC"
            order_parts.append(f"`{body.order_by}` {dir_}")
        order = ("ORDER BY " + ", ".join(order_parts)) if order_parts else ""

        rows = _run_mysql_json(cfg, f"SELECT * FROM `{body.table}` {where} {order} LIMIT {body.limit} OFFSET {body.offset};", database=body.database)
        columns = list(rows[0].keys()) if rows else []
        return JSONResponse({"columns": columns, "rows": rows, "total": total})
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))


class UpdateCellBody(BaseModel):
    conn_id: str
    database: str
    table: str
    primary_key: str
    primary_value: str
    column: str
    value: str


@router.post("/update-cell")
def update_cell(body: UpdateCellBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        sql = f"UPDATE `{body.table}` SET `{body.column}`={_escape(body.value)} WHERE `{body.primary_key}`={_escape(body.primary_value)};"
        _run_mysql_write(cfg, sql, database=body.database)
        return {"ok": True}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))


class DeleteRowBody(BaseModel):
    conn_id: str
    database: str
    table: str
    where: Optional[dict] = None
    primary_key: Optional[str] = None
    primary_value: Optional[str] = None


@router.post("/delete-row")
def delete_row(body: DeleteRowBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        if body.where:
            where_parts = [f"`{c}`={_escape(v)}" for c, v in body.where.items()]
            sql = f"DELETE FROM `{body.table}` WHERE {' AND '.join(where_parts)};"
        else:
            sql = f"DELETE FROM `{body.table}` WHERE `{body.primary_key}`={_escape(body.primary_value)};"
        _run_mysql_write(cfg, sql, database=body.database)
        return {"ok": True}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))


@router.get("/table-structure")
def table_structure(conn_id: str, database: str, table: str, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], conn_id)
    try:
        columns = _run_mysql_json(cfg, f"DESCRIBE `{table}`;", database=database)
        indexes = _run_mysql_json(cfg, f"SHOW INDEX FROM `{table}`;", database=database)
        return JSONResponse({"columns": columns, "indexes": indexes})
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))


# ── Export ────────────────────────────────────────────────────────────────────

@router.get("/export")
def export_table(conn_id: str, database: str, table: str, format: str = "sql",
                 session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], conn_id)
    try:
        rows = _run_mysql_json(cfg, f"SELECT * FROM `{table}`;", database=database)
        columns = list(rows[0].keys()) if rows else []
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))

    if format == "csv":
        import csv, io
        out = io.StringIO()
        writer = csv.writer(out)
        writer.writerow(columns)
        for row in rows:
            writer.writerow([row.get(c, "") for c in columns])
        content = out.getvalue().encode()
        return StreamingResponse(iter([content]),
                                 media_type="text/csv",
                                 headers={"Content-Disposition": f"attachment; filename={table}.csv"})
    else:
        lines = [f"-- YourSQL export: {database}.{table}\n"]
        lines.append(f"-- Generated by YourSQL / mvmOS\n\n")
        col_list = ", ".join([f"`{c}`" for c in columns])
        for row in rows:
            vals = [_escape(row.get(c)) for c in columns]
            lines.append(f"INSERT INTO `{table}` ({col_list}) VALUES ({', '.join(vals)});\n")
        content = "".join(lines).encode()
        return StreamingResponse(iter([content]),
                                 media_type="application/sql",
                                 headers={"Content-Disposition": f"attachment; filename={table}.sql"})


# ── Import ────────────────────────────────────────────────────────────────────

from fastapi import UploadFile, File, Form


@router.post("/import")
async def import_file(
    conn_id: str = Form(...),
    database: str = Form(...),
    file: UploadFile = File(...),
    session=Depends(get_current_session)
):
    cfg = _get_conn_config(session["effective_user"], conn_id)
    content = await file.read()
    filename = file.filename or ""
    errors = []
    affected = 0

    try:
        if filename.endswith(".csv"):
            import csv, io
            text = content.decode("utf-8-sig")
            reader = csv.DictReader(io.StringIO(text))
            rows = list(reader)
            if rows:
                table = filename.rsplit(".", 1)[0]
                cols = list(rows[0].keys())
                col_str = ", ".join([f"`{c}`" for c in cols])
                for row in rows:
                    vals = [_escape(row.get(c)) for c in cols]
                    sql = f"INSERT INTO `{table}` ({col_str}) VALUES ({', '.join(vals)});"
                    try:
                        _run_mysql_write(cfg, sql, database=database)
                        affected += 1
                    except Exception as e:
                        errors.append(str(e))
        else:
            sql_text = content.decode("utf-8", errors="replace")
            statements = [s.strip() for s in sql_text.split(";") if s.strip()]
            for stmt in statements:
                try:
                    n = _run_mysql_write(cfg, stmt + ";", database=database)
                    affected += n
                except Exception as e:
                    errors.append(str(e))

        return JSONResponse({"ok": True, "affected": affected, "errors": errors[:10]})
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))
