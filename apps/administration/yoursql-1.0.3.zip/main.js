// YourSQL — MySQL Manager for mvmOS v1.0.0

mvmOS.registerApp({
  id: 'yoursql',
  name: 'YourSQL',
  icon: '🗄️',
  category: 'Administration',
  width: 1100,
  height: 680,
  minWidth: 700,
  minHeight: 400,

  launch() {
    mvmOS.createWindow({
      id: 'yoursql',
      title: 'YourSQL',
      icon: '🗄️',
      width: 1100,
      height: 680,
      minWidth: 700,
      minHeight: 400,
      onMount: (body) => {
        body.innerHTML = '<div style="padding:20px">YourSQL loading...</div>';
        _ysqlInit(body);
      }
    });
  }
});

function _ysqlInit(container) {
  const BASE = '/apps/yoursql/';
  const MODULES = ['state.js', 'ui.js', 'connections.js', 'sidebar.js', 'browse.js', 'filters.js', 'row-edit.js', 'structure.js', 'query.js'];

  MODULES.reduce(function(p, mod) {
    return p.then(function() {
      return new Promise(function(resolve, reject) {
        if (document.querySelector('script[data-ysql="' + mod + '"]')) { resolve(); return; }
        var s = document.createElement('script');
        s.src = BASE + mod + '?_=' + Date.now();
        s.dataset.ysql = mod;
        s.onload = resolve;
        s.onerror = function() { reject(new Error('Failed: ' + mod)); };
        document.head.appendChild(s);
      });
    });
  }, Promise.resolve()).then(function() {
    window.YS = window.YS || {};
    _ysqlRenderApp(container);
  }).catch(function(e) {
    container.innerHTML = '<div style="padding:20px;color:red">Error: ' + e.message + '</div>';
  });
}

function _ysqlRenderApp(container) {
  if (!window.YS) { container.innerHTML = '<div style="padding:20px;color:red">YS modules not loaded</div>'; return; }
  YS.state.activeConn = null;
  YS.state.activeDb = null;
  YS.state.activeTable = null;

  container.innerHTML = [
    '<div style="display:flex;height:100%;overflow:hidden;position:relative">',
    '  <div id="ysql-sidebar" class="as-sidebar" style="width:220px;min-width:180px;max-width:300px;display:flex;flex-direction:column;overflow:hidden;flex-shrink:0">',
    '    <div style="padding:8px;border-bottom:1px solid var(--border);display:flex;gap:6px">',
    '      <button class="s-btn s-btn-sm" id="ysql-add-conn" style="flex:1">＋ Connection</button>',
    '    </div>',
    '    <div id="ysql-conn-list" style="overflow-y:auto;flex:1"></div>',
    '    <div id="ysql-db-section" style="border-top:1px solid var(--border);padding:8px;flex-shrink:0;display:none">',
    '      <div style="font-size:.72rem;color:var(--text-dim);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px">Database</div>',
    '      <select id="ysql-db-select" class="s-input" style="width:100%;font-size:.82rem"><option value="">— select —</option></select>',
    '    </div>',
    '  </div>',
    '  <div id="ysql-main" style="flex:1;display:flex;flex-direction:column;overflow:hidden;min-width:0">',
    '    <div id="ysql-toolbar" style="display:flex;align-items:center;gap:6px;padding:6px 10px;border-bottom:1px solid var(--border);flex-shrink:0">',
    '      <span id="ysql-breadcrumb" style="font-size:.82rem;color:var(--text-dim);flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0"></span>',
    '      <button class="s-btn s-btn-sm" id="ysql-btn-browse" style="font-size:.8rem">📋 Browse</button>',
    '      <button class="s-btn s-btn-sm" id="ysql-btn-query" style="font-size:.8rem">⌨️ SQL</button>',
    '    </div>',
    '    <div id="ysql-content" style="flex:1;overflow:hidden;display:flex"></div>',
    '  </div>',
    '</div>'
  ].join('');

  YS.connections.load(container);

  container.querySelector('#ysql-add-conn').addEventListener('click', function() { YS.connections.openDialog(container); });

  container.querySelector('#ysql-db-select').addEventListener('change', function() {
    YS.state.activeDb = this.value || null;
    YS.state.activeTable = null;
    YS.sidebar.loadTables(container).then(function() { YS.browse.showWelcome(container); });
  });

  container.querySelector('#ysql-btn-browse').addEventListener('click', function() {
    if (YS.state.activeTable) YS.browse.show(container);
  });
  container.querySelector('#ysql-btn-query').addEventListener('click', function() { YS.query.show(container); });

  // re-run desktop.js mobile sidebar init — our onMount is async so
  // the first call (at createWindow time) ran before .as-sidebar existed
  mvmOS.initMobileSidebar(container);

}
