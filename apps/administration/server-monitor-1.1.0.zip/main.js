// mvmOS App: Server Monitor v1.0.0
const _sm18n = {
  en: {
    title: 'Server Monitor', garden: 'Bit Garden',
    plant_btn: 'Plant the seed', watered: 'Watered! ×0.9 penalties for 1h',
    water_btn: '💧 Water', boost_active: 'Boost active',
    health_lbl: 'Health', growth_lbl: 'Growth', daily_rate: 'Daily rate',
    seed_title: 'Your server has no plant yet.', seed_sub: 'Click to plant the seed and start growing.',
    stage_seed: 'Seed', stage_sprout: 'Sprout', stage_young: 'Young plant',
    stage_mature: 'Plant', stage_bloom: 'Blooming', stage_tree: 'Tree',
    modifiers: 'Current modifiers', boost_rem: 'Boost remaining',
    add_widget: '🪴 Add to desktop',
    influence: 'Influence (last hour)', waiting_first: '— waiting for first hour',
    metric: 'Metric', value: 'Value', effect: 'Effect',
    on_health: 'health', on_growth: 'growth',
    disk_slow: 'growth −', disk_ok: 'full growth',
    ram_cpu_more: '% more CPU dmg', ram_cpu_less: '% less CPU dmg', ram_neutral: 'neutral',
    boost_status: 'Boost active — {h}h left · damage blocked · growth ×2',
    archive_label: 'Archive', days_label: 'days',
    cpu: 'CPU', ram: 'RAM', swap: 'Swap', disk: 'Disk', net: 'Network', sensors: 'Sensors',
    load: 'Load Avg', disk_io: 'Disk I/O', net_in: 'Network In', net_out: 'Network Out',
    read: 'Read', write: 'Write',
    period_hour: 'Last hour', period_today: 'Today', period_yesterday: 'Yesterday',
    period_week: 'Week', period_month: 'Month',
    avg: 'Avg', min: 'Min', max: 'Max',
    no_data: 'No data yet — keep this window open to start recording.',
    loading: 'Loading…', no_sensors: 'No temperature sensors detected on this machine.',
    error: 'Error loading data',
    records: 'records', time: 'Time', click_details: 'Click for details',
    cpu_pct: 'CPU %', load_1m: 'Load avg 1m', load_5m: 'Load avg 5m', load_15m: 'Load avg 15m',
    ram_used: 'RAM used %', swap_used: 'Swap used %',
    disk_used: 'Disk used %', read_mbs: 'Read MB/s', write_mbs: 'Write MB/s',
    net_in_mbs: 'Network in MB/s', net_out_mbs: 'Network out MB/s',
    temp_max: 'Temperature max °C',
  },
  bg: {
    title: 'Сървър Монитор', garden: 'Бит Градина',
    plant_btn: 'Посади семето', watered: 'Полято! ×0.9 наказания за 1ч',
    water_btn: '💧 Полей', boost_active: 'Бустът е активен',
    health_lbl: 'Здраве', growth_lbl: 'Растеж', daily_rate: 'Дневна скорост',
    seed_title: 'Сървърът ти няма растение.', seed_sub: 'Кликни за да посадиш семето и да започнеш.',
    stage_seed: 'Семе', stage_sprout: 'Кълн', stage_young: 'Малко растение',
    stage_mature: 'Растение', stage_bloom: 'Цъфти', stage_tree: 'Дърво',
    modifiers: 'Текущи модификатори', boost_rem: 'Буст оставащо',
    add_widget: '🪴 Добави на десктопа',
    influence: 'Влияние (последния час)', waiting_first: '— изчаква първия час',
    metric: 'Метрика', value: 'Стойност', effect: 'Ефект',
    on_health: 'здраве', on_growth: 'растеж',
    disk_slow: 'растеж −', disk_ok: 'пълен растеж',
    ram_cpu_more: '% повече CPU щета', ram_cpu_less: '% по-малко CPU щета', ram_neutral: 'неутрална',
    boost_status: 'Boost активен — {h}ч остават · щети блокирани · растеж ×2',
    archive_label: 'Архив', days_label: 'дни',
    cpu: 'Процесор', ram: 'Памет', swap: 'Суап', disk: 'Диск', net: 'Мрежа', sensors: 'Сензори',
    load: 'Натоварване', disk_io: 'Диск I/O', net_in: 'Мрежа Вход', net_out: 'Мрежа Изход',
    read: 'Четене', write: 'Запис',
    period_hour: 'Последен час', period_today: 'Днес', period_yesterday: 'Вчера',
    period_week: 'Седмица', period_month: 'Месец',
    avg: 'Средно', min: 'Мин', max: 'Макс',
    no_data: 'Няма данни — оставете прозореца отворен за да започне записването.',
    loading: 'Зарежда…', no_sensors: 'Няма открити температурни сензори на тази машина.',
    error: 'Грешка при зареждане',
    records: 'записа', time: 'Час', click_details: 'Кликни за детайли',
    cpu_pct: 'Процесор %', load_1m: 'Натоварване 1м', load_5m: 'Натоварване 5м', load_15m: 'Натоварване 15м',
    ram_used: 'Памет заета %', swap_used: 'Суап зает %',
    disk_used: 'Диск зает %', read_mbs: 'Четене MB/s', write_mbs: 'Запис MB/s',
    net_in_mbs: 'Мрежа вход MB/s', net_out_mbs: 'Мрежа изход MB/s',
    temp_max: 'Температура макс °C',
  },
};
function _smt(k) { const l = window.mvmOS?.lang || 'en'; return (_sm18n[l] || _sm18n.en)[k] || k; }

mvmOS.registerApp({
  id: 'server-monitor',
  name: _smt('title'),
  icon: '📊',
  category: 'Administration',
  launch() {
    mvmOS.createWindow({
      id: 'server-monitor',
      title: '📊 ' + _smt('title'),
      width: 860,
      height: 580,
      onMount(body) {
        body.style.cssText = 'margin:0;padding:0;overflow:hidden;background:#0f1117;color:#e2e8f0;font-family:system-ui,sans-serif;display:flex;flex-direction:column;height:100%';

        body.innerHTML = `
          <style>
            .sm-tabs { display:flex; gap:2px; padding:10px 12px 0; background:#0f1117; border-bottom:1px solid #1e2433; flex-wrap:wrap; }
            .sm-tab  { padding:6px 16px; border-radius:6px 6px 0 0; cursor:pointer; font-size:.82rem; color:#64748b; background:transparent; border:none; transition:all .15s; white-space:nowrap; }
            .sm-tab.active { background:#1e2433; color:#e2e8f0; }
            .sm-tab:hover:not(.active) { color:#94a3b8; }
            .sm-periods { display:flex; gap:6px; padding:10px 14px 6px; flex-wrap:wrap; border-bottom:1px solid #1e2433; }
            .sm-period { padding:3px 12px; border-radius:20px; cursor:pointer; font-size:.78rem; color:#64748b; background:#1e2433; border:none; transition:all .15s; }
            .sm-period.active { background:#3b82f6; color:#fff; }
            .sm-period:hover:not(.active) { background:#263142; color:#94a3b8; }
            .sm-content { flex:1; overflow-y:auto; padding:14px; }
            .sm-chart-wrap { background:#1e2433; border-radius:10px; padding:14px; margin-bottom:12px; }
            .sm-chart-title { font-size:.8rem; color:#94a3b8; margin-bottom:4px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px; }
            .sm-chart-name { font-weight:600; color:#e2e8f0; }
            .sm-stats { display:flex; gap:14px; font-size:.72rem; }
            .sm-stat { color:#64748b; } .sm-stat span { color:#e2e8f0; font-weight:600; }
            .sm-chart-svg { width:100%; height:90px; display:block; margin-top:6px; }
            .sm-no-data { text-align:center; padding:60px 20px; color:#475569; font-size:.85rem; line-height:1.6; }
            .sm-sensor-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:10px; }
            .sm-sensor-card { background:#1e2433; border-radius:10px; padding:12px 14px; }
            .sm-sensor-label { font-size:.72rem; color:#64748b; margin-bottom:4px; }
            .sm-sensor-val { font-size:1.5rem; font-weight:700; }
          </style>

          <div class="sm-tabs" id="sm-tabs"></div>

          <div id="sm-panels" style="display:flex;flex-direction:column;flex:1;overflow:hidden">
            <div class="sm-periods" id="sm-periods"></div>
            <div class="sm-content" id="sm-content">
              <div class="sm-no-data">${_smt('loading')}</div>
            </div>
          </div>
        `;

        // ── State ─────────────────────────────────────────────────────────────
        const TABS = [
          { id: 'garden',  label: '🌱 ' + _smt('garden')  },
          { id: 'cpu',     label: '⚡ ' + _smt('cpu')     },
          { id: 'ram',     label: '🧠 ' + _smt('ram')     },
          { id: 'disk',    label: '💾 ' + _smt('disk')    },
          { id: 'net',     label: '🌐 ' + _smt('net')     },
          { id: 'sensors', label: '🌡️ ' + _smt('sensors') },
        ];
        const PERIODS = [
          { id: 'hour',      label: _smt('period_hour')      },
          { id: 'today',     label: _smt('period_today')     },
          { id: 'yesterday', label: _smt('period_yesterday') },
          { id: 'week',      label: _smt('period_week')      },
          { id: 'month',     label: _smt('period_month')     },
        ];

        let activeTab    = 'garden';
        let activePeriod = 'today';
        let cache        = {};  // key: tab+period
        let refreshTimer = null;

        // ── Build tabs ────────────────────────────────────────────────────────
        const tabsEl = body.querySelector('#sm-tabs');
        TABS.forEach(t => {
          const btn = document.createElement('button');
          btn.className = 'sm-tab' + (t.id === activeTab ? ' active' : '');
          btn.textContent = t.label;
          btn.dataset.tab = t.id;
          btn.addEventListener('click', () => {
            tabsEl.querySelectorAll('.sm-tab').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            activeTab = t.id;
            loadTab();
          });
          tabsEl.appendChild(btn);
        });

        // ── Build period bar ──────────────────────────────────────────────────
        const periodsEl = body.querySelector('#sm-periods');
        PERIODS.forEach(p => {
          const btn = document.createElement('button');
          btn.className = 'sm-period' + (p.id === activePeriod ? ' active' : '');
          btn.textContent = p.label;
          btn.dataset.period = p.id;
          btn.addEventListener('click', () => {
            periodsEl.querySelectorAll('.sm-period').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            activePeriod = p.id;
            cache = {};
            loadTab();
          });
          periodsEl.appendChild(btn);
        });

        // ── Chart helpers ─────────────────────────────────────────────────────
        function sparkline(points, field, color) {
          const vals = points.map(p => p[`avg_${field}`]).filter(v => v != null);
          if (!vals.length) return '';
          const maxV = Math.max(...vals, 0.001);
          const minV = Math.min(...vals);
          const W = 800, H = 90, pad = 2;
          const step = (W - pad * 2) / Math.max(vals.length - 1, 1);
          const coords = vals.map((v, i) => {
            const x = pad + i * step;
            const y = H - pad - ((v - minV) / (maxV - minV || 1)) * (H - pad * 2);
            return `${x.toFixed(1)},${y.toFixed(1)}`;
          });
          const id = field.replace(/[^a-z]/g, '');
          const last = coords[coords.length - 1];
          const area = `M${coords[0]} L${coords.join(' L')} L${last.split(',')[0]},${H} L${pad},${H} Z`;
          const line = `M${coords[0]} L${coords.join(' L')}`;
          return `<svg class="sm-chart-svg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">
            <defs>
              <linearGradient id="g${id}" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="${color}" stop-opacity=".25"/>
                <stop offset="100%" stop-color="${color}" stop-opacity="0"/>
              </linearGradient>
            </defs>
            <path d="${area}" fill="url(#g${id})"/>
            <path d="${line}" fill="none" stroke="${color}" stroke-width="2"/>
          </svg>`;
        }

        // ── Chart click registry (populated by chartBlock, consumed by listener)
        const _chartClickRegistry = {};

        // ── Detail modal ──────────────────────────────────────────────────────
        function showDetail(name, points, field, unit) {
          const existing = body.querySelector('#sm-modal');
          if (existing) existing.remove();

          const fmt = ts => {
            const d = new Date(ts * 1000);
            return d.toLocaleDateString([], {day:'2-digit',month:'2-digit'}) + ' '
                 + d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
          };

          const rows = points
            .filter(p => p[`avg_${field}`] != null)
            .map(p => {
              const avg = p[`avg_${field}`];
              const mn  = p[`min_${field}`];
              const mx  = p[`max_${field}`];
              const isMx = mx === Math.max(...points.map(x => x[`max_${field}`] ?? -Infinity));
              return `<tr style="${isMx ? 'color:#f59e0b' : ''}">
                <td style="padding:5px 10px;border-bottom:1px solid #263142;white-space:nowrap">${fmt(p.ts)}</td>
                <td style="padding:5px 10px;border-bottom:1px solid #263142;text-align:right;font-weight:600">${avg.toFixed(2)}${unit}</td>
                <td style="padding:5px 10px;border-bottom:1px solid #263142;text-align:right;color:#64748b">${mn.toFixed(2)}</td>
                <td style="padding:5px 10px;border-bottom:1px solid #263142;text-align:right;color:${isMx?'#f59e0b':'#64748b'}">${mx.toFixed(2)}</td>
              </tr>`;
            }).join('');

          const modal = document.createElement('div');
          modal.id = 'sm-modal';
          modal.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,.7);z-index:100;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(2px)';
          modal.innerHTML = `
            <div style="background:#1e2433;border-radius:12px;width:90%;max-width:600px;max-height:80%;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.6)">
              <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 16px;border-bottom:1px solid #263142">
                <span style="font-weight:700;font-size:.9rem">${name} — ${points.filter(p=>p[`avg_${field}`]!=null).length} ${_smt('records')}</span>
                <button id="sm-modal-close" style="background:none;border:none;color:#64748b;font-size:1.2rem;cursor:pointer;line-height:1">✕</button>
              </div>
              <div style="overflow-y:auto;flex:1">
                <table style="width:100%;border-collapse:collapse;font-size:.8rem">
                  <thead>
                    <tr style="color:#475569;font-size:.72rem;text-transform:uppercase;letter-spacing:.05em">
                      <th style="padding:8px 10px;text-align:left;border-bottom:1px solid #263142">${_smt('time')}</th>
                      <th style="padding:8px 10px;text-align:right;border-bottom:1px solid #263142">${_smt('avg')}</th>
                      <th style="padding:8px 10px;text-align:right;border-bottom:1px solid #263142">${_smt('min')}</th>
                      <th style="padding:8px 10px;text-align:right;border-bottom:1px solid #263142">${_smt('max')}</th>
                    </tr>
                  </thead>
                  <tbody>${rows}</tbody>
                </table>
              </div>
            </div>
          `;
          modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
          modal.querySelector('#sm-modal-close').addEventListener('click', () => modal.remove());
          // position relative to the window body
          const wrap = body.closest('[style*="position"]') || body.parentElement;
          body.style.position = 'relative';
          body.appendChild(modal);
        }

        function chartBlock(name, points, field, color, unit = '%') {
          const vals = points.map(p => p[`avg_${field}`]).filter(v => v != null);
          if (!vals.length) return '';
          const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
          const mn  = Math.min(...vals);
          const mx  = Math.max(...vals);
          const peakIdx  = vals.indexOf(mx);
          const peakTs   = points[peakIdx]?.ts;
          const peakTime = peakTs ? new Date(peakTs * 1000).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) : '';
          const blockId  = 'smcb_' + field + '_' + Math.random().toString(36).slice(2);
          // attach click after render via a registry
          _chartClickRegistry[blockId] = () => showDetail(name, points, field, unit);
          return `<div class="sm-chart-wrap" data-smcb="${blockId}" style="cursor:pointer" title="${_smt('click_details')}">
            <div class="sm-chart-title">
              <span class="sm-chart-name">${name}</span>
              <div class="sm-stats">
                <div class="sm-stat">${_smt('avg')}: <span>${avg.toFixed(2)}${unit}</span></div>
                <div class="sm-stat">${_smt('min')}: <span>${mn.toFixed(2)}${unit}</span></div>
                <div class="sm-stat">${_smt('max')}: <span>${mx.toFixed(2)}${unit}</span>${peakTime ? ` <span style="color:#475569;font-weight:400">@ ${peakTime}</span>` : ''}</div>
              </div>
            </div>
            ${sparkline(points, field, color)}
          </div>`;
        }

        body.querySelector('#sm-content').addEventListener('click', e => {
          const block = e.target.closest('[data-smcb]');
          if (block) _chartClickRegistry[block.dataset.smcb]?.();
        });

        // ── SVG Plant renderer ────────────────────────────────────────────────
        function _seededRng(seed) {
          let s = seed | 0;
          return () => { s = (s * 1664525 + 1013904223) & 0xffffffff; return (s >>> 0) / 0xffffffff; };
        }

        function drawPlant(growth, health, seed = 0) {
          const rng = _seededRng(seed);
          const W = 200, H = 230;
          const cx = W / 2, ground = H - 28;

          // seed-driven personality
          const leafType  = Math.floor(rng() * 4);      // 0=round 1=pointed 2=wide 3=narrow
          const curve     = (rng() - 0.5) * 18;         // stem lean
          const bloomHue  = Math.floor(rng() * 6);
          const leafHue   = Math.floor(rng() * 3);
          const stemBrown = rng() > 0.7;

          const BLOOM_COLORS = ['#f9a8d4','#c4b5fd','#93c5fd','#fde68a','#6ee7b7','#fca5a5'];
          const LEAF_COLORS  = ['#22c55e','#16a34a','#4ade80'];

          const sick    = health < 30;
          const wilted  = health < 10;
          const leafC   = wilted ? '#6b4226' : sick ? '#a38a2a' : LEAF_COLORS[leafHue];
          const stemC   = wilted ? '#6b4226' : stemBrown ? '#5a3e28' : '#15803d';
          const bloomC  = BLOOM_COLORS[bloomHue];

          // ── Phase 0: seed (0%) ───────────────────────────────────────────────
          if (growth === 0) {
            return `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">
              <ellipse cx="${cx}" cy="${ground+10}" rx="70" ry="12" fill="#3d2b1f"/>
              <ellipse cx="${cx}" cy="${ground+5}"  rx="16" ry="4"  fill="#4a3728"/>
              <ellipse cx="${cx}" cy="${ground}"    rx="6"  ry="4"  fill="#5c4a2a"/>
            </svg>`;
          }

          // ── Stem height grows from 5% onward, maxes at 60% ──────────────────
          // 0-5%: no stem. 5-60%: grows to full height. 60-100%: stays full.
          const stemGrowthPct = Math.max(0, Math.min(1, (growth - 5) / 55));
          const maxStemH = 130;
          const stemH    = stemGrowthPct * maxStemH;
          const stemTop  = ground - stemH;
          const stemW    = growth >= 60 ? 4.5 : growth >= 30 ? 3.5 : 2;

          let svg = `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">
            <ellipse cx="${cx}" cy="${ground+10}" rx="70" ry="12" fill="#3d2b1f"/>`;

          // ── Phase 1: sprout only (1-5%) — tiny green tip, no stem yet ───────
          if (growth < 5) {
            const tipH = (growth / 5) * 14;
            svg += `<path d="M${cx},${ground} Q${cx+2},${ground-tipH*0.6} ${cx},${ground-tipH}"
              fill="none" stroke="${stemC}" stroke-width="1.5" stroke-linecap="round"/>`;
            svg += `</svg>`;
            return svg;
          }

          // stem
          const cpx = cx + curve, cpy = ground - stemH * 0.5;
          svg += `<path d="M${cx},${ground} Q${cpx},${cpy} ${cx - curve*0.25},${stemTop}"
            fill="none" stroke="${stemC}" stroke-width="${stemW}" stroke-linecap="round"/>`;

          // leaf helper
          function leaf(lx, ly, dir, size) {
            let path;
            if (leafType === 0) {
              const ex = lx+dir*size, ey = ly-size*0.4;
              path = `M${lx},${ly} Q${lx+dir*size*0.5},${ly-size*0.9} ${ex},${ey} Q${lx+dir*4},${ly-4} ${lx},${ly}`;
            } else if (leafType === 1) {
              const ex = lx+dir*size*1.2, ey = ly-size*0.15;
              path = `M${lx},${ly} Q${lx+dir*size*0.35},${ly-size*1.15} ${ex},${ey} Q${lx+dir*size*0.8},${ly+5} ${lx},${ly}`;
            } else if (leafType === 2) {
              const ex = lx+dir*size*0.85, ey = ly-size*0.55;
              path = `M${lx},${ly} Q${lx+dir*size*0.95},${ly-size*0.25} ${ex},${ey} Q${lx+dir*size*0.45},${ly-size*1.05} ${lx},${ly}`;
            } else {
              const ex = lx+dir*size*0.55, ey = ly-size*0.75;
              path = `M${lx},${ly} Q${lx+dir*size*0.18},${ly-size*1.25} ${ex},${ey} Q${lx+dir*3},${ly-2} ${lx},${ly}`;
            }
            return `<path d="${path}" fill="${leafC}" opacity="${wilted?0.45:0.92}"/>`;
          }

          // ── Phase 2: one leaf (5-10%) ────────────────────────────────────────
          if (growth >= 5) {
            const sc = Math.min(1, (growth - 5) / 5);
            const s  = 12 * sc;
            if (s > 1) svg += leaf(cx+2, ground-stemH*0.35, 1, s);
          }

          // ── Phase 3: leaf grows bigger (10-20%), second leaf appears ─────────
          if (growth >= 10) {
            svg += leaf(cx+2, ground-stemH*0.35, 1, 14 + (growth-10)*0.3);
          }
          if (growth >= 20) {
            const sc = Math.min(1, (growth-20)/10);
            const s  = 18 * sc;
            if (s > 1) svg += leaf(cx-2, ground-stemH*0.55, -1, s);
          }

          // ── Phase 4: third leaf (30%) ─────────────────────────────────────────
          if (growth >= 30) {
            const sc = Math.min(1, (growth-30)/10);
            svg += leaf(cx+2, ground-stemH*0.35, 1, 16);
            svg += leaf(cx-2, ground-stemH*0.55, -1, 20);
            const s = 22 * sc;
            if (s > 1) svg += leaf(cx+3, ground-stemH*0.72, 1, s);
          }

          // ── Phase 5: fourth leaf (40%) ────────────────────────────────────────
          if (growth >= 40) {
            const sc = Math.min(1, (growth-40)/10);
            svg += leaf(cx+2, ground-stemH*0.35, 1, 16);
            svg += leaf(cx-2, ground-stemH*0.55, -1, 20);
            svg += leaf(cx+3, ground-stemH*0.72, 1, 24);
            const s = 18 * sc;
            if (s > 1) svg += leaf(cx-3, ground-stemH*0.86, -1, s);
          }

          // ── Phase 6: full leaves, stem thickens (50-60%) ─────────────────────
          if (growth >= 50) {
            svg += leaf(cx+2, ground-stemH*0.35, 1, 16);
            svg += leaf(cx-2, ground-stemH*0.55, -1, 20);
            svg += leaf(cx+3, ground-stemH*0.72, 1, 24);
            svg += leaf(cx-3, ground-stemH*0.86, -1, 18);
          }

          // ── Phase 7: small buds appear (60-70%) ──────────────────────────────
          if (growth >= 60) {
            svg += leaf(cx+2, ground-stemH*0.35, 1, 16);
            svg += leaf(cx-2, ground-stemH*0.55, -1, 20);
            svg += leaf(cx+3, ground-stemH*0.72, 1, 24);
            svg += leaf(cx-3, ground-stemH*0.86, -1, 18);
            // small closed buds at top
            const budScale = Math.min(1, (growth-60)/10);
            const br = 3 * budScale;
            if (br > 0.5) {
              for (let i = 0; i < 3; i++) {
                const a = (i/3)*Math.PI*2 - Math.PI/2;
                const bx2 = (cx-3) + Math.cos(a)*6*budScale;
                const by2 = stemTop + Math.sin(a)*6*budScale;
                svg += `<circle cx="${bx2}" cy="${by2}" r="${br}" fill="${bloomC}" opacity=".7"/>`;
              }
            }
          }

          // ── Phase 8: small bloom (70-80%) ────────────────────────────────────
          if (growth >= 70) {
            svg += leaf(cx+2, ground-stemH*0.35, 1, 16);
            svg += leaf(cx-2, ground-stemH*0.55, -1, 20);
            svg += leaf(cx+3, ground-stemH*0.72, 1, 24);
            svg += leaf(cx-3, ground-stemH*0.86, -1, 18);
            const sc = Math.min(1, (growth-70)/10);
            const bx = cx-3, by = stemTop;
            const pr = 5 + sc*3;
            for (let i = 0; i < 5; i++) {
              const a = (i/5)*Math.PI*2;
              const px = bx + Math.cos(a)*pr, py = by + Math.sin(a)*pr;
              svg += `<ellipse cx="${px}" cy="${py}" rx="${3+sc*1.5}" ry="${2+sc}" fill="${bloomC}"
                transform="rotate(${i*72},${px},${py})" opacity="${0.6+sc*0.35}"/>`;
            }
            svg += `<circle cx="${bx}" cy="${by}" r="${2+sc*2}" fill="#fde68a"/>`;
          }

          // ── Phase 9: full bloom growing (80-90%) ─────────────────────────────
          if (growth >= 80) {
            svg += leaf(cx+2, ground-stemH*0.35, 1, 16);
            svg += leaf(cx-2, ground-stemH*0.55, -1, 20);
            svg += leaf(cx+3, ground-stemH*0.72, 1, 24);
            svg += leaf(cx-3, ground-stemH*0.86, -1, 18);
            const sc = Math.min(1, (growth-80)/10);
            const bx = cx-3, by = stemTop;
            const pr = 9 + sc*4;
            for (let i = 0; i < 6; i++) {
              const a = (i/6)*Math.PI*2;
              const px = bx + Math.cos(a)*pr, py = by + Math.sin(a)*pr;
              svg += `<ellipse cx="${px}" cy="${py}" rx="${5+sc*2}" ry="${3+sc*1.5}" fill="${bloomC}"
                transform="rotate(${i*60},${px},${py})"/>`;
            }
            svg += `<circle cx="${bx}" cy="${by}" r="${4+sc*2}" fill="#fde68a"/>`;
          }

          // ── Phase 10: full glorious bloom (90-100%) ──────────────────────────
          if (growth >= 90) {
            svg += leaf(cx+2, ground-stemH*0.35, 1, 16);
            svg += leaf(cx-2, ground-stemH*0.55, -1, 20);
            svg += leaf(cx+3, ground-stemH*0.72, 1, 24);
            svg += leaf(cx-3, ground-stemH*0.86, -1, 18);
            const sc = Math.min(1, (growth-90)/10);
            const bx = cx-3, by = stemTop;
            // outer ring of petals
            for (let i = 0; i < 8; i++) {
              const a = (i/8)*Math.PI*2;
              const px = bx + Math.cos(a)*(13+sc*4), py = by + Math.sin(a)*(13+sc*4);
              svg += `<ellipse cx="${px}" cy="${py}" rx="${6+sc*3}" ry="${4+sc*2}" fill="${bloomC}"
                transform="rotate(${i*45},${px},${py})"/>`;
            }
            // inner ring
            for (let i = 0; i < 5; i++) {
              const a = (i/5)*Math.PI*2 + 0.3;
              const px = bx + Math.cos(a)*7, py = by + Math.sin(a)*7;
              svg += `<ellipse cx="${px}" cy="${py}" rx="4" ry="2.5" fill="${bloomC}" opacity=".8"
                transform="rotate(${i*72},${px},${py})"/>`;
            }
            svg += `<circle cx="${bx}" cy="${by}" r="${5+sc*2}" fill="#fde68a"/>`;
            // sparkle dots at 100%
            if (growth >= 98) {
              for (let i = 0; i < 6; i++) {
                const a = (i/6)*Math.PI*2;
                const dx = bx + Math.cos(a)*20, dy = by + Math.sin(a)*20;
                svg += `<circle cx="${dx}" cy="${dy}" r="1.5" fill="#fde68a" opacity=".7"/>`;
              }
            }
          }

          // ── Sick/wilted overlays ─────────────────────────────────────────────
          if (sick && stemH > 5) {
            const sickPct = Math.max(0, (30 - health) / 30); // 0 at health=30, 1 at health=0

            // drooping leaves — tips bend down proportional to sickness
            const droopAmt = sickPct * 14;
            if (droopAmt > 1) {
              [[cx+2, ground-stemH*0.35, 1], [cx-2, ground-stemH*0.55, -1],
               [cx+3, ground-stemH*0.72, 1], [cx-3, ground-stemH*0.86, -1]].forEach(([lx, ly, dir]) => {
                if (ly > stemTop) {
                  svg += `<path d="M${lx},${ly} Q${lx+dir*10},${ly+droopAmt} ${lx+dir*18},${ly+droopAmt*1.4}"
                    fill="none" stroke="${leafC}" stroke-width="1.5" opacity="${0.3+sickPct*0.4}"/>`;
                }
              });
            }

            // brown spots on leaves at health < 20
            if (health < 20) {
              const spotCount = Math.floor(sickPct * 5) + 1;
              [[cx+14, ground-stemH*0.28], [cx-16, ground-stemH*0.5],
               [cx+18, ground-stemH*0.68], [cx-14, ground-stemH*0.82],
               [cx+8,  ground-stemH*0.4]].slice(0, spotCount).forEach(([sx, sy]) => {
                svg += `<circle cx="${sx}" cy="${sy}" r="${2+sickPct*2}" fill="#7a4a1a" opacity="${0.4+sickPct*0.4}"/>`;
              });
            }

            // stem sag — stem leans more when wilted
            if (wilted) {
              svg += `<path d="M${cx},${ground+2} Q${cx+12},${ground-stemH*0.4} ${cx+6},${stemTop+stemH*0.15}"
                fill="none" stroke="${stemC}" stroke-width="1.5" opacity=".25"/>`;
            }

            // yellow/brown leaf veins at health < 15
            if (health < 15) {
              [[cx+2, ground-stemH*0.35, 1], [cx-2, ground-stemH*0.55, -1]].forEach(([lx, ly, dir]) => {
                svg += `<path d="M${lx},${ly} L${lx+dir*12},${ly-6}"
                  fill="none" stroke="#8b6914" stroke-width="0.8" opacity=".6"/>`;
                svg += `<path d="M${lx+dir*5},${ly-3} L${lx+dir*10},${ly-9}"
                  fill="none" stroke="#8b6914" stroke-width="0.6" opacity=".4"/>`;
              });
            }
          }

          svg += `</svg>`;
          return svg;
        }

        // ── Garden tab render ─────────────────────────────────────────────────
        async function loadGarden() {
          const cont = body.querySelector('#sm-content');
          cont.innerHTML = `<div class="sm-no-data">${_smt('loading')}</div>`;
          try {
            const r = await fetch('/api/apps/server-monitor/plant');
            if (!r.ok) throw new Error(r.status);
            const p = await r.json();
            renderGarden(p);
          } catch(e) {
            cont.innerHTML = `<div class="sm-no-data">${_smt('error')}</div>`;
          }
        }

        function renderGarden(p) {
          const cont = body.querySelector('#sm-content');
          const archive  = p.archive ?? [];
          const gen      = p.generation ?? 1;
          const seed     = p.seed ?? 0;
          const plantName = p.name ?? 'Lumivex';

          // ── Seed screen ────────────────────────────────────────────────────
          if (!p.started) {
            const archiveHtml = archive.length ? `
              <div style="margin-top:24px;width:100%;max-width:520px">
                <div style="font-size:.7rem;color:#475569;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px">Архивирани растения</div>
                <div style="display:flex;flex-wrap:wrap;gap:12px;justify-content:center">
                  ${archive.map(a => `
                    <div style="text-align:center;background:#1e2433;border-radius:10px;padding:10px 14px">
                      <div style="font-size:.65rem;color:#60a5fa;font-weight:600;margin-bottom:4px">#${a.generation} ${a.name}</div>
                      ${drawPlant(100, a.health, a.seed)}
                      <div style="font-size:.6rem;color:#475569;margin-top:4px">${a.days} ${_smt('days_label')} · health ${a.health}%</div>
                    </div>`).join('')}
                </div>
              </div>` : '';

            cont.innerHTML = `
              <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100%;gap:16px;padding:20px">
                <div style="opacity:.4">${drawPlant(0, 100, seed)}</div>
                <div style="text-align:center">
                  <div style="font-size:.7rem;color:#60a5fa;margin-bottom:4px;font-weight:600">#${gen} ${plantName}</div>
                  <div style="font-size:1rem;color:#e2e8f0;margin-bottom:6px">${_smt('seed_title')}</div>
                  <div style="font-size:.8rem;color:#64748b;margin-bottom:20px">${_smt('seed_sub')}</div>
                  <button id="sm-plant-btn" style="background:#22c55e;color:#fff;border:none;border-radius:8px;padding:10px 24px;font-size:.9rem;cursor:pointer;font-weight:600">
                    🌱 ${_smt('plant_btn')}
                  </button>
                </div>
                ${archiveHtml}
              </div>`;
            cont.querySelector('#sm-plant-btn').addEventListener('click', async () => {
              await fetch('/api/apps/server-monitor/plant/plant', { method: 'POST' });
              loadGarden();
            });
            return;
          }

          const growth = p.growth ?? 0;
          const health = p.health ?? 100;
          const stage  = growth < 3  ? _smt('stage_seed')   :
                         growth < 20 ? _smt('stage_sprout')  :
                         growth < 40 ? _smt('stage_young')   :
                         growth < 60 ? _smt('stage_mature')  :
                         growth < 80 ? _smt('stage_bloom')   : _smt('stage_tree');

          const hColor = health > 60 ? '#22c55e' : health > 30 ? '#f59e0b' : '#ef4444';
          const gColor = '#3b82f6';
          const lastLog   = p.log?.[p.log.length - 1];
          const dailyRate = lastLog ? (lastLog.growth_delta * 24).toFixed(2) : '—';
          const boostMins = Math.ceil((p.boost_remaining ?? 0) / 60);
          const lastCpu   = lastLog?.cpu  ?? null;
          const lastRam   = lastLog?.ram  ?? null;
          const lastDisk  = lastLog?.disk ?? null;
          const lastNetMb = lastLog?.net_mb ?? null; // MB/min avg → *60 = MB/hr

          // compute effects (same formulas as backend)
          function _fmtEff(val, pos) {
            if (val === null) return '—';
            const s = (val >= 0 ? '+' : '') + val.toFixed(3) + '%/ч';
            return `<span style="color:${val > 0 ? '#22c55e' : val < 0 ? '#ef4444' : '#64748b'}">${s}</span>`;
          }
          let cpuEffect = null, ramMod = null, diskEffect = null, dlBonus = null, ulBonus = null;
          if (lastCpu !== null) {
            cpuEffect = -((lastCpu - 20) / 80) * (100 / 24);
            ramMod    = lastRam !== null ? ((lastRam - 50) / 50) * 0.5 : 0;
            cpuEffect = cpuEffect * (1 + ramMod);
            if (p.boost_active && cpuEffect < 0) cpuEffect = 0;
          }
          if (lastDisk !== null) {
            const diskMult = 1 - Math.max(0, (lastDisk - 50) / 50);
            diskEffect = (1/24) * diskMult - (1/24); // deviation from base
          }
          if (lastNetMb !== null) {
            const netHr = lastNetMb * 60;
            dlBonus = Math.min(3, netHr / 100);
            ulBonus = Math.min(3, netHr / 100);
          }

          const canArchive = growth >= 100 && health >= 70;
          const boostHours = Math.round((p.boost_remaining ?? 0) / 3600 * 10) / 10;

          // archived list html
          const archiveListHtml = archive.length ? `
            <div style="background:#1e2433;border-radius:10px;padding:12px 14px">
              <div style="font-size:.7rem;color:#475569;text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">${_smt('archive_label')}</div>
              <div style="display:flex;flex-direction:column;gap:8px">
                ${archive.map(a => `
                  <div style="display:flex;align-items:center;gap:10px">
                    <div style="flex-shrink:0;transform:scale(0.4);transform-origin:left center;width:80px;height:50px;overflow:visible">
                      ${drawPlant(100, a.health, a.seed)}
                    </div>
                    <div>
                      <div style="font-size:.75rem;color:#60a5fa;font-weight:600">#${a.generation} ${a.name}</div>
                      <div style="font-size:.65rem;color:#64748b">${a.days} ${_smt('days_label')} · health ${a.health}%</div>
                    </div>
                  </div>`).join('')}
              </div>
            </div>` : '';

          cont.innerHTML = `
            <div style="display:flex;gap:16px;padding:4px 0;height:100%;box-sizing:border-box;flex-wrap:wrap">

              <!-- Plant visual -->
              <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:200px;flex:0 0 auto;gap:8px">
                <div style="font-size:.65rem;color:#60a5fa;font-weight:600">#${gen} ${plantName}</div>
                <div style="font-size:.7rem;color:#64748b;text-transform:uppercase;letter-spacing:.05em">${stage}</div>
                <div id="sm-plant-svg" style="cursor:${p.boost_active ? 'default' : 'pointer'}" title="${p.boost_active ? _smt('boost_active') : _smt('water_btn')}">
                  ${drawPlant(growth, health, seed)}
                </div>
                ${p.boost_active
                  ? `<div style="font-size:.75rem;color:#60a5fa;background:#1e3a5f;padding:4px 10px;border-radius:20px">
                       💧 ${_smt('boost_active')} — ${boostHours}ч
                     </div>`
                  : `<button id="sm-water-btn" style="background:#1e3a5f;color:#60a5fa;border:1px solid #2563eb;border-radius:8px;padding:6px 16px;font-size:.8rem;cursor:pointer">
                       ${_smt('water_btn')}
                     </button>`
                }
                ${canArchive ? `
                  <button id="sm-archive-btn" style="background:#854d0e;color:#fde68a;border:1px solid #a16207;border-radius:8px;padding:6px 14px;font-size:.78rem;cursor:pointer;font-weight:600">
                    🏆 Архивирай
                  </button>` : ''}
              </div>

              <!-- Stats -->
              <div style="flex:1;min-width:200px;display:flex;flex-direction:column;gap:10px;overflow-y:auto">

                <div style="background:#1e2433;border-radius:10px;padding:12px 14px">
                  <div style="font-size:.7rem;color:#475569;text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">${_smt('health_lbl')} & ${_smt('growth_lbl')}</div>
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
                    <div>
                      <div style="font-size:.7rem;color:#64748b">${_smt('health_lbl')}</div>
                      <div style="font-size:1.6rem;font-weight:700;color:${hColor}">${health.toFixed(1)}%</div>
                      <div style="height:4px;background:#263142;border-radius:2px;margin-top:4px">
                        <div style="height:4px;width:${health}%;background:${hColor};border-radius:2px;transition:width .4s"></div>
                      </div>
                    </div>
                    <div>
                      <div style="font-size:.7rem;color:#64748b">${_smt('growth_lbl')}</div>
                      <div style="font-size:1.6rem;font-weight:700;color:${gColor}">${growth.toFixed(1)}%</div>
                      <div style="height:4px;background:#263142;border-radius:2px;margin-top:4px">
                        <div style="height:4px;width:${growth}%;background:${gColor};border-radius:2px;transition:width .4s"></div>
                      </div>
                    </div>
                  </div>
                  <div style="margin-top:8px;font-size:.75rem;color:#64748b">
                    ${_smt('daily_rate')}: <span style="color:#e2e8f0;font-weight:600">${dailyRate}% / ден</span>
                  </div>
                </div>

                <div style="background:#1e2433;border-radius:10px;padding:12px 14px">
                  <div style="font-size:.7rem;color:#475569;text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">
                    ${_smt('influence')}
                    ${!lastLog ? `<span style="color:#334155;font-weight:400;text-transform:none">${_smt('waiting_first')}</span>` : ''}
                  </div>
                  <div style="display:flex;flex-direction:column;gap:5px;font-size:.75rem">

                    <div style="display:grid;grid-template-columns:80px 1fr 1fr;gap:4px;align-items:center">
                      <span style="color:#475569">${_smt('metric')}</span>
                      <span style="color:#475569">${_smt('value')}</span>
                      <span style="color:#475569">${_smt('effect')}</span>
                    </div>
                    <div style="height:1px;background:#263142;margin:2px 0"></div>

                    <div style="display:grid;grid-template-columns:80px 1fr 1fr;gap:4px;align-items:center">
                      <span style="color:#64748b">CPU</span>
                      <span style="color:${lastCpu!==null?(lastCpu>60?'#ef4444':lastCpu>20?'#f59e0b':'#22c55e'):'#334155'}">${lastCpu !== null ? lastCpu.toFixed(1)+'%' : '—'}</span>
                      <span style="font-size:.7rem">${cpuEffect !== null ? _fmtEff(cpuEffect) : '—'} <span style="color:#334155">${_smt('on_health')}</span></span>
                    </div>

                    <div style="display:grid;grid-template-columns:80px 1fr 1fr;gap:4px;align-items:center">
                      <span style="color:#64748b">RAM</span>
                      <span style="color:${lastRam!==null?(lastRam>80?'#ef4444':lastRam>50?'#f59e0b':'#22c55e'):'#334155'}">${lastRam !== null ? lastRam.toFixed(1)+'%' : '—'}</span>
                      <span style="font-size:.7rem;color:#64748b">${lastRam !== null
                        ? (Math.abs(ramMod) < 0.01 ? _smt('ram_neutral')
                          : ramMod > 0 ? `+${(ramMod*100).toFixed(0)}% ${_smt('ram_cpu_more')}`
                          : `${(ramMod*100).toFixed(0)}% ${_smt('ram_cpu_less')}`)
                        : '—'}</span>
                    </div>

                    <div style="display:grid;grid-template-columns:80px 1fr 1fr;gap:4px;align-items:center">
                      <span style="color:#64748b">Disk</span>
                      <span style="color:${lastDisk!==null?(lastDisk>80?'#ef4444':lastDisk>50?'#f59e0b':'#22c55e'):'#334155'}">${lastDisk !== null ? lastDisk.toFixed(1)+'%' : '—'}</span>
                      <span style="font-size:.7rem">${lastDisk !== null
                        ? (lastDisk > 50
                          ? `<span style="color:#ef4444">${_smt('disk_slow')}${((lastDisk-50)/50*100).toFixed(0)}%</span>`
                          : `<span style="color:#22c55e">+${(1/24).toFixed(3)}%/h ${_smt('on_growth')}</span>`)
                        : '—'}</span>
                    </div>

                    <div style="display:grid;grid-template-columns:80px 1fr 1fr;gap:4px;align-items:center">
                      <span style="color:#64748b">Net↓</span>
                      <span style="color:#94a3b8">${lastNetMb !== null ? (lastNetMb*60).toFixed(1)+' MB/h' : '—'}</span>
                      <span style="font-size:.7rem">${dlBonus !== null ? _fmtEff(dlBonus) : '—'} <span style="color:#334155">${_smt('on_health')}</span></span>
                    </div>

                    <div style="display:grid;grid-template-columns:80px 1fr 1fr;gap:4px;align-items:center">
                      <span style="color:#64748b">Net↑</span>
                      <span style="color:#94a3b8">${lastNetMb !== null ? (lastNetMb*60).toFixed(1)+' MB/h' : '—'}</span>
                      <span style="font-size:.7rem">${ulBonus !== null ? _fmtEff(ulBonus) : '—'} <span style="color:#334155">${_smt('on_growth')}</span></span>
                    </div>

                  </div>
                  ${p.boost_active ? `
                    <div style="margin-top:8px;padding-top:8px;border-top:1px solid #263142;font-size:.72rem;color:#60a5fa">
                      💧 ${_smt('boost_status').replace('{h}', boostHours)}
                    </div>` : ''}
                </div>

                ${archiveListHtml}

                <div style="display:flex;gap:6px">
                  <button id="sm-widget-btn" style="flex:1;background:#1e2433;border:1px solid #334155;color:#94a3b8;border-radius:8px;padding:8px 14px;font-size:.78rem;cursor:pointer;text-align:left">
                    ${_smt('add_widget')}
                  </button>
                  <button id="sm-taskbar-btn" style="flex:1;background:#1e2433;border:1px solid #334155;color:#94a3b8;border-radius:8px;padding:8px 14px;font-size:.78rem;cursor:pointer;text-align:left">
                    🌱 Add to taskbar
                  </button>
                  <button id="sm-preview-btn" style="background:#1e2433;border:1px solid #334155;color:#64748b;border-radius:8px;padding:8px 12px;font-size:.78rem;cursor:pointer" title="Preview">
                    🔍
                  </button>
                </div>
              </div>
            </div>`;

          // water button
          cont.querySelector('#sm-water-btn')?.addEventListener('click', async () => {
            await fetch('/api/apps/server-monitor/plant/water', { method: 'POST' });
            mvmOS.notify('Bit Garden', _smt('watered'));
            loadGarden();
          });

          // click on plant = water shortcut
          cont.querySelector('#sm-plant-svg')?.addEventListener('click', async () => {
            if (p.boost_active) return;
            await fetch('/api/apps/server-monitor/plant/water', { method: 'POST' });
            mvmOS.notify('Bit Garden', _smt('watered'));
            loadGarden();
          });

          // archive button
          cont.querySelector('#sm-archive-btn')?.addEventListener('click', async () => {
            const ok = await mvmOS.confirm(`Архивирай ${plantName}?\n\nРастението ще се запази в архива и ще започне ново.`);
            if (!ok) return;
            const r = await fetch('/api/apps/server-monitor/plant/archive', { method: 'POST' });
            const d = await r.json();
            if (d.ok) {
              mvmOS.notify('Bit Garden', `${plantName} е архивиран! Започва поколение #${d.generation}.`);
              loadGarden();
            } else {
              mvmOS.notify('Bit Garden', d.reason ?? 'Грешка');
            }
          });

          // preview button
          cont.querySelector('#sm-preview-btn')?.addEventListener('click', () => {
            const existing = body.querySelector('#sm-modal');
            if (existing) existing.remove();

            const PHASES = [
              { g:  0, label: '0%'  }, { g:  3, label: '3%'  }, { g:  7, label: '7%'  },
              { g: 15, label: '15%' }, { g: 25, label: '25%' }, { g: 35, label: '35%' },
              { g: 45, label: '45%' }, { g: 55, label: '55%' }, { g: 65, label: '65%' },
              { g: 75, label: '75%' }, { g: 85, label: '85%' }, { g: 95, label: '95%' },
              { g:100, label: '100%'},
            ];

            const HEALTHS = [
              { h: 100, label: '100% здраво',  col: '#22c55e' },
              { h:  50, label: '50% нормално', col: '#f59e0b' },
              { h:  25, label: '25% болно',    col: '#f97316' },
              { h:  15, label: '15% много болно', col: '#ef4444' },
              { h:   5, label: '5% умира',     col: '#7f1d1d' },
            ];

            const stagesRow = PHASES.map(ph => `
              <div style="text-align:center">
                <div style="font-size:.6rem;color:#475569;margin-bottom:2px">${ph.label}</div>
                ${drawPlant(ph.g, 100, 42)}
              </div>`).join('');

            const healthRow = HEALTHS.map(hs => `
              <div style="text-align:center">
                <div style="font-size:.6rem;color:${hs.col};margin-bottom:2px;white-space:nowrap">${hs.label}</div>
                ${drawPlant(70, hs.h, 42)}
              </div>`).join('');

            const modal = document.createElement('div');
            modal.id = 'sm-modal';
            modal.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,.75);z-index:100;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(3px)';
            modal.innerHTML = `
              <div style="background:#0f1117;border:1px solid #1e2433;border-radius:14px;width:95%;max-width:960px;max-height:88%;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 24px 64px rgba(0,0,0,.7)">
                <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid #1e2433">
                  <span style="font-weight:700;font-size:.9rem">🌱 Plant Preview</span>
                  <button id="sm-modal-close" style="background:none;border:none;color:#64748b;font-size:1.2rem;cursor:pointer">✕</button>
                </div>
                <div style="overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:20px">
                  <div>
                    <div style="font-size:.7rem;color:#475569;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px">Фази на растежа</div>
                    <div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center">${stagesRow}</div>
                  </div>
                  <div>
                    <div style="font-size:.7rem;color:#475569;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px">Здравословни състояния (70% растеж)</div>
                    <div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center">${healthRow}</div>
                  </div>
                </div>
              </div>`;
            modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
            modal.querySelector('#sm-modal-close').addEventListener('click', () => modal.remove());
            body.style.position = 'relative';
            body.appendChild(modal);
          });

          // add widget button — install as proper widget (persists across reloads)
          cont.querySelector('#sm-widget-btn')?.addEventListener('click', async () => {
            const btn = cont.querySelector('#sm-widget-btn');
            btn.disabled = true;
            try {
              const r = await fetch('/api/widgets/install', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  id:          'server-monitor-garden',
                  name:        'Bit Garden',
                  icon:        '🌱',
                  category:    'System',
                  version:     '1.0.0',
                  description: 'Server plant that grows based on server health',
                  widget_type: 'desktop',
                  js_url:      window.location.origin + '/apps/server-monitor/widget.js',
                }),
              });
              if (r.ok) {
                // load & register immediately without page reload
                window._bgwRegistered = false;
                const s = document.createElement('script');
                s.src = '/apps/server-monitor/widget.js?_=' + Date.now();
                document.head.appendChild(s);
                btn.textContent = '✓ ' + _smt('add_widget');
                mvmOS.notify('Bit Garden', _smt('add_widget'));
              }
            } catch(e) {
              btn.disabled = false;
            }
          });
          // taskbar widget install button
          cont.querySelector('#sm-taskbar-btn')?.addEventListener('click', async () => {
            const btn = cont.querySelector('#sm-taskbar-btn');
            btn.disabled = true;
            try {
              const r = await fetch('/api/widgets/install', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  id:          'server-monitor-garden-taskbar',
                  name:        'Bit Garden (taskbar)',
                  icon:        '🌱',
                  category:    'System',
                  version:     '1.0.0',
                  description: 'Bit Garden taskbar widget',
                  widget_type: 'taskbar',
                  js_url:      window.location.origin + '/apps/server-monitor/widget.js',
                }),
              });
              if (r.ok) {
                window._bgwRegistered = false;
                const s = document.createElement('script');
                s.src = '/apps/server-monitor/widget.js?_=' + Date.now();
                document.head.appendChild(s);
                btn.textContent = '✓ Taskbar';
                mvmOS.notify('Bit Garden', 'Taskbar widget added!');
              }
            } catch(e) {
              btn.disabled = false;
            }
          });
        }

        // ── Render functions per tab ──────────────────────────────────────────
        function renderCpu(data) {
          const pts = data.points;
          if (!pts.length) return `<div class="sm-no-data">${_smt('no_data')}</div>`;
          return chartBlock(_smt('cpu_pct'),  pts, 'cpu',    '#3b82f6')
               + chartBlock(_smt('load_1m'),  pts, 'load1',  '#8b5cf6', '')
               + chartBlock(_smt('load_5m'),  pts, 'load5',  '#6366f1', '')
               + chartBlock(_smt('load_15m'), pts, 'load15', '#4f46e5', '');
        }

        function renderRam(data) {
          const pts = data.points;
          if (!pts.length) return `<div class="sm-no-data">${_smt('no_data')}</div>`;
          return chartBlock(_smt('ram_used'),  pts, 'ram_used_pct',  '#22c55e')
               + chartBlock(_smt('swap_used'), pts, 'swap_used_pct', '#f59e0b');
        }

        function renderDisk(data) {
          const pts = data.points;
          if (!pts.length) return `<div class="sm-no-data">${_smt('no_data')}</div>`;
          return chartBlock(_smt('disk_used'),  pts, 'disk_used_pct',  '#f97316')
               + chartBlock(_smt('read_mbs'),  pts, 'disk_read_mb',  '#06b6d4', ' MB/s')
               + chartBlock(_smt('write_mbs'), pts, 'disk_write_mb', '#8b5cf6', ' MB/s');
        }

        function renderNet(data) {
          const pts = data.points;
          if (!pts.length) return `<div class="sm-no-data">${_smt('no_data')}</div>`;
          return chartBlock(_smt('net_in_mbs'),  pts, 'net_in_mb',  '#22c55e', ' MB/s')
               + chartBlock(_smt('net_out_mbs'), pts, 'net_out_mb', '#ef4444', ' MB/s');
        }

        function renderSensors(data) {
          const pts = data.points;
          const hasSensors = pts.some(p => p.avg_temp_max != null);
          if (!hasSensors) {
            return `<div class="sm-no-data">🌡️<br><br>${_smt('no_sensors')}</div>`;
          }
          return chartBlock(_smt('temp_max'), pts, 'temp_max', '#f43f5e', '°C');
        }

        const RENDERERS = { cpu: renderCpu, ram: renderRam, disk: renderDisk, net: renderNet, sensors: renderSensors };

        // ── Load & render ─────────────────────────────────────────────────────
        async function loadTab() {
          // garden has its own loader
          if (activeTab === 'garden') { loadGarden(); return; }

          const key = activeTab + '_' + activePeriod;
          const cont = body.querySelector('#sm-content');

          if (cache[key]) {
            cont.innerHTML = RENDERERS[activeTab](cache[key]);
            return;
          }

          cont.innerHTML = `<div class="sm-no-data">${_smt('loading')}</div>`;

          try {
            const r = await fetch(`/api/apps/server-monitor/metrics?period=${activePeriod}`);
            if (!r.ok) throw new Error(r.status);
            const data = await r.json();
            cache[key] = data;
            cont.innerHTML = RENDERERS[activeTab](data);
          } catch(e) {
            cont.innerHTML = `<div class="sm-no-data">${_smt('error')}</div>`;
          }
        }

        // ── Period bar visibility — hide for garden tab ───────────────────────
        function updatePeriodBar() {
          body.querySelector('#sm-periods').style.display = activeTab === 'garden' ? 'none' : '';
        }

        // patch tab click to also toggle period bar
        tabsEl.querySelectorAll('.sm-tab').forEach(btn => {
          btn.addEventListener('click', updatePeriodBar);
        });

        // ── Auto-refresh every 60s ────────────────────────────────────────────
        updatePeriodBar();
        loadTab();
        refreshTimer = setInterval(() => {
          cache = {};
          loadTab();
        }, 60000);

        // cleanup
        body._smCleanup = () => clearInterval(refreshTimer);
      }
    });
  }
});
