// YourSQL — SQL Query editor

YS.query = (() => {

  function show(container) {
    if (!YS.state.activeConn) return;
    var content = container.querySelector('#ysql-content');
    if (!content) return;
    var esc = YS.escHtml;

    content.innerHTML =
      '<div style="display:flex;flex-direction:column;width:100%;overflow:hidden">' +
        '<div style="display:flex;gap:6px;padding:6px 10px;border-bottom:1px solid var(--border);align-items:center;flex-shrink:0">' +
          '<span style="font-size:.82rem;font-weight:500;color:var(--text-dim)">⌨️ SQL Query</span>' +
          '<span style="flex:1"></span>' +
          '<span style="font-size:.72rem;color:var(--text-dim)">Ctrl+Enter</span>' +
          '<button class="s-btn s-btn-sm" id="ysql-sql-clear" style="font-size:.78rem">Clear</button>' +
          '<button class="s-btn s-btn-sm" id="ysql-run-btn" style="background:var(--accent);color:#fff;border-color:var(--accent)">▶ Run</button>' +
        '</div>' +
        '<textarea id="ysql-sql-editor" style="flex:none;height:140px;resize:vertical;padding:10px;font-family:monospace;font-size:.85rem;border:none;border-bottom:1px solid var(--border);background:var(--bg);color:var(--text);outline:none;box-sizing:border-box;width:100%" placeholder="SELECT * FROM table LIMIT 100;\n\nCtrl+Enter to run" spellcheck="false"></textarea>' +
        '<div id="ysql-sql-result" style="flex:1;overflow:auto;padding:4px 0"></div>' +
      '</div>';

    content.querySelector('#ysql-run-btn').addEventListener('click', function() { _run(content); });
    content.querySelector('#ysql-sql-clear').addEventListener('click', function() {
      content.querySelector('#ysql-sql-editor').value = '';
      content.querySelector('#ysql-sql-result').innerHTML = '';
    });
    content.querySelector('#ysql-sql-editor').addEventListener('keydown', function(e) {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); _run(content); }
      // Tab → indent
      if (e.key === 'Tab') {
        e.preventDefault();
        var ta = this, s = ta.selectionStart, e2 = ta.selectionEnd;
        ta.value = ta.value.substring(0,s) + '  ' + ta.value.substring(e2);
        ta.selectionStart = ta.selectionEnd = s + 2;
      }
    });
  }

  async function _run(content) {
    var sql = content.querySelector('#ysql-sql-editor').value.trim();
    if (!sql || !YS.state.activeConn) return;
    var result = content.querySelector('#ysql-sql-result');
    result.innerHTML = '<div style="padding:10px;color:var(--text-dim);display:flex;align-items:center;gap:8px"><div style="width:14px;height:14px;border:2px solid var(--accent);border-top-color:transparent;border-radius:50%;animation:spin 0.8s linear infinite"></div> Running…</div>';

    var r = await YS.api('/query', { method: 'POST', json: {
      conn_id: YS.state.activeConn.id,
      database: YS.state.activeDb || '',
      sql: sql
    }}).catch(function(e){ return { error: e.message }; });

    if (r.detail || r.error) {
      result.innerHTML = '<div style="padding:10px;color:#f38ba8;font-family:monospace;font-size:.82rem;white-space:pre-wrap">' + YS.escHtml(r.detail || r.error) + '</div>';
      return;
    }

    if (r.affected !== null && r.affected !== undefined) {
      result.innerHTML = '<div style="padding:10px;color:#50fa7b;font-size:.85rem">✓ Query OK — ' + r.affected + ' row(s) affected</div>';
      return;
    }

    if (!r.columns || !r.columns.length) {
      result.innerHTML = '<div style="padding:10px;color:var(--text-dim)">No results</div>';
      return;
    }

    var esc = YS.escHtml;
    var wrap = document.createElement('div');
    wrap.style.cssText = 'overflow:auto;height:100%';

    var info = document.createElement('div');
    info.style.cssText = 'padding:4px 10px;font-size:.75rem;color:var(--text-dim)';
    info.textContent = r.rows.length + ' row(s)';
    wrap.appendChild(info);

    var table = document.createElement('table');
    table.style.cssText = 'border-collapse:collapse;width:100%;font-size:.82rem;white-space:nowrap';
    table.innerHTML =
      '<thead><tr style="position:sticky;top:0;background:var(--surface)">' +
        r.columns.map(function(c){ return '<th style="padding:6px 10px;border-bottom:2px solid var(--border);text-align:left">' + esc(c) + '</th>'; }).join('') +
      '</tr></thead>' +
      '<tbody>' +
        r.rows.map(function(row) {
          return '<tr style="border-bottom:1px solid var(--border)">' +
            r.columns.map(function(col) {
              var v = row[col];
              if (v === null) return '<td style="padding:5px 10px;color:var(--text-dim);font-style:italic">NULL</td>';
              var s = String(v);
              var style = 'padding:5px 10px;max-width:300px;overflow:hidden;text-overflow:ellipsis';
              if (/^-?\d+(\.\d+)?$/.test(s)) style += ';color:var(--color-num,#8be9fd)';
              else if (/^\d{4}-\d{2}-\d{2}/.test(s)) style += ';color:var(--color-date,#f1fa8c)';
              return '<td style="' + style + '" title="' + esc(s) + '">' + esc(s) + '</td>';
            }).join('') +
          '</tr>';
        }).join('') +
      '</tbody>';

    wrap.appendChild(table);
    result.innerHTML = '';
    result.appendChild(wrap);
  }

  return { show };
})();
