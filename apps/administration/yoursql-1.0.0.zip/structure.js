// YourSQL — Table structure view

YS.structure = (() => {

  async function show(container, content) {
    content.innerHTML = '<div style="flex:1;display:flex;align-items:center;justify-content:center;color:var(--text-dim)">Loading structure…</div>';
    var esc = YS.escHtml;

    var data = await YS.api('/table-structure?conn_id=' + YS.state.activeConn.id +
      '&database=' + encodeURIComponent(YS.state.activeDb) +
      '&table=' + encodeURIComponent(YS.state.activeTable)).catch(function(){ return {}; });

    var cols = data.columns || [];
    var indexes = data.indexes || [];

    content.innerHTML =
      '<div style="display:flex;flex-direction:column;width:100%;overflow:hidden">' +
        '<div style="display:flex;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid var(--border);flex-shrink:0">' +
          '<span style="font-size:.82rem;font-weight:500">⚙ Structure — ' + esc(YS.state.activeTable) + '</span>' +
          '<span style="flex:1"></span>' +
          '<button class="s-btn s-btn-sm" id="ysql-struct-back">← Back to Data</button>' +
        '</div>' +
        '<div style="display:flex;gap:0;border-bottom:1px solid var(--border);flex-shrink:0">' +
          '<button class="s-btn s-btn-sm struct-tab active" data-tab="cols" style="border-radius:0;border:none;border-bottom:2px solid var(--accent)">Columns</button>' +
          '<button class="s-btn s-btn-sm struct-tab" data-tab="idx" style="border-radius:0;border:none;border-bottom:2px solid transparent">Indexes</button>' +
        '</div>' +
        '<div id="ysql-struct-body" style="overflow:auto;flex:1;padding:8px 10px"></div>' +
      '</div>';

    content.querySelector('#ysql-struct-back').addEventListener('click', function() {
      YS.browse.show(container);
    });

    var tabs = content.querySelectorAll('.struct-tab');
    tabs.forEach(function(tab) {
      tab.addEventListener('click', function() {
        tabs.forEach(function(t){ t.style.borderBottomColor='transparent'; t.classList.remove('active'); });
        tab.style.borderBottomColor='var(--accent)'; tab.classList.add('active');
        if (tab.dataset.tab === 'cols') _renderColumns(content, cols);
        else _renderIndexes(content, indexes);
      });
    });

    _renderColumns(content, cols);
  }

  function _renderColumns(content, cols) {
    var body = content.querySelector('#ysql-struct-body');
    var esc = YS.escHtml;

    if (!cols.length) { body.innerHTML = '<div style="color:var(--text-dim);padding:10px">No columns</div>'; return; }

    var html = '<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:.82rem;white-space:nowrap">' +
      '<thead><tr style="background:var(--surface)">' +
      ['Field','Type','Null','Key','Default','Extra','Comment'].map(function(h){
        return '<th style="padding:6px 10px;border-bottom:2px solid var(--border);text-align:left">' + h + '</th>';
      }).join('') +
      '</tr></thead><tbody>';

    cols.forEach(function(c) {
      var isPK = c.Key === 'PRI';
      html += '<tr style="border-bottom:1px solid var(--border)">' +
        '<td style="padding:5px 10px;font-weight:' + (isPK?'600':'400') + ';color:' + (isPK?'var(--accent)':'') + '">' + esc(c.Field) + '</td>' +
        '<td style="padding:5px 10px;color:var(--color-num,#8be9fd)">' + esc(c.Type) + '</td>' +
        '<td style="padding:5px 10px">' + esc(c.Null||'') + '</td>' +
        '<td style="padding:5px 10px">' + (isPK?'<span style="color:var(--accent);font-size:.75rem">PRI</span>':esc(c.Key||'')) + '</td>' +
        '<td style="padding:5px 10px;color:var(--text-dim)">' + esc(c.Default==null?'NULL':c.Default) + '</td>' +
        '<td style="padding:5px 10px;color:var(--text-dim)">' + esc(c.Extra||'') + '</td>' +
        '<td style="padding:5px 10px;color:var(--text-dim)">' + esc(c.Comment||'') + '</td>' +
        '</tr>';
    });

    html += '</tbody></table></div>';
    body.innerHTML = html;
  }

  function _renderIndexes(content, indexes) {
    var body = content.querySelector('#ysql-struct-body');
    var esc = YS.escHtml;

    if (!indexes.length) { body.innerHTML = '<div style="color:var(--text-dim);padding:10px">No indexes</div>'; return; }

    // group by Key_name
    var groups = {};
    indexes.forEach(function(ix) {
      var name = ix.Key_name;
      if (!groups[name]) groups[name] = [];
      groups[name].push(ix);
    });

    var html = '<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:.82rem;white-space:nowrap">' +
      '<thead><tr style="background:var(--surface)">' +
      ['Name','Type','Column(s)','Unique','Comment'].map(function(h){
        return '<th style="padding:6px 10px;border-bottom:2px solid var(--border);text-align:left">' + h + '</th>';
      }).join('') +
      '</tr></thead><tbody>';

    Object.keys(groups).forEach(function(name) {
      var rows = groups[name];
      var first = rows[0];
      var cols = rows.map(function(r){return r.Column_name;}).join(', ');
      var isPK = name === 'PRIMARY';
      var isUniq = first.Non_unique == 0;
      html += '<tr style="border-bottom:1px solid var(--border)">' +
        '<td style="padding:5px 10px;color:' + (isPK?'var(--accent)':'') + '">' + esc(name) + '</td>' +
        '<td style="padding:5px 10px;font-size:.78rem">' + esc(first.Index_type||'BTREE') + '</td>' +
        '<td style="padding:5px 10px">' + esc(cols) + '</td>' +
        '<td style="padding:5px 10px">' + (isUniq?'<span style="color:#50fa7b">✓</span>':'') + '</td>' +
        '<td style="padding:5px 10px;color:var(--text-dim)">' + esc(first.Comment||'') + '</td>' +
        '</tr>';
    });

    html += '</tbody></table></div>';
    body.innerHTML = html;
  }

  return { show };
})();
