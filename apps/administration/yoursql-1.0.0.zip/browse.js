// YourSQL — Table browser

YS.browse = (() => {

  function showWelcome(container) {
    const content = container.querySelector('#ysql-content');
    if (!content) return;
    if (!YS.state.activeDb) {
      content.innerHTML = '<div style="flex:1;display:flex;align-items:center;justify-content:center;color:var(--text-dim);flex-direction:column;gap:8px"><div style="font-size:2rem">🗄️</div><div>Select a database to get started</div></div>';
      return;
    }
    content.innerHTML = '<div style="flex:1;display:flex;align-items:center;justify-content:center;color:var(--text-dim);flex-direction:column;gap:8px"><div style="font-size:2rem">📋</div><div>Select a table from the sidebar</div></div>';
  }

  async function show(container) {
    const content = container.querySelector('#ysql-content');
    if (!content || !YS.state.activeConn || !YS.state.activeDb || !YS.state.activeTable) return;

    // reset page/filters on new table
    YS.state.page = 1;
    YS.state.filters = [];
    YS.state.sort = [];
    YS.state.selection = { mode: 'none', pageRows: [] };

    content.innerHTML = '<div style="flex:1;display:flex;align-items:center;justify-content:center;color:var(--text-dim)">Loading…</div>';

    // load structure first for colMeta
    try {
      const struct = await YS.api('/table-structure?conn_id=' + YS.state.activeConn.id +
        '&database=' + encodeURIComponent(YS.state.activeDb) +
        '&table=' + encodeURIComponent(YS.state.activeTable));
      YS.state.colMeta = YS.parseColMeta(struct.columns || []);
    } catch(e) { YS.state.colMeta = {}; }

    _renderBrowse(container, content);
    await _loadData(container, content);
  }

  function _renderBrowse(container, content) {
    content.innerHTML =
      '<div style="display:flex;flex-direction:column;width:100%;overflow:hidden">' +
        '<div id="ysql-browse-toolbar" style="display:flex;align-items:center;gap:6px;padding:6px 8px;border-bottom:1px solid var(--border);flex-shrink:0;flex-wrap:wrap"></div>' +
        '<div id="ysql-filter-bar" style="flex-shrink:0"></div>' +
        '<div style="overflow:auto;flex:1" id="ysql-table-wrap">' +
          '<table id="ysql-table" style="border-collapse:collapse;width:100%;font-size:.82rem;white-space:nowrap">' +
            '<thead id="ysql-thead"></thead>' +
            '<tbody id="ysql-tbody"></tbody>' +
          '</table>' +
        '</div>' +
        '<div id="ysql-pagination" style="display:flex;align-items:center;gap:8px;padding:6px 10px;border-top:1px solid var(--border);font-size:.8rem;color:var(--text-dim);flex-shrink:0"></div>' +
      '</div>';

    _renderToolbar(container, content);
  }

  function _renderToolbar(container, content) {
    const tb = content.querySelector('#ysql-browse-toolbar');
    const esc = YS.escHtml;
    tb.innerHTML =
      '<span style="font-size:.82rem;font-weight:500;color:var(--text-dim)">▤ ' + esc(YS.state.activeTable) + '</span>' +
      '<button class="s-btn s-btn-sm" id="ysql-btn-insert" style="background:var(--accent);color:#fff;border-color:var(--accent)">＋ Row</button>' +
      '<button class="s-btn s-btn-sm" id="ysql-btn-filter">⚙ Filter</button>' +
      '<button class="s-btn s-btn-sm" id="ysql-btn-structure">Structure</button>' +
      '<span style="flex:1"></span>' +
      '<span id="ysql-selection-info" style="font-size:.78rem;color:var(--text-dim)"></span>' +
      '<button class="s-btn s-btn-sm" id="ysql-btn-bulk" style="display:none">Edit selected</button>' +
      '<div style="display:flex;gap:4px">' +
        '<button class="s-btn s-btn-sm" id="ysql-export-csv">↓ CSV</button>' +
        '<button class="s-btn s-btn-sm" id="ysql-export-sql">↓ SQL</button>' +
        '<label class="s-btn s-btn-sm" style="cursor:pointer">↑ Import<input type="file" id="ysql-import-file" style="display:none" accept=".csv,.sql"></label>' +
      '</div>' +
      '<select id="ysql-pagesize" class="s-input" style="width:70px;font-size:.78rem">' +
        '<option value="25">25</option><option value="50" selected>50</option>' +
        '<option value="100">100</option><option value="250">250</option>' +
      '</select>';

    tb.querySelector('#ysql-btn-insert').addEventListener('click', function() {
      YS.rowInsert.show(container, content);
    });
    tb.querySelector('#ysql-btn-filter').addEventListener('click', function() {
      YS.filters.toggle(container, content);
    });
    tb.querySelector('#ysql-btn-structure').addEventListener('click', function() {
      YS.structure.show(container, content);
    });
    tb.querySelector('#ysql-btn-bulk').addEventListener('click', function() {
      YS.bulkEdit.open(container, content);
    });
    tb.querySelector('#ysql-export-csv').addEventListener('click', function() { _exportTable('csv'); });
    tb.querySelector('#ysql-export-sql').addEventListener('click', function() { _exportTable('sql'); });
    tb.querySelector('#ysql-import-file').addEventListener('change', function(e) { _importFile(e, container, content); });
    tb.querySelector('#ysql-pagesize').addEventListener('change', function() {
      YS.state.pageSize = parseInt(this.value);
      YS.state.page = 1;
      _loadData(container, content);
    });
  }

  async function _loadData(container, content) {
    const tbody = content.querySelector('#ysql-tbody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="99" style="padding:20px;text-align:center;color:var(--text-dim)">Loading…</td></tr>';

    const body = {
      conn_id: YS.state.activeConn.id,
      database: YS.state.activeDb,
      table: YS.state.activeTable,
      limit: YS.state.pageSize,
      offset: (YS.state.page - 1) * YS.state.pageSize,
      filters: YS.state.filters,
      sort: YS.state.sort,
    };

    const res = await YS.api('/table-data', { method: 'POST', json: body }).catch(function(e) { return { error: e.message }; });

    if (res.error || res.detail) {
      tbody.innerHTML = '<tr><td colspan="99" style="padding:20px;color:#f38ba8">' + YS.escHtml(res.error || res.detail) + '</td></tr>';
      return;
    }

    YS.state.totalRows = res.total;
    _renderTable(content, res.columns, res.rows);
    _renderPagination(container, content);
  }

  function _renderTable(content, columns, rows) {
    const esc = YS.escHtml;
    const colMeta = YS.state.colMeta;

    // thead
    const thead = content.querySelector('#ysql-thead');
    const sortMap = {};
    YS.state.sort.forEach(function(s) { sortMap[s.col] = s.dir; });

    thead.innerHTML = '';
    const tr = document.createElement('tr');
    tr.style.cssText = 'position:sticky;top:0;background:var(--surface);z-index:1';

    // checkbox col
    const thCk = document.createElement('th');
    thCk.style.cssText = 'padding:6px 8px;border-bottom:2px solid var(--border);width:32px';
    thCk.innerHTML = '<input type="checkbox" id="ysql-sel-all" title="Select page">';
    tr.appendChild(thCk);

    columns.forEach(function(c) {
      const th = document.createElement('th');
      th.style.cssText = 'padding:6px 10px;border-bottom:2px solid var(--border);text-align:left;cursor:pointer;user-select:none;white-space:nowrap';
      var arrow = sortMap[c] === 'ASC' ? '▴' : sortMap[c] === 'DESC' ? '▾' : '';
      var meta = colMeta[c] || {};
      var badge = meta.key === 'PRI' ? '<span style="font-size:.65rem;color:var(--accent);margin-left:3px">PK</span>' : '';
      th.innerHTML = esc(c) + badge + (arrow ? '<span style="margin-left:3px;color:var(--accent)">' + arrow + '</span>' : '');
      th.addEventListener('click', function() {
        var cur = sortMap[c];
        // remove existing sort for this col
        YS.state.sort = YS.state.sort.filter(function(s) { return s.col !== c; });
        if (!cur) YS.state.sort.unshift({ col: c, dir: 'ASC' });
        else if (cur === 'ASC') YS.state.sort.unshift({ col: c, dir: 'DESC' });
        // if DESC, remove it (toggle off)
        YS.state.page = 1;
        // re-render content from parent
        var container = content.closest('[id]');
        _loadData(container, content);
      });
      tr.appendChild(th);
    });
    tr.appendChild(Object.assign(document.createElement('th'), {
      style: 'padding:6px 8px;border-bottom:2px solid var(--border);width:32px'
    }));
    thead.appendChild(tr);

    // select-all checkbox
    thead.querySelector('#ysql-sel-all').addEventListener('change', function() {
      var mode = this.checked ? 'page' : 'none';
      YS.state.selection = { mode: mode, pageRows: this.checked ? rows.slice() : [] };
      _updateSelectionUI(content);
    });

    // tbody
    const tbody = content.querySelector('#ysql-tbody');
    tbody.innerHTML = '';

    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="' + (columns.length + 2) + '" style="padding:20px;text-align:center;color:var(--text-dim)">No rows</td></tr>';
      return;
    }

    rows.forEach(function(row) {
      const tr = document.createElement('tr');
      tr.style.borderBottom = '1px solid var(--border)';
      tr.addEventListener('mouseenter', function() { tr.style.background = 'var(--hover)'; });
      tr.addEventListener('mouseleave', function() { if (!tr.dataset.selected) tr.style.background = ''; });

      // checkbox
      const tdCk = document.createElement('td');
      tdCk.style.cssText = 'padding:4px 8px;';
      const ck = document.createElement('input');
      ck.type = 'checkbox';
      ck.addEventListener('change', function() {
        tr.dataset.selected = ck.checked ? '1' : '';
        if (!ck.checked) tr.style.background = '';
        var selRows = YS.state.selection.pageRows;
        if (ck.checked) {
          if (!selRows.find(function(r){return r===row;})) selRows.push(row);
        } else {
          YS.state.selection.pageRows = selRows.filter(function(r){return r!==row;});
        }
        YS.state.selection.mode = YS.state.selection.pageRows.length ? 'page' : 'none';
        _updateSelectionUI(content);
      });
      tdCk.appendChild(ck);
      tr.appendChild(tdCk);

      columns.forEach(function(col) {
        const td = document.createElement('td');
        td.style.cssText = 'padding:5px 10px;max-width:240px;overflow:hidden;text-overflow:ellipsis;cursor:pointer';
        td.dataset.col = col;
        var val = row[col];
        _renderCellValue(td, val, colMeta[col]);
        td.addEventListener('dblclick', function() {
          _editCellInline(td, row, col, colMeta[col], content);
        });
        tr.appendChild(td);
      });

      // edit button
      const tdAct = document.createElement('td');
      tdAct.style.cssText = 'padding:4px 6px;text-align:center';
      const editBtn = document.createElement('button');
      editBtn.className = 's-btn s-btn-sm';
      editBtn.style.cssText = 'font-size:.72rem;padding:2px 6px';
      editBtn.textContent = '✎';
      editBtn.title = 'Edit row';
      editBtn.addEventListener('click', function() {
        YS.rowEdit.open(row, columns, colMeta, content);
      });
      tdAct.appendChild(editBtn);
      tr.appendChild(tdAct);

      tbody.appendChild(tr);
    });
  }

  function _renderCellValue(td, val, meta) {
    meta = meta || {};
    if (val === null || val === undefined) {
      td.innerHTML = '<span style="color:var(--text-dim);font-style:italic">NULL</span>';
      td.dataset.origVal = '\x00NULL';
      return;
    }
    var s = String(val);
    td.dataset.origVal = s;
    var base = (meta.baseType || '').toUpperCase();
    if (YS.isNumericType(base)) {
      td.style.color = 'var(--color-num, #8be9fd)';
    } else if (YS.isDateType(base)) {
      td.style.color = 'var(--color-date, #f1fa8c)';
    }
    td.textContent = s;
    td.title = s;
  }

  function _editCellInline(td, row, col, meta, content) {
    var orig = td.dataset.origVal;
    var isNull = orig === '\x00NULL';
    var input = YS.buildCellInput(meta || {}, isNull ? null : orig, true);
    input.style.cssText = 'width:100%;font-size:.82rem;padding:2px 4px;box-sizing:border-box';
    td.innerHTML = '';
    td.appendChild(input);
    input.focus();

    async function save() {
      var val = YS.getCellInputValue(input, meta || {});
      _renderCellValue(td, val, meta);
      var where = YS.buildWhereFromRow(row, YS.state.colMeta);
      var r = await YS.api('/update-cell', { method: 'POST', json: {
        conn_id: YS.state.activeConn.id, database: YS.state.activeDb,
        table: YS.state.activeTable, where: where, column: col, value: val
      }}).catch(function(){return {};});
      if (!r.ok) { _renderCellValue(td, isNull ? null : orig, meta); YS.toast('Update failed', 'error'); }
      else { row[col] = val; }
    }

    input.addEventListener('blur', save);
    input.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') input.blur();
      if (e.key === 'Escape') { _renderCellValue(td, isNull ? null : orig, meta); }
    });
  }

  function _updateSelectionUI(content) {
    const tb = content.querySelector('#ysql-browse-toolbar');
    if (!tb) return;
    const sel = YS.state.selection;
    const info = tb.querySelector('#ysql-selection-info');
    const bulkBtn = tb.querySelector('#ysql-btn-bulk');
    const selAll = content.querySelector('#ysql-sel-all');

    if (sel.mode === 'none') {
      info.textContent = '';
      bulkBtn.style.display = 'none';
      if (selAll) selAll.checked = false;
    } else if (sel.mode === 'page') {
      info.textContent = sel.pageRows.length + ' selected';
      bulkBtn.style.display = '';
    } else {
      info.textContent = 'All ' + YS.state.totalRows + ' rows selected';
      bulkBtn.style.display = '';
    }

    // sync checkboxes
    content.querySelectorAll('#ysql-tbody input[type=checkbox]').forEach(function(ck, i) {
      var row = YS.state.selection.pageRows[i];
      // ck.checked = sel.mode === 'all' || !!sel.pageRows.find(...) — simpler:
    });
  }

  function _renderPagination(container, content) {
    const pag = content.querySelector('#ysql-pagination');
    if (!pag) return;
    var total = YS.state.totalRows, page = YS.state.page, ps = YS.state.pageSize;
    var from = (page-1)*ps+1, to = Math.min(page*ps, total);
    var pages = Math.ceil(total / ps);

    pag.innerHTML =
      '<button class="s-btn s-btn-sm" id="ysql-prev"' + (page<=1?' disabled':'') + '>‹</button>' +
      '<span>Page <input id="ysql-page-inp" type="number" min="1" max="' + pages + '" value="' + page + '" style="width:46px;text-align:center" class="s-input"> / ' + pages + '</span>' +
      '<button class="s-btn s-btn-sm" id="ysql-next"' + (to>=total?' disabled':'') + '>›</button>' +
      '<span style="flex:1"></span>' +
      '<span>' + (total ? from+'–'+to+' of '+total : 'No rows') + '</span>' +
      (YS.state.selection.mode !== 'none' && pages > 1 ?
        '<button class="s-btn s-btn-sm" id="ysql-sel-all-pages">Select all ' + total + ' rows</button>' : '');

    pag.querySelector('#ysql-prev').addEventListener('click', function() {
      YS.state.page--; _loadData(container, content);
    });
    pag.querySelector('#ysql-next').addEventListener('click', function() {
      YS.state.page++; _loadData(container, content);
    });
    var pageInp = pag.querySelector('#ysql-page-inp');
    pageInp.addEventListener('change', function() {
      var p = Math.max(1, Math.min(pages, parseInt(this.value)||1));
      YS.state.page = p; _loadData(container, content);
    });
    var selAllPages = pag.querySelector('#ysql-sel-all-pages');
    if (selAllPages) {
      selAllPages.addEventListener('click', function() {
        YS.state.selection.mode = 'all';
        _updateSelectionUI(content);
      });
    }
  }

  function _exportTable(format) {
    var url = '/api/apps/yoursql/export?conn_id=' + YS.state.activeConn.id +
      '&database=' + encodeURIComponent(YS.state.activeDb) +
      '&table=' + encodeURIComponent(YS.state.activeTable) +
      '&format=' + format;
    var a = document.createElement('a');
    a.href = url; a.download = YS.state.activeTable + '.' + format;
    a.click();
  }

  async function _importFile(e, container, content) {
    var file = e.target.files[0];
    if (!file) return;
    var fd = new FormData();
    fd.append('conn_id', YS.state.activeConn.id);
    fd.append('database', YS.state.activeDb);
    fd.append('file', file);
    var r = await YS.api('/import', { method: 'POST', form: fd }).catch(function(e){return{error:e.message};});
    if (r.ok) {
      YS.toast('Imported ' + r.affected + ' rows' + (r.errors && r.errors.length ? ' (' + r.errors.length + ' errors)' : ''), 'success');
      _loadData(container, content);
    } else {
      YS.toast('Import failed: ' + (r.detail || r.error), 'error');
    }
    e.target.value = '';
  }

  // Public reload — called from row-edit, filters etc.
  function _reload(container, content) {
    if (!content) {
      // find content from active window
      var win = document.querySelector('.window.focused #ysql-content');
      if (win) content = win;
      else return;
    }
    if (!container) container = content.closest('[style*="position:relative"]') || content.parentElement;
    _loadData(container, content);
  }

  return { show, showWelcome, _reload };
})();
