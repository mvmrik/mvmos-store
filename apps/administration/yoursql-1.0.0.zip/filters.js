// YourSQL — Filter & Sort bar

YS.filters = (() => {

  const OPS = ['=','!=','<','>','<=','>=','LIKE','NOT LIKE','LIKE %%','REGEXP','IS NULL','IS NOT NULL'];
  const OPS_NO_VAL = new Set(['IS NULL','IS NOT NULL']);

  function toggle(container, content) {
    var bar = content.querySelector('#ysql-filter-bar');
    if (!bar) return;
    if (bar.dataset.open === '1') {
      bar.dataset.open = '';
      bar.innerHTML = '';
    } else {
      bar.dataset.open = '1';
      render(container, content);
    }
  }

  function render(container, content) {
    var bar = content.querySelector('#ysql-filter-bar');
    if (!bar) return;
    var columns = Object.keys(YS.state.colMeta);
    if (!columns.length) {
      // fallback: get from thead
      content.querySelectorAll('#ysql-thead th[data-col]').forEach(function(th){ columns.push(th.dataset.col); });
    }
    bar.innerHTML = '';
    var wrap = document.createElement('div');
    wrap.style.cssText = 'padding:6px 8px;border-bottom:1px solid var(--border);background:var(--surface2,var(--surface));display:flex;flex-direction:column;gap:4px';

    // render filter rows
    var filterRows = document.createElement('div');
    filterRows.id = 'ysql-filter-rows';
    wrap.appendChild(filterRows);

    // sort rows
    var sortWrap = document.createElement('div');
    sortWrap.style.cssText = 'display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-top:4px';
    sortWrap.innerHTML = '<span style="font-size:.75rem;color:var(--text-dim);min-width:40px">Sort</span>';
    var sortRows = document.createElement('div');
    sortRows.id = 'ysql-sort-rows';
    sortRows.style.cssText = 'display:flex;flex-wrap:wrap;gap:4px;flex:1';
    sortWrap.appendChild(sortRows);
    wrap.appendChild(sortWrap);

    // buttons
    var btns = document.createElement('div');
    btns.style.cssText = 'display:flex;gap:6px;flex-wrap:wrap;margin-top:2px';
    btns.innerHTML =
      '<button class="s-btn s-btn-sm" id="ysql-filter-add">＋ Filter</button>' +
      '<button class="s-btn s-btn-sm" id="ysql-sort-add">＋ Sort</button>' +
      '<span style="flex:1"></span>' +
      '<button class="s-btn s-btn-sm" id="ysql-filter-reset" style="color:#f38ba8">✕ Clear all</button>' +
      '<button class="s-btn s-btn-sm" id="ysql-filter-apply" style="background:var(--accent);color:#fff;border-color:var(--accent)">Apply</button>';
    wrap.appendChild(btns);

    bar.appendChild(wrap);

    _renderFilterRows(filterRows, columns);
    _renderSortRows(sortRows, columns);

    btns.querySelector('#ysql-filter-add').addEventListener('click', function() {
      YS.state.filters.push({ col: columns[0] || '', op: '=', val: '' });
      _renderFilterRows(filterRows, columns);
    });
    btns.querySelector('#ysql-sort-add').addEventListener('click', function() {
      var existing = YS.state.sort.map(function(s){return s.col;});
      var next = columns.find(function(c){return !existing.includes(c);}) || columns[0];
      if (next) { YS.state.sort.push({ col: next, dir: 'ASC' }); _renderSortRows(sortRows, columns); }
    });
    btns.querySelector('#ysql-filter-reset').addEventListener('click', function() {
      YS.state.filters = []; YS.state.sort = []; YS.state.page = 1;
      bar.dataset.open = ''; bar.innerHTML = '';
      YS.browse._loadDataFromOutside ? YS.browse._loadDataFromOutside(container, content) : _applyAndLoad(container, content);
    });
    btns.querySelector('#ysql-filter-apply').addEventListener('click', function() {
      _readFiltersFromDOM(filterRows);
      _readSortFromDOM(sortRows);
      YS.state.page = 1;
      _applyAndLoad(container, content);
    });
  }

  function _renderFilterRows(container, columns) {
    container.innerHTML = '';
    YS.state.filters.forEach(function(f, idx) {
      var row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:center;gap:4px;flex-wrap:wrap';

      var colSel = document.createElement('select'); colSel.className = 's-input'; colSel.style.cssText = 'width:130px;font-size:.8rem';
      columns.forEach(function(c){ var o = document.createElement('option'); o.value=c; o.textContent=c; if(c===f.col)o.selected=true; colSel.appendChild(o); });

      var opSel = document.createElement('select'); opSel.className = 's-input'; opSel.style.cssText = 'width:110px;font-size:.8rem';
      OPS.forEach(function(op){ var o = document.createElement('option'); o.value=op; o.textContent=op; if(op===f.op)o.selected=true; opSel.appendChild(o); });

      var valInp = document.createElement('input'); valInp.className = 's-input'; valInp.style.cssText = 'flex:1;min-width:80px;font-size:.8rem';
      valInp.value = f.val || '';
      if (OPS_NO_VAL.has(f.op)) valInp.style.display = 'none';
      opSel.addEventListener('change', function() { valInp.style.display = OPS_NO_VAL.has(opSel.value) ? 'none' : ''; });

      var rmBtn = document.createElement('button'); rmBtn.className = 's-btn s-btn-sm'; rmBtn.textContent = '✕';
      rmBtn.style.cssText = 'color:#f38ba8;padding:2px 6px';
      rmBtn.addEventListener('click', function() {
        YS.state.filters.splice(idx, 1);
        _renderFilterRows(container, columns);
      });

      row.dataset.filterIdx = idx;
      row.append(colSel, opSel, valInp, rmBtn);
      container.appendChild(row);
    });
    if (!YS.state.filters.length) {
      container.innerHTML = '<div style="font-size:.78rem;color:var(--text-dim);padding:2px 0">No filters — click "+ Filter" to add one</div>';
    }
  }

  function _renderSortRows(container, columns) {
    container.innerHTML = '';
    YS.state.sort.forEach(function(s, idx) {
      var tag = document.createElement('div');
      tag.style.cssText = 'display:flex;align-items:center;gap:4px;background:var(--surface);border:1px solid var(--border);border-radius:4px;padding:2px 6px';

      var colSel = document.createElement('select'); colSel.className = 's-input'; colSel.style.cssText = 'width:110px;font-size:.78rem;border:none;background:transparent';
      columns.forEach(function(c){ var o=document.createElement('option'); o.value=c; o.textContent=c; if(c===s.col)o.selected=true; colSel.appendChild(o); });

      var dirBtn = document.createElement('button'); dirBtn.className = 's-btn s-btn-sm';
      dirBtn.textContent = s.dir === 'ASC' ? '▴ ASC' : '▾ DESC';
      dirBtn.style.cssText = 'font-size:.72rem;padding:1px 5px';
      dirBtn.addEventListener('click', function() {
        s.dir = s.dir === 'ASC' ? 'DESC' : 'ASC';
        dirBtn.textContent = s.dir === 'ASC' ? '▴ ASC' : '▾ DESC';
      });

      var rmBtn = document.createElement('button'); rmBtn.className = 's-btn s-btn-sm'; rmBtn.textContent = '✕';
      rmBtn.style.cssText = 'color:#f38ba8;padding:1px 4px;font-size:.7rem';
      rmBtn.addEventListener('click', function() {
        YS.state.sort.splice(idx, 1);
        _renderSortRows(container, columns);
      });

      tag.dataset.sortIdx = idx;
      tag.append(colSel, dirBtn, rmBtn);
      container.appendChild(tag);
    });
  }

  function _readFiltersFromDOM(container) {
    var rows = container.querySelectorAll('[data-filter-idx]');
    YS.state.filters = [];
    rows.forEach(function(row) {
      var col = row.querySelector('select:nth-child(1)').value;
      var op = row.querySelector('select:nth-child(2)').value;
      var val = OPS_NO_VAL.has(op) ? '' : (row.querySelector('input').value || '');
      YS.state.filters.push({ col, op, val });
    });
  }

  function _readSortFromDOM(container) {
    var tags = container.querySelectorAll('[data-sort-idx]');
    YS.state.sort = [];
    tags.forEach(function(tag) {
      var col = tag.querySelector('select').value;
      var dir = tag.querySelector('button').textContent.includes('ASC') ? 'ASC' : 'DESC';
      YS.state.sort.push({ col, dir });
    });
  }

  function _applyAndLoad(container, content) {
    // trigger browse re-load
    var container2 = content.closest('[style*="overflow:hidden"]') || content.parentElement;
    YS.browse._reload(container2, content);
  }

  return { toggle, render };
})();
