// YourSQL — Sidebar: database selector + table list

YS.sidebar = (() => {

  async function loadTables(container) {
    container.querySelectorAll('.ysql-table-item').forEach(e => e.remove());
    if (!YS.state.activeConn || !YS.state.activeDb) return;

    const tables = await YS.api(`/tables?conn_id=${YS.state.activeConn.id}&database=${encodeURIComponent(YS.state.activeDb)}`).catch(() => []);
    const list = container.querySelector('#ysql-conn-list');

    const header = document.createElement('div');
    header.className = 'ysql-table-item';
    header.style.cssText = 'padding:6px 10px;font-size:.75rem;color:var(--text-dim);border-bottom:1px solid var(--border);background:var(--surface)';
    header.textContent = `📂 ${YS.state.activeDb}`;
    list.appendChild(header);

    (Array.isArray(tables) ? tables : []).forEach(t => {
      const row = document.createElement('div');
      row.className = 'ysql-table-item';
      const isActive = YS.state.activeTable === t;
      row.style.cssText = `display:flex;align-items:center;gap:6px;padding:6px 10px 6px 22px;cursor:pointer;font-size:.83rem;background:${isActive ? 'var(--accent-dim,rgba(99,102,241,.15))' : ''}`;
      row.innerHTML = `<span style="color:var(--text-dim)">▤</span><span style="flex:1">${t}</span>`;
      row.dataset.table = t;
      row.addEventListener('click', () => {
        YS.state.activeTable = t;
        container.querySelectorAll('.ysql-table-item[data-table]').forEach(el => el.style.background = '');
        row.style.background = 'var(--accent-dim,rgba(99,102,241,.15))';

        // update breadcrumb
        const bc = container.querySelector('#ysql-breadcrumb');
        if (bc) bc.textContent = (YS.state.activeConn?.name || '') + ' › ' + YS.state.activeDb + ' › ' + t;

        // close sidebar on mobile
        const sidebar = container.querySelector('.as-sidebar');
        if (sidebar && sidebar.classList.contains('mobile-open')) {
          sidebar.classList.remove('mobile-open');
          container.querySelector('.as-sidebar-overlay')?.remove();
        }

        YS.browse.show(container);
      });
      list.appendChild(row);
    });
  }

  return { loadTables };
})();
