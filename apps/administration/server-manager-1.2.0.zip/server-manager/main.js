// mvmOS App: Server Manager v1.2.0
const _sm18n = {
  en: {
    title: 'Server Manager', sudo_msg: '⚠️ Root password required', sudo_ph: 'sudo password…',
    ok: 'OK', cancel: 'Cancel', detected: 'Detected system services',
    refresh: '↺ Refresh', loading: 'Loading…', no_services: 'No known services detected.',
    restart: '↺', stop: '■ Stop', start: '▶ Start', settings: '⚙ Settings',
    svc_error: 'Service error', auth_failed: 'Authentication failed', wrong_sudo: 'Incorrect sudo password.',
    back: '← Back', save: 'Save', saved: 'Saved!', save_error: 'Save failed',
    php_settings: 'PHP Settings', php_ini_path: 'Config file',
    php_memory_limit: 'Memory limit', php_max_execution_time: 'Max execution time (s)',
    php_max_input_time: 'Max input time (s)', php_max_input_vars: 'Max input vars',
    php_upload_max_filesize: 'Max upload size', php_post_max_size: 'Max POST size',
    php_file_uploads: 'File uploads', php_display_errors: 'Display errors',
    php_error_reporting: 'Error reporting', php_default_charset: 'Default charset',
    php_date_timezone: 'Timezone', php_session_gc_maxlifetime: 'Session lifetime (s)',
    php_opcache_enable: 'OPcache',
    grp_memory: 'Memory & Limits', grp_uploads: 'File Uploads', grp_errors: 'Errors', grp_misc: 'Miscellaneous',
  },
  bg: {
    title: 'Мениджър на услуги', sudo_msg: '⚠️ Необходима е root парола', sudo_ph: 'sudo парола…',
    ok: 'OK', cancel: 'Отказ', detected: 'Открити системни услуги',
    refresh: '↺ Обнови', loading: 'Зареждане…', no_services: 'Няма открити известни услуги.',
    restart: '↺', stop: '■ Спри', start: '▶ Стартирай', settings: '⚙ Настройки',
    svc_error: 'Грешка на услугата', auth_failed: 'Грешка при автентикация', wrong_sudo: 'Грешна sudo парола.',
    back: '← Назад', save: 'Запази', saved: 'Запазено!', save_error: 'Грешка при запазване',
    php_settings: 'PHP Настройки', php_ini_path: 'Конфигурационен файл',
    php_memory_limit: 'Лимит памет', php_max_execution_time: 'Макс. време за изпълнение (с)',
    php_max_input_time: 'Макс. вр. за вход (с)', php_max_input_vars: 'Макс. входни променливи',
    php_upload_max_filesize: 'Макс. размер за качване', php_post_max_size: 'Макс. POST размер',
    php_file_uploads: 'Качване на файлове', php_display_errors: 'Показвай грешки',
    php_error_reporting: 'Отчитане на грешки', php_default_charset: 'Кодиране по подразбиране',
    php_date_timezone: 'Часова зона', php_session_gc_maxlifetime: 'Живот на сесия (с)',
    php_opcache_enable: 'OPcache',
    grp_memory: 'Памет и лимити', grp_uploads: 'Качване на файлове', grp_errors: 'Грешки', grp_misc: 'Разни',
  },
};
function _smt(key) { const lang = window.mvmOS?.lang || 'en'; return (_sm18n[lang] || _sm18n.en)[key] || key; }

mvmOS.registerApp({
  id: 'server-manager', name: _smt('title'), icon: '🖧', category: 'Administration',
  launch() {
    mvmOS.createWindow({
      id: 'server-manager', title: '🖧 ' + _smt('title'), width: 620, height: 480,
      onMount(body) { (window.mvmOS?.i18nReady || Promise.resolve()).then(() => SM.render(body)); },
    });
  }
});

const SM = (() => {
  let _sudoPassword = '', _pendingAction = null;

  // ── Main service list ───────────────────────────────────────────────────────
  function render(body) {
    body.style.padding = '0';
    body.innerHTML = `
      <div style="display:flex;flex-direction:column;height:100%;background:var(--surface)">
        <div id="sm-sudo-bar" style="display:none;align-items:center;gap:8px;padding:8px 14px;background:var(--surface2);border-bottom:1px solid var(--border);font-size:.82rem">
          <span style="color:#f1fa8c">${_smt('sudo_msg')}</span>
          <input id="sm-sudo-input" type="password" placeholder="${_smt('sudo_ph')}"
            style="flex:1;background:var(--surface);border:1px solid var(--border);border-radius:4px;padding:4px 8px;color:var(--text);font-size:.82rem">
          <button class="s-btn s-btn-sm" id="sm-sudo-ok">${_smt('ok')}</button>
          <button class="s-btn s-btn-sm" id="sm-sudo-cancel" style="opacity:.6">${_smt('cancel')}</button>
        </div>
        <div style="display:flex;align-items:center;padding:10px 14px;gap:8px;border-bottom:1px solid var(--border)">
          <span style="font-size:.8rem;color:var(--text-dim);flex:1">${_smt('detected')}</span>
          <button class="s-btn s-btn-sm" id="sm-refresh">${_smt('refresh')}</button>
        </div>
        <div id="sm-list" style="flex:1;overflow-y:auto;padding:8px 0">
          <div style="padding:20px;color:var(--text-dim);font-size:.85rem">${_smt('loading')}</div>
        </div>
      </div>`;
    body.querySelector('#sm-refresh').addEventListener('click', () => loadServices(body));
    body.querySelector('#sm-sudo-ok').addEventListener('click', () => confirmSudo(body));
    body.querySelector('#sm-sudo-cancel').addEventListener('click', () => hideSudoBar(body));
    body.querySelector('#sm-sudo-input').addEventListener('keydown', e => { if (e.key === 'Enter') confirmSudo(body); });
    loadServices(body);
    window.mvmOS?.onLangChange(() => render(body));
  }

  const PHP_SERVICES = new Set(['php8.3-fpm', 'php8.2-fpm', 'php8.1-fpm', 'php-fpm']);

  async function loadServices(body) {
    const list = body.querySelector('#sm-list');
    list.innerHTML = `<div style="padding:20px;color:var(--text-dim);font-size:.85rem">${_smt('loading')}</div>`;
    const services = await mvmOS.system.services();
    if (!services.length) { list.innerHTML = `<div style="padding:20px;color:var(--text-dim);font-size:.85rem">${_smt('no_services')}</div>`; return; }
    list.innerHTML = '';
    services.forEach(svc => {
      const row = document.createElement('div');
      row.dataset.name = svc.name;
      row.style.cssText = 'display:flex;align-items:center;gap:10px;padding:9px 14px;border-bottom:1px solid var(--border);font-size:.85rem';
      const isActive = svc.status === 'active', isFailed = svc.status === 'failed';
      const hasSettings = PHP_SERVICES.has(svc.name);
      row.innerHTML = `
        <span style="font-size:1.1rem;width:24px;text-align:center">${svc.icon}</span>
        <div style="flex:1;min-width:0">
          <div style="font-weight:600;color:var(--text)">${svc.label}</div>
          <div style="font-size:.75rem;color:var(--text-dim);font-family:monospace">${svc.name}</div>
        </div>
        <span class="sm-status-badge" style="font-size:.72rem;padding:2px 8px;border-radius:3px;font-weight:600;
          ${isActive ? 'color:#50fa7b;background:rgba(80,250,123,.12);border:1px solid rgba(80,250,123,.3)'
                     : isFailed ? 'color:#ff5555;background:rgba(255,85,85,.12);border:1px solid rgba(255,85,85,.3)'
                     : 'color:#6272a4;background:rgba(98,114,164,.1);border:1px solid rgba(98,114,164,.25)'}">${svc.status}</span>
        <div style="display:flex;gap:4px">
          ${hasSettings ? `<button class="s-btn s-btn-sm sm-settings" data-name="${svc.name}" title="${_smt('settings')}">${_smt('settings')}</button>` : ''}
          ${isActive
            ? `<button class="s-btn s-btn-sm sm-action" data-action="restart" data-name="${svc.name}" title="Restart">${_smt('restart')}</button>
               <button class="s-btn s-btn-sm s-btn-danger sm-action" data-action="stop" data-name="${svc.name}">${_smt('stop')}</button>`
            : `<button class="s-btn s-btn-sm sm-action" data-action="start" data-name="${svc.name}">${_smt('start')}</button>`}
        </div>`;
      row.querySelectorAll('.sm-action').forEach(btn => btn.addEventListener('click', () => doAction(body, svc.name, btn.dataset.action, row)));
      row.querySelectorAll('.sm-settings').forEach(btn => btn.addEventListener('click', () => renderPhpSettings(body, svc.name)));
      list.appendChild(row);
    });
  }

  // ── Service actions ─────────────────────────────────────────────────────────
  async function doAction(body, name, action, row) {
    const res = await callAction(body, name, action);
    if (res === 'sudo_needed') { _pendingAction = { body, name, action, row }; showSudoBar(body); return; }
    if (res?.ok) updateRow(row, res.status);
  }

  async function callAction(body, name, action, sudoPassword = '') {
    const data = await mvmOS.system.serviceAction(name, action, sudoPassword);
    if (data.error === 'permission_denied') return 'sudo_needed';
    if (data.error) { mvmOS.notify(_smt('svc_error'), data.detail || data.error); return null; }
    return data;
  }

  function showSudoBar(body) {
    const bar = body.querySelector('#sm-sudo-bar');
    bar.style.display = 'flex';
    body.querySelector('#sm-sudo-input').value = '';
    body.querySelector('#sm-sudo-input').focus();
  }
  function hideSudoBar(body) { body.querySelector('#sm-sudo-bar').style.display = 'none'; _pendingAction = null; }

  async function confirmSudo(body) {
    const pwd = body.querySelector('#sm-sudo-input').value;
    if (!pwd || !_pendingAction) return;
    _sudoPassword = pwd; hideSudoBar(body);
    const { name, action, row } = _pendingAction; _pendingAction = null;
    const res = await callAction(body, name, action, _sudoPassword);
    if (res === 'sudo_needed') { mvmOS.notify(_smt('auth_failed'), _smt('wrong_sudo')); _sudoPassword = ''; return; }
    if (res?.ok) updateRow(row, res.status);
  }

  function updateRow(row, status) {
    const isActive = status === 'active', isFailed = status === 'failed';
    const badge = row.querySelector('.sm-status-badge');
    if (badge) {
      badge.textContent = status;
      badge.style.cssText = `font-size:.72rem;padding:2px 8px;border-radius:3px;font-weight:600;
        ${isActive ? 'color:#50fa7b;background:rgba(80,250,123,.12);border:1px solid rgba(80,250,123,.3)'
                   : isFailed ? 'color:#ff5555;background:rgba(255,85,85,.12);border:1px solid rgba(255,85,85,.3)'
                   : 'color:#6272a4;background:rgba(98,114,164,.1);border:1px solid rgba(98,114,164,.25)'}`;
    }
    const btns = row.querySelector('div[style*="gap:4px"]');
    if (btns) {
      const name = row.dataset.name;
      const hasSettings = PHP_SERVICES.has(name);
      btns.innerHTML = `
        ${hasSettings ? `<button class="s-btn s-btn-sm sm-settings" data-name="${name}">${_smt('settings')}</button>` : ''}
        ${isActive
          ? `<button class="s-btn s-btn-sm sm-action" data-action="restart" data-name="${name}">${_smt('restart')}</button>
             <button class="s-btn s-btn-sm s-btn-danger sm-action" data-action="stop" data-name="${name}">${_smt('stop')}</button>`
          : `<button class="s-btn s-btn-sm sm-action" data-action="start" data-name="${name}">${_smt('start')}</button>`}`;
      const body2 = row.closest('.window-body') || document.body;
      btns.querySelectorAll('.sm-action').forEach(btn => btn.addEventListener('click', () => doAction(body2, name, btn.dataset.action, row)));
      btns.querySelectorAll('.sm-settings').forEach(btn => btn.addEventListener('click', () => renderPhpSettings(body2, name)));
    }
  }

  // ── PHP Settings screen ─────────────────────────────────────────────────────
  const PHP_GROUPS = [
    { key: 'grp_memory', fields: ['memory_limit','max_execution_time','max_input_time','max_input_vars'] },
    { key: 'grp_uploads', fields: ['upload_max_filesize','post_max_size','file_uploads'] },
    { key: 'grp_errors', fields: ['display_errors','error_reporting'] },
    { key: 'grp_misc', fields: ['default_charset','date.timezone','session.gc_maxlifetime','opcache.enable'] },
  ];
  const TOGGLE_FIELDS = new Set(['file_uploads','display_errors','opcache.enable']);
  const FIELD_KEY = k => 'php_' + k.replace('.','_');

  async function renderPhpSettings(body, svcName) {
    body.innerHTML = `<div style="display:flex;flex-direction:column;height:100%">
      <div style="padding:10px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px">
        <button class="s-btn s-btn-sm" id="sm-back">${_smt('back')}</button>
        <span style="font-weight:600;font-size:.9rem;flex:1">${_smt('php_settings')}</span>
        <button class="s-btn s-btn-sm" id="sm-save" style="background:var(--accent);color:#fff;border-color:var(--accent)">${_smt('save')}</button>
      </div>
      <div id="sm-php-content" style="flex:1;overflow-y:auto;padding:12px 16px">
        <div style="color:var(--text-dim);font-size:.85rem">${_smt('loading')}</div>
      </div>
    </div>`;

    body.querySelector('#sm-back').addEventListener('click', () => render(body));

    const res = await fetch('/api/system/php-ini');
    const data = await res.json();
    const values = data.values || {};
    const content = body.querySelector('#sm-php-content');

    let html = `<div style="font-size:.75rem;color:var(--text-dim);margin-bottom:14px;font-family:monospace">${_smt('php_ini_path')}: ${data.path || '—'}</div>`;

    for (const grp of PHP_GROUPS) {
      html += `<div style="font-size:.78rem;font-weight:700;color:var(--accent);margin:14px 0 6px;text-transform:uppercase;letter-spacing:.05em">${_smt(grp.key)}</div>`;
      for (const field of grp.fields) {
        const val = values[field] ?? '';
        const label = _smt(FIELD_KEY(field));
        if (TOGGLE_FIELDS.has(field)) {
          const checked = val.toLowerCase() === 'on' || val === '1' ? 'checked' : '';
          html += `<div style="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--border)">
            <label style="flex:1;font-size:.83rem">${label}</label>
            <input type="checkbox" class="sm-php-field" data-key="${field}" ${checked} style="width:16px;height:16px;accent-color:var(--accent)">
          </div>`;
        } else {
          html += `<div style="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--border)">
            <label style="flex:1;font-size:.83rem">${label}</label>
            <input type="text" class="sm-php-field s-input" data-key="${field}" value="${val}"
              style="width:150px;font-size:.82rem;padding:3px 7px">
          </div>`;
        }
      }
    }
    content.innerHTML = html;

    body.querySelector('#sm-save').addEventListener('click', () => savePhpSettings(body, svcName));
  }

  async function savePhpSettings(body, svcName) {
    const fields = body.querySelectorAll('.sm-php-field');
    const values = {};
    fields.forEach(f => {
      if (f.type === 'checkbox') values[f.dataset.key] = f.checked ? 'On' : 'Off';
      else values[f.dataset.key] = f.value.trim();
    });

    const saveBtn = body.querySelector('#sm-save');
    saveBtn.disabled = true;

    const res = await fetch('/api/system/php-ini', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ values, sudo_password: _sudoPassword }),
    });
    const data = await res.json();

    if (res.status === 403) {
      // need sudo password
      _pendingAction = { type: 'php-save', body, svcName };
      showSudoBar(body);
      saveBtn.disabled = false;
      return;
    }

    saveBtn.disabled = false;
    if (data.ok) {
      mvmOS.notify(_smt('php_settings'), _smt('saved'));
      // restart service to apply
      await mvmOS.system.serviceAction(svcName, 'restart', _sudoPassword);
    } else {
      mvmOS.notify(_smt('php_settings'), _smt('save_error'));
    }
  }

  return { render };
})();
