"""
YourSQL — MySQL manager backend for mvmOS.
Routes: /api/apps/yoursql/...
"""

import json
import os
import subprocess
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel
from typing import Optional

import sqlite3
import sys
get_current_session = sys.modules["backend.auth"].get_current_session

router = APIRouter(prefix="/api/apps/yoursql")
router._app_backend = "yoursql"

VENV_PIP = os.path.join(os.path.dirname(sys.executable), "pip")

# App-own SQLite DB — stored in apps/yoursql/data.db
_DB_PATH = os.path.join(
    os.path.dirname(sys.modules["backend.db"].APPS_DIR),
    "apps", "yoursql", "data.db"
)

def _app_conn():
    conn = sqlite3.connect(_DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS connections (
            id TEXT PRIMARY KEY,
            user TEXT NOT NULL,
            name TEXT NOT NULL,
            host TEXT NOT NULL DEFAULT 'localhost',
            port INTEGER NOT NULL DEFAULT 3306,
            db_user TEXT NOT NULL,
            password TEXT NOT NULL DEFAULT '',
            database TEXT NOT NULL DEFAULT '',
            created_at INTEGER DEFAULT (strftime('%s','now'))
        )
    """)
    conn.commit()
    return conn


def _serialize_rows(rows):
    """Convert non-JSON-serializable types (datetime, Decimal, bytes…) to strings."""
    import datetime, decimal
    result = []
    for row in rows:
        clean = {}
        for k, v in (row.items() if hasattr(row, 'items') else zip(range(len(row)), row)):
            if isinstance(v, (datetime.datetime, datetime.date, datetime.time, datetime.timedelta)):
                clean[k] = str(v)
            elif isinstance(v, decimal.Decimal):
                clean[k] = float(v)
            elif isinstance(v, bytes):
                try:
                    clean[k] = v.decode('utf-8', errors='replace')
                except Exception:
                    clean[k] = repr(v)
            else:
                clean[k] = v
        result.append(clean)
    return result


# ── Driver check ──────────────────────────────────────────────────────────────

@router.get("/driver-status")
def driver_status(session=Depends(get_current_session)):
    try:
        import pymysql  # noqa
        return {"installed": True}
    except ImportError:
        return {"installed": False}


@router.post("/install-driver")
def install_driver(session=Depends(get_current_session)):
    pip = os.path.abspath(VENV_PIP)
    if not os.path.exists(pip):
        raise HTTPException(500, "pip not found")
    r = subprocess.run([pip, "install", "pymysql"], capture_output=True, text=True)
    if r.returncode != 0:
        raise HTTPException(500, r.stderr or r.stdout)
    return {"ok": True}


# ── Connections (stored in apps/yoursql/data.db) ──────────────────────────────

def _get_connections(user: str) -> list:
    with _app_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM connections WHERE user=? ORDER BY created_at", (user,)
        ).fetchall()
    return [dict(r) for r in rows]


def _get_conn_by_id(user: str, conn_id: str) -> dict:
    with _app_conn() as conn:
        row = conn.execute(
            "SELECT * FROM connections WHERE id=? AND user=?", (conn_id, user)
        ).fetchone()
    if not row:
        raise HTTPException(404, "Connection not found")
    return dict(row)


@router.get("/connections")
def list_connections(session=Depends(get_current_session)):
    conns = _get_connections(session["effective_user"])
    safe = [{k: v for k, v in c.items() if k != "password"} for c in conns]
    return JSONResponse(safe)


class ConnectionBody(BaseModel):
    id: Optional[str] = None
    name: str
    host: str = "localhost"
    port: int = 3306
    user: str
    password: str
    database: str = ""


@router.post("/connections")
def save_connection(body: ConnectionBody, session=Depends(get_current_session)):
    import uuid
    user = session["effective_user"]
    conn_id = body.id or str(uuid.uuid4())[:8]
    # if editing and password is blank, keep existing
    password = body.password
    if not password and body.id:
        try:
            existing = _get_conn_by_id(user, conn_id)
            password = existing["password"]
        except HTTPException:
            pass
    with _app_conn() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO connections (id, user, name, host, port, db_user, password, database)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (conn_id, user, body.name, body.host, body.port, body.user, password, body.database))
    return {"ok": True, "id": conn_id}


@router.delete("/connections/{conn_id}")
def delete_connection(conn_id: str, session=Depends(get_current_session)):
    user = session["effective_user"]
    with _app_conn() as conn:
        conn.execute("DELETE FROM connections WHERE id=? AND user=?", (conn_id, user))
    return {"ok": True}


# ── MySQL queries ─────────────────────────────────────────────────────────────

def _get_conn_config(user: str, conn_id: str) -> dict:
    c = _get_conn_by_id(user, conn_id)
    # map db_user → user for _mysql_connect
    c["user"] = c.get("db_user", c.get("user", ""))
    return c


def _find_mysql_socket() -> str:
    """Try to find the MySQL Unix socket path from config or common locations."""
    import subprocess
    # Try to get socket path from MySQL config
    try:
        r = subprocess.run(
            ["mysql", "--print-defaults"],
            capture_output=True, text=True, timeout=3
        )
        for part in r.stdout.split():
            if part.startswith("--socket="):
                path = part.split("=", 1)[1]
                if os.path.exists(path):
                    return path
    except Exception:
        pass
    # Common socket locations
    for path in [
        "/var/run/mysqld/mysqld.sock",
        "/tmp/mysql.sock",
        "/var/lib/mysql/mysql.sock",
        "/run/mysqld/mysqld.sock",
    ]:
        if os.path.exists(path):
            return path
    return None


def _mysql_connect(cfg: dict, database: str = None):
    try:
        import pymysql
        import pymysql.cursors
    except ImportError:
        raise HTTPException(503, "pymysql not installed")
    db = database or cfg.get("database") or None
    host = cfg["host"]
    # When host is localhost/127.0.0.1, use Unix socket to avoid TCP permission issues
    if host in ("localhost", "127.0.0.1"):
        sock = _find_mysql_socket()
        if sock:
            return pymysql.connect(
                unix_socket=sock,
                user=cfg["user"], password=cfg["password"],
                database=db, charset="utf8mb4",
                cursorclass=pymysql.cursors.DictCursor,
                connect_timeout=5,
            )
    return pymysql.connect(
        host=host, port=int(cfg["port"]),
        user=cfg["user"], password=cfg["password"],
        database=db, charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        connect_timeout=5,
    )


@router.get("/databases")
def list_databases(conn_id: str, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], conn_id)
    try:
        con = _mysql_connect(cfg, database=None)
        with con.cursor() as cur:
            cur.execute("SHOW DATABASES")
            rows = [r["Database"] for r in cur.fetchall()]
        con.close()
        return JSONResponse(rows)
    except Exception as e:
        raise HTTPException(400, str(e))


@router.get("/tables")
def list_tables(conn_id: str, database: str, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], conn_id)
    try:
        con = _mysql_connect(cfg, database=database)
        with con.cursor() as cur:
            cur.execute("SHOW TABLES")
            key = f"Tables_in_{database}"
            rows = [list(r.values())[0] for r in cur.fetchall()]
        con.close()
        return JSONResponse(rows)
    except Exception as e:
        raise HTTPException(400, str(e))


class QueryBody(BaseModel):
    conn_id: str
    database: str = ""
    sql: str
    limit: int = 500
    offset: int = 0


@router.post("/query")
def run_query(body: QueryBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        con = _mysql_connect(cfg, database=body.database or None)
        with con.cursor() as cur:
            sql = body.sql.strip()
            is_select = sql.upper().startswith("SELECT") or sql.upper().startswith("SHOW") or sql.upper().startswith("DESCRIBE") or sql.upper().startswith("EXPLAIN")
            if is_select:
                cur.execute(sql)
                rows = cur.fetchmany(body.limit)
                columns = [d[0] for d in cur.description] if cur.description else []
                return JSONResponse({"columns": columns, "rows": _serialize_rows(rows), "affected": None})
            else:
                cur.execute(sql)
                con.commit()
                return JSONResponse({"columns": [], "rows": [], "affected": cur.rowcount})
        con.close()
    except Exception as e:
        raise HTTPException(400, str(e))


class UpdateRowBody(BaseModel):
    conn_id: str
    database: str
    table: str
    where: dict        # {col: value} — identifies the row
    updates: dict      # {col: value | None}


@router.post("/update-row")
def update_row(body: UpdateRowBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        con = _mysql_connect(cfg, database=body.database)
        with con.cursor() as cur:
            set_parts = [f"`{c}`=%s" for c in body.updates]
            where_parts = [f"`{c}`=%s" for c in body.where]
            sql = f"UPDATE `{body.table}` SET {', '.join(set_parts)} WHERE {' AND '.join(where_parts)}"
            params = list(body.updates.values()) + list(body.where.values())
            cur.execute(sql, params)
            con.commit()
        con.close()
        return {"ok": True, "affected": cur.rowcount}
    except Exception as e:
        raise HTTPException(400, str(e))


class InsertRowBody(BaseModel):
    conn_id: str
    database: str
    table: str
    values: dict  # {col: value | None}


@router.post("/insert-row")
def insert_row(body: InsertRowBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        con = _mysql_connect(cfg, database=body.database)
        with con.cursor() as cur:
            cols = list(body.values.keys())
            vals = list(body.values.values())
            col_str = ", ".join([f"`{c}`" for c in cols])
            placeholders = ", ".join(["%s"] * len(cols))
            cur.execute(f"INSERT INTO `{body.table}` ({col_str}) VALUES ({placeholders})", vals)
            con.commit()
            last_id = cur.lastrowid
        con.close()
        return {"ok": True, "id": last_id}
    except Exception as e:
        raise HTTPException(400, str(e))


class BulkDeleteBody(BaseModel):
    conn_id: str
    database: str
    table: str
    mode: str = "page"               # "page" or "all"
    where_rows: Optional[list] = None  # list of {col:val} dicts for mode=page


@router.post("/bulk-delete")
def bulk_delete(body: BulkDeleteBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        con = _mysql_connect(cfg, database=body.database)
        deleted = 0
        with con.cursor() as cur:
            if body.mode == "all":
                cur.execute(f"DELETE FROM `{body.table}`")
                deleted = cur.rowcount
            elif body.where_rows:
                for where_dict in body.where_rows:
                    where_parts = [f"`{c}`=%s" for c in where_dict]
                    cur.execute(f"DELETE FROM `{body.table}` WHERE {' AND '.join(where_parts)}",
                                list(where_dict.values()))
                    deleted += cur.rowcount
        con.commit()
        con.close()
        return {"ok": True, "affected": deleted}
    except Exception as e:
        raise HTTPException(400, str(e))


class BulkUpdateBody(BaseModel):
    conn_id: str
    database: str
    table: str
    updates: dict        # {col: {op: set|increment|decrement, value: ...}}
    mode: str = "page"   # "page" or "all"
    where_rows: Optional[list] = None  # list of {col:val} dicts for mode=page


@router.post("/bulk-update")
def bulk_update(body: BulkUpdateBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        con = _mysql_connect(cfg, database=body.database)
        with con.cursor() as cur:
            set_parts = []
            params = []
            for col, op_dict in body.updates.items():
                operation = op_dict.get("op", "set") if isinstance(op_dict, dict) else "set"
                val = op_dict.get("value") if isinstance(op_dict, dict) else op_dict
                if operation == "set":
                    set_parts.append(f"`{col}`=%s")
                    params.append(val)
                elif operation == "set_null" or (operation == "set" and val is None):
                    set_parts.append(f"`{col}`=NULL")
                elif operation == "increment":
                    set_parts.append(f"`{col}`=`{col}`+%s")
                    params.append(val)
                elif operation == "decrement":
                    set_parts.append(f"`{col}`=`{col}`-%s")
                    params.append(val)
            if not set_parts:
                raise HTTPException(400, "No operations")
            total_affected = 0
            if body.mode == "all":
                cur.execute(f"UPDATE `{body.table}` SET {', '.join(set_parts)}", params)
                total_affected = cur.rowcount
            elif body.where_rows:
                for where_dict in (body.where_rows or []):
                    where_parts = [f"`{c}`=%s" for c in where_dict]
                    cur.execute(
                        f"UPDATE `{body.table}` SET {', '.join(set_parts)} WHERE {' AND '.join(where_parts)}",
                        params + list(where_dict.values())
                    )
                    total_affected += cur.rowcount
            con.commit()
        con.close()
        return {"ok": True, "affected": total_affected}
    except Exception as e:
        raise HTTPException(400, str(e))


class FilterItem(BaseModel):
    col: str
    op: str
    val: str = ""

class SortItem(BaseModel):
    col: str
    dir: str = "ASC"

class TableDataBody(BaseModel):
    conn_id: str
    database: str
    table: str
    limit: int = 100
    offset: int = 0
    search: str = ""
    order_by: str = ""
    order_dir: str = "ASC"
    filters: Optional[list] = None
    sort: Optional[list] = None


def _build_where(filters, search=None, search_cols=None):
    """Build WHERE clause and params from filter list and optional search."""
    parts = []
    params = []
    if search and search_cols:
        parts.append("(" + " OR ".join([f"`{c}` LIKE %s" for c in search_cols]) + ")")
        params += [f"%{search}%"] * len(search_cols)
    OP_MAP = {
        '=': ('`{col}`=%s', True),
        '!=': ('`{col}`!=%s', True),
        '<': ('`{col}`<%s', True),
        '>': ('`{col}`>%s', True),
        '<=': ('`{col}`<=%s', True),
        '>=': ('`{col}`>=%s', True),
        'LIKE': ('`{col}` LIKE %s', True),
        'NOT LIKE': ('`{col}` NOT LIKE %s', True),
        'LIKE %%': ('`{col}` LIKE %s', True),
        'REGEXP': ('`{col}` REGEXP %s', True),
        'IS NULL': ('`{col}` IS NULL', False),
        'IS NOT NULL': ('`{col}` IS NOT NULL', False),
    }
    for f in (filters or []):
        col = f.get('col') if isinstance(f, dict) else f.col
        op = f.get('op') if isinstance(f, dict) else f.op
        val = f.get('val', '') if isinstance(f, dict) else getattr(f, 'val', '')
        if op not in OP_MAP:
            continue
        tpl, has_val = OP_MAP[op]
        parts.append(tpl.format(col=col))
        if has_val:
            if op == 'LIKE %%':
                params.append(f"%{val}%")
            else:
                params.append(val)
    where = ("WHERE " + " AND ".join(parts)) if parts else ""
    return where, params


@router.post("/table-data")
def get_table_data(body: TableDataBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        con = _mysql_connect(cfg, database=body.database)
        with con.cursor() as cur:
            search_cols = []
            if body.search:
                cur.execute(f"DESCRIBE `{body.table}`")
                cols = cur.fetchall()
                search_cols = [c["Field"] for c in cols if any(t in c["Type"].lower() for t in ["char", "text", "varchar"])]

            where, params = _build_where(body.filters, body.search, search_cols)
            cur.execute(f"SELECT COUNT(*) as cnt FROM `{body.table}` {where}", params)
            total = cur.fetchone()["cnt"]

            # build ORDER BY from sort list or legacy order_by field
            order_parts = []
            if body.sort:
                for s in body.sort:
                    col = s.get('col') if isinstance(s, dict) else s.col
                    dir_ = "DESC" if (s.get('dir') if isinstance(s, dict) else s.dir).upper() == "DESC" else "ASC"
                    order_parts.append(f"`{col}` {dir_}")
            elif body.order_by:
                dir_ = "DESC" if body.order_dir.upper() == "DESC" else "ASC"
                order_parts.append(f"`{body.order_by}` {dir_}")
            order = ("ORDER BY " + ", ".join(order_parts)) if order_parts else ""

            cur.execute(f"SELECT * FROM `{body.table}` {where} {order} LIMIT %s OFFSET %s",
                        params + [body.limit, body.offset])
            rows = cur.fetchall()
            columns = [d[0] for d in cur.description] if cur.description else []
        con.close()
        return JSONResponse({"columns": columns, "rows": _serialize_rows(rows), "total": total})
    except Exception as e:
        raise HTTPException(400, str(e))


class UpdateCellBody(BaseModel):
    conn_id: str
    database: str
    table: str
    primary_key: str
    primary_value: str
    column: str
    value: str


@router.post("/update-cell")
def update_cell(body: UpdateCellBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        con = _mysql_connect(cfg, database=body.database)
        with con.cursor() as cur:
            cur.execute(
                f"UPDATE `{body.table}` SET `{body.column}`=%s WHERE `{body.primary_key}`=%s",
                (body.value, body.primary_value)
            )
            con.commit()
        con.close()
        return {"ok": True}
    except Exception as e:
        raise HTTPException(400, str(e))


class DeleteRowBody(BaseModel):
    conn_id: str
    database: str
    table: str
    where: Optional[dict] = None         # {col: value} — from row-edit
    primary_key: Optional[str] = None    # legacy fallback
    primary_value: Optional[str] = None  # legacy fallback


@router.post("/delete-row")
def delete_row(body: DeleteRowBody, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], body.conn_id)
    try:
        con = _mysql_connect(cfg, database=body.database)
        with con.cursor() as cur:
            if body.where:
                where_parts = [f"`{c}`=%s" for c in body.where]
                cur.execute(f"DELETE FROM `{body.table}` WHERE {' AND '.join(where_parts)}",
                            list(body.where.values()))
            else:
                cur.execute(f"DELETE FROM `{body.table}` WHERE `{body.primary_key}`=%s",
                            (body.primary_value,))
            con.commit()
        con.close()
        return {"ok": True}
    except Exception as e:
        raise HTTPException(400, str(e))


@router.get("/table-structure")
def table_structure(conn_id: str, database: str, table: str, session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], conn_id)
    try:
        con = _mysql_connect(cfg, database=database)
        with con.cursor() as cur:
            cur.execute(f"DESCRIBE `{table}`")
            columns = cur.fetchall()
            cur.execute(f"SHOW INDEX FROM `{table}`")
            indexes = cur.fetchall()
        con.close()
        return JSONResponse({"columns": columns, "indexes": indexes})
    except Exception as e:
        raise HTTPException(400, str(e))


# ── Export ────────────────────────────────────────────────────────────────────

@router.get("/export")
def export_table(conn_id: str, database: str, table: str, format: str = "sql",
                 session=Depends(get_current_session)):
    cfg = _get_conn_config(session["effective_user"], conn_id)
    try:
        con = _mysql_connect(cfg, database=database)
        with con.cursor() as cur:
            cur.execute(f"SELECT * FROM `{table}`")
            rows = _serialize_rows(cur.fetchall())
            columns = [d[0] for d in cur.description] if cur.description else []
        con.close()
    except Exception as e:
        raise HTTPException(400, str(e))

    if format == "csv":
        import csv, io
        out = io.StringIO()
        writer = csv.writer(out)
        writer.writerow(columns)
        for row in rows:
            writer.writerow([row.get(c, "") for c in columns])
        content = out.getvalue().encode()
        return StreamingResponse(iter([content]),
                                 media_type="text/csv",
                                 headers={"Content-Disposition": f"attachment; filename={table}.csv"})
    else:
        # SQL dump
        lines = [f"-- YourSQL export: {database}.{table}\n"]
        lines.append(f"-- Generated by YourSQL / mvmOS\n\n")
        col_list = ", ".join([f"`{c}`" for c in columns])
        for row in rows:
            vals = []
            for c in columns:
                v = row.get(c)
                if v is None:
                    vals.append("NULL")
                else:
                    escaped = str(v).replace("\\", "\\\\").replace("'", "\\'")
                    vals.append(f"'{escaped}'")
            lines.append(f"INSERT INTO `{table}` ({col_list}) VALUES ({', '.join(vals)});\n")
        content = "".join(lines).encode()
        return StreamingResponse(iter([content]),
                                 media_type="application/sql",
                                 headers={"Content-Disposition": f"attachment; filename={table}.sql"})


# ── Import ────────────────────────────────────────────────────────────────────

from fastapi import UploadFile, File, Form

@router.post("/import")
async def import_file(
    conn_id: str = Form(...),
    database: str = Form(...),
    file: UploadFile = File(...),
    session=Depends(get_current_session)
):
    cfg = _get_conn_config(session["effective_user"], conn_id)
    content = await file.read()
    filename = file.filename or ""

    try:
        con = _mysql_connect(cfg, database=database)
        errors = []
        affected = 0

        if filename.endswith(".csv"):
            import csv, io
            text = content.decode("utf-8-sig")
            reader = csv.DictReader(io.StringIO(text))
            rows = list(reader)
            if rows:
                table = filename.rsplit(".", 1)[0]
                cols = list(rows[0].keys())
                col_str = ", ".join([f"`{c}`" for c in cols])
                placeholders = ", ".join(["%s"] * len(cols))
                with con.cursor() as cur:
                    for row in rows:
                        try:
                            cur.execute(f"INSERT INTO `{table}` ({col_str}) VALUES ({placeholders})",
                                        [row.get(c) for c in cols])
                            affected += 1
                        except Exception as e:
                            errors.append(str(e))
                con.commit()
        else:
            # SQL file — execute statement by statement
            sql_text = content.decode("utf-8", errors="replace")
            statements = [s.strip() for s in sql_text.split(";") if s.strip()]
            with con.cursor() as cur:
                for stmt in statements:
                    try:
                        cur.execute(stmt)
                        affected += cur.rowcount
                    except Exception as e:
                        errors.append(str(e))
            con.commit()

        con.close()
        return JSONResponse({"ok": True, "affected": affected, "errors": errors[:10]})
    except Exception as e:
        raise HTTPException(400, str(e))
