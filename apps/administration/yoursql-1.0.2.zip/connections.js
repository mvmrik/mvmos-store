// YourSQL — Connection management

YS.connections = (() => {

  async function load(container) {
    const res = await YS.api('/connections').catch(() => []);
    YS.state.connections = Array.isArray(res) ? res : [];
    renderList(container);
  }

  function renderList(container) {
    const list = container.querySelector('#ysql-conn-list');
    if (!list) return;
    if (!YS.state.connections.length) {
      list.innerHTML = `<div style="padding:16px;color:var(--text-dim);font-size:.82rem;text-align:center">No connections yet.<br>Click + to add one.</div>`;
      return;
    }
    list.innerHTML = '';
    YS.state.connections.forEach(c => {
      const isActive = YS.state.activeConn?.id === c.id;
      const item = document.createElement('div');
      item.style.cssText = `display:flex;align-items:center;gap:6px;padding:8px 10px;cursor:pointer;border-bottom:1px solid var(--border);background:${isActive ? 'var(--accent-dim,rgba(99,102,241,.15))' : ''}`;
      item.innerHTML = `
        <span style="font-size:1rem">🔌</span>
        <div style="flex:1;min-width:0">
          <div style="font-weight:500;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${c.name}</div>
          <div style="font-size:.75rem;color:var(--text-dim)">${c.db_user}@${c.host}:${c.port}</div>
        </div>
        <button class="s-btn s-btn-sm ysql-edit-conn" data-id="${c.id}" style="font-size:.7rem;padding:2px 6px">✎</button>
      `;
      item.addEventListener('click', e => {
        if (e.target.classList.contains('ysql-edit-conn')) return;
        connect(container, c);
      });
      item.querySelector('.ysql-edit-conn').addEventListener('click', e => {
        e.stopPropagation();
        openDialog(container, c);
      });
      list.appendChild(item);
    });
  }

  async function connect(container, c) {
    YS.state.activeConn = c;
    YS.state.activeDb = c.database || null;
    YS.state.activeTable = null;
    renderList(container);

    // show DB selector in sidebar
    const dbSection = container.querySelector('#ysql-db-section');
    if (dbSection) dbSection.style.display = 'block';

    let dbs = [];
    try {
      dbs = await YS.api(`/databases?conn_id=${c.id}`);
    } catch(e) {
      const sel = container.querySelector('#ysql-db-select');
      if (sel) sel.innerHTML = '<option value="">— error —</option>';
      alert('Cannot connect to MySQL:\n\n' + (e?.message || e));
      return;
    }
    const sel = container.querySelector('#ysql-db-select');
    if (sel) {
      sel.innerHTML = '<option value="">— select —</option>' +
        (Array.isArray(dbs) ? dbs : []).map(d => `<option value="${d}" ${d === YS.state.activeDb ? 'selected' : ''}>${d}</option>`).join('');
    }

    // update breadcrumb
    const bc = container.querySelector('#ysql-breadcrumb');
    if (bc) bc.textContent = c.name;

    if (YS.state.activeDb) await YS.sidebar.loadTables(container);
    YS.browse.showWelcome(container);
  }

  function openDialog(container, existing = null) {
    const modal = YS.modal(container, `
      <div style="font-weight:600;font-size:.95rem">${existing ? 'Edit Connection' : 'New Connection'}</div>
      <div style="display:flex;flex-direction:column;gap:8px">
        <input class="s-input" id="yc-name" placeholder="Name (e.g. Local MySQL)" value="${existing?.name || ''}">
        <div style="display:grid;grid-template-columns:1fr auto;gap:6px">
          <input class="s-input" id="yc-host" placeholder="Host" value="${existing?.host || 'localhost'}">
          <input class="s-input" id="yc-port" placeholder="Port" value="${existing?.port || 3306}" style="width:70px">
        </div>
        <input class="s-input" id="yc-user" placeholder="Username" value="${existing?.db_user || ''}">
        <input class="s-input" id="yc-pass" type="password" placeholder="Password">
        <input class="s-input" id="yc-db" placeholder="Default database (optional)" value="${existing?.database || ''}">
      </div>
      <div id="yc-error" style="color:#f38ba8;font-size:.82rem;display:none"></div>
      <div style="display:flex;gap:8px;justify-content:flex-end">
        ${existing ? `<button class="s-btn" id="yc-delete" style="margin-right:auto;color:#f38ba8">Delete</button>` : ''}
        <button class="s-btn" id="yc-cancel">Cancel</button>
        <button class="s-btn" id="yc-save" style="background:var(--accent);color:#fff;border-color:var(--accent)">Save</button>
      </div>
    `);

    modal.querySelector('#yc-cancel').addEventListener('click', () => modal.close());

    if (existing) {
      modal.querySelector('#yc-delete').addEventListener('click', async () => {
        await YS.api(`/connections/${existing.id}`, { method: 'DELETE' });
        if (YS.state.activeConn?.id === existing.id) {
          YS.state.activeConn = null;
          YS.state.activeDb = null;
        }
        modal.close();
        load(container);
      });
    }

    modal.querySelector('#yc-save').addEventListener('click', async () => {
      const body = {
        id: existing?.id,
        name: modal.querySelector('#yc-name').value.trim(),
        host: modal.querySelector('#yc-host').value.trim(),
        port: parseInt(modal.querySelector('#yc-port').value) || 3306,
        user: modal.querySelector('#yc-user').value.trim(),
        password: modal.querySelector('#yc-pass').value,
        database: modal.querySelector('#yc-db').value.trim(),
      };
      if (!body.name || !body.host || !body.user) {
        const err = modal.querySelector('#yc-error');
        err.textContent = 'Name, host and username are required.';
        err.style.display = 'block';
        return;
      }
      // if editing and no password entered, send empty string → backend keeps existing
      const r = await YS.api('/connections', { method: 'POST', json: body });
      if (r.ok) { modal.close(); load(container); }
    });
  }

  return { load, renderList, connect, openDialog };
})();
