(function(){
  if(window.NostradamusWidget)return;
  var API='/pub/nostradamus';
  var bytesToHex=window.NostrCrypto.bytesToHex,hexToBytes=window.NostrCrypto.hexToBytes;
  function t(k,v){return(window.t||function(x){return x})(k,v)}
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  function b64(bytesIn){var s='';new Uint8Array(bytesIn).forEach(function(x){s+=String.fromCharCode(x)});return btoa(s)}
  function bytes(s){var bin=atob(s),out=new Uint8Array(bin.length);for(var i=0;i<bin.length;i++)out[i]=bin.charCodeAt(i);return out}
  var DEFAULT_RELAYS=['wss://relay.damus.io','wss://nos.lol','wss://relay.nostr.band','wss://relay.primal.net'];
  var RELAY_DISCOVERY=['wss://purplepag.es','wss://relay.nos.social','wss://relay.nostr.wirednet.jp'];
  var MIN_MASTER=10;
  // DeepL's full target-language list (matches apps/deepl/public/widget.js) —
  // this picks the DeepL translation target, not the mvmOS UI language, so it
  // isn't limited to the 9 languages the rest of the interface is translated into.
  var NOS_LANGS=[
    {value:'BG',label:'Bulgarian'},{value:'ZH',label:'Chinese'},{value:'CS',label:'Czech'},{value:'DA',label:'Danish'},
    {value:'NL',label:'Dutch'},{value:'EN-GB',label:'English (British)'},{value:'EN-US',label:'English (American)'},
    {value:'ET',label:'Estonian'},{value:'FI',label:'Finnish'},{value:'FR',label:'French'},{value:'DE',label:'German'},
    {value:'EL',label:'Greek'},{value:'HU',label:'Hungarian'},{value:'ID',label:'Indonesian'},{value:'IT',label:'Italian'},
    {value:'JA',label:'Japanese'},{value:'KO',label:'Korean'},{value:'LV',label:'Latvian'},{value:'LT',label:'Lithuanian'},
    {value:'NB',label:'Norwegian'},{value:'PL',label:'Polish'},{value:'PT-BR',label:'Portuguese (Brazilian)'},
    {value:'PT-PT',label:'Portuguese (European)'},{value:'RO',label:'Romanian'},{value:'RU',label:'Russian'},
    {value:'SK',label:'Slovak'},{value:'SL',label:'Slovenian'},{value:'ES',label:'Spanish'},{value:'SV',label:'Swedish'},
    {value:'TR',label:'Turkish'},{value:'UK',label:'Ukrainian'},
  ];

  // ---- NIP-19 bech32 (BIP-173 reference algorithm, hand-rolled: no CDN dep) ----
  var CHARSET='qpzry9x8gf2tvdw0s3jn54khce6mua7l';
  function polymod(values){
    var GEN=[0x3b6a57b2,0x26508e6d,0x1ea119fa,0x3d4233dd,0x2a1462b3],chk=1;
    for(var p=0;p<values.length;p++){
      var top=chk>>25;
      chk=(chk&0x1ffffff)<<5^values[p];
      for(var i=0;i<5;i++)if((top>>i)&1)chk^=GEN[i];
    }
    return chk;
  }
  function hrpExpand(hrp){
    var ret=[],p;
    for(p=0;p<hrp.length;p++)ret.push(hrp.charCodeAt(p)>>5);
    ret.push(0);
    for(p=0;p<hrp.length;p++)ret.push(hrp.charCodeAt(p)&31);
    return ret;
  }
  function createChecksum(hrp,data){
    var values=hrpExpand(hrp).concat(data).concat([0,0,0,0,0,0]);
    var mod=polymod(values)^1,ret=[];
    for(var p=0;p<6;p++)ret.push((mod>>5*(5-p))&31);
    return ret;
  }
  function verifyChecksum(hrp,data){return polymod(hrpExpand(hrp).concat(data))===1}
  function bech32Encode(hrp,data){
    var combined=data.concat(createChecksum(hrp,data)),out=hrp+'1';
    for(var p=0;p<combined.length;p++)out+=CHARSET.charAt(combined[p]);
    return out;
  }
  function bech32Decode(str){
    str=String(str||'');
    if(str.toLowerCase()!==str&&str.toUpperCase()!==str)return null;
    str=str.toLowerCase();
    var pos=str.lastIndexOf('1');
    if(pos<1||pos+7>str.length||str.length>1000)return null;
    var hrp=str.substring(0,pos),data=[];
    for(var p=pos+1;p<str.length;p++){
      var d=CHARSET.indexOf(str.charAt(p));
      if(d===-1)return null;
      data.push(d);
    }
    if(!verifyChecksum(hrp,data))return null;
    return{hrp:hrp,data:data.slice(0,data.length-6)};
  }
  function convertBits(data,fromBits,toBits,pad){
    var acc=0,bits=0,ret=[],maxv=(1<<toBits)-1;
    for(var i=0;i<data.length;i++){
      var value=data[i];
      if(value<0||value>>fromBits!==0)return null;
      acc=(acc<<fromBits)|value;bits+=fromBits;
      while(bits>=toBits){bits-=toBits;ret.push((acc>>bits)&maxv)}
    }
    if(pad){if(bits>0)ret.push((acc<<(toBits-bits))&maxv)}
    else if(bits>=fromBits||((acc<<(toBits-bits))&maxv))return null;
    return ret;
  }
  function encodeBech32Bytes(hrp,byteArray){
    var words=convertBits(Array.prototype.slice.call(byteArray),8,5,true);
    return words?bech32Encode(hrp,words):null;
  }
  function decodeBech32Bytes(str){
    var d=bech32Decode(str);if(!d)return null;
    var out=convertBits(d.data,5,8,false);
    return out?{hrp:d.hrp,bytes:new Uint8Array(out)}:null;
  }
  function npubEncode(pubHex){return encodeBech32Bytes('npub',hexToBytes(pubHex))}
  function nsecEncode(privHex){return encodeBech32Bytes('nsec',hexToBytes(privHex))}
  function noteEncode(idHex){return encodeBech32Bytes('note',hexToBytes(idHex))}
  function nsecDecode(nsec){var d=decodeBech32Bytes(nsec);return d&&d.hrp==='nsec'?bytesToHex(d.bytes):null}
  function npubDecode(npub){var d=decodeBech32Bytes(npub);return d&&d.hrp==='npub'?bytesToHex(d.bytes):null}
  function shortNpub(npub){return npub.slice(0,10)+'…'+npub.slice(-6)}
  // ---- Lightning: invoices and LNURL-pay (NIP-57 zaps) ----
  // Only what a zap needs: the amount and the description hash of a BOLT11
  // invoice, so an invoice that does not match the zap is never shown.
  function bolt11Parse(pr){
    pr=String(pr||'').trim().toLowerCase();
    if(pr.indexOf('lightning:')===0)pr=pr.slice(10);
    var pos=pr.lastIndexOf('1');
    if(pos<3||pr.length>8000)return null;
    var hrp=pr.slice(0,pos),words=[];
    for(var i=pos+1;i<pr.length;i++){var d=CHARSET.indexOf(pr.charAt(i));if(d<0)return null;words.push(d)}
    if(!verifyChecksum(hrp,words))return null;
    words=words.slice(0,words.length-6);
    var m=hrp.match(/^ln(?:bcrt|tbs|bc|tb)(\d*)([munp]?)$/);
    if(!m||words.length<7+104)return null;
    var msats=null;
    if(m[1]){var mult={'':1e11,m:1e8,u:1e5,n:1e2,p:0.1}[m[2]];msats=Math.round(Number(m[1])*mult)}
    var out={msats:msats,descHash:null},at=7,end=words.length-104;
    while(at+3<=end){
      var type=words[at],len=words[at+1]*32+words[at+2],data=words.slice(at+3,at+3+len);
      if(data.length<len)return null;
      if(type===23&&len===52){var b=convertBits(data,5,8,false);if(b)out.descHash=bytesToHex(new Uint8Array(b))}
      at+=3+len;
    }
    return out;
  }
  async function lnurlPayInfo(address){
    var m=String(address||'').trim().match(/^([A-Za-z0-9._+-]+)@([A-Za-z0-9.-]+\.[A-Za-z]{2,})$/);
    if(!m)throw new Error('address');
    var r=await fetch('https://'+m[2].toLowerCase()+'/.well-known/lnurlp/'+encodeURIComponent(m[1]),{cache:'no-store',headers:{Accept:'application/json'}});
    if(!r.ok)throw new Error('lnurl');
    var d=await r.json();
    if(!d||d.tag!=='payRequest'||typeof d.callback!=='string'||!/^https:\/\//i.test(d.callback))throw new Error('lnurl');
    return d;
  }
  async function lnurlInvoice(info,msats,zapRequestJson){
    var url=new URL(info.callback);
    url.searchParams.set('amount',String(msats));
    url.searchParams.set('nostr',zapRequestJson);
    var r=await fetch(url.toString(),{cache:'no-store'});
    if(!r.ok)throw new Error('invoice');
    var d=await r.json();
    if(!d||d.status==='ERROR'||typeof d.pr!=='string')throw new Error('invoice');
    return d.pr;
  }
  function fmtSats(n){
    n=Number(n)||0;
    if(n>=1e6)return(n/1e6).toFixed(n>=1e7?0:1).replace(/\.0$/,'')+'M';
    if(n>=1e4)return(n/1e3).toFixed(n>=1e5?0:1).replace(/\.0$/,'')+'k';
    return n.toLocaleString();
  }
  var DEFAULT_ZAPS=[{sats:21,msg:'👍'},{sats:100,msg:'🤙'},{sats:500,msg:'🔥'},{sats:1000,msg:'🚀'},{sats:5000,msg:'🎉'}];
  var zapStyled=false;
  function zapStyle(){
    if(zapStyled)return;zapStyled=true;
    var el=document.createElement('style');
    el.textContent='.nos-zap-modal input{display:block;width:100%;box-sizing:border-box;margin:.25rem 0 .6rem;padding:.55rem .65rem;font:inherit;font-size:.9rem;color:var(--pub-fg,#cdd6f4);background:var(--pub-bg,#1e1e2e);border:1px solid var(--pub-border,#45475a);border-radius:.45rem;outline:none}'+
      '.nos-zap-modal input:focus{border-color:var(--pub-accent,#89b4fa)}.nos-zap-modal label.nos-zap-who{display:block;margin-top:.5rem}'+
      '.nos-zap-prefs input{width:100%;box-sizing:border-box;padding:.55rem .65rem;font:inherit;font-size:.9rem;color:var(--pub-fg,#cdd6f4);background:var(--pub-bg,#1e1e2e);border:1px solid var(--pub-border,#45475a);border-radius:.45rem;outline:none}.nos-zap-prefs input:focus{border-color:var(--pub-accent,#89b4fa)}'+
      '.nos-zap-sums{display:flex;gap:.6rem;margin-bottom:.7rem}.nos-zap-sum{flex:1;min-width:0;padding:.7rem .8rem;border-radius:.65rem;background:var(--pub-surface2,#313244);border:2px solid transparent;cursor:pointer}.nos-zap-sum.active{border-color:var(--pub-accent,#89b4fa)}'+
      '.nos-zap-sum-label{font-size:.74rem;color:var(--pub-fg2,#a6adc8)}.nos-zap-sum-val{font-size:1.25rem;font-weight:800;margin:.15rem 0;overflow-wrap:anywhere}.nos-zap-sum-n{font-size:.72rem;color:var(--pub-fg2,#a6adc8)}'+
      '.nos-zap-periods{display:flex;flex-wrap:wrap;gap:.3rem;margin-bottom:.5rem}.nos-zap-foot{font-size:.72rem;line-height:1.45;color:var(--pub-fg2,#a6adc8);margin:1rem 0 0}'+
      '.nos-act.nos-a-zap.on{color:var(--pub-yellow,#f9e2af);font-weight:700}'+
      '.nos-zap-chips{display:flex;flex-wrap:wrap;gap:.4rem;margin:.4rem 0}'+
      '.nos-zap-chip{padding:.5rem .7rem!important;font-size:.85rem!important}.nos-zap-chip.on{background:var(--pub-accent,#89b4fa)!important;color:var(--on-accent,var(--pub-bg,#1e1e2e))!important}'+
      '.nos-zap-who{font-size:.8rem;color:var(--pub-fg2,#a6adc8);margin:.2rem 0 .4rem;overflow-wrap:anywhere}'+
      '.nos-zap-qr{display:flex;justify-content:center;margin:.6rem 0}.nos-zap-qr svg{width:min(15rem,70vw);height:auto;background:#fff;padding:.5rem;border-radius:.5rem}'+
      '.nos-zap-amount{text-align:center;font-weight:800;font-size:1.1rem;margin:.3rem 0}'+
      '.nos-zap-actions{display:flex;gap:.4rem;flex-wrap:wrap;justify-content:center;margin:.5rem 0}'+
      '.nos-zap-actions a.primary{display:inline-block;text-decoration:none;border-radius:.45rem;padding:.45rem .8rem;font-size:.8rem;font-weight:600;background:var(--pub-accent,#89b4fa);color:var(--on-accent,var(--pub-bg,#1e1e2e))}'+
      '.nos-zap-status{text-align:center;font-size:.82rem;color:var(--pub-fg2,#a6adc8);min-height:1.2rem}.nos-zap-status.ok{color:var(--pub-green,#a6e3a1);font-weight:700}'+
      '.nos-zap-prefs{margin-top:1.2rem;border-top:1px solid var(--pub-border,#45475a);padding-top:.8rem}.nos-zap-prefs h3{margin:0 0 .3rem;font-size:.95rem}'+
      '.nos-zap-row{display:flex;gap:.4rem;align-items:center}.nos-zap-row input{margin:.2rem 0}.nos-zap-row .nos-zp-sats{flex:0 0 6.5rem;width:6.5rem}.nos-zap-row .nos-zp-msg{flex:1;min-width:0}.nos-zap-row button{flex:0 0 auto;padding:.4rem .55rem}';
    document.head.appendChild(el);
  }
  var qrLoading=null;
  function loadQr(){
    if(window.qrcode)return Promise.resolve();
    if(qrLoading)return qrLoading;
    qrLoading=new Promise(function(ok,bad){
      var el=document.createElement('script'),src='/apps/nostradamus/vendor/qrcode.js';
      el.src=window.asset?window.asset(src):src;el.onload=ok;el.onerror=function(){qrLoading=null;bad(new Error('qr'))};
      document.head.appendChild(el);
    });
    return qrLoading;
  }

  // nevent/nprofile carry a TLV payload; type 0 is the 32-byte id or pubkey and is
  // the only field a reader of a mention or a quote actually needs.
  function decodeTLV(raw){
    var out={},i=0;
    while(i+2<=raw.length){
      var type=raw[i],len=raw[i+1],value=raw.slice(i+2,i+2+len);
      if(value.length<len)break;
      (out[type]=out[type]||[]).push(value);
      i+=2+len;
    }
    return out;
  }
  function refToId(str){
    var d=decodeBech32Bytes(str);if(!d)return null;
    if(d.hrp==='note')return d.bytes.length===32?bytesToHex(d.bytes):null;
    if(d.hrp==='nevent'){var tlv=decodeTLV(d.bytes);return tlv[0]&&tlv[0][0].length===32?bytesToHex(tlv[0][0]):null}
    return null;
  }
  function refToPubkey(str){
    var d=decodeBech32Bytes(str);if(!d)return null;
    if(d.hrp==='npub')return d.bytes.length===32?bytesToHex(d.bytes):null;
    if(d.hrp==='nprofile'){var tlv=decodeTLV(d.bytes);return tlv[0]&&tlv[0][0].length===32?bytesToHex(tlv[0][0]):null}
    return null;
  }

  // ---- Nostr event crypto (NIP-01) ----
  function getXOnlyPubkey(priv){return window.NostrCrypto.getPublicKey(priv,true).slice(1)}
  function genPrivKey(){
    for(var i=0;i<10;i++){
      var candidate=crypto.getRandomValues(new Uint8Array(32));
      try{getXOnlyPubkey(candidate);return candidate}catch(_){}
    }
    throw new Error('keygen_failed');
  }
  async function sha256(dataBytes){return new Uint8Array(await crypto.subtle.digest('SHA-256',dataBytes))}
  function serializeEvent(ev){return JSON.stringify([0,ev.pubkey,ev.created_at,ev.kind,ev.tags,ev.content])}
  async function finalizeEvent(base,priv){
    var ev={kind:base.kind,tags:base.tags||[],content:base.content||'',created_at:Math.floor(Date.now()/1000)};
    ev.pubkey=bytesToHex(getXOnlyPubkey(priv));
    var idBytes=await sha256(new TextEncoder().encode(serializeEvent(ev)));
    ev.id=bytesToHex(idBytes);
    ev.sig=bytesToHex(window.NostrCrypto.schnorr.sign(idBytes,priv));
    return ev;
  }

  // ---- tag readers (NIP-10 / NIP-18) ----
  function tagsOf(ev,name){return(ev&&ev.tags||[]).filter(function(tg){return tg[0]===name})}
  function eTags(ev){return tagsOf(ev,'e')}
  function lastETag(ev){var list=eTags(ev);return list.length?list[list.length-1][1]:null}
  function isReply(ev){return eTags(ev).length>0}
  // NIP-10 leaves two conventions in the wild: marked tags, and the positional
  // form where the first e tag is the root and the last one is the parent. Reading
  // markers first and falling back to position is what makes threads from mixed
  // clients hang together instead of flattening.
  function replyTarget(ev){
    var list=eTags(ev);
    if(!list.length)return null;
    var marked=list.filter(function(tg){return tg[3]==='reply'});
    if(marked.length)return marked[marked.length-1][1];
    var root=list.filter(function(tg){return tg[3]==='root'});
    if(root.length&&list.length===1)return root[0][1];
    return list[list.length-1][1];
  }
  function rootTarget(ev){
    var list=eTags(ev);
    if(!list.length)return null;
    var root=list.filter(function(tg){return tg[3]==='root'});
    if(root.length)return root[0][1];
    return list[0][1];
  }
  function quotedId(ev){
    var q=tagsOf(ev,'q');
    if(q.length&&q[0][1])return q[0][1];
    var match=(ev.content||'').match(/nostr:(n(?:ote|event)1[023456789acdefghjklmnpqrstuvwxyz]+)/);
    return match?refToId(match[1]):null;
  }
  // What a reaction or a repost points at is always its last e tag; a reply's
  // target needs the NIP-10 reading above.
  function targetOf(ev){return ev.kind===1?replyTarget(ev):lastETag(ev)}

  // ---- relay pool: raw WebSocket per relay, NIP-01 REQ/EVENT/CLOSE ----
  var CONTACT_RELAYS=['wss://purplepag.es'];
  var EOSE_GRACE_MS=1500;
  function createPool(){
    var conns={},subs={},okWaiters={},statusListeners=[];
    function notifyStatus(){statusListeners.forEach(function(cb){cb()})}
    function send(c,msg){
      if(c.status==='open'&&c.ws&&c.ws.readyState===1)c.ws.send(JSON.stringify(msg));
      else c.buffer.push(msg);
    }
    function scheduleReconnect(c){
      if(c.closing)return;
      clearTimeout(c.timer);
      c.retries=(c.retries||0)+1;
      var delay=Math.min(30000,1000*Math.pow(2,c.retries));
      c.timer=setTimeout(function(){open(c)},delay);
    }
    function open(c){
      try{c.ws=new WebSocket(c.url)}catch(_){c.status='error';notifyStatus();scheduleReconnect(c);return}
      c.status='connecting';notifyStatus();
      c.ws.onopen=function(){
        c.status='open';c.retries=0;notifyStatus();
        Object.keys(subs).forEach(function(subId){
          var sub=subs[subId];
          if(sub.urls.indexOf(c.url)>=0)send(c,['REQ',subId].concat(sub.filters));
        });
        var queued=c.buffer;c.buffer=[];
        queued.forEach(function(msg){c.ws.send(JSON.stringify(msg))});
      };
      c.ws.onmessage=function(ev){
        var data;try{data=JSON.parse(ev.data)}catch(_){return}
        handleMessage(c.url,data);
      };
      c.ws.onclose=function(){c.status='closed';notifyStatus();scheduleReconnect(c)};
      c.ws.onerror=function(){c.status='error';notifyStatus()};
    }
    function connect(url){
      if(conns[url])return conns[url];
      var c={url:url,ws:null,status:'connecting',buffer:[],retries:0,timer:0,closing:false};
      conns[url]=c;open(c);return c;
    }
    function fireEose(subId){
      var sub=subs[subId];
      if(!sub||sub.eosed)return;
      sub.eosed=true;clearTimeout(sub.timer);clearTimeout(sub.grace);
      if(sub.onEose)sub.onEose(sub.responses||0);
    }
    function handleMessage(url,data){
      var type=data[0];
      if(type==='EVENT'){
        var sub=subs[data[1]];
        if(sub&&sub.onEvent)sub.onEvent(data[2],url);
      }else if(type==='EOSE'){
        var sub2=subs[data[1]];
        if(sub2){
          if(sub2.pending[url])sub2.responses=(sub2.responses||0)+1;
          delete sub2.pending[url];
          if(!Object.keys(sub2.pending).length)fireEose(data[1]);
          // A relay that is down never answers, and waiting out the full ceiling
          // for it held every list on "Loading". Once a relay has answered, the
          // rest get a short grace period and then the list is drawn without them.
          else if(!sub2.waitAll&&!sub2.grace){var sid=data[1];sub2.grace=setTimeout(function(){fireEose(sid)},EOSE_GRACE_MS)}
        }
      }else if(type==='OK'){
        var waiters=okWaiters[data[1]]||[];
        waiters.slice().forEach(function(fn){fn(url,data[2],data[3])});
      }
    }
    return{
      // One relay reaching the end of its stored events is not the end of the
      // query — the fastest relay is often the emptiest. Ranking a trending window
      // needs every relay's answer, so EOSE waits for all of them, with a ceiling
      // because a relay that is merely unreachable would otherwise never answer.
      subscribe:function(urls,subId,filters,onEvent,onEose,waitAll){
        var sub={urls:urls,filters:filters,onEvent:onEvent,onEose:onEose,eosed:false,pending:{},timer:0,waitAll:!!waitAll};
        urls.forEach(function(url){sub.pending[url]=true});
        subs[subId]=sub;
        if(!urls.length){setTimeout(function(){fireEose(subId)},0);return}
        sub.timer=setTimeout(function(){fireEose(subId)},6000);
        urls.forEach(function(url){send(connect(url),['REQ',subId].concat(filters))});
      },
      unsubscribe:function(subId){
        var sub=subs[subId];if(!sub)return;
        clearTimeout(sub.timer);clearTimeout(sub.grace);
        sub.urls.forEach(function(url){var c=conns[url];if(c)send(c,['CLOSE',subId])});
        delete subs[subId];
      },
      publish:function(urls,event,onProgress){
        return new Promise(function(resolve){
          var results=[],pending=urls.length,finished=false,resolved=false,answered={};
          if(!pending){resolve(results);return}
          // The caller is released as soon as ONE relay has accepted the note: the
          // event has already gone out to every relay, and waiting for the slowest
          // (or dead) one kept the composer open for up to 8 seconds. The waiter
          // stays registered until all have answered, so late answers still land.
          var allDone;results.all=new Promise(function(r){allDone=r});
          function done(){if(resolved)return;resolved=true;resolve(results)}
          function finish(){if(finished)return;finished=true;clearTimeout(timer);
            var idx=(okWaiters[event.id]||[]).indexOf(fn);if(idx>=0)okWaiters[event.id].splice(idx,1);
            done();allDone({ok:results.filter(function(r){return r.ok}).length,total:urls.length});
          }
          function fn(url,ok,msg){
            if(urls.indexOf(url)<0||answered[url])return;
            answered[url]=true;results.push({url:url,ok:ok,message:msg});
            if(onProgress)onProgress(results.filter(function(r){return r.ok}).length,results.length,urls.length);
            if(ok)done();
            pending--;if(pending<=0)finish();
          }
          okWaiters[event.id]=okWaiters[event.id]||[];okWaiters[event.id].push(fn);
          var timer=setTimeout(finish,8000);
          urls.forEach(function(url){send(connect(url),['EVENT',event])});
        });
      },
      // `keep` is for connections that are not relays and therefore are not in
      // the user's relay list — the ranking cache. Without it, saving the relay
      // tab would tear down a connection the relay list never described.
      setRelayUrls:function(urls,keep){
        keep=keep||[];
        Object.keys(conns).forEach(function(url){
          if(urls.indexOf(url)<0&&keep.indexOf(url)<0){var c=conns[url];c.closing=true;clearTimeout(c.timer);if(c.ws)c.ws.close();delete conns[url]}
        });
        urls.forEach(function(url){connect(url)});
        notifyStatus();
      },
      statusOf:function(url){return(conns[url]&&conns[url].status)||'closed'},
      onStatusChange:function(cb){statusListeners.push(cb)},
      destroy:function(){
        Object.keys(subs).forEach(function(subId){clearTimeout(subs[subId].timer)});
        Object.keys(conns).forEach(function(url){var c=conns[url];c.closing=true;clearTimeout(c.timer);if(c.ws)c.ws.close()});
        conns={};subs={};okWaiters={};
      }
    };
  }

  // ---- unlock session storage ----
  // The unlocked session keeps a non-extractable CryptoKey in IndexedDB. Web
  // Storage can only hold the raw exported bytes, and raw AES bytes sitting next
  // to the Apps Hub token in the same origin means one XSS anywhere on the domain
  // walks away with the nsec itself — the very thing the master password exists to
  // prevent. A CryptoKey survives the structured clone but never yields its
  // material to script, so the worst an attacker on the page can do is sign while
  // the session is live; the identity itself stays where it cannot be copied.
  var IDB_NAME='nostradamus',IDB_STORE='session';
  function idbOpen(){
    return new Promise(function(resolve,reject){
      var req=indexedDB.open(IDB_NAME,1);
      req.onupgradeneeded=function(){if(!req.result.objectStoreNames.contains(IDB_STORE))req.result.createObjectStore(IDB_STORE)};
      req.onsuccess=function(){resolve(req.result)};
      req.onerror=function(){reject(req.error)};
    });
  }
  function idbRun(mode,fn){
    return idbOpen().then(function(db){
      return new Promise(function(resolve,reject){
        var tx=db.transaction(IDB_STORE,mode),request=fn(tx.objectStore(IDB_STORE));
        tx.oncomplete=function(){db.close();resolve(request?request.result:null)};
        tx.onerror=function(){db.close();reject(tx.error)};
      });
    });
  }
  // A browser with IndexedDB blocked (private mode, hardened settings) simply gets
  // no persistence: the key lives in memory for as long as the widget is mounted
  // and the password is asked for again on reload. That is a worse experience than
  // a stored session but never a worse secret.
  // Keyed by npub, not a single fixed id: several identities can each hold a
  // live cached session at once, which is what lets switching between them
  // skip the password when both are still within their unlock window.
  function idbGet(id){return idbRun('readonly',function(store){return store.get(id)}).catch(function(){return null})}
  function idbPut(id,value){return idbRun('readwrite',function(store){store.put(value,id);return null}).catch(function(){})}
  function idbDel(id){return idbRun('readwrite',function(store){store.delete(id);return null}).catch(function(){})}

  var styled=false;
  function style(){if(styled)return;styled=true;var s=document.createElement('style');s.textContent='.nos,.nos *,.nos-modal,.nos-modal *{box-sizing:border-box}.nos{height:100%;display:flex;flex-direction:column;position:relative;background:var(--pub-bg,#1e1e2e);color:var(--pub-fg,#cdd6f4);font-family:system-ui,sans-serif;overflow:hidden}.nos-bar{border-bottom:1px solid var(--pub-border,#45475a);flex:0 0 auto}.nos-bar-head{display:flex;align-items:center;gap:.5rem;padding:.55rem .7rem}.nos-title{font-weight:700;font-size:.88rem;white-space:nowrap}.nos-tabs{display:flex;gap:.25rem;flex:1;overflow-x:auto;scrollbar-width:none}.nos-tabs::-webkit-scrollbar{display:none}.nos-tab{background:transparent;padding:.35rem .6rem;border-radius:.5rem;white-space:nowrap;position:relative}.nos-tab.active{background:var(--pub-accent,#89b4fa);color:var(--on-accent,var(--pub-bg,#1e1e2e))}.nos-badge{display:inline-block;min-width:1.05rem;padding:0 .25rem;margin-left:.25rem;border-radius:.6rem;background:var(--pub-red,#f38ba8);color:var(--pub-bg,#1e1e2e);font-size:.65rem;line-height:1.05rem;text-align:center}.nos-bar-btn{flex:0 0 auto;padding:.35rem .5rem;display:inline-flex;align-items:center;justify-content:center}.nos-me{flex:0 0 auto;padding:0;background:none!important}.nos-modes{display:flex;gap:.3rem;padding:0 .7rem .55rem;overflow-x:auto;scrollbar-width:none}.nos-modes::-webkit-scrollbar{display:none}.nos-mode{background:var(--pub-surface2,#313244);padding:.28rem .6rem;border-radius:999px;font-size:.74rem;white-space:nowrap}.nos-mode.active{background:var(--pub-accent,#89b4fa);color:var(--on-accent,var(--pub-bg,#1e1e2e))}.nos-body{flex:1;min-height:0;overflow:auto;overflow-anchor:none;padding:.7rem}.nos button,.nos input,.nos textarea,.nos select,.nos-modal button,.nos-modal textarea{font:inherit}.nos button,.nos-modal button{border:0;border-radius:.45rem;padding:.45rem .7rem;cursor:pointer;font-size:.8rem;font-weight:600;background:var(--pub-border,#45475a);color:var(--pub-fg,#cdd6f4);transition:filter .15s,transform .15s}.nos button:hover,.nos-modal button:hover{filter:brightness(1.12)}.nos button:active{transform:translateY(1px)}.nos button:disabled{opacity:.6;cursor:default}.nos .primary,.nos-modal .primary{background:var(--pub-accent,#89b4fa);color:var(--on-accent,var(--pub-bg,#1e1e2e))}.nos input,.nos textarea,.nos select,.nos-modal textarea{width:100%;background:var(--pub-bg,#1e1e2e);border:1px solid var(--pub-border,#45475a);border-radius:.45rem;color:var(--pub-fg,#cdd6f4);padding:.55rem .65rem;outline:none;margin:.3rem 0}.nos input:focus,.nos textarea:focus,.nos select:focus,.nos-modal textarea:focus{border-color:var(--pub-accent,#89b4fa)}.nos-error{min-height:1.2rem;color:var(--pub-red,#f38ba8);font-size:.8rem;margin:.3rem 0}.nos-empty{display:flex;flex:1;align-items:center;justify-content:center;text-align:center;padding:1.5rem;color:var(--pub-fg2,#a6adc8);font-size:.85rem}.nos-unlock,.nos-onboard{display:flex;flex:1;align-items:center;justify-content:center;padding:1rem}.nos-unlock>div,.nos-card{width:100%;max-width:24rem;background:var(--pub-surface2,#313244);padding:1.25rem;border-radius:.7rem}.nos-unlock h2,.nos-card h2{font-size:1.05rem;margin:0 0 .4rem}.nos-unlock p,.nos-card p{font-size:.82rem;line-height:1.45;color:var(--pub-fg2,#a6adc8)}.nos-duration-hint{font-size:.72rem;opacity:.75;margin:.2rem 0 .6rem}.nos-warn{font-size:.78rem;line-height:1.45;color:var(--pub-yellow,#f9e2af);border:1px solid var(--pub-yellow,#f9e2af);border-radius:.45rem;padding:.5rem .6rem;margin:.5rem 0}.nos-link{background:none!important;padding:.4rem 0;font-size:.78rem;font-weight:400;color:var(--pub-accent,#89b4fa);text-decoration:underline}.nos-view-value{background:var(--pub-bg,#1e1e2e);border:1px solid var(--pub-border,#45475a);border-radius:.45rem;padding:.55rem .65rem;font-size:.8rem;overflow-wrap:anywhere;margin:.3rem 0}.nos-key-value{font-family:monospace}.nos-check{display:flex!important;align-items:center;gap:.45rem;width:auto;font-size:.8rem;cursor:pointer}.nos-check input{width:auto;margin:0}.nos-note{border:1px solid var(--pub-border,#45475a);background:var(--pub-surface2,#313244);border-radius:.65rem;padding:.65rem;margin-bottom:.55rem;cursor:pointer;transition:background .3s}.nos-note:hover{filter:brightness(1.05)}.nos-note.nos-flat{border:0;background:none;padding:.55rem 0;border-bottom:1px solid var(--pub-border,#45475a);border-radius:0;margin:0}.nos-boost{font-size:.72rem;color:var(--pub-fg2,#a6adc8);margin-bottom:.35rem}.nos-note-head{display:flex;align-items:center;gap:.5rem}.nos-avatar-wrap{position:relative;width:2.1rem;height:2.1rem;flex:0 0 auto;cursor:pointer}.nos-avatar-wrap.nos-lg{width:4rem;height:4rem}.nos-avatar{position:absolute;inset:0;width:100%;height:100%;border-radius:.5rem;object-fit:cover;display:grid;place-items:center;background:var(--pub-accent,#89b4fa);color:var(--on-accent,var(--pub-bg,#1e1e2e));font-weight:800;overflow:hidden}.nos-avatar-img{background:var(--pub-surface2,#313244)}.nos-note-who{flex:1;min-width:0;cursor:pointer}.nos-note-name{display:block;font-weight:700;font-size:.84rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.nos-note-time{display:block;font-size:.71rem;color:var(--pub-dim,#a6adc8)}.nos-nip05{font-size:.71rem;color:var(--pub-accent,#89b4fa)}.nos-mute-btn{flex:0 0 auto;padding:.28rem .45rem;font-size:.78rem;line-height:1}.nos-mute-btn.on{background:var(--pub-accent,#89b4fa)!important;color:var(--on-accent,var(--pub-bg,#1e1e2e))!important}@media(max-width:520px){.nos-mute-text{display:none}}.nos-follow-btn{flex:0 0 auto;padding:.28rem .55rem;font-size:.72rem}.nos-reply-of-wrap{margin:.35rem 0}.nos-reply-of-label{font-size:.72rem;color:var(--pub-fg2,#a6adc8);margin-bottom:.2rem}.nos-reply-of-wrap .nos-quote{margin:0;padding:.4rem .5rem}.nos-reply-of-wrap .nos-quote .nos-note-content{font-size:.76rem;max-height:5rem}.nos-reply-of-wrap .nos-avatar-wrap{width:1.5rem;height:1.5rem}.nos-reply-of-wrap .nos-note-name{font-size:.76rem}.nos-reply-of-wrap .nos-note-time{font-size:.66rem}.nos-note-content{white-space:pre-wrap;overflow-wrap:anywhere;font-size:.86rem;margin:.4rem 0;overflow:hidden}.nos-note-content a{color:var(--pub-accent,#89b4fa)}.nos-mention{color:var(--pub-accent,#89b4fa);cursor:pointer}.nos-embed-link{display:block;width:100%}.nos-embed-img{display:block;max-width:100%;height:auto;max-height:22rem;border-radius:.5rem;margin-top:.4rem;object-fit:contain}.nos-embed-video{display:block;max-width:100%;height:auto;max-height:22rem;border-radius:.5rem;margin-top:.4rem;background:#000}.nos-embed-audio{display:block;width:100%;margin-top:.4rem}.nos-quote{border:1px solid var(--pub-border,#45475a);border-radius:.5rem;padding:.5rem;margin:.45rem 0;background:var(--pub-bg,#1e1e2e)}.nos-preview-card{display:flex;gap:.6rem;align-items:stretch;border:1px solid var(--pub-border,#45475a);border-radius:.5rem;margin:.45rem 0;background:var(--pub-bg,#1e1e2e);overflow:hidden;text-decoration:none;color:inherit}.nos-preview-card:hover{filter:brightness(1.08)}.nos-preview-img{width:5.5rem;flex:0 0 5.5rem;object-fit:cover;background:var(--pub-surface2,#313244)}.nos-preview-text{flex:1;min-width:0;display:flex;flex-direction:column;gap:.15rem;padding:.5rem .55rem}.nos-preview-site{font-size:.68rem;color:var(--pub-fg2,#a6adc8);text-transform:uppercase;letter-spacing:.03em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.nos-preview-title{font-size:.82rem;font-weight:700;line-height:1.3;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.nos-preview-desc{font-size:.74rem;color:var(--pub-fg2,#a6adc8);line-height:1.35;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.nos-compose-preview:empty{display:none}.nos-quote .nos-note-content{font-size:.8rem;max-height:12rem}.nos-menu{position:absolute;z-index:30;min-width:10rem;max-width:calc(100% - 8px);display:flex;flex-direction:column;gap:.1rem;padding:.3rem;background:var(--pub-surface2,#313244);border:1px solid var(--pub-border,#45475a);border-radius:.55rem;box-shadow:0 .4rem 1rem rgba(0,0,0,.35)}.nos-menu button{text-align:left;background:transparent!important;padding:.5rem .6rem}.nos-menu button:hover{background:var(--pub-border,#45475a)!important}.nos-a-more{font-weight:700!important;letter-spacing:.05em}.nos-subtabs{display:flex;border-bottom:1px solid var(--pub-border,#45475a);margin:.4rem 0 .6rem}.nos-subtab{flex:1;background:transparent!important;border-radius:0!important;padding:.6rem .4rem!important;color:var(--pub-fg2,#a6adc8)!important;border-bottom:3px solid transparent!important}.nos-subtab.active{color:var(--pub-fg,#cdd6f4)!important;border-bottom-color:var(--pub-accent,#89b4fa)!important}.nos-ai-card{display:flex;flex-direction:column;max-height:calc(100% - 2rem)}.nos-ai-modal{padding:.5rem}.nos-ai-card .nos-modal-close{flex:0 0 auto}.nos-ai-foot textarea{font-size:1rem;min-height:2.6rem;max-height:7rem}@media(max-width:520px){.nos-ai-modal{padding:0;align-items:stretch}.nos-ai-card{max-width:none;height:100%;max-height:100%;border-radius:0;padding:.7rem}.nos-ai-msg{max-width:96%}}.nos-ai-post{max-height:7rem;overflow:auto;margin:0 0 .5rem}.nos-ai-log{flex:1;min-height:6rem;overflow:auto;display:flex;flex-direction:column;gap:.4rem;margin-bottom:.4rem}.nos-ai-msg{white-space:pre-wrap;overflow-wrap:anywhere;font-size:.84rem;line-height:1.45;padding:.5rem .65rem;border-radius:.6rem;max-width:92%}.nos-ai-user{align-self:flex-end;background:var(--pub-accent,#89b4fa);color:var(--on-accent,var(--pub-bg,#1e1e2e))}.nos-ai-bot{align-self:flex-start;background:var(--pub-bg,#1e1e2e);border:1px solid var(--pub-border,#45475a)}.nos-ai-wait{color:var(--pub-fg2,#a6adc8);font-style:italic}.nos-ai-discuss{margin-top:.4rem;display:flex}.nos-ai-discuss button{flex:1}.nos-ai-hint{font-size:.78rem;color:var(--pub-fg2,#a6adc8);padding:.3rem 0}.nos-ai-foot{display:flex;gap:.4rem;align-items:flex-end}.nos-ai-foot textarea{margin:0;resize:none;flex:1}.nos-ai-credits{font-size:.74rem;color:var(--pub-fg2,#a6adc8);white-space:nowrap}.nos-ai-item{cursor:pointer}.nos-ai-excerpt{max-height:4.5rem;color:var(--pub-fg2,#a6adc8)}.nos-note-actions{display:flex;gap:.15rem;flex-wrap:wrap;margin-top:.2rem}.nos-act{background:transparent!important;padding:.3rem .45rem;font-size:.74rem;font-weight:400;color:var(--pub-fg2,#a6adc8)}.nos-act:hover{color:var(--pub-fg,#cdd6f4)}.nos-act.on{color:var(--pub-accent,#89b4fa);font-weight:700}.nos-act.nos-a-like.on{color:var(--pub-red,#f38ba8)}.nos-act.nos-a-repost.on{color:var(--pub-green,#a6e3a1)}.nos-note-translation{font-size:.82rem;line-height:1.4;font-style:italic;color:var(--pub-fg2,#a6adc8);border-top:1px dashed var(--pub-border,#45475a);padding-top:.35rem;margin-top:.2rem;overflow-wrap:anywhere;white-space:pre-wrap}.nos-modal{position:absolute;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:flex-start;justify-content:center;padding:1rem;z-index:20;overflow:auto}.nos-modal-card{width:100%;max-width:30rem;background:var(--pub-surface2,#313244);color:var(--pub-fg,#cdd6f4);border-radius:.7rem;padding:.9rem;font-family:system-ui,sans-serif}.nos-modal-head{display:flex;align-items:center;gap:.5rem;margin-bottom:.4rem}.nos-modal-title{flex:1;font-weight:700;font-size:.9rem}.nos-modal-input{min-height:6rem;resize:vertical}.nos-modal-foot{display:flex;gap:.4rem;justify-content:flex-end;align-items:center}.nos-modal-ctx{max-height:11rem;overflow:auto;margin-bottom:.5rem}.nos-user-head{margin-bottom:.7rem}.nos-banner{width:100%;height:6.5rem;object-fit:cover;border-radius:.5rem;background:var(--pub-surface2,#313244)}.nos-user-row{display:flex;align-items:flex-end;gap:.6rem;margin-top:-1.6rem;padding:0 .3rem}.nos-user-meta{flex:1;min-width:0;padding-bottom:.2rem}.nos-user-name{font-weight:800;font-size:1rem}.nos-user-about{font-size:.82rem;line-height:1.45;margin:.5rem 0;white-space:pre-wrap;overflow-wrap:anywhere}.nos-user-stats{font-size:.74rem;color:var(--pub-fg2,#a6adc8);display:flex;gap:.9rem;flex-wrap:wrap}.nos-notif{display:flex;gap:.5rem;align-items:flex-start;border-bottom:1px solid var(--pub-border,#45475a);padding:.55rem .1rem;cursor:pointer}.nos-notif-new{background:color-mix(in srgb,var(--pub-accent,#89b4fa) 14%,transparent);box-shadow:inset 3px 0 0 var(--pub-accent,#89b4fa);padding-left:.5rem}.nos-notif-body{flex:1;min-width:0}.nos-notif-line{font-size:.8rem}.nos-notif-quote{font-size:.76rem;color:var(--pub-fg2,#a6adc8);overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;margin-top:.15rem}.nos-notif-on{font-size:.74rem;color:var(--pub-fg2,#a6adc8);border-left:2px solid var(--pub-accent,#89b4fa);padding-left:.45rem;margin-top:.25rem;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.nos-notif-on span{font-weight:700}.nos-notif-time{font-size:.7rem;color:var(--pub-dim,#a6adc8)}.nos-profile-form label{display:block;font-size:.75rem;font-weight:700;color:var(--pub-fg2,#a6adc8);margin:.55rem 0 .15rem}.nos-profile-form textarea{min-height:4rem}.nos-profile-meta{margin-top:1rem;font-size:.76rem;color:var(--pub-fg2,#a6adc8)}.nos-relay-row{display:flex;align-items:center;gap:.5rem;padding:.4rem 0;border-bottom:1px solid var(--pub-border,#45475a);font-size:.82rem;flex-wrap:wrap}.nos-relay-dot{width:.6rem;height:.6rem;border-radius:50%;flex:0 0 auto;background:var(--pub-dim,#a6adc8)}.nos-relay-open{background:var(--pub-green,#a6e3a1)}.nos-relay-connecting{background:var(--pub-yellow,#f9e2af)}.nos-relay-dot.nos-relay-closed,.nos-relay-dot.nos-relay-error{background:var(--pub-red,#f38ba8)}.nos-relay-url{flex:1;min-width:9rem;overflow-wrap:anywhere}.nos-relay-del{flex:0 0 auto;padding:.3rem .5rem}.nos-relay-add{display:flex;gap:.4rem;margin-top:.6rem}.nos-relay-add input{flex:1;margin:0}.nos-relay-add button{flex:0 0 auto}.nos-newposts-bar{position:sticky;top:0;z-index:5;height:0;display:flex;justify-content:center;overflow:visible}.nos-newposts{display:flex;align-items:center;gap:.4rem;margin:0;padding:.4rem .8rem .4rem .4rem;border-radius:999px;background:var(--pub-accent,#89b4fa);color:var(--on-accent,var(--pub-bg,#1e1e2e));font-size:.78rem;font-weight:700;box-shadow:0 .25rem .6rem rgba(0,0,0,.25)}.nos-newposts-avatars{display:flex}.nos-newposts-avatars .nos-avatar-wrap{width:1.6rem;height:1.6rem;margin-left:-.6rem;border:2px solid var(--pub-accent,#89b4fa);border-radius:.6rem}.nos-newposts-avatars .nos-avatar-wrap:first-child{margin-left:0}.nos-newposts-avatars .nos-avatar{font-size:.68rem}.nos-people-stats{display:flex;gap:1rem;margin:.5rem 0}.nos-people-btn{background:none!important;padding:0;font-size:.8rem;font-weight:400;color:var(--pub-fg2,#a6adc8)}.nos-people-btn:hover{color:var(--pub-fg,#cdd6f4)}.nos-people-btn b{color:var(--pub-fg,#cdd6f4);font-weight:700}.nos-modal-images{display:flex;gap:.4rem;flex-wrap:wrap;margin:.3rem 0}.nos-modal-image{position:relative;width:4.5rem;height:4.5rem}.nos-modal-image img{width:100%;height:100%;object-fit:cover;border-radius:.45rem}.nos-modal-image-del{position:absolute;top:-.35rem;right:-.35rem;width:1.3rem;height:1.3rem;padding:0;border-radius:50%;background:var(--pub-red,#f38ba8)!important;color:var(--pub-bg,#1e1e2e);font-size:.65rem;line-height:1;display:flex;align-items:center;justify-content:center}.nos-modal-image-btn{background:transparent!important;font-size:1rem;padding:.4rem .5rem}.nos-modal-foot{align-items:center}.nos-identity-row{display:flex;align-items:center;gap:.5rem;padding:.45rem 0;border-bottom:1px solid var(--pub-border,#45475a)}.nos-identity-row[data-npub],.nos-identity-row[data-user]{cursor:pointer}.nos-search-input{margin:0 0 .6rem}.nos-search-results .nos-identity-row{padding:.55rem .1rem}.nos-search-results .nos-avatar-wrap{width:2.1rem;height:2.1rem}.nos-identity-row .nos-avatar-wrap{width:1.8rem;height:1.8rem}.nos-identity-label{flex:1;min-width:0;overflow-wrap:anywhere;font-size:.8rem}.nos-identity-actions{display:flex;gap:.3rem;flex:0 0 auto}.nos-identity-actions button{padding:.25rem .5rem;font-size:.72rem}.nos-identities-title{font-weight:700;font-size:.76rem;margin-top:.7rem}';s.textContent+='.nos-desktop-modes{display:flex;gap:.25rem}.nos-desktop-modes .nos-mode{border-radius:.5rem;padding:.35rem .6rem;white-space:nowrap}.nos-mode-icon{display:none}.nos .nos-bar-head .nos-new,.nos-bar-head .nos-notifications-btn,.nos-bar-head .nos-more-btn{width:2.7rem;height:2rem;padding:.2rem}.nos-more-btn .nos-avatar-wrap{width:1.5rem;height:1.5rem}.nos-more-btn.active,.nos-notifications-btn.active{background:var(--pub-accent,#89b4fa);color:var(--on-accent,var(--pub-bg,#1e1e2e))}.nos-notifications-btn{position:relative}.nos-notifications-btn .nos-badge{position:absolute;top:0;right:0;margin:0}.nos-menu{max-height:calc(100% - 8px);overflow:auto}.nos-menu-separator{border-top:1px solid var(--pub-border,#45475a);margin:.25rem .2rem}.nos-menu .nos-menu-identity{display:flex;align-items:center;gap:.5rem}.nos-menu-identity .nos-avatar-wrap{width:1.8rem;height:1.8rem;flex:0 0 1.8rem}.nos-menu-identity-name{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}@media(min-width:521px){.nos-modes{display:none!important}}@media(max-width:520px){.nos-desktop-modes{display:flex;gap:.2rem}.nos-desktop-modes .nos-mode{position:relative;width:2.5rem;height:2.5rem;padding:.3rem;display:inline-flex;align-items:center;justify-content:center}.nos-mode-icon{display:inline;font-size:1rem}.nos-mode-label{display:none}.nos-desktop-modes .nos-badge{position:absolute;top:0;right:0;margin:0}.nos-bar-head{gap:.2rem;padding:.4rem .6rem}.nos-bar-head .nos-tabs{min-width:0;flex:1;gap:.2rem;overflow:visible}.nos-bar-head .nos-feed-tab{display:inline-flex!important;align-items:center;justify-content:center;width:2.5rem;height:2.5rem;padding:.3rem}.nos-bar-head .nos-bar-btn{width:2.5rem;height:2.5rem;padding:.3rem}.nos-modes{flex-wrap:wrap;overflow:visible;gap:.25rem;padding:0 .6rem .4rem}.nos-modes .nos-mode{flex:1 1 auto;text-align:center;padding:.35rem .3rem}}';document.head.appendChild(s);zapStyle();imageViewerStyle()}

  // A native modal keeps focus inside the preview and supports Escape on desktop.
  function imageViewerStyle(){
    var s=document.createElement('style');
    s.textContent='.nos-image-viewer{box-sizing:border-box;position:fixed;inset:0;width:100%;height:100%;max-width:none;max-height:none;margin:0;border:0;padding:3.5rem 1rem 1rem;background:rgba(0,0,0,.94);color:#fff;overflow:hidden}.nos-image-viewer[open]{display:flex;align-items:center;justify-content:center}.nos-image-viewer::backdrop{background:rgba(0,0,0,.7)}.nos-image-viewer img{display:block;max-width:100%;max-height:100%;object-fit:contain}.nos-image-viewer-close{position:absolute;top:.6rem;right:.6rem;width:2.75rem;height:2.75rem;border:1px solid #888;border-radius:50%;background:#222;color:#fff;font:1.3rem system-ui,sans-serif;cursor:pointer}.nos-image-viewer-close:focus-visible{outline:2px solid #fff;outline-offset:2px}';
    document.head.appendChild(s);
  }

  function mount(root,opts){
    opts=opts||{};style();
    var token=localStorage.getItem('apphub_token');
    if(!token){root.innerHTML='<div class="nos-empty">'+esc(t('nos_login'))+'</div>';if(opts.onNeedLogin)opts.onNeedLogin();return{destroy:function(){}}}
    var DURATION_KEY='nos_vault_duration',TAB_KEY='nos_vault_tab',SEEN_KEY='nos_notif_seen',FEED_MODE_KEY='nos_feed_mode',ACTIVE_KEY='nos_active_npub';
    var TR_LANG_KEY='nos_translate_lang',PUB_LANG_KEY='nos_publish_lang';
    var FEED_MODES=['following','trending','discover'];
    // Anyone still carrying a saved '1', '4' or '24' from the old trending
    // windows lands on Discover rather than on a mode that no longer exists.
    var DISCOVER_LIMIT=60;
    // Popular. A relay has no ranking to offer — trending is a service built on
    // top of Nostr, not a part of the protocol — so this is the one connection
    // in the app the user did not choose themselves. Primal's cache speaks the
    // ordinary relay protocol, so the existing pool talks to it unchanged.
    //
    // Two lists rather than one, because measuring them showed they answer
    // different questions. Trending over 24h is dominated by notes old enough to
    // have gathered engagement (median age 19h), so on its own it barely moves
    // between visits. Most-zapped over 4h has a median age of 2h and turns over
    // within the hour. Merged and shown newest-first, the top of the list is
    // what is happening now and the day's big threads sit below it — and there
    // is no time window for anyone to have to pick.
    var TRENDING_URL='wss://cache2.primal.net/v1';
    var TRENDING_CACHES=['explore_global_trending_24h','explore_global_mostzapped_4h'];
    // The cache honours only the first filter of a REQ, so each list is its own
    // subscription rather than one request carrying both.
    var TRENDING_SUBS=TRENDING_CACHES.map(function(_,i){return 'trending'+i});
    // The background refresh asks the same two lists again, under its own ids, so
    // it never disturbs the subscriptions the open list is holding.
    var TRENDING_POLL_SUBS=TRENDING_CACHES.map(function(_,i){return 'poll-trending'+i});
    var TRENDING_TTL=300000;
    var PRIMAL_STATS_KIND=10000100;
    var key=null,privBytes=null,pubHex=null,vaultInfo=null,relays=[],autoLockTimer=0,destroyed=false,session=null;
    var _prefs={};
    fetch('/api/pub/apphub/me',{headers:{'X-Pub-Token':token}}).then(function(r){return r.ok?r.json():{}}).then(function(p){_prefs=p||{}}).catch(function(){});
    // Translate/publish target language, saved per Apps Hub account on the
    // server so it follows the user across devices instead of resetting on
    // every browser. _langPrefs starts empty and fills in once the fetch
    // below resolves; translateTargetLang/publishTargetLang fall back to
    // localStorage (pre-migration values from before this moved server-side)
    // until then, and one-time-migrate any such value up to the server.
    var _langPrefs={},aiPrefsDraft=null,aiPrefsSaving=false;
    fetch(API+'/prefs',{headers:{'X-Pub-Token':token}}).then(function(r){return r.ok?r.json():{}}).then(function(p){
      _langPrefs=p||{};
      var migrate={};
      if(!_langPrefs.translate_lang){var v=localStorage.getItem(TR_LANG_KEY);if(v)migrate.translate_lang=LEGACY_LANG_MAP[v]||v}
      if(!_langPrefs.publish_lang){var v2=localStorage.getItem(PUB_LANG_KEY);if(v2)migrate.publish_lang=LEGACY_LANG_MAP[v2]||v2}
      if(migrate.translate_lang||migrate.publish_lang){
        Object.assign(_langPrefs,migrate);
        fetch(API+'/prefs',{method:'PUT',headers:{'Content-Type':'application/json','X-Pub-Token':token},body:JSON.stringify(migrate)}).catch(function(){});
      }
      renderBody();
    }).catch(function(){});
    // The translate button and the composer's translate-before-publish button are
    // both premium-gated server-side: this flag only says whether the server has
    // turned the integration on, never anything about the viewer's own premium
    // status (the public page must never show premium messaging at all).
    var deeplEnabled=false,aiEnabled=false,aiCredits=null,aiChat=null,aiHistory=null,aiHistoryBusy=false;
    fetch(API+'/deepl-status').then(function(r){return r.ok?r.json():{}}).then(function(d){deeplEnabled=!!d.enabled;renderBody();scheduleRenderShell()}).catch(function(){});
    function loadAiStatus(){
      if(!token)return;
      fetch(API+'/ai/status',{headers:{'X-Pub-Token':token}}).then(function(r){return r.ok?r.json():{}}).then(function(d){
        aiEnabled=!!d.enabled;aiCredits=d.credits||null;renderBody();scheduleRenderShell();
      }).catch(function(){});
    }
    loadAiStatus();
    var translations={};
    // Values saved before the language list grew to DeepL's full set were the
    // 9 mvmOS UI locale codes (en, bg, zh-CN…) — map anyone's already-saved
    // choice onto its DeepL equivalent so it doesn't silently break.
    var LEGACY_LANG_MAP={en:'EN-US',bg:'BG',de:'DE',es:'ES',fr:'FR',ja:'JA','pt-BR':'PT-BR',ru:'RU','zh-CN':'ZH'};
    function translateTargetLang(){if(_langPrefs.translate_lang)return _langPrefs.translate_lang;var v=localStorage.getItem(TR_LANG_KEY);return LEGACY_LANG_MAP[v]||v||'EN-US'}
    function publishTargetLang(){if(_langPrefs.publish_lang)return _langPrefs.publish_lang;var v=localStorage.getItem(PUB_LANG_KEY);return LEGACY_LANG_MAP[v]||v||'EN-US'}
    // Posts to Nostradamus's own endpoint, never to the DeepL app directly:
    // the translation is a premium feature of *this* app, and only its premium
    // module can perform one. On an install without that module the route is
    // not there at all and this throws, which is the correct outcome.
    async function deeplTranslate(text,lang){
      var r=await fetch(API+'/translate',{method:'POST',headers:{'Content-Type':'application/json','X-Pub-Token':token},body:JSON.stringify({text:text,target_lang:lang||'EN-US'})});
      var d=await r.json().catch(function(){return{}});
      if(!r.ok)throw new Error(d.error||'error');
      return d.translated_text||'';
    }
    // Raw content can carry nostr: mention URIs and image/link URLs that are
    // rendered separately (quoted-note card, inline <img>) and never need
    // translating — sending them to DeepL just burns characters on gibberish.
    function textForTranslation(text){
      return text.replace(NOSTR_RE,'').replace(URL_RE,'').trim();
    }
    async function translateNote(id){
      var note=noteCache[id];if(!note)return;
      var tr=translations[id];
      if(tr&&tr.status==='done'){tr.shown=!tr.shown;renderBody();return}
      translations[id]={status:'loading',shown:true};
      renderBody();
      try{
        var text=await deeplTranslate(textForTranslation(note.content),translateTargetLang());
        translations[id]={status:'done',shown:true,text:text};
      }catch(_){translations[id]={status:'error',shown:true}}
      renderBody();
    }
    // All of the owner's identities (from GET /vaults); vaultInfo is whichever one
    // is active. addMode/switcherOpen drive the onboarding screen and the identity
    // switcher panel reused for "add another identity" and "switch identity".
    var identities=[],addMode=false,switcherOpen=false;
    var scrollReset=false;
    var searchQuery='',searchResults=[],searchSeq=0,searchBusy=false,searchDebounce=0;
    var activeTab='feed',feedMode=FEED_MODES.indexOf(localStorage.getItem(FEED_MODE_KEY))>=0?localStorage.getItem(FEED_MODE_KEY):'following',stack=[];
    var feedItems=[],feedKeys={},feedLoaded=false,feedToken=0;
    var FEED_PAGE_SIZE=10,feedVisible=FEED_PAGE_SIZE,feedCursors={},feedExhausted={},feedPageSubs=[],feedPaging=false;
    var pendingItems=[],pendingKeys={};
    // How many unseen following-feed items are waiting while Discover is the
    // active mode — shown as a badge on the Following button. Discover needs no
    // badge of its own: it holds an open subscription whenever it is on screen
    // and puts what arrives straight into its own "new posts" pill.
    // modeSeenKeys stops the background poll from re-counting the same note on
    // every tick; modeSeenInit seeds it silently on the first poll instead of
    // counting whatever it happens to find as "new".
    var modeCounts={following:0,trending:0,discover:0};
    // Engagement counts as the ranking service measured them, network-wide.
    // Kept apart from `stats`, which counts only what the user's own relays
    // happen to store: merging the two would either double-count the same
    // reaction or replace a network-wide number with a much smaller local one.
    var netStats={};
    var trendingFailed=false,trendingAt=0;
    var modeSeenKeys={following:{},trending:{}};
    var modeSeenInit={following:false,trending:false};
    var modePollTimer=0;
    var contactPubkeys=[];
    // NIP-51 mute list (kind 10000). The newest event is kept whole: its other tags and
    // its (possibly encrypted) content must survive when this app rewrites the list.
    var deletedIds={};
    var mutedPubkeys=[],muteEvent=null,mutesLoaded=false;
    function isMuted(pk){return mutedPubkeys.indexOf(pk)>=0}
    var profileCache={},noteCache={},stats={},myReactions={},myReposts={},myZaps={},ownProfileRaw={};
    var notifItems=[],notifKeys={},notifLoaded=false,notifSeen=Number(localStorage.getItem(SEEN_KEY)||0),notifBase=null;
    var zapRows=[],zapRowKeys={},zapLoaded=false,zapDir='in',zapPeriod='all',zapTimer=0;
    var followerNotifs=[],followerKnown={},followerReady=false,followerGeneration=0;
    var threadReplies=[],threadKeys={},threadLoaded=false;
    var userNotes=[],userKeys={},userLoaded=false,profileSub='posts';
    var peopleList=[],peopleKeys={},peopleLoaded=false;
    var followerCounts={},followerCountPending={};
    var imageViewer=null;
    function closeImagePreview(){
      if(!imageViewer)return;
      var dialog=imageViewer;imageViewer=null;
      dialog.close();dialog.remove();
    }
    function openImagePreview(link){
      closeImagePreview();
      var dialog=document.createElement('dialog');
      dialog.className='nos-image-viewer';
      dialog.setAttribute('aria-label',t('nos_image_preview'));
      var close=document.createElement('button');
      close.type='button';close.className='nos-image-viewer-close';
      close.textContent='✕';close.setAttribute('aria-label',t('nos_close'));
      close.onclick=closeImagePreview;
      var img=document.createElement('img');
      img.alt=t('nos_image_preview');img.referrerPolicy='no-referrer';img.src=link.href;
      dialog.appendChild(close);dialog.appendChild(img);
      dialog.onclick=function(e){if(e.target===dialog)closeImagePreview()};
      dialog.oncancel=function(e){e.preventDefault();closeImagePreview()};
      document.body.appendChild(dialog);imageViewer=dialog;dialog.showModal();
    }
    // Capture before a note/list handler can open its thread, including quoted
    // notes and composer previews. The anchor remains usable as a normal link.
    function onImageClick(e){
      var link=e.target.closest('.nos-embed-link');
      if(!link||!root.contains(link))return;
      e.preventDefault();e.stopPropagation();openImagePreview(link);
    }
    root.addEventListener('click',onImageClick,true);
    var composer=null;
    var obStep='choose',obPriv=null;
    function blankRecover(){return{nsec:'',pass:'',confirm:'',duration:''}}
    var recoverForm=blankRecover();
    // Builds before this one cached the raw exported AES key in Web Storage. That
    // entry is dead code now, but leaving it on disk would keep the exact secret
    // this vault stopped storing — so an upgraded install drops it on first run.
    try{localStorage.removeItem('nos_vault_session');sessionStorage.removeItem('nos_vault_session')}catch(_){}
    var pool=createPool();
    root.style.position='relative';
    function bindPool(){pool.onStatusChange(function(){if(activeTab==='relays'&&!stack.length)renderRelayList()})}
    bindPool();

    function api(path,options){options=options||{};var h=Object.assign({'X-Pub-Token':token,'Content-Type':'application/json'},options.headers||{});return fetch(API+path,Object.assign({},options,{headers:h})).then(async function(r){var d=await r.json().catch(function(){return{}});if(r.status===401&&opts.onNeedLogin)opts.onNeedLogin();if(!r.ok)throw new Error(d.error||'error');return d})}
    // Not extractable: the session is stored as this CryptoKey object itself, so
    // there is never a moment where the raw AES material exists as bytes in the page.
    async function derive(password,salt,iterations){var raw=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',salt:bytes(salt),iterations:iterations,hash:'SHA-256'},raw,{name:'AES-GCM',length:256},false,['encrypt','decrypt'])}
    async function encryptWithKey(k,rawBytes){var iv=crypto.getRandomValues(new Uint8Array(12));var data=await crypto.subtle.encrypt({name:'AES-GCM',iv:iv},k,rawBytes);return{iv:b64(iv),ciphertext:b64(data)}}
    function encryptPriv(rawBytes){return encryptWithKey(key,rawBytes)}
    async function decryptPriv(ivB64,ctB64){var out=await crypto.subtle.decrypt({name:'AES-GCM',iv:bytes(ivB64)},key,bytes(ctB64));return new Uint8Array(out)}
    function minutesOf(value){return value==='session'?0:Number(value)||0}
    // Sliding window: every time the vault is used the expiry is pushed out to
    // now + the chosen duration, so a daily user keeps the same span (7 days stays
    // 7 days) and only a vault left untouched for that long asks for the password.
    function expiryOf(saved){return saved.minutes?Date.now()+saved.minutes*60000:0}
    function scheduleAutoLock(expires){clearTimeout(autoLockTimer);if(!expires)return;var remaining=expires-Date.now();if(remaining<=0){lockNow();return}autoLockTimer=setTimeout(lockNow,remaining)}
    // "Until tab is closed" has to outlive nothing at all, but IndexedDB outlives
    // everything — so that mode is tied to a marker that only this tab's
    // sessionStorage holds, and a session whose tab is gone is unusable by design.
    function tabMarker(){var mark=sessionStorage.getItem(TAB_KEY);if(!mark){mark=b64(crypto.getRandomValues(new Uint8Array(12)));try{sessionStorage.setItem(TAB_KEY,mark)}catch(_){}}return mark}
    function saveSession(saved){idbPut(vaultInfo.npub,saved)}
    function renewSession(saved){
      if(!saved||!saved.minutes)return saved;
      saved.expires=expiryOf(saved);
      saveSession(saved);
      return saved;
    }
    function buildSession(k,value){
      var minutes=minutesOf(value),saved={key:k,minutes:minutes,tab:minutes?null:tabMarker()};
      saved.expires=expiryOf(saved);
      return saved;
    }
    function cacheKey(value){
      var saved=buildSession(key,value);
      session=saved;
      scheduleAutoLock(saved.expires);
      try{localStorage.setItem(DURATION_KEY,value)}catch(_){}
      return idbPut(vaultInfo.npub,saved);
    }
    async function readSession(){
      var saved=await idbGet(vaultInfo.npub);
      if(!saved)return null;
      var alive=saved.minutes?saved.expires>Date.now():!!saved.tab&&saved.tab===sessionStorage.getItem(TAB_KEY);
      if(!alive){await idbDel(vaultInfo.npub);return null}
      return saved;
    }
    async function restoreLocalKey(){
      var saved=await readSession();
      if(!saved)return false;
      try{
        key=saved.key;
        privBytes=await decryptPriv(vaultInfo.iv,vaultInfo.ciphertext);
        pubHex=bytesToHex(getXOnlyPubkey(privBytes));
        session=renewSession(saved);
        scheduleAutoLock(session.expires);
        return true;
      }catch(_){await idbDel(vaultInfo.npub);key=null;privBytes=null;session=null;return false}
    }
    function onVisible(){
      if(document.hidden||!key)return;
      readSession().then(function(saved){
        if(!key)return;
        if(!saved){lockNow();return}
        session=renewSession(saved);
        scheduleAutoLock(session.expires);
      });
    }
    function clearCachedKey(){return idbDel(vaultInfo.npub)}
    function fmtTime(d){return _prefs.time_format?d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',hour12:_prefs.time_format==='12'}):d.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit'})}
    function fmtDate(d){return _prefs.date_format==='MM/DD/YYYY'?(d.getMonth()+1)+'/'+d.getDate()+'/'+d.getFullYear():_prefs.date_format==='YYYY-MM-DD'?d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'):_prefs.date_format==='DD/MM/YYYY'?d.getDate()+'/'+(d.getMonth()+1)+'/'+d.getFullYear():d.toLocaleDateString()}
    function lockedAtHint(){return session&&session.expires?t('nos_locks_at',{time:fmtDate(new Date(session.expires))+' '+fmtTime(new Date(session.expires))}):t('nos_lock')}
    function resetState(){
      clearTimeout(autoLockTimer);autoLockTimer=0;clearTimeout(renderTimer);clearTimeout(profileTimer);clearTimeout(noteTimer);
      clearTimeout(searchDebounce);searchQuery='';searchResults=[];searchBusy=false;searchSeq++;
      stopModePolling();pool.unsubscribe('zaps');clearTimeout(zapTimer);zapRows=[];zapRowKeys={};zapLoaded=false;
      key=null;privBytes=null;pubHex=null;session=null;composer=null;stack=[];activeTab='feed';
      feedItems=[];feedKeys={};feedLoaded=false;feedToken++;deletedIds={};contactPubkeys=[];mutedPubkeys=[];muteEvent=null;mutesLoaded=false;
      modeCounts={following:0,trending:0,discover:0};quietProfiles={};modeSeenKeys={following:{},trending:{}};modeSeenInit={following:false,trending:false};
      netStats={};trendingFailed=false;followerCounts={};followerCountPending={};
      pendingItems=[];pendingKeys={};
      profileCache={};noteCache={};stats={};myReactions={};myReposts={};myZaps={};ownProfileRaw={};
      notifItems=[];notifKeys={};notifLoaded=false;followerNotifs=[];followerKnown={};followerReady=false;followerGeneration++;profileQueue=[];noteQueue=[];
      clearCachedKey();pool.destroy();pool=createPool();bindPool();
    }
    function lockNow(){resetState();load()}
    function switchIdentity(npub){try{localStorage.setItem(ACTIVE_KEY,npub)}catch(_){}remount()}
    async function logoutIdentity(npub){
      await idbDel(npub);
      var other=identities.filter(function(v){return v.npub!==npub})[0];
      try{if(other)localStorage.setItem(ACTIVE_KEY,other.npub);else localStorage.removeItem(ACTIVE_KEY)}catch(_){}
      remount();
    }
    async function removeIdentity(npub){
      if(!confirm(t('nos_identity_confirm_remove')))return;
      try{await api('/vault?npub='+encodeURIComponent(npub),{method:'DELETE'})}catch(_){return}
      await idbDel(npub);
      if(npub===vaultInfo.npub){
        var other=identities.filter(function(v){return v.npub!==npub})[0];
        try{if(other)localStorage.setItem(ACTIVE_KEY,other.npub);else localStorage.removeItem(ACTIVE_KEY)}catch(_){}
      }
      remount();
    }
    function shortNpub(n){return n.slice(0,12)+'…'+n.slice(-6)}
    function closeSwitcher(){switcherOpen=false;renderSwitcher()}
    function startAddIdentity(){closeSwitcher();addMode=true;obStep='choose';obPriv=null;onboardingScreen()}
    function renderSwitcher(){
      var existing=root.querySelector('.nos-switcher');
      if(existing)existing.remove();
      if(!switcherOpen||!key)return;
      var wrap=document.createElement('div');
      wrap.className='nos-modal nos-switcher';
      wrap.innerHTML='<div class="nos-modal-card"><div class="nos-modal-head"><span class="nos-modal-title">'+esc(t('nos_switch_identity'))+'</span><button type="button" class="nos-modal-close">✕</button></div>'+
        identities.map(function(v){
          var active=v.npub===vaultInfo.npub,hex=active?pubHex:npubDecode(v.npub);
          if(hex)ensureProfile(hex);
          return'<div class="nos-identity-row"'+(active?'':' data-npub="'+esc(v.npub)+'"')+'>'+
            (hex?avatarHtml(hex):'<span class="nos-avatar-wrap"><span class="nos-avatar">?</span></span>')+
            '<span class="nos-identity-label">'+esc(hex?displayName(hex):shortNpub(v.npub))+(active?' — '+esc(t('nos_identity_current')):'')+'</span>'+
            '</div>';
        }).join('')+
        '<button type="button" class="nos-link nos-switcher-add">'+esc(t('nos_add_identity'))+'</button></div>';
      root.appendChild(wrap);
      wrap.querySelector('.nos-modal-close').onclick=closeSwitcher;
      wrap.querySelectorAll('.nos-identity-row[data-npub]').forEach(function(row){row.onclick=function(){switchIdentity(row.dataset.npub)}});
      wrap.querySelector('.nos-switcher-add').onclick=startAddIdentity;
    }

    function writeUrls(){return relays.filter(function(r){return r.write}).map(function(r){return r.url})}
    function readUrls(){return relays.filter(function(r){return r.read}).map(function(r){return r.url})}

    function durationOptions(){return'<option value="5">'+esc(t('nos_minutes',{n:5}))+'</option><option value="15">'+esc(t('nos_minutes',{n:15}))+'</option><option value="60">'+esc(t('nos_hour'))+'</option><option value="240">'+esc(t('nos_hours',{n:4}))+'</option><option value="1440">'+esc(t('nos_hours',{n:24}))+'</option><option value="10080">'+esc(t('nos_days',{n:7}))+'</option><option value="session">'+esc(t('nos_until_closed'))+'</option>'}
    function durationBlock(){return'<label class="nos-duration-label">'+esc(t('nos_unlock_for'))+'</label><select class="nos-duration">'+durationOptions()+'</select><div class="nos-duration-hint">'+esc(t('nos_unlock_sliding'))+'</div>'}
    function applyDuration(){var select=root.querySelector('.nos-duration');if(select)select.value=localStorage.getItem(DURATION_KEY)||'15';return select}

    function formatTime(ts){var diff=Math.floor(Date.now()/1000)-ts;if(diff<60)return t('nos_just_now');if(diff<3600)return t('nos_minutes_ago',{n:Math.floor(diff/60)});if(diff<86400)return t('nos_hours_ago',{n:Math.floor(diff/3600)});if(diff<604800)return t('nos_days_ago',{n:Math.floor(diff/86400)});return fmtDate(new Date(ts*1000))}

    // ---- onboarding ----
    function onboardingScreen(error){
      if(obStep==='choose'){
        var cancel=addMode?'<button type="button" class="nos-ob-cancel">'+esc(t('nos_back'))+'</button>':'';
        root.innerHTML='<div class="nos nos-onboard"><div class="nos-card"><h2>'+esc(addMode?t('nos_add_identity_title'):t('nos_welcome_title'))+'</h2><p>'+esc(t('nos_welcome_info'))+'</p><button class="primary nos-ob-generate">'+esc(t('nos_generate_key'))+'</button><button class="nos-ob-import">'+esc(t('nos_import_key'))+'</button>'+cancel+'</div></div>';
        if(error)showToast(error);
        root.querySelector('.nos-ob-generate').onclick=function(){obPriv=genPrivKey();obStep='reveal';onboardingScreen()};
        root.querySelector('.nos-ob-import').onclick=function(){obStep='import';onboardingScreen()};
        if(addMode)root.querySelector('.nos-ob-cancel').onclick=function(){addMode=false;renderShell()};
        return;
      }
      if(obStep==='reveal'){
        var nsec=nsecEncode(bytesToHex(obPriv));
        root.innerHTML='<div class="nos nos-onboard"><div class="nos-card"><h2>'+esc(t('nos_your_key'))+'</h2><p>'+esc(t('nos_key_warning'))+'</p><div class="nos-view-value nos-key-value">'+esc(nsec)+'</div><button type="button" class="nos-copy-key">'+esc(t('nos_copy'))+'</button><label class="nos-check"><input type="checkbox" class="nos-saved-check"> '+esc(t('nos_key_saved_confirm'))+'</label><button class="primary nos-ob-continue" disabled>'+esc(t('nos_continue'))+'</button><button class="nos-ob-back">'+esc(t('nos_back'))+'</button></div></div>';
        if(error)showToast(error);
        var check=root.querySelector('.nos-saved-check'),cont=root.querySelector('.nos-ob-continue');
        check.onchange=function(){cont.disabled=!check.checked};
        root.querySelector('.nos-copy-key').onclick=function(){if(navigator.clipboard)navigator.clipboard.writeText(nsec)};
        cont.onclick=function(){obStep='password';onboardingScreen()};
        root.querySelector('.nos-ob-back').onclick=function(){obStep='choose';obPriv=null;onboardingScreen()};
        return;
      }
      if(obStep==='import'){
        root.innerHTML='<div class="nos nos-onboard"><div class="nos-card"><h2>'+esc(t('nos_import_key'))+'</h2><p>'+esc(t('nos_import_info'))+'</p><input class="nos-import-input" type="password" placeholder="'+esc(t('nos_import_placeholder'))+'"><button class="primary nos-ob-import-go">'+esc(t('nos_continue'))+'</button><button class="nos-ob-back">'+esc(t('nos_back'))+'</button></div></div>';
        if(error)showToast(error);
        root.querySelector('.nos-ob-back').onclick=function(){obStep='choose';onboardingScreen()};
        root.querySelector('.nos-ob-import-go').onclick=function(){
          var raw=root.querySelector('.nos-import-input').value.trim();
          var privHex=raw.indexOf('nsec1')===0?nsecDecode(raw):(/^[0-9a-fA-F]{64}$/.test(raw)?raw:null);
          if(!privHex){obStep='import';onboardingScreen(t('nos_invalid_key'));return}
          try{obPriv=hexToBytes(privHex);getXOnlyPubkey(obPriv)}catch(_){obStep='import';onboardingScreen(t('nos_invalid_key'));return}
          obStep='password';onboardingScreen();
        };
        return;
      }
      if(obStep==='password'){
        root.innerHTML='<div class="nos nos-unlock"><div><h2>'+esc(t('nos_create_title'))+'</h2><p>'+esc(t('nos_create_info'))+'</p><input class="nos-master" type="password" autocomplete="new-password" placeholder="'+esc(t('nos_master'))+'"><input class="nos-confirm" type="password" autocomplete="new-password" placeholder="'+esc(t('nos_confirm_master'))+'">'+durationBlock()+'<button class="primary nos-ob-finish">'+esc(t('nos_create'))+'</button><button class="nos-ob-back">'+esc(t('nos_back'))+'</button></div></div>';
        if(error)showToast(error);
        var select=applyDuration();
        root.querySelector('.nos-ob-back').onclick=function(){obStep='choose';obPriv=null;onboardingScreen()};
        root.querySelector('.nos-ob-finish').onclick=async function(){
          var pass=root.querySelector('.nos-master').value,confirmPass=root.querySelector('.nos-confirm').value;
          if(pass.length<MIN_MASTER){onboardingScreen(t('nos_password_short',{n:MIN_MASTER}));return}
          if(pass!==confirmPass){onboardingScreen(t('nos_passwords_differ'));return}
          var priv=obPriv,pubHexLocal=bytesToHex(getXOnlyPubkey(priv)),npub=npubEncode(pubHexLocal);
          if(identities.some(function(v){return v.npub===npub})){onboardingScreen(t('nos_identity_exists'));return}
          try{
            var salt=b64(crypto.getRandomValues(new Uint8Array(32)));
            var newKey=await derive(pass,salt,600000);
            var enc=await encryptWithKey(newKey,priv);
            await api('/vault',{method:'POST',body:JSON.stringify({npub:npub,salt:salt,iterations:600000,iv:enc.iv,ciphertext:enc.ciphertext})});
            var saved=buildSession(newKey,select.value);
            await idbPut(npub,saved);
            try{localStorage.setItem(DURATION_KEY,select.value);localStorage.setItem(ACTIVE_KEY,npub)}catch(_){}
            obPriv=null;
            // In "add another identity" mode the currently active identity stays fully
            // untouched in memory (module key/vaultInfo were never reassigned above) —
            // the reload is what actually switches over to the new one.
            if(addMode){addMode=false;remount();return}
            key=newKey;privBytes=priv;pubHex=pubHexLocal;
            vaultInfo={npub:npub,salt:salt,iterations:600000,iv:enc.iv,ciphertext:enc.ciphertext};
            identities=[vaultInfo];session=saved;
            scheduleAutoLock(saved.expires);
            await afterUnlock();
          }catch(_){key=null;onboardingScreen(t('nos_save_error'))}
        };
        return;
      }
    }

    function unlockScreen(error){
      root.innerHTML='<div class="nos nos-unlock"><div><h2>'+esc(t('nos_unlock'))+'</h2><p>'+esc(t('nos_unlock_info'))+'</p><input class="nos-master" type="password" autocomplete="current-password" placeholder="'+esc(t('nos_master'))+'">'+durationBlock()+'<button class="primary nos-unlock-go">'+esc(t('nos_unlock'))+'</button><button type="button" class="nos-link nos-forgot">'+esc(t('nos_forgot'))+'</button></div></div>';
      if(error)showToast(error);
      var select=applyDuration();
      var input=root.querySelector('.nos-master'),go=root.querySelector('.nos-unlock-go');
      go.onclick=async function(){
        var pass=input.value;
        if(!pass){unlockScreen(t('nos_unlock_failed'));return}
        try{
          key=await derive(pass,vaultInfo.salt,vaultInfo.iterations);
          privBytes=await decryptPriv(vaultInfo.iv,vaultInfo.ciphertext);
          pubHex=bytesToHex(getXOnlyPubkey(privBytes));
          await cacheKey(select.value);
          await afterUnlock();
        }catch(_){key=null;privBytes=null;unlockScreen(t('nos_unlock_failed'))}
      };
      root.querySelector('.nos-forgot').onclick=function(){recoverForm=blankRecover();recoverScreen()};
      input.onkeydown=function(e){if(e.key==='Enter')go.click()};
      setTimeout(function(){input.focus()},30);
    }

    // A forgotten master password used to be the end of the account: the vault is
    // undecryptable and nothing in the UI offered a way past it. The private key is
    // the real credential though — proving you hold it is at least as strong as the
    // password it replaces, so it can mint a new one. A key that turns out to
    // belong to a different identity is rejected here rather than silently
    // overwriting this vault — that identity gets added alongside it instead,
    // through "Add account".
    function recoverScreen(error){
      root.innerHTML='<div class="nos nos-unlock"><div><h2>'+esc(t('nos_reset_title'))+'</h2><p>'+esc(t('nos_reset_info'))+'</p>'+
        '<input class="nos-r-key" type="password" autocomplete="off" placeholder="'+esc(t('nos_import_placeholder'))+'">'+
        '<input class="nos-r-pass" type="password" autocomplete="new-password" placeholder="'+esc(t('nos_master'))+'">'+
        '<input class="nos-r-confirm" type="password" autocomplete="new-password" placeholder="'+esc(t('nos_confirm_master'))+'">'+
        durationBlock()+
        '<button class="primary nos-r-go">'+esc(t('nos_reset_go'))+'</button><button type="button" class="nos-r-back">'+esc(t('nos_back'))+'</button></div></div>';
      if(error)showToast(error);
      var select=applyDuration();
      // Confirming the identity swap re-renders this screen, so what was typed is
      // carried across as values rather than markup — a password does not belong in
      // an HTML attribute, even one only this page will ever read.
      var keyInput=root.querySelector('.nos-r-key'),passInput=root.querySelector('.nos-r-pass'),confirmInput=root.querySelector('.nos-r-confirm');
      keyInput.value=recoverForm.nsec;passInput.value=recoverForm.pass;confirmInput.value=recoverForm.confirm;
      if(recoverForm.duration)select.value=recoverForm.duration;
      function readForm(){
        recoverForm.nsec=keyInput.value.trim();
        recoverForm.pass=passInput.value;
        recoverForm.confirm=confirmInput.value;
        recoverForm.duration=select.value;
      }
      root.querySelector('.nos-r-back').onclick=function(){recoverForm=blankRecover();unlockScreen()};
      root.querySelector('.nos-r-go').onclick=async function(){
        readForm();
        var raw=recoverForm.nsec;
        var privHex=raw.indexOf('nsec1')===0?nsecDecode(raw):(/^[0-9a-fA-F]{64}$/.test(raw)?raw:null);
        var priv=null,pubHexLocal=null;
        if(privHex){try{priv=hexToBytes(privHex);pubHexLocal=bytesToHex(getXOnlyPubkey(priv))}catch(_){priv=null}}
        if(!priv){recoverScreen(t('nos_invalid_key'));return}
        var npub=npubEncode(pubHexLocal);
        if(npub!==vaultInfo.npub){recoverScreen(t('nos_reset_wrong_key'));return}
        if(recoverForm.pass.length<MIN_MASTER){recoverScreen(t('nos_password_short',{n:MIN_MASTER}));return}
        if(recoverForm.pass!==recoverForm.confirm){recoverScreen(t('nos_passwords_differ'));return}
        var chosen=select.value;
        try{
          var salt=b64(crypto.getRandomValues(new Uint8Array(32)));
          key=await derive(recoverForm.pass,salt,600000);
          var enc=await encryptPriv(priv);
          var body={salt:salt,iterations:600000,iv:enc.iv,ciphertext:enc.ciphertext};
          await api('/vault?target_npub='+encodeURIComponent(vaultInfo.npub),{method:'PUT',body:JSON.stringify(body)});
          vaultInfo={npub:npub,salt:salt,iterations:600000,iv:enc.iv,ciphertext:enc.ciphertext};
          privBytes=priv;pubHex=pubHexLocal;
          recoverForm=blankRecover();
          await cacheKey(chosen);
          await afterUnlock();
        }catch(_){key=null;privBytes=null;recoverScreen(t('nos_save_error'))}
      };
      setTimeout(function(){root.querySelector('.nos-r-key').focus()},30);
    }

    async function load(){
      if(destroyed)return;
      try{var data=await api('/vaults');identities=data.vaults||[]}catch(_){root.innerHTML='<div class="nos-empty">'+esc(t('nos_load_error'))+'</div>';return}
      if(!identities.length){vaultInfo=null;obStep='choose';obPriv=null;onboardingScreen();return}
      var active=localStorage.getItem(ACTIVE_KEY);
      vaultInfo=identities.filter(function(v){return v.npub===active})[0]||identities[0];
      try{localStorage.setItem(ACTIVE_KEY,vaultInfo.npub)}catch(_){}
      var restored=await restoreLocalKey();
      if(restored){await afterUnlock();return}
      unlockScreen();
    }

    // The signed NIP-65 event is the source of truth. Bootstrap relays are
    // temporary discovery connections, never an automatic profile update.
    var relayEvent=null,relayLookupSeq=0,relayDiscoveryOK=false;
    function relayTags(event){
      var found={},list=[];
      (event.tags||[]).forEach(function(tag){
        if(!Array.isArray(tag)||tag[0]!=='r'||typeof tag[1]!=='string'||!/^wss?:\/\//.test(tag[1]))return;
        var marker=tag[2];if(marker&&marker!=='read'&&marker!=='write')return;
        var url=tag[1],item=found[url];
        if(!item){item={url:url,read:false,write:false};found[url]=item;list.push(item)}
        if(!marker||marker==='read')item.read=true;
        if(!marker||marker==='write')item.write=true;
      });
      return list;
    }
    async function discoverRelays(){
      var urls=Array.from(new Set(RELAY_DISCOVERY.concat(DEFAULT_RELAYS,relays.map(function(r){return r.url}))));
      var subId='relay-list-'+(++relayLookupSeq),events=[],checks=[];
      var responses=await new Promise(function(resolve){
        pool.subscribe(urls,subId,[{kinds:[10002],authors:[pubHex]}],function(ev){
          if(!ev||ev.kind!==10002||ev.pubkey!==pubHex||!Number.isSafeInteger(ev.created_at))return;
          checks.push(verifyEvent(ev).then(function(ok){if(ok)events.push(ev)}));
        },function(count){pool.unsubscribe(subId);resolve(count)},true);
      });
      await Promise.all(checks);
      events.sort(function(a,b){return b.created_at-a.created_at||(a.id<b.id?-1:a.id>b.id?1:0)});
      return {event:events[0]||null,ok:responses>0};
    }
    function cacheRelayEvent(event){
      try{localStorage.setItem('nos_relay_event_'+pubHex,JSON.stringify(event))}catch(_){}
    }
    async function loadRelays(){
      relays=DEFAULT_RELAYS.map(function(url){return {url:url,read:true,write:true}});
      var cached=null;
      try{cached=JSON.parse(localStorage.getItem('nos_relay_event_'+pubHex)||'null')}catch(_){}
      if(cached&&cached.kind===10002&&cached.pubkey===pubHex&&Number.isSafeInteger(cached.created_at)&&await verifyEvent(cached)){
        relayEvent=cached;relayDiscoveryOK=true;relays=relayTags(cached);
      }else{
        var result=await discoverRelays();
        relayDiscoveryOK=result.ok;relayEvent=result.event;
        if(result.event){relays=relayTags(result.event);cacheRelayEvent(result.event)}
      }
      pool.setRelayUrls(relays.map(function(r){return r.url}),[TRENDING_URL]);
    }
    async function refreshRelays(){
      if(relaySaving)return;
      relaySaving=true;
      var panel=root.querySelector('.nos-relays');
      if(panel){panel.querySelector('.nos-relay-refresh').disabled=true;panel.querySelector('.nos-relay-add-btn').disabled=true}
      renderRelayList();
      try{
        var result=await discoverRelays();
        if(!result.ok||!result.event)throw new Error('relay_discovery_failed');
        if(!relayEvent||result.event.created_at>relayEvent.created_at||(result.event.created_at===relayEvent.created_at&&result.event.id<relayEvent.id)){
          relayEvent=result.event;relays=relayTags(result.event);cacheRelayEvent(result.event);
          pool.setRelayUrls(relays.map(function(r){return r.url}),[TRENDING_URL]);
          loadFeed();loadNotifications();startFollowerNotifications();
        }
        relayDiscoveryOK=true;
        panel=root.querySelector('.nos-relays');
        if(panel){var hint=panel.querySelector('.nos-relay-hint');if(hint)hint.remove();showToast(t('nos_relay_refreshed'))}
      }catch(_){panel=root.querySelector('.nos-relays');if(panel)showToast(t('nos_relay_discovery_error'))}
      finally{relaySaving=false;panel=root.querySelector('.nos-relays');if(panel){panel.querySelector('.nos-relay-refresh').disabled=false;panel.querySelector('.nos-relay-add-btn').disabled=false}renderRelayList()}
    }

    async function afterUnlock(){
      await loadRelays();
      renderShell();
      subscribeSelfMeta();
      subscribeContacts();
      subscribeMutes();
      loadNotifications();
      startFollowerNotifications();
      // Following is loaded by the arrival of the contact list. Popular and Latest
      // wait for nothing, but nothing started them either, so reopening the app
      // on one of them stayed on "Loading" until another mode was clicked.
      if(activeTab==='feed'&&feedMode!=='following'&&!feedItems.length)loadFeed();
    }

    // ---- profiles, notes and counters, fetched in batches ----
    // One subscription per pubkey was survivable for a feed of people you follow
    // and hopeless for a trending window, where fifty strangers appear at once.
    // Everything that needs looking up is queued, debounced and asked for in a
    // single REQ instead.
    var profileQueue=[],profileTimer=0,profileSubId=0;
    var noteQueue=[],noteTimer=0,noteSubId=0;
    var renderTimer=0;
    function scheduleRender(){clearTimeout(renderTimer);renderTimer=setTimeout(function(){renderBody();if(switcherOpen)renderSwitcher()},140)}
    var shellRenderTimer=0,pillTimer=0,quietProfiles={};
    function scheduleRenderShell(){clearTimeout(shellRenderTimer);shellRenderTimer=setTimeout(function(){if(key)renderShell()},140)}
    function parseProfile(ev){
      var data={};try{data=JSON.parse(ev.content)||{}}catch(_){}
      return{created_at:ev.created_at,raw:data,name:data.display_name||data.name||'',handle:data.name||'',
             about:data.about||'',picture:data.picture||'',banner:data.banner||'',website:data.website||'',nip05:data.nip05||'',lud16:typeof data.lud16==='string'?data.lud16:''};
    }
    // `quiet` marks a profile wanted only for a post waiting behind the pill.
    // Nothing on screen is showing that author yet, so when the profile lands
    // there is nothing to redraw but the pill itself — and redrawing the feed for
    // it is exactly what made Discover flash, since a steady stream of new posts
    // is a steady stream of unknown authors.
    function ensureProfile(pk,quiet){
      if(!pk||profileCache[pk]!==undefined)return;
      if(quiet)quietProfiles[pk]=1;
      profileCache[pk]=null;
      profileQueue.push(pk);
      clearTimeout(profileTimer);profileTimer=setTimeout(flushProfiles,180);
    }
    function flushProfiles(){
      var batch=profileQueue.splice(0,profileQueue.length);
      if(!batch.length||!readUrls().length)return;
      var subId='meta-'+(++profileSubId);
      pool.subscribe(withIndexers(readUrls()),subId,[{kinds:[0],authors:batch}],function(ev){
        var prev=profileCache[ev.pubkey];
        if(prev&&prev.created_at>=ev.created_at)return;
        profileCache[ev.pubkey]=parseProfile(ev);
        if(ev.pubkey===pubHex){ownProfileRaw=profileCache[ev.pubkey].raw||{};scheduleRenderShell()}
        var quiet=quietProfiles[ev.pubkey];delete quietProfiles[ev.pubkey];
        if(quiet)schedulePill();else scheduleRender();
      },function(){pool.unsubscribe(subId)});
    }
    var noteMissing={};
    function ensureNote(id){
      if(!id||noteCache[id]!==undefined)return;
      noteCache[id]=null;
      noteQueue.push(id);
      clearTimeout(noteTimer);noteTimer=setTimeout(flushNotes,180);
    }
    function flushNotes(){
      var batch=noteQueue.splice(0,noteQueue.length);
      if(!batch.length||!readUrls().length)return;
      var subId='note-'+(++noteSubId);
      // A note you replied to or that was quoted often lives only on the relay of
      // its author, so the well-known relays are asked as well as your own.
      var urls=readUrls().slice();
      DEFAULT_RELAYS.forEach(function(u){if(urls.indexOf(u)<0)urls.push(u)});
      pool.subscribe(urls,subId,[{ids:batch}],function(ev){
        noteCache[ev.id]=ev;ensureProfile(ev.pubkey);
        scheduleRender();
      },function(){
        pool.unsubscribe(subId);
        // Not found anywhere: say so instead of showing "Loading" for ever.
        var gone=false;
        batch.forEach(function(id){if(!noteCache[id]){noteMissing[id]=true;gone=true}});
        if(gone)scheduleRender();
      });
    }
    function statOf(id){return stats[id]||(stats[id]={replies:0,reposts:0,likes:0,zaps:0,sats:0,zapSeen:{},seen:{}})}
    // Reply, repost and like counts for whatever is on screen, in one live
    // subscription that is replaced whenever the visible set changes.
    function refreshStats(ids){
      ids=ids.filter(function(id){return!!id}).slice(0,120);
      pool.unsubscribe('stats');
      if(!ids.length||!readUrls().length)return;
      pool.subscribe(readUrls(),'stats',[{kinds:[1,6,7,9735],'#e':ids}],function(ev){
        var target=targetOf(ev);
        if(!target||ids.indexOf(target)<0)return;
        var s=statOf(target);
        if(s.seen[ev.id])return;
        s.seen[ev.id]=1;
        if(ev.kind===9735){countZap(target,ev);return}
        // Your own like or repost was already counted the moment you pressed the
        // button (toggleLike/toggleRepost); the relay echoing it back before
        // publish() returns must not count it a second time.
        if(ev.pubkey===pubHex&&ev.kind===7&&myReactions[target]==='pending'){myReactions[target]=ev.id;scheduleRender();return}
        if(ev.pubkey===pubHex&&ev.kind===6&&myReposts[target]==='pending'){myReposts[target]=ev.id;scheduleRender();return}
        if(ev.kind===1)s.replies++;
        else if(ev.kind===6){s.reposts++;if(ev.pubkey===pubHex)myReposts[target]=ev.id}
        else if(ev.kind===7){s.likes++;if(ev.pubkey===pubHex)myReactions[target]=ev.id}
        scheduleRender();
      });
    }

    function subscribeSelfMeta(){
      ensureProfile(pubHex);
      pool.subscribe(withIndexers(readUrls()),'self-meta',[{kinds:[0],authors:[pubHex],limit:1}],function(ev){
        var prev=profileCache[pubHex];
        if(prev&&prev.created_at>=ev.created_at)return;
        profileCache[pubHex]=parseProfile(ev);
        ownProfileRaw=profileCache[pubHex].raw||{};
        scheduleRenderShell();
        scheduleRender();
      },function(){pool.unsubscribe('self-meta')});
    }
    // Profiles and contact lists are often published only to indexer relays such
    // as purplepag.es, not to the relays notes are read from.
    function withIndexers(urls){
      var all=urls.slice();
      CONTACT_RELAYS.forEach(function(u){if(all.indexOf(u)<0)all.push(u)});
      return all;
    }
    function subscribeMutes(){
      var newest=0;
      pool.subscribe(withIndexers(readUrls()),'mutes',[{kinds:[10000],authors:[pubHex],limit:1}],function(ev){
        if(ev.created_at<=newest)return;
        newest=ev.created_at;muteEvent=ev;
        mutedPubkeys=tagsOf(ev,'p').map(function(tg){return tg[1]}).filter(Boolean);
        scheduleRender();
      },function(){pool.unsubscribe('mutes');mutesLoaded=true;scheduleRender()});
    }
    function subscribeContacts(){
      // Every relay answers with its own copy of the list, and an old copy can
      // arrive last. Only the newest one is taken; an older one changes nothing.
      var newest=0;
      // The list is often stored only on an indexer relay such as purplepag.es,
      // which clients publish it to for exactly this lookup, and not on the relays
      // the user reads notes from. Without it a real list looked empty.
      pool.subscribe(withIndexers(readUrls()),'contacts',[{kinds:[3],authors:[pubHex],limit:1}],function(ev){
        if(ev.created_at<=newest)return;
        newest=ev.created_at;
        contactPubkeys=tagsOf(ev,'p').map(function(tg){return tg[1]}).filter(Boolean);
        if(activeTab==='feed'&&feedMode==='following')loadFeed();
      },function(){pool.unsubscribe('contacts');if(activeTab==='feed'&&feedMode==='following'&&!feedItems.length)loadFeed()});
    }

    // ---- feed ----
    function pushItem(item){
      if(feedKeys[item.key])return;
      feedKeys[item.key]=1;
      var i=0;while(i<feedItems.length&&feedItems[i].at>item.at)i++;
      feedItems.splice(i,0,item);
      scheduleRender();
    }
    // Once the initial batch has loaded, notes that trickle in live no longer
    // jump straight into the list — that reflows whatever the user is reading,
    // same problem X.com's feed had before it gated new posts behind a button.
    // They wait in pendingItems until acceptPending() merges them in.
    function pushPending(item){
      if(feedKeys[item.key]||pendingKeys[item.key])return;
      // What you just posted yourself is not news to you. It used to land behind
      // the pill like everyone else's, so publishing a note announced "1 new
      // post" and made you press a button to see your own writing. Yours goes
      // straight into the list; a repost of it by somebody else still counts,
      // because there the new event is theirs, not yours.
      var author=item.boost?item.boost.pubkey:(noteCache[item.noteId]||{}).pubkey;
      if(author&&author===pubHex){pushItem(item);return}
      pendingKeys[item.key]=1;
      pendingItems.push(item);
      if(pendingItems.length>40)pendingItems.length=40;
      schedulePill();
    }
    // A post arriving while you read changes nothing in the list on screen — it
    // changes only the pill above it. Repainting the feed for that rebuilds every
    // note, reloads every image and re-queries every engagement count, and on
    // Discover, where notes stream in continuously, it reads as the whole screen
    // flashing. So the pill is patched in place and the list is left alone.
    function schedulePill(){clearTimeout(pillTimer);pillTimer=setTimeout(renderPendingPill,140)}
    function renderPendingPill(){
      var body=root.querySelector('.nos-body');
      if(!body||stack.length||activeTab!=='feed')return;
      var cur=body.querySelector('.nos-newposts-bar'),html=pendingHtml();
      if(!html){if(cur)cur.remove();return}
      var tmp=document.createElement('div');tmp.innerHTML=html;
      var el=tmp.firstChild;
      el.onclick=function(e){e.stopPropagation();acceptPending()};
      if(cur)body.replaceChild(el,cur);else body.insertBefore(el,body.firstChild);
      bindImages(el);
    }
    // "N new posts" means new to the reader, so they open at the top, where the
    // button takes them. Sorting them into the list by time put them wherever
    // their timestamp fell — on Popular a note that just entered the ranking is
    // usually hours old, and a relay can deliver a late note long after it was
    // written — so pressing the button showed the same top as before.
    function acceptPending(){
      quietProfiles={};
      var fresh=pendingItems.filter(function(item){delete pendingKeys[item.key];return!feedKeys[item.key]});
      fresh.sort(function(a,b){return b.at-a.at});
      fresh.forEach(function(item){feedKeys[item.key]=1});
      feedItems=fresh.concat(feedItems);
      pendingItems=[];
      feedVisible=FEED_PAGE_SIZE;
      anchor=null;
      var body=root.querySelector('.nos-body');
      if(body)body.scrollTop=0;
      scheduleRender();
    }
    function addFeedEvent(ev,historical){
      // Following is the people you follow; your own notes are on your profile.
      if(feedMode==='following'&&ev.pubkey===pubHex)return;
      // Both modes hold an open subscription now, so anything arriving after the
      // stored batch is genuinely new and belongs behind the pill.
      var live=feedLoaded&&!historical;
      if(ev.kind===6){
        var targetId=lastETag(ev);
        if(!targetId)return;
        var embedded=null;try{embedded=JSON.parse(ev.content)}catch(_){}
        // NIP-18 lets the repost carry the original inline; using it saves a
        // round trip, but only when it really is the event the tag points at.
        if(embedded&&embedded.id===targetId&&embedded.kind===1){noteCache[targetId]=embedded;ensureProfile(embedded.pubkey,live)}
        else ensureNote(targetId);
        ensureProfile(ev.pubkey,live);
        (live?pushPending:pushItem)({key:'boost:'+ev.id,noteId:targetId,boost:ev,at:ev.created_at});
        return;
      }
      if(ev.kind!==1)return;
      noteCache[ev.id]=ev;ensureProfile(ev.pubkey,live);
      (live?pushPending:pushItem)({key:ev.id,noteId:ev.id,boost:null,at:ev.created_at});
    }
    // Every other connection in this app is a relay the user picked. The ranking
    // cache is not, so what comes back from it is checked rather than trusted:
    // the id must be the hash of the event and the signature must match the
    // author's key. That bounds what a compromised ranking service can do to
    // choosing which real notes to show — it cannot put words in anyone's mouth.
    // Verification is per event as it streams in, so the cost never lands as one
    // block on the main thread.
    async function verifyEvent(ev){
      try{
        if(!ev||!ev.id||!ev.sig||!ev.pubkey||!Array.isArray(ev.tags))return false;
        var idBytes=await sha256(new TextEncoder().encode(serializeEvent(ev)));
        if(bytesToHex(idBytes)!==ev.id)return false;
        return window.NostrCrypto.schnorr.verify(hexToBytes(ev.sig),idBytes,hexToBytes(ev.pubkey));
      }catch(_){return false}
    }
    // The cache answers with the notes, the profiles behind them and its own
    // engagement counts in one stream, so a popular note arrives ready to draw:
    // no follow-up query for the author's avatar and none for the numbers.
    //
    // The same request serves both the first load and the background refresh.
    // Nothing already on screen moves on a refresh: a note the list did not have
    // waits behind the "new posts" pill exactly as in the other two modes, so the
    // ranking can keep changing underneath without costing the reader their
    // place. When Popular is not the open mode the new notes raise its badge
    // instead. Either way the ranking goes on being checked, which is the point —
    // nothing here should need reloading the app to notice that it moved.
    function fetchTrending(token,poll){
      var subs=poll?TRENDING_POLL_SUBS:TRENDING_SUBS;
      // Seeding. The very first answer is the state of the world, not news about
      // it: without this, opening the app on Following and letting the poll run
      // once would stamp the Popular button with the size of the whole ranking.
      var firstRun=!modeSeenInit.trending;
      if(!poll)trendingFailed=false;
      trendingAt=Date.now();
      var pendingSubs=subs.length,pendingChecks=0,got=0,eosed=false;
      // Signature checks are asynchronous, so the last EOSE is not the end of the
      // load: settling on it alone would flash the empty state over a list that
      // is about to arrive, and would call a working service dead.
      function settle(){
        if(!eosed||pendingChecks>0)return;
        modeSeenInit.trending=true;
        if(poll){subs.forEach(function(id){pool.unsubscribe(id)});return}
        if(token!==feedToken)return;
        feedLoaded=true;
        trendingFailed=got===0;
        scheduleRender();
      }
      subs.forEach(function(subId,i){
        if(poll)pool.unsubscribe(subId);
        pool.subscribe([TRENDING_URL],subId,[{cache:[TRENDING_CACHES[i]]}],function(ev){
          if(!poll&&token!==feedToken)return;
          if(ev.kind===0){
            var prev=profileCache[ev.pubkey];
            if(!prev||prev.created_at<ev.created_at)profileCache[ev.pubkey]=parseProfile(ev);
            return;
          }
          if(ev.kind===PRIMAL_STATS_KIND){
            try{
              var st=JSON.parse(ev.content||'{}');
              if(st.event_id)netStats[st.event_id]={
                replies:st.replies||0,reposts:st.reposts||0,
                likes:st.likes||0,zaps:st.zaps||0
              };
            }catch(_){}
            return;
          }
          if(ev.kind!==1||!String(ev.content||'').trim())return;
          got++;
          if(poll){
            // A refresh mostly returns the list it returned last time, and the
            // very first one returns all of it. Both are dropped before the
            // signature check rather than after: these ids only ever decide new
            // from already-counted, so re-verifying eighty notes every few
            // minutes would buy nothing.
            if(modeSeenKeys.trending[ev.id])return;
            if(firstRun){modeSeenKeys.trending[ev.id]=1;return}
          }
          pendingChecks++;
          verifyEvent(ev).then(function(ok){
            pendingChecks--;
            if(ok)takeTrending(token,ev,poll);
            settle();
          });
        },function(){if(--pendingSubs<=0){eosed=true;settle()}});
      });
    }
    function takeTrending(token,ev,poll){
      modeSeenKeys.trending[ev.id]=1;
      var item={key:ev.id,noteId:ev.id,boost:null,at:ev.created_at};
      // The two lists overlap by a note or two; both pushItem and pushPending key
      // them out, so the overlap costs nothing.
      if(!poll){
        if(token!==feedToken||feedMode!=='trending')return;
        noteCache[ev.id]=ev;ensureProfile(ev.pubkey);
        pushItem(item);
        return;
      }
      // Only the mode actually on screen needs the note itself. Counting for the
      // badge must never pull in avatars for a list nobody is looking at: each
      // profile that came back would repaint the feed that *is* on screen, so a
      // silent count on one button would flicker the other mode's list. Switching
      // to Popular fetches the notes properly anyway.
      if(feedMode==='trending'&&activeTab==='feed'){
        noteCache[ev.id]=ev;ensureProfile(ev.pubkey,true);
        pushPending(item);
      }else{modeCounts.trending++;scheduleRenderShell()}
    }
    function stopFeedSubs(){['feed','discover'].concat(feedPageSubs,TRENDING_SUBS).forEach(function(id){pool.unsubscribe(id)});feedPageSubs=[]}
    function loadFeed(){
      var token=++feedToken;
      feedItems=[];feedKeys={};feedLoaded=false;
      feedVisible=FEED_PAGE_SIZE;feedCursors={};feedExhausted={};feedPaging=false;
      pendingItems=[];pendingKeys={};
      modeCounts[feedMode]=0;
      if(feedMode==='following'){modeSeenKeys.following={};modeSeenInit.following=true}
      stopFeedSubs();
      // Popular does not read from the user's relays, so it is the one mode that
      // still works on an installation with none configured yet.
      if(feedMode==='trending'){fetchTrending(token,false);scheduleRender();startModePolling();return}
      if(!readUrls().length){feedLoaded=true;scheduleRender();return}
      if(feedMode==='following'){
        var authors=contactPubkeys.filter(function(pk){return pk!==pubHex});
        if(!authors.length){feedLoaded=true;scheduleRender();return}
        pool.subscribe(readUrls(),'feed',[{kinds:[1,6],authors:authors,limit:20}],
          function(ev,url){if(token===feedToken){modeSeenKeys.following[ev.id]=1;if(!feedLoaded)rememberFeedTime(ev,url);addFeedEvent(ev)}},
          function(){if(token===feedToken){feedLoaded=true;scheduleRender()}});
      }else loadDiscover(token);
      scheduleRender();
      startModePolling();
    }
    // Following streams live on its own open subscription, and Discover does too
    // now, so neither mode needs re-querying to notice new posts. What is still
    // needed is the count on the *other* button: while Discover is open, the
    // Following tab has no subscription of its own to raise its badge, so a small
    // periodic query fills it.
    var MODE_POLL_MS=90000;
    function startModePolling(){
      clearInterval(modePollTimer);
      modePollTimer=setInterval(pollAllModes,MODE_POLL_MS);
    }
    function stopModePolling(){
      clearInterval(modePollTimer);modePollTimer=0;
      TRENDING_POLL_SUBS.forEach(function(id){pool.unsubscribe(id)});
    }
    // Popular is the only mode with no open subscription of its own: the cache
    // answers once and closes, so a poll is the only thing that can notice the
    // ranking has moved. It moves by about a note every couple of minutes, so it
    // gets its own slower beat than the Following count — asking faster would
    // only re-download the list it just returned, and this is the heavier of the
    // two answers, carrying notes, profiles and counts together.
    var TRENDING_POLL_MS=180000;
    function pollAllModes(){
      if(activeTab!=='feed'||stack.length)return;
      // Not gated on the relay list: the ranking cache is not one of the user's
      // relays, so Popular keeps refreshing even where none are configured.
      if(Date.now()-trendingAt>=TRENDING_POLL_MS)fetchTrending(0,true);
      if(!readUrls().length||feedMode==='following')return;
      pollFollowingCount();
    }
    function pollFollowingCount(){
      var authors=contactPubkeys.filter(function(pk){return pk!==pubHex}),subId='poll-following',firstRun=!modeSeenInit.following;
      pool.unsubscribe(subId);
      if(!authors.length)return;
      pool.subscribe(readUrls(),subId,[{kinds:[1,6],authors:authors,limit:20}],function(ev){
        if(modeSeenKeys.following[ev.id])return;
        modeSeenKeys.following[ev.id]=1;
        // Same reason as pushPending: your own note must not raise the badge that
        // tells you there is something new to catch up on.
        if(!firstRun&&ev.pubkey!==pubHex&&!isMuted(ev.pubkey)&&!deletedIds[ev.id]){modeCounts.following++;scheduleRenderShell()}
      },function(){pool.unsubscribe(subId);modeSeenInit.following=true});
    }
    // A relay has no trending endpoint — trending is a service Primal runs on top
    // of Nostr, not a part of the protocol. This used to measure it honestly and
    // expensively: pull up to a thousand reactions from a chosen window, tally
    // what they pointed at, then fetch those notes. Three round trips across
    // every relay had to finish before a single note could be drawn, which is
    // why picking 1h/4h/24h meant waiting, sometimes minutes — and why having to
    // pick at all was a chore rather than a feature.
    //
    // Recency is the one thing every relay really does index, so Discover asks
    // for that and nothing else: one open subscription for recent notes. It
    // paints as events arrive rather than after the last of them, and because the
    // subscription stays open afterwards, new posts keep streaming into the
    // pill by themselves. No window to choose and nothing to poll.
    // Kind 1 means "a human wrote this", but nothing enforces that, and some
    // people run their infrastructure over it: device heartbeats, presence pings
    // and join events published as notes because a relay is a convenient message
    // bus. Measured against the live firehose it is about one note in thirteen,
    // from a handful of authors. There is nothing to draw — it is not a NIP, just
    // somebody's own JSON — so in Discover, the one feed nobody chose the authors
    // of, a note whose entire content is a JSON document is dropped. Following is
    // deliberately left alone: what someone you chose to follow posts is between
    // you and them, not something this app should quietly withhold.
    function isMachineNote(content){
      var c=content.charAt(0);
      if(c!=='{'&&c!=='[')return false;
      try{var v=JSON.parse(content);return v!==null&&typeof v==='object'}catch(_){return false}
    }
    // Encrypted payloads (NIP-44 base64, NIP-04 "...?iv=...") published as plain
    // notes: one long unbroken base64 string. Nobody wrote it to be read.
    function isCipherNote(content){
      if(content.length<80||/\s/.test(content))return false;
      return /^[A-Za-z0-9+\/]+={0,2}$/.test(content)||/^[A-Za-z0-9+\/]+={0,2}\?iv=[A-Za-z0-9+\/]+={0,2}$/.test(content);
    }
    // Machine-generated service discovery identifiers are not readable posts.
    function isServiceDiscoveryNote(content){
      return /^(?:https?:\/\/)?sp_[a-z0-9]+(?:\.[a-z0-9_-]+)+\.drift\.gits\.net\/?\.?$/i.test(content.replace(/\s+/g,''));
    }
    function rememberFeedTime(ev,url){
      if(Number.isFinite(ev.created_at)&&(feedCursors[url]===undefined||ev.created_at<feedCursors[url]))feedCursors[url]=ev.created_at;
    }
    function acceptableDiscover(ev){
      var content=String(ev.content||'').trim();
      return !isReply(ev)&&!!content&&!isMachineNote(content)&&!isCipherNote(content)&&!isServiceDiscoveryNote(content);
    }
    function loadDiscover(token){
      pool.subscribe(readUrls(),'discover',[{kinds:[1],limit:DISCOVER_LIMIT}],function(ev,url){
        // Replies are conversation, not discovery, and an empty note is a relay
        // artefact; both would only pad the list out with things nobody can read.
        if(token!==feedToken)return;
        if(!feedLoaded)rememberFeedTime(ev,url);
        if(!acceptableDiscover(ev))return;
        addFeedEvent(ev);
      },function(){if(token===feedToken){feedLoaded=true;scheduleRender()}});
    }
    function loadOlderFeed(){
      if(feedPaging||feedMode==='trending')return;
      var token=feedToken,mode=feedMode,urls=readUrls().filter(function(url){return feedCursors[url]!==undefined&&!feedExhausted[url]});
      var authors=contactPubkeys.filter(function(pk){return pk!==pubHex});
      if(!urls.length||(mode==='following'&&!authors.length))return;
      feedPaging=true;feedVisible+=FEED_PAGE_SIZE;
      var remaining=urls.length;
      urls.forEach(function(url,i){
        var until=feedCursors[url],oldest=until,received=0,subId='feed-older-'+i;
        var filter=mode==='following'?{kinds:[1,6],authors:authors,limit:40,until:until}:{kinds:[1],limit:DISCOVER_LIMIT,until:until};
        feedPageSubs.push(subId);
        pool.subscribe([url],subId,[filter],function(ev){
          if(token!==feedToken)return;
          received++;
          if(Number.isFinite(ev.created_at)&&ev.created_at<oldest)oldest=ev.created_at;
          if(mode==='discover'&&!acceptableDiscover(ev))return;
          addFeedEvent(ev,true);
        },function(){
          pool.unsubscribe(subId);
          if(token!==feedToken)return;
          // Each relay has its own cursor; their histories need not overlap.
          feedCursors[url]=oldest<until?oldest:until-1;
          if(!received)feedExhausted[url]=true;
          if(!--remaining){feedPageSubs=[];feedPaging=false;scheduleRender()}
        });
      });
    }

    // ---- notifications ----
    function loadNotifications(){
      pool.unsubscribe('notif');
      notifItems=[];notifKeys={};notifLoaded=false;
      loadNotifSeen();
      if(!readUrls().length){notifLoaded=true;return}
      pool.subscribe(readUrls(),'notif',[{kinds:[1,6,7,9735],'#p':[pubHex],limit:80}],function(ev){
        if(ev.kind===9735){
          // A zap receipt is signed by the wallet's server; the person who zapped is
          // inside it, and only a receipt that checks out is shown.
          if(notifKeys[ev.id])return;
          notifKeys[ev.id]=1;
          parseZapReceipt(ev).then(function(z){
            if(!z||!key||z.recipient!==pubHex||z.sender===pubHex)return;
            ev._zap=z;ensureProfile(z.sender);
            var tg=lastETag(ev);if(tg)ensureNote(tg);
            var j=0;while(j<notifItems.length&&notifItems[j].created_at>ev.created_at)j++;
            notifItems.splice(j,0,ev);
            if(notifItems.length>100)notifItems.length=100;
            scheduleRender();
          });
          return;
        }
        if(ev.pubkey===pubHex||notifKeys[ev.id])return;
        notifKeys[ev.id]=1;
        ensureProfile(ev.pubkey);
        var target=targetOf(ev);
        if(target)ensureNote(target);
        // A repost may carry the original signed event even when our relays no
        // longer return it. Verify it before using it for this and other notices.
        if(ev.kind===6&&target&&ev.content){
          try{
            var embedded=JSON.parse(ev.content);
            if(embedded.id===target&&embedded.kind===1)verifyEvent(embedded).then(function(valid){
              if(!valid||!key||noteCache[target])return;
              noteCache[target]=embedded;delete noteMissing[target];ensureProfile(embedded.pubkey);scheduleRender();
            });
          }catch(_){}
        }
        var i=0;while(i<notifItems.length&&notifItems[i].created_at>ev.created_at)i++;
        notifItems.splice(i,0,ev);
        if(notifItems.length>100)notifItems.length=100;
        scheduleRender();
      },function(){notifLoaded=true;scheduleRender()});
    }
    // Remember the first observed follower set without raising notifications.
    // Keep it per identity and only add entries: a partial relay response must
    // not make existing followers look new on the next connection.
    function startFollowerNotifications(){
      var generation=++followerGeneration,owner=pubHex,storageKey='nos_followers_'+owner;
      pool.unsubscribe('follower-notifications');
      followerKnown={};followerNotifs=[];followerReady=false;
      try{
        var stored=JSON.parse(localStorage.getItem(storageKey)||'null');
        if(stored&&stored.version===1&&Array.isArray(stored.known)&&Array.isArray(stored.notifications)){
          stored.known.forEach(function(pk){if(typeof pk==='string'&&/^[0-9a-f]{64}$/.test(pk))followerKnown[pk]=1});
          followerNotifs=stored.notifications.filter(function(n){return n&&typeof n.pubkey==='string'&&/^[0-9a-f]{64}$/.test(n.pubkey)&&Number.isSafeInteger(n.created_at)}).slice(0,100);
          followerReady=true;
        }
      }catch(_){}
      followerNotifs.forEach(function(n){ensureProfile(n.pubkey)});
      if(!readUrls().length)return;
      var pending=[],initial={},baselineDone=followerReady;
      function persist(){try{localStorage.setItem(storageKey,JSON.stringify({version:1,known:Object.keys(followerKnown),notifications:followerNotifs.slice(0,100)}))}catch(_){}}
      function accept(ev){
        if(generation!==followerGeneration||!key||pubHex!==owner||followerKnown[ev.pubkey])return;
        followerKnown[ev.pubkey]=1;
        followerNotifs.unshift({kind:3,pubkey:ev.pubkey,created_at:Math.min(ev.created_at||0,Math.floor(Date.now()/1000))||Math.floor(Date.now()/1000),id:'follow-'+ev.pubkey});
        followerNotifs=followerNotifs.slice(0,100);ensureProfile(ev.pubkey);persist();scheduleRenderShell();
      }
      pool.subscribe(readUrls(),'follower-notifications',[{kinds:[3],'#p':[owner]}],function(ev){
        if(!ev||ev.kind!==3||ev.pubkey===owner||!Array.isArray(ev.tags)||!ev.tags.some(function(tag){return Array.isArray(tag)&&tag[0]==='p'&&tag[1]===owner}))return;
        var check=verifyEvent(ev).then(function(valid){
          if(!valid||generation!==followerGeneration||!key||pubHex!==owner)return;
          if(!baselineDone)initial[ev.pubkey]=1;else accept(ev);
        });
        if(!baselineDone)pending.push(check);
      },function(count){
        if(baselineDone)return;
        if(!count){setTimeout(function(){if(generation===followerGeneration&&key&&pubHex===owner)startFollowerNotifications()},30000);return}
        Promise.all(pending).then(function(){
          if(generation!==followerGeneration||!key||pubHex!==owner)return;
          Object.keys(initial).forEach(function(pk){followerKnown[pk]=1});
          baselineDone=true;followerReady=true;persist();
        });
      },true);
    }
    function notifActor(ev){return ev._zap?ev._zap.sender:ev.pubkey}
    function unreadCount(){return notifItems.concat(followerNotifs).filter(function(ev){return ev.created_at>notifSeen&&!isMuted(notifActor(ev))}).length}
    // The point up to which notifications were read lives in the database per
    // Nostr identity, so every device shows the same unread count. The
    // browser copy is only a cache for the moment before the answer arrives.
    function saveNotifSeen(){
      var owner=pubHex,value=notifSeen;
      if(!owner||!token||!value)return;
      fetch(API+'/notif-seen',{method:'PUT',headers:{'Content-Type':'application/json','X-Pub-Token':token},body:JSON.stringify({pubkey:owner,seen:value})}).catch(function(){});
    }
    function loadNotifSeen(){
      var owner=pubHex;if(!owner||!token)return;
      fetch(API+'/notif-seen?pubkey='+owner,{headers:{'X-Pub-Token':token}}).then(function(r){return r.ok?r.json():null}).then(function(d){
        if(!d||owner!==pubHex)return;
        if(typeof d.seen==='number'){
          if(d.seen!==notifSeen){notifSeen=d.seen;try{localStorage.setItem(SEEN_KEY,String(notifSeen))}catch(_){}if(notifBase!==null&&activeTab!=='notifications')notifBase=null;scheduleRenderShell();if(activeTab==='notifications')renderBody()}
        }else if(notifSeen)saveNotifSeen();
      }).catch(function(){});
    }
    function markNotifSeen(){
      var all=notifItems.concat(followerNotifs);if(!all.length)return;
      var next=Math.max.apply(Math,[notifSeen].concat(all.map(function(ev){return ev.created_at})));
      if(next===notifSeen)return;
      notifSeen=next;
      try{localStorage.setItem(SEEN_KEY,String(notifSeen))}catch(_){}
      saveNotifSeen();
    }

    // ---- thread and user views ----
    function pushView(view){stack.push(view);scrollReset=true;renderShell()}
    function popView(){
      stack.pop();
      scrollReset=true;
      var top=stack[stack.length-1];
      if(top&&top.type==='thread')loadThread(top.id);
      else if(top&&top.type==='user')loadUser(top.pubkey);
      else if(top&&top.type==='people')loadPeople(top.mode,top.pubkey);
      renderShell();
    }
    function openThread(id){
      if(!id)return;
      ensureNote(id);
      loadThread(id);
      pushView({type:'thread',id:id});
    }
    function openUser(pk){
      if(!pk)return;
      ensureProfile(pk);
      loadUser(pk);
      pushView({type:'user',pubkey:pk});
    }
    // Finding somebody by name is not something Nostr gives a client for free.
    // A relay indexes events, not people, and only relays that implement NIP-50
    // understand a text query at all. So this asks in three ways at once and
    // merges whatever answers: profiles already in this session's cache (instant,
    // and it covers everyone you follow), a NIP-05 address resolved against the
    // domain that owns it, and a NIP-50 query to the relays. Relays that do not
    // support NIP-50 ignore the search field and reply with unrelated profiles,
    // so every relay answer is checked against the query here before it is shown
    // — an unsupporting relay then simply contributes nothing instead of noise.
    var NIP05_RE=/^[\w.+-]+@(?:[\w-]+\.)+[a-z]{2,}$/i;
    function openSearch(){
      var top=stack[stack.length-1];
      if(top&&top.type==='search')return;
      // Your follow list is the most likely place for the person you are looking
      // for, and their profiles may never have been fetched if they have not
      // posted lately. One batched REQ through the existing queue covers it.
      contactPubkeys.slice(0,500).forEach(ensureProfile);
      pushView({type:'search'});
      setTimeout(function(){var i=root.querySelector('.nos-search-input');if(i)i.focus()},30);
    }
    function profileMatches(pk,q){
      var p=profileCache[pk];
      if(!p)return false;
      q=q.toLowerCase();
      return String(p.name||'').toLowerCase().indexOf(q)>=0||
             String(p.handle||'').toLowerCase().indexOf(q)>=0||
             String(p.nip05||'').toLowerCase().indexOf(q)>=0;
    }
    function addSearchResult(pk){
      if(!pk||searchResults.indexOf(pk)>=0||searchResults.length>=60)return;
      searchResults.push(pk);
      scheduleRender();
    }
    function scheduleSearch(q){clearTimeout(searchDebounce);searchDebounce=setTimeout(function(){runSearch(q)},350)}
    function runSearch(raw){
      var q=String(raw||'').trim();
      searchQuery=q;
      var seq=++searchSeq;
      pool.unsubscribe('search');
      searchResults=[];searchBusy=false;
      if(!q){scheduleRender();return}
      // A pasted npub or nostr: URI is not a search — it names one person exactly,
      // so go straight to them instead of pretending to look.
      var direct=npubDecode(q)||refToPubkey(q.replace(/^nostr:/,''))||(/^[0-9a-f]{64}$/i.test(q)?q.toLowerCase():null);
      if(direct){openUser(direct);return}
      searchBusy=true;
      Object.keys(profileCache).forEach(function(pk){if(profileMatches(pk,q))addSearchResult(pk)});
      if(NIP05_RE.test(q))resolveNip05(q,seq);
      if(!readUrls().length){searchBusy=false;scheduleRender();return}
      pool.subscribe(readUrls(),'search',[{kinds:[0],search:q,limit:40}],function(ev){
        if(seq!==searchSeq)return;
        var prev=profileCache[ev.pubkey];
        if(prev===undefined||prev===null||prev.created_at<ev.created_at)profileCache[ev.pubkey]=parseProfile(ev);
        if(profileMatches(ev.pubkey,q))addSearchResult(ev.pubkey);
      },function(){if(seq===searchSeq){searchBusy=false;pool.unsubscribe('search');scheduleRender()}});
      scheduleRender();
    }
    // NIP-05 is resolved by the domain in the address, not by a relay: the browser
    // asks that host directly, which is exactly what the spec describes and why
    // those hosts serve the file with permissive CORS. A host that does not is
    // simply one source that returns nothing; the other two still answer.
    function resolveNip05(q,seq){
      var at=q.indexOf('@'),name=q.slice(0,at),domain=q.slice(at+1);
      fetch('https://'+domain+'/.well-known/nostr.json?name='+encodeURIComponent(name),{referrerPolicy:'no-referrer'})
        .then(function(r){return r.ok?r.json():null})
        .then(function(d){
          if(seq!==searchSeq||!d||!d.names)return;
          var pk=d.names[name]||d.names[name.toLowerCase()];
          if(pk&&/^[0-9a-f]{64}$/i.test(pk)){ensureProfile(pk);addSearchResult(pk)}
        }).catch(function(){});
    }
    function searchRank(pk){
      var p=profileCache[pk]||{},n=String(p.name||p.handle||'').toLowerCase(),q=searchQuery.toLowerCase(),s=0;
      if(contactPubkeys.indexOf(pk)>=0)s+=8;
      if(n===q)s+=4;else if(n.indexOf(q)===0)s+=2;
      if(p.nip05)s+=1;
      return s;
    }
    // The input element is deliberately left in place across re-renders: this view
    // repaints whenever a relay answers, and rebuilding it would take the caret
    // and half-typed query with it.
    function renderSearch(body){
      var input=body.querySelector('.nos-search-input');
      if(!input){
        body.innerHTML='<div class="nos-search"><input class="nos-search-input" type="search" autocomplete="off" spellcheck="false" placeholder="'+esc(t('nos_search_placeholder'))+'" value="'+esc(searchQuery)+'">'+
          '<div class="nos-search-results"></div></div>';
        input=body.querySelector('.nos-search-input');
        input.oninput=function(){scheduleSearch(input.value)};
        input.onkeydown=function(e){if(e.key==='Enter'){clearTimeout(searchDebounce);runSearch(input.value)}};
      }
      var res=body.querySelector('.nos-search-results');
      if(!searchQuery)res.innerHTML='<div class="nos-empty">'+esc(t('nos_search_hint'))+'</div>';
      else if(!searchResults.length)res.innerHTML='<div class="nos-empty">'+esc(searchBusy?t('nos_searching'):t('nos_search_none'))+'</div>';
      else res.innerHTML=searchResults.slice().sort(function(a,b){return searchRank(b)-searchRank(a)}).map(function(pk){
        var p=profileCache[pk]||{};
        return'<div class="nos-identity-row" data-user="'+esc(pk)+'">'+avatarHtml(pk)+
          '<span class="nos-identity-label"><b>'+esc(displayName(pk))+'</b>'+
          (p.nip05?'<br><span class="nos-nip05">'+esc(p.nip05)+'</span>':'')+'</span></div>';
      }).join('')+(searchBusy?'<div class="nos-empty">'+esc(t('nos_searching'))+'</div>':'');
      bindList(res);
    }
    function openPeople(mode,pk){
      loadPeople(mode,pk);
      pushView({type:'people',mode:mode,pubkey:pk});
    }
    function loadThread(id){
      threadReplies=[];threadKeys={};threadLoaded=false;
      pool.unsubscribe('thread');
      var note=noteCache[id];
      if(note){var parent=replyTarget(note);if(parent)ensureNote(parent);var rootId=rootTarget(note);if(rootId)ensureNote(rootId)}
      if(!readUrls().length){threadLoaded=true;return}
      pool.subscribe(readUrls(),'thread',[{kinds:[1],'#e':[id],limit:100}],function(ev){
        if(threadKeys[ev.id]||replyTarget(ev)!==id)return;
        threadKeys[ev.id]=1;
        noteCache[ev.id]=ev;ensureProfile(ev.pubkey);
        var i=0;while(i<threadReplies.length&&threadReplies[i].created_at<ev.created_at)i++;
        threadReplies.splice(i,0,ev);
        scheduleRender();
      },function(){threadLoaded=true;scheduleRender()});
    }
    // Primal indexes contact lists across relays; a single relay cannot provide a
    // network-wide follower total. Keep an unavailable result distinct from zero.
    function loadFollowerCount(pk){
      var cached=followerCounts[pk];
      if(followerCountPending[pk]||(cached&&Date.now()-cached.at<300000))return;
      var subId='follower-count-'+pk;
      followerCountPending[pk]=true;
      pool.subscribe([TRENDING_URL],subId,[{cache:['user_profile',{pubkey:pk}]}],function(ev){
        if(ev.kind!==10000105)return;
        try{
          var data=JSON.parse(ev.content||'{}'),count=data.followers_count;
          if(data.pubkey!==pk||!Number.isSafeInteger(count)||count<0)return;
          followerCounts[pk]={count:count,at:Date.now()};
          root.querySelectorAll('[data-people="followers"]').forEach(function(btn){
            if(btn.dataset.pubkey===pk)btn.querySelector('b').textContent=String(count);
          });
        }catch(_){}
      },function(){pool.unsubscribe(subId);delete followerCountPending[pk]});
    }
    function loadUser(pk){
      loadFollowerCount(pk);
      userNotes=[];userKeys={};userLoaded=false;
      pool.unsubscribe('user');
      if(!readUrls().length){userLoaded=true;return}
      pool.subscribe(readUrls(),'user',[{kinds:[1],authors:[pk],limit:100}],function(ev){
        if(userKeys[ev.id])return;
        userKeys[ev.id]=1;
        noteCache[ev.id]=ev;
        var i=0;while(i<userNotes.length&&userNotes[i].created_at>ev.created_at)i++;
        userNotes.splice(i,0,ev);
        scheduleRender();
      },function(){userLoaded=true;scheduleRender()});
    }
    // Following comes straight from the already-loaded kind:3 list — no relay
    // round trip needed for your own. A stranger's following list, and anyone's
    // followers, aren't cached anywhere and have to be fetched on demand.
    function loadPeople(mode,pk){
      peopleList=[];peopleKeys={};peopleLoaded=false;
      pool.unsubscribe('people');
      if(mode==='following'&&pk===pubHex){
        peopleList=contactPubkeys.slice();
        peopleList.forEach(ensureProfile);
        peopleLoaded=true;
        scheduleRender();
        return;
      }
      if(!readUrls().length){peopleLoaded=true;scheduleRender();return}
      if(mode==='following'){
        pool.subscribe(readUrls(),'people',[{kinds:[3],authors:[pk],limit:1}],function(ev){
          tagsOf(ev,'p').map(function(tg){return tg[1]}).filter(Boolean).forEach(function(other){
            if(peopleKeys[other])return;
            peopleKeys[other]=1;peopleList.push(other);ensureProfile(other);
          });
          scheduleRender();
        },function(){peopleLoaded=true;scheduleRender()});
      }else{
        pool.subscribe(readUrls(),'people',[{kinds:[3],'#p':[pk],limit:500}],function(ev){
          if(peopleKeys[ev.pubkey])return;
          peopleKeys[ev.pubkey]=1;peopleList.push(ev.pubkey);ensureProfile(ev.pubkey);
          scheduleRender();
        },function(){peopleLoaded=true;scheduleRender()});
      }
    }

    // ---- publishing ----
    function showToast(text){
      var el=document.createElement('div');
      el.className='nos-toast';el.setAttribute('role','status');el.textContent=text;
      el.style.cssText='position:absolute;left:50%;bottom:1rem;transform:translateX(-50%);z-index:40;max-width:calc(100% - 2rem);padding:.5rem .9rem;border-radius:999px;background:var(--pub-accent,#89b4fa);color:var(--on-accent,var(--pub-bg,#1e1e2e));font-size:.8rem;font-weight:700;box-shadow:0 .25rem .6rem rgba(0,0,0,.3);pointer-events:none';
      root.appendChild(el);
      setTimeout(function(){el.remove()},3500);
    }
    function publishingToast(total){
      var el=document.createElement('div');
      el.className='nos-toast';el.setAttribute('role','status');
      el.style.cssText='position:absolute;left:50%;bottom:1rem;transform:translateX(-50%);z-index:40;max-width:calc(100% - 2rem);padding:.5rem .9rem;border-radius:1rem;background:var(--pub-accent,#89b4fa);color:var(--on-accent,var(--pub-bg,#1e1e2e));font-size:.8rem;font-weight:700;box-shadow:0 .25rem .6rem rgba(0,0,0,.3);pointer-events:none';
      var label=document.createElement('div'),track=document.createElement('div'),bar=document.createElement('div');
      track.style.cssText='height:.25rem;margin-top:.35rem;border-radius:1rem;background:rgba(0,0,0,.18);overflow:hidden';
      bar.style.cssText='height:100%;width:0;background:currentColor;transition:width .35s ease';
      track.appendChild(bar);el.appendChild(label);el.appendChild(track);root.appendChild(el);
      function update(ok,done){label.textContent=t('nos_publishing_progress',{ok:ok,total:total});bar.style.width=(total?done/total*100:0)+'%'}
      update(0,0);
      return {update:update,finish:function(result){
        label.textContent=t('nos_published_all',{ok:result.ok,total:result.total});
        setTimeout(function(){el.remove()},3500);
      },remove:function(){el.remove()}};
    }
    async function publish(base,onProgress){
      var ev=await finalizeEvent(base,privBytes);
      var results=await pool.publish(writeUrls(),ev,onProgress);
      if(!results.some(function(r){return r.ok}))throw new Error('publish_failed');
      ev._done=results.all;
      return ev;
    }
    // Rewriting the list before the stored copy has arrived would silently drop
    // everything already muted from other clients, so wait for it first.
    async function toggleMute(pk){
      var waited=0;
      while(!mutesLoaded&&waited<6000){await new Promise(function(r){setTimeout(r,200)});waited+=200}
      if(!mutesLoaded)return;
      var tags=(muteEvent?muteEvent.tags:[]).filter(function(tg){return!(tg[0]==='p'&&tg[1]===pk)});
      if(!isMuted(pk))tags.push(['p',pk]);
      mutedPubkeys=tags.filter(function(tg){return tg[0]==='p'}).map(function(tg){return tg[1]});
      renderBody();
      try{
        var ev=await publish({kind:10000,tags:tags,content:muteEvent?muteEvent.content:''});
        if(ev)muteEvent=ev;
      }catch(_){}
    }
    async function toggleFollow(pk){
      var idx=contactPubkeys.indexOf(pk);
      if(idx>=0)contactPubkeys.splice(idx,1);else contactPubkeys.push(pk);
      renderBody();
      try{await publish({kind:3,tags:contactPubkeys.map(function(x){return['p',x]}),content:''})}catch(_){}
      if(activeTab==='feed'&&feedMode==='following'&&!stack.length)loadFeed();
    }
    async function toggleLike(id){
      var note=noteCache[id];if(!note)return;
      var existing=myReactions[id],s=statOf(id);
      if(existing){
        delete myReactions[id];s.likes=Math.max(0,s.likes-1);renderBody();
        try{await publish({kind:5,tags:[['e',existing]],content:''})}catch(_){}
        return;
      }
      myReactions[id]='pending';s.likes++;renderBody();
      try{var ev=await publish({kind:7,tags:[['e',id],['p',note.pubkey]],content:'+'});myReactions[id]=ev.id;s.seen[ev.id]=1}
      catch(_){delete myReactions[id];s.likes=Math.max(0,s.likes-1);renderBody()}
    }
    async function toggleRepost(id){
      var note=noteCache[id];if(!note)return;
      var existing=myReposts[id],s=statOf(id);
      if(existing){
        delete myReposts[id];s.reposts=Math.max(0,s.reposts-1);renderBody();
        try{await publish({kind:5,tags:[['e',existing]],content:''})}catch(_){}
        return;
      }
      myReposts[id]='pending';s.reposts++;renderBody();
      try{
        var ev=await publish({kind:6,tags:[['e',id,readUrls()[0]||''],['p',note.pubkey]],content:JSON.stringify(note)});
        myReposts[id]=ev.id;s.seen[ev.id]=1;
      }catch(_){delete myReposts[id];s.reposts=Math.max(0,s.reposts-1);renderBody()}
    }

    // ---- composer ----
    var composePreviewTimer=0;
    function openComposer(mode,id,suggesting){
      composer={mode:mode,id:id||null,error:'',busy:false,images:[],uploading:false,suggesting:!!suggesting};
      if(mode==='edit'&&noteCache[id])composer.text=noteCache[id].content;
      renderComposer();
    }
    // Nostr events cannot be changed, so an edit is a fresh note with the same tags
    // (it stays in its thread) plus a NIP-09 request to drop the old one. Relays
    // are free to ignore that request, which is why the old note is hidden here
    // at once rather than waiting for the relays to agree.
    function retireNote(id){
      deletedIds[id]=1;
      feedItems=feedItems.filter(function(item){return item.noteId!==id});
      threadReplies=threadReplies.filter(function(ev){return ev.id!==id});
      var top=stack[stack.length-1];
      if(top&&top.type==='thread'&&top.id===id)stack.pop();
    }
    function confirmDelete(){
      if(window.mvmOS&&window.mvmOS.confirm)return window.mvmOS.confirm(t('nos_delete_confirm'),{ok:t('nos_delete'),cancel:t('nos_cancel'),danger:true});
      return new Promise(function(resolve){
        var dialog=document.createElement('dialog');dialog.className='nos-modal-card';
        dialog.style.margin='auto';dialog.style.border='1px solid var(--pub-border,#45475a)';
        dialog.innerHTML='<p>'+esc(t('nos_delete_confirm'))+'</p><div class="nos-modal-foot"><button data-cancel>'+esc(t('nos_cancel'))+'</button><button data-delete>'+esc(t('nos_delete'))+'</button></div>';
        function finish(ok){dialog.close();dialog.remove();resolve(ok)}
        dialog.querySelector('[data-cancel]').onclick=function(){finish(false)};
        dialog.querySelector('[data-delete]').onclick=function(){finish(true)};
        dialog.oncancel=function(e){e.preventDefault();finish(false)};
        root.appendChild(dialog);dialog.showModal();
      });
    }
    async function deleteNote(id){
      var note=noteCache[id];
      if(!note||note.pubkey!==pubHex)return;
      if(!await confirmDelete())return;
      retireNote(id);renderShell();
      try{await publish({kind:5,tags:[['e',id],['k',String(note.kind)]],content:''})}catch(_){}
    }
    function closeComposer(){clearTimeout(composePreviewTimer);composer=null;renderComposer()}
    // nostr.build authenticates uploads with an ephemeral NIP-98 event.
    async function uploadImage(file){
      var url='https://nostr.build/api/v2/upload/files';
      var auth=await finalizeEvent({kind:27235,tags:[['u',url],['method','POST']],content:''},privBytes);
      var form=new FormData();
      form.append('file',file);
      return fetch(url,{method:'POST',headers:{Authorization:'Nostr '+btoa(JSON.stringify(auth))},body:form})
        .then(function(res){if(!res.ok)throw new Error('upload_failed');return res.json()})
        .then(function(data){
          var url=data&&data.data&&data.data[0]&&(data.data[0].url||data.data[0].original_url);
          if(!url)throw new Error('upload_failed');
          return url;
        });
    }
    // ---- Zaps (NIP-57) ----
    // A receipt is believed only when it is signed by the key the recipient's own
    // Lightning address publishes for zaps (anyone can sign a made-up receipt, but
    // only that server can sign this one), its zap request is signed by the sender
    // and addressed to the recipient, and the amount asked for is the amount of the
    // invoice. Some wallet servers do not tie the invoice to the request by its
    // description hash, so that hash is not required.
    var zapServerKeys={};
    function zapServerKey(recipient){
      if(zapServerKeys[recipient])return zapServerKeys[recipient];
      zapServerKeys[recipient]=(async function(){
        for(var i=0;i<6&&!(profileCache[recipient]&&profileCache[recipient].lud16);i++){ensureProfile(recipient);await new Promise(function(r){setTimeout(r,700)})}
        var addr=profileCache[recipient]&&profileCache[recipient].lud16;
        if(!addr)return null;
        var info=await lnurlPayInfo(addr);
        return info.allowsNostr&&/^[0-9a-f]{64}$/i.test(info.nostrPubkey||'')?String(info.nostrPubkey).toLowerCase():null;
      })().catch(function(){return null});
      zapServerKeys[recipient].then(function(k){if(!k)delete zapServerKeys[recipient]});
      return zapServerKeys[recipient];
    }
    async function parseZapReceipt(ev){
      try{
        var desc=(tagsOf(ev,'description')[0]||[])[1],bolt=(tagsOf(ev,'bolt11')[0]||[])[1];
        if(!desc||!bolt||ev.kind!==9735||!(await verifyEvent(ev)))return null;
        var inv=bolt11Parse(bolt);
        if(!inv||!inv.msats)return null;
        var req=JSON.parse(desc);
        if(!req||req.kind!==9734||!(await verifyEvent(req)))return null;
        var to=(tagsOf(ev,'p')[0]||[])[1];
        if(!to||to!==(tagsOf(req,'p')[0]||[])[1])return null;
        var asked=Number((tagsOf(req,'amount')[0]||[])[1]);
        if(asked&&asked!==inv.msats)return null;
        var serverKey=await zapServerKey(to);
        if(!serverKey||serverKey!==String(ev.pubkey).toLowerCase())return null;
        return{sender:req.pubkey,recipient:to,sats:Math.floor(inv.msats/1000),comment:String(req.content||'').slice(0,300),reqId:req.id};
      }catch(_){return null}
    }
    // Count one receipt towards a post, once however many relays repeat it.
    function countZap(target,ev){
      var s=statOf(target);
      if(s.zapSeen[ev.id])return;
      s.zapSeen[ev.id]=1;
      parseZapReceipt(ev).then(function(z){
        if(!z||!key)return;
        var n=noteCache[target];
        if(n&&n.pubkey!==z.recipient)return;
        s.zaps++;s.sats+=z.sats;
        if(z.sender===pubHex)myZaps[target]=1;
        scheduleRender();
      });
    }
    function zapPresets(){
      var list=_langPrefs.zap_presets;
      return Array.isArray(list)&&list.length?list:DEFAULT_ZAPS;
    }
    var zapModal=null;
    function closeZap(){
      pool.unsubscribe('zapwatch');
      if(zapModal){zapModal.remove();zapModal=null}
    }
    function openZap(id){
      var note=noteCache[id];
      if(!note||note.pubkey===pubHex)return;
      closeZap();
      var pk=note.pubkey,name=displayName(pk);
      ensureProfile(pk);
      var wrap=document.createElement('div');
      wrap.className='nos-modal nos-zap-modal';
      zapModal=wrap;
      root.appendChild(wrap);
      function frame(inner){
        wrap.innerHTML='<div class="nos-modal-card"><div class="nos-modal-head"><span class="nos-modal-title">⚡ '+esc(t('nos_zap_to',{name:name}))+'</span><button type="button" class="nos-modal-close">✕</button></div>'+inner+'</div>';
        wrap.querySelector('.nos-modal-close').onclick=closeZap;
      }
      var tries=0;
      function begin(){
        if(zapModal!==wrap)return;
        var prof=profileCache[pk];
        if(!prof&&tries++<8){frame('<div class="nos-empty">'+esc(t('nos_loading'))+'</div>');setTimeout(begin,500);return}
        if(!prof||!prof.lud16){frame('<p class="nos-zap-who">'+esc(t('nos_zap_no_lud',{name:name}))+'</p>');return}
        choose(prof.lud16);
      }
      function choose(addr){
        var presets=zapPresets();
        frame('<div class="nos-zap-who">'+esc(addr)+'</div><div class="nos-ai-hint">'+esc(t('nos_zap_pick'))+'</div>'+
          '<div class="nos-zap-chips">'+presets.map(function(pr,i){
            return'<button type="button" class="nos-zap-chip" data-i="'+i+'">⚡ '+esc(Number(pr.sats).toLocaleString())+(pr.msg?' · '+esc(pr.msg):'')+'</button>';
          }).join('')+'</div>'+
          '<label class="nos-zap-who">'+esc(t('nos_zap_amount'))+'</label><input class="nos-zap-sats" type="number" min="1" step="1" inputmode="numeric">'+
          '<label class="nos-zap-who">'+esc(t('nos_zap_message'))+'</label><input class="nos-zap-msg" type="text" maxlength="140">'+
          '<div class="nos-error nos-zap-error"></div>'+
          '<div class="nos-modal-foot"><button type="button" class="nos-modal-cancel">'+esc(t('nos_cancel'))+'</button><button type="button" class="primary nos-zap-go">'+esc(t('nos_zap_prepare'))+'</button></div>');
        var satsEl=wrap.querySelector('.nos-zap-sats'),msgEl=wrap.querySelector('.nos-zap-msg'),errEl=wrap.querySelector('.nos-zap-error'),go=wrap.querySelector('.nos-zap-go');
        wrap.querySelector('.nos-modal-cancel').onclick=closeZap;
        wrap.querySelectorAll('.nos-zap-chip').forEach(function(chip){
          chip.onclick=function(){
            var pr=presets[Number(chip.dataset.i)];
            satsEl.value=pr.sats;msgEl.value=pr.msg||'';
            wrap.querySelectorAll('.nos-zap-chip').forEach(function(c){c.classList.toggle('on',c===chip)});
            errEl.textContent='';
          };
        });
        satsEl.oninput=function(){wrap.querySelectorAll('.nos-zap-chip.on').forEach(function(c){c.classList.remove('on')})};
        go.onclick=async function(){
          var sats=Math.floor(Number(satsEl.value)),msg=msgEl.value.trim();
          if(!(sats>=1)){errEl.textContent=t('nos_zap_amount');return}
          go.disabled=true;errEl.textContent='';
          try{
            var info=await lnurlPayInfo(addr),msats=sats*1000;
            if(!info.allowsNostr||!/^[0-9a-f]{64}$/i.test(info.nostrPubkey||'')){errEl.textContent=t('nos_zap_unsupported');go.disabled=false;return}
            if(msats<info.minSendable||msats>info.maxSendable){
              errEl.textContent=t('nos_zap_range',{min:Math.ceil(info.minSendable/1000).toLocaleString(),max:Math.floor(info.maxSendable/1000).toLocaleString()});go.disabled=false;return;
            }
            var relayList=[];readUrls().concat(writeUrls()).forEach(function(u){if(relayList.indexOf(u)<0)relayList.push(u)});
            var req=await finalizeEvent({kind:9734,tags:[['relays'].concat(relayList.slice(0,6)),['amount',String(msats)],['p',pk],['e',id]],content:msg},privBytes);
            var json=JSON.stringify(req);
            var pr=await lnurlInvoice(info,msats,json);
            var inv=bolt11Parse(pr);
            if(!inv||inv.msats!==msats){errEl.textContent=t('nos_zap_bad_invoice');go.disabled=false;return}
            if(zapModal!==wrap)return;
            invoice(pr,sats,req);
          }catch(_){
            if(zapModal!==wrap)return;
            errEl.textContent=t('nos_zap_error');go.disabled=false;
          }
        };
      }
      function invoice(pr,sats,req){
        frame('<div class="nos-zap-amount">⚡ '+esc(sats.toLocaleString())+' sats</div>'+
          '<div class="nos-zap-qr"></div><div class="nos-ai-hint" style="text-align:center">'+esc(t('nos_zap_scan'))+'</div>'+
          '<div class="nos-zap-actions"><a class="primary" href="lightning:'+esc(pr)+'">'+esc(t('nos_zap_open'))+'</a><button type="button" class="nos-zap-copy">'+esc(t('nos_zap_copy'))+'</button></div>'+
          '<div class="nos-zap-status">'+esc(t('nos_zap_waiting'))+'</div>');
        var status=wrap.querySelector('.nos-zap-status');
        loadQr().then(function(){
          if(zapModal!==wrap)return;
          var q=window.qrcode(0,'L');q.addData(pr.toUpperCase());q.make();
          var box=wrap.querySelector('.nos-zap-qr');
          if(box)box.innerHTML=q.createSvgTag(4,0);
        }).catch(function(){});
        wrap.querySelector('.nos-zap-copy').onclick=function(){
          function done(){showToast(t('nos_zap_copied'))}
          if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(pr).then(done,function(){});
          else{var ta=document.createElement('textarea');ta.value=pr;document.body.appendChild(ta);ta.select();try{document.execCommand('copy');done()}catch(_){}ta.remove()}
        };
        // The receipt arrives from the relays once the wallet has paid the invoice.
        pool.unsubscribe('zapwatch');
        pool.subscribe(readUrls(),'zapwatch',[{kinds:[9735],'#p':[pk],since:Math.floor(Date.now()/1000)-60}],function(ev){
          if(zapModal!==wrap||(ev.tags||[]).every(function(tg){return tg[0]!=='description'||String(tg[1]).indexOf(req.id)<0}))return;
          parseZapReceipt(ev).then(function(z){
            if(!z||z.reqId!==req.id||zapModal!==wrap)return;
            countZap(id,ev);
            status.textContent='✅ '+t('nos_zap_sent');status.className='nos-zap-status ok';
            setTimeout(function(){if(zapModal===wrap)closeZap()},2500);
          });
        });
      }
      begin();
    }

    function renderComposer(){
      var existing=root.querySelector('.nos-modal');
      if(existing)existing.remove();
      if(!composer)return;
      var target=composer.id&&composer.mode!=='edit'?noteCache[composer.id]:null;
      var title=composer.mode==='edit'?t('nos_edit'):composer.mode==='reply'?t('nos_reply'):composer.mode==='quote'?t('nos_quote'):t('nos_new_note');
      var wrap=document.createElement('div');
      wrap.className='nos-modal';
      wrap.innerHTML='<div class="nos-modal-card"><div class="nos-modal-head"><span class="nos-modal-title">'+esc(title)+'</span><button type="button" class="nos-modal-close">✕</button></div>'+
        (target?'<div class="nos-modal-ctx">'+noteCardHtml({key:'ctx',noteId:target.id,boost:null},{flat:true,actions:false,clickable:false})+'</div>':'')+
        '<textarea class="nos-modal-input"'+(composer.suggesting?' disabled':'')+' placeholder="'+esc(composer.mode==='reply'?t('nos_reply_placeholder'):t('nos_compose_placeholder'))+'"></textarea>'+
        '<div class="nos-compose-preview"></div>'+
        (composer.images.length?'<div class="nos-modal-images">'+composer.images.map(function(url,i){
          return'<div class="nos-modal-image"><img src="'+esc(url)+'"><button type="button" class="nos-modal-image-del" data-i="'+i+'">✕</button></div>';
        }).join('')+'</div>':'')+
        (composer.suggesting?'<div class="nos-ai-hint">'+esc(t('nos_ai_thinking'))+'</div>':'')+
        '<div class="nos-modal-foot"><input type="file" accept="image/*" class="nos-modal-file" hidden>'+
        '<button type="button" class="nos-modal-image-btn" title="'+esc(t('nos_attach_image'))+'"'+(composer.uploading||composer.suggesting?' disabled':'')+'>'+(composer.uploading?'…':'🖼')+'</button>'+
        (deeplEnabled?'<button type="button" class="nos-modal-image-btn nos-modal-translate" title="'+esc(t('nos_translate'))+'"'+(composer.translating||composer.suggesting?' disabled':'')+'>'+(composer.translating?'…':'🌐')+'</button>':'')+
        '<span style="flex:1"></span>'+
        '<button type="button" class="nos-modal-cancel">'+esc(t('nos_cancel'))+'</button><button type="button" class="primary nos-modal-send"'+(composer.busy||composer.suggesting||composer.uploading?' disabled':'')+'>'+esc(composer.busy?t('nos_sending'):t('nos_publish'))+'</button></div></div>';
      root.appendChild(wrap);
      var textarea=wrap.querySelector('.nos-modal-input');
      textarea.value=composer.text||'';
      // Seeing the card before publishing is the point: a link that will render as
      // a bare address, or with somebody else's stale title, is worth knowing
      // about while it can still be changed. Only this one box is rewritten —
      // re-rendering the composer would take the caret with it — and the lookup
      // waits for a pause in typing so a half-typed address is not fetched.
      function refreshComposePreview(){
        var box=wrap.querySelector('.nos-compose-preview');
        if(!box)return;
        var url=firstPlainLink(textarea.value);
        if(!url){box.innerHTML='';return}
        box.innerHTML=previewHtml(url);
        bindImages(box);
        requestPreview(url).then(function(){
          if(!wrap.parentNode||firstPlainLink(textarea.value)!==url)return;
          box.innerHTML=previewHtml(url);
          bindImages(box);
        });
      }
      textarea.oninput=function(){
        composer.text=textarea.value;
        clearTimeout(composePreviewTimer);
        composePreviewTimer=setTimeout(refreshComposePreview,700);
      };
      refreshComposePreview();
      wrap.querySelector('.nos-modal-close').onclick=closeComposer;
      wrap.querySelector('.nos-modal-cancel').onclick=closeComposer;
      wrap.onclick=function(e){if(e.target===wrap)closeComposer()};
      wrap.querySelectorAll('.nos-modal-image-del').forEach(function(btn){
        btn.onclick=function(){composer.text=textarea.value;composer.images.splice(Number(btn.dataset.i),1);renderComposer()};
      });
      var fileInput=wrap.querySelector('.nos-modal-file');
      wrap.querySelector('.nos-modal-image-btn').onclick=function(){fileInput.click()};
      var translateBtn=wrap.querySelector('.nos-modal-translate');
      if(translateBtn)translateBtn.onclick=async function(){
        var text=textarea.value.trim();
        if(!text)return;
        composer.text=text;composer.translating=true;composer.error='';renderComposer();
        try{
          var out=await deeplTranslate(text,publishTargetLang());
          composer.text=out;composer.translating=false;
          renderComposer();
        }catch(_){composer.translating=false;renderComposer();showToast(t('nos_translate_error'))}
      };
      async function attachImage(file){
        if(!file||!composer||composer.uploading)return;
        var current=composer;
        var focused=document.activeElement===textarea, start=textarea.selectionStart, end=textarea.selectionEnd;
        current.text=textarea.value;current.uploading=true;current.error='';renderComposer();
        if(focused){var input=root.querySelector('.nos-modal-input');input.focus();input.setSelectionRange(start,end)}
        try{
          var url=await uploadImage(file);
          current.images.push(url);
        }catch(_){showToast(t('nos_upload_error'))}
        current.uploading=false;
        if(composer===current){
          var input=root.querySelector('.nos-modal-input');
          focused=document.activeElement===input;
          if(focused){start=input.selectionStart;end=input.selectionEnd}
          renderComposer();
          if(focused){input=root.querySelector('.nos-modal-input');input.focus();input.setSelectionRange(start,end)}
        }
      }
      fileInput.onchange=function(){
        attachImage(fileInput.files&&fileInput.files[0]);
      };
      textarea.onpaste=function(e){
        var items=e.clipboardData&&e.clipboardData.items;
        if(!items)return;
        var image=null;
        for(var i=0;i<items.length;i++){
          if(items[i].kind==='file'&&items[i].type.indexOf('image/')===0){image=items[i].getAsFile();if(image)break}
        }
        if(!image)return;
        e.preventDefault();
        var text=e.clipboardData.getData('text/plain');
        if(text){textarea.setRangeText(text,textarea.selectionStart,textarea.selectionEnd,'end');textarea.oninput()}
        attachImage(image);
      };
      wrap.querySelector('.nos-modal-send').onclick=async function(){
        if(composer.suggesting)return;
        var text=textarea.value.trim();
        if(composer.images.length)text=(text?text+'\n\n':'')+composer.images.join('\n');
        if(!text&&composer.mode!=='quote')return;
        composer.text=textarea.value.trim();composer.busy=true;composer.error='';renderComposer();
        var progress=publishingToast(writeUrls().length);
        try{
          var reopen=false,old=composer.mode==='edit'?noteCache[composer.id]:null;
          var ev=await publish(old?{kind:1,tags:old.tags||[],content:text}:composeEvent(composer.mode,text,target),function(ok,done){progress.update(ok,done)});
          ev._done.then(function(result){progress.finish(result)});
          if(old){
            var wasOpen=stack.length&&stack[stack.length-1].type==='thread'&&stack[stack.length-1].id===old.id;
            retireNote(old.id);
            try{await publish({kind:5,tags:[['e',old.id],['k','1']],content:''})}catch(_){}
            reopen=wasOpen;
          }
          if(composer.mode==='reply'&&target)statOf(target.id).replies++;
          noteCache[ev.id]=ev;
          if(reopen)openThread(ev.id);
          if(!stack.length&&activeTab==='feed'&&feedMode!=='following')pushItem({key:ev.id,noteId:ev.id,boost:null,at:ev.created_at});
          var top=stack[stack.length-1];
          if(top&&top.type==='thread'&&composer.mode==='reply'&&target&&target.id===top.id&&!threadKeys[ev.id]){threadKeys[ev.id]=1;threadReplies.push(ev)}
          composer=null;renderComposer();renderBody();
        }catch(_){progress.remove();composer.busy=false;renderComposer();showToast(t('nos_publish_error'))}
      };
      setTimeout(function(){textarea.focus()},30);
    }
    // NIP-10 wants both ends of the conversation: the root so every client can
    // group the thread, and the direct parent so the reply lands under the right
    // note. A quote is a plain note that names what it points at, both as a q tag
    // for clients that read tags and as a nostr: URI for those that read text.
    function composeEvent(mode,text,target){
      if(mode==='reply'&&target){
        var rootId=rootTarget(target)||target.id;
        var tags=[['e',rootId,'','root']];
        if(rootId!==target.id)tags.push(['e',target.id,'','reply']);
        tags.push(['p',target.pubkey]);
        return{kind:1,tags:tags,content:text};
      }
      if(mode==='quote'&&target){
        var ref=noteEncode(target.id);
        return{kind:1,tags:[['q',target.id,'',target.pubkey],['p',target.pubkey]],content:(text?text+'\n\n':'')+'nostr:'+ref};
      }
      return{kind:1,tags:[],content:text};
    }

    // ---- rendering ----
    function displayName(pk){
      var p=profileCache[pk];
      if(p&&p.name)return p.name;
      var npub=npubEncode(pk);
      return npub?shortNpub(npub):pk.slice(0,10)+'…';
    }
    function avatarHtml(pk,large){
      var p=profileCache[pk],initial=(displayName(pk)||'?').charAt(0).toUpperCase();
      // The fallback initial is always in the DOM underneath: a picture URL that
      // 404s or refuses hotlinking then degrades to a letter instead of a broken
      // image icon, which is what a missing avatar looked like before.
      return'<span class="nos-avatar-wrap'+(large?' nos-lg':'')+'" data-user="'+esc(pk)+'"><span class="nos-avatar">'+esc(initial)+'</span>'+
        (p&&p.picture?'<img class="nos-avatar nos-avatar-img" src="'+esc(p.picture)+'" referrerpolicy="no-referrer" loading="lazy" alt="">':'')+'</span>';
    }
    var URL_RE=/https?:\/\/[^\s<]+[^\s<.,:;!?)'"]/g;
    var NOSTR_RE=/nostr:(n(?:pub|profile|ote|event)1[023456789acdefghjklmnpqrstuvwxyz]+)/g;
    var IMG_EXT_RE=/\.(png|jpe?g|gif|webp|avif)$/i;
    // Nostr has no media type on a link — an attachment is just a URL in the
    // text, so the extension is all there is to go on. Video was falling through
    // to the plain-link branch and an .mp4 someone posted read as a bare address.
    // preload="metadata" is what keeps that affordable: a feed can hold a dozen
    // clips and the browser fetches a few hundred bytes of header for each
    // instead of the files themselves.
    var VID_EXT_RE=/\.(mp4|webm|ogv|ogm|m4v|mov)$/i;
    var AUD_EXT_RE=/\.(mp3|oga|wav|m4a|flac)$/i;
    function renderContent(text,skipId){
      var out=esc(text).replace(URL_RE,function(url){
        var plain=url.replace(/&amp;/g,'&').replace(/&#39;/g,"'").replace(/&quot;/g,'"');
        var noQuery=plain.split(/[?#]/)[0];
        if(IMG_EXT_RE.test(noQuery))return'<a href="'+url+'" class="nos-embed-link"><img class="nos-embed-img" src="'+url+'" loading="lazy" referrerpolicy="no-referrer"></a>';
        if(VID_EXT_RE.test(noQuery))return'<video class="nos-embed-video" src="'+url+'" controls playsinline preload="metadata"></video>';
        if(AUD_EXT_RE.test(noQuery))return'<audio class="nos-embed-audio" src="'+url+'" controls preload="metadata"></audio>';
        return'<a href="'+url+'" target="_blank" rel="noopener noreferrer">'+url+'</a>';
      });
      return out.replace(NOSTR_RE,function(whole,ref){
        var id=refToId(ref);
        // The quoted note is rendered as a card below, so its URI is noise in the text.
        if(id)return id===skipId?'':'<span class="nos-mention" data-note="'+esc(id)+'">'+esc(t('nos_quoted_note'))+'</span>';
        var pk=refToPubkey(ref);
        if(pk){ensureProfile(pk);return'<span class="nos-mention" data-user="'+esc(pk)+'">@'+esc(displayName(pk))+'</span>'}
        return whole;
      });
    }
    // A link with nothing else to it is the one case worth previewing: an image,
    // a clip or an audio file already renders as itself, and a quoted note gets
    // its own card. Only the first such link is previewed — a note that is a list
    // of ten links should stay a list, not turn into ten cards.
    function firstPlainLink(text){
      var found=String(text||'').match(URL_RE);
      if(!found)return'';
      for(var i=0;i<found.length;i++){
        var noQuery=found[i].split(/[?#]/)[0];
        if(IMG_EXT_RE.test(noQuery)||VID_EXT_RE.test(noQuery)||AUD_EXT_RE.test(noQuery))continue;
        return found[i];
      }
      return'';
    }
    var previewCache={},previewInFlight={};
    // false means "asked, and there is nothing to show" — cached exactly like a
    // real answer so a link without Open Graph tags is not re-requested forever.
    function requestPreview(url){
      if(!url)return Promise.resolve(false);
      if(previewCache[url]!==undefined)return Promise.resolve(previewCache[url]);
      if(previewInFlight[url])return previewInFlight[url];
      previewInFlight[url]=fetch(API+'/preview?url='+encodeURIComponent(url),{headers:{'X-Pub-Token':token}})
        .then(function(r){return r.ok?r.json():null})
        .catch(function(){return null})
        .then(function(d){
          delete previewInFlight[url];
          previewCache[url]=(d&&(d.title||d.image))?d:false;
          scheduleRender();
          return previewCache[url];
        });
      return previewInFlight[url];
    }
    function previewHtml(url){
      if(!url)return'';
      var d=previewCache[url];
      // Not asked for yet: leave a marker the observer can pick up when the card
      // actually reaches the screen.
      if(d===undefined)return'<div class="nos-preview" data-preview-url="'+esc(url)+'"></div>';
      if(!d)return'';
      return'<a class="nos-preview-card" href="'+esc(url)+'" target="_blank" rel="noopener noreferrer">'+
        (d.image?'<img class="nos-preview-img" src="'+esc(d.image)+'" loading="lazy" referrerpolicy="no-referrer" alt="">':'')+
        '<span class="nos-preview-text">'+
          (d.site?'<span class="nos-preview-site">'+esc(d.site)+'</span>':'')+
          (d.title?'<span class="nos-preview-title">'+esc(d.title)+'</span>':'')+
          (d.description?'<span class="nos-preview-desc">'+esc(d.description)+'</span>':'')+
        '</span></a>';
    }
    // Discover can hold a hundred notes. Fetching a preview for every link in
    // them the moment they render would have the server open a hundred pages for
    // one scroll the reader may never reach the bottom of, so a preview is only
    // asked for once its card is near the screen.
    var previewObserver=('IntersectionObserver'in window)?new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(!entry.isIntersecting)return;
        previewObserver.unobserve(entry.target);
        requestPreview(entry.target.dataset.previewUrl);
      });
    },{rootMargin:'250px'}):null;
    // ---- Ask AI about a post (premium) ----
    // A chat is opened per post and lives only in this modal. The server keeps the
    // transcript for the History tab, but a closed chat is read-only there: every
    // new chat is a fresh question to mvmAI that carries just that post.
    function aiBalanceHtml(){
      return aiCredits&&aiCredits.message>0?'<span class="nos-ai-credits" title="'+esc(t('nos_ai_credits'))+'">💳 '+esc(aiCredits.balance)+'</span>':'';
    }
    function aiErrorText(code){
      return t(code==='no_credits'?'nos_ai_err_credits':code==='mvmai_unavailable'||code==='mvmai_disabled'?'nos_ai_err_unavailable':code==='chat_full'?'nos_ai_err_full':'nos_ai_err');
    }
    async function suggestAiComment(id){
      var note=noteCache[id];if(!note||composer)return;
      openComposer('reply',id,true);
      var draft=composer;
      try{
        var d=await api('/ai/chat',{method:'POST',body:JSON.stringify({mode:'comment',
          note:{id:note.id,author:displayName(note.pubkey),content:note.content,created_at:note.created_at},
          lang:translateTargetLang()})});
        if(d.error||!d.text)throw new Error(d.error||'error');
        if(d.balance!=null&&aiCredits)aiCredits.balance=d.balance;
        if(destroyed||composer!==draft)return;
        draft.text=d.text;
      }catch(e){
        if(destroyed||composer!==draft)return;
        draft.error=aiErrorText(e.message);
      }
      draft.suggesting=false;
      if(!destroyed&&composer===draft)renderComposer();
    }
    function openAiChat(mode,id){
      var note=noteCache[id];if(!note)return;
      ensureProfile(note.pubkey);
      aiChat={mode:mode,note:{id:note.id,author:displayName(note.pubkey),content:note.content,created_at:note.created_at},
              chatId:null,messages:[],busy:false,error:'',draft:'',readonly:false};
      renderAiChat();
      if(mode==='explain')sendAiTurn('');
    }
    function openAiHistoryChat(id){
      fetch(API+'/ai/history/'+encodeURIComponent(id),{headers:{'X-Pub-Token':token}}).then(function(r){return r.ok?r.json():null}).then(function(c){
        if(!c)return;
        aiChat={mode:c.mode,note:{id:c.note_id,author:c.author,content:c.note,created_at:c.note_at},chatId:c.id,
                messages:c.messages,busy:false,error:'',draft:'',readonly:true};
        renderAiChat();
      }).catch(function(){});
    }
    function closeAiChat(){
      aiChat=null;aiHistory=null;
      var m=root.querySelector('.nos-ai-modal');if(m)m.remove();
      if(activeTab==='profile'&&!stack.length)renderBody();
    }
    async function sendAiTurn(text){
      var chat=aiChat;if(!chat||chat.busy)return;
      if(text)chat.messages.push({role:'user',content:text});
      chat.busy=true;chat.error='';renderAiChat();
      try{
        var r=await fetch(API+'/ai/chat',{method:'POST',headers:{'X-Pub-Token':token,'Content-Type':'application/json'},
          body:JSON.stringify({chat_id:chat.chatId,mode:chat.mode,note:chat.note,text:text||null,lang:translateTargetLang()})});
        var d=await r.json().catch(function(){return{}});
        if(!r.ok||d.error)throw new Error(d.error||'error');
        chat.chatId=d.chat_id;
        chat.messages.push({role:'assistant',content:d.text});
        if(d.balance!=null&&aiCredits)aiCredits.balance=d.balance;
      }catch(e){
        // The question that got no answer goes back into the box to be sent again.
        if(text){chat.messages.pop();chat.draft=text}
        showToast(aiErrorText(e.message));
      }
      chat.busy=false;
      if(aiChat===chat)renderAiChat();
    }
    // A chat is short on purpose: one answer, either the explanation or the reply to one question.
    // Anything more is carried over into a real mvmAI chat.
    function aiMaxAnswers(mode){return 1}
    function openMvmai(id){
      try{localStorage.setItem('mvmai_open_chat',id)}catch(e){}
      if(opts.isDesktop&&window.mvmOS&&window.mvmOS.openApp){
        window.mvmOS.openApp('mvmai');
        window.dispatchEvent(new CustomEvent('mvmai-open-chat',{detail:id}));
      }else location.href='/pub/mvmai/';
    }
    async function discussAi(){
      var c=aiChat;if(!c||!c.chatId||c.busy)return;
      c.busy=true;c.error='';renderAiChat();
      try{
        var r=await fetch(API+'/ai/discuss',{method:'POST',headers:{'X-Pub-Token':token,'Content-Type':'application/json'},
          body:JSON.stringify({chat_id:c.chatId,lang:translateTargetLang()})});
        var d=await r.json().catch(function(){return{}});
        if(!r.ok||!d.session_id)throw new Error(d.error||'error');
        closeAiChat();openMvmai(d.session_id);return;
      }catch(e){showToast(t('nos_ai_discuss_err'))}
      c.busy=false;
      if(aiChat===c)renderAiChat();
    }
    function renderAiChat(){
      var old=root.querySelector('.nos-ai-modal');
      if(old)old.remove();
      if(!aiChat)return;
      var c=aiChat,n=c.note;
      var answers=c.messages.filter(function(m){return m.role==='assistant'}).length;
      var done=c.readonly||answers>=aiMaxAnswers(c.mode);
      var wrap=document.createElement('div');
      wrap.className='nos-modal nos-ai-modal';
      wrap.innerHTML='<div class="nos-modal-card nos-ai-card"><div class="nos-modal-head"><span class="nos-modal-title">✨ '+esc(t(c.mode==='question'?'nos_ai_ask':'nos_ai_explain'))+'</span>'+aiBalanceHtml()+'<button type="button" class="nos-modal-close">✕</button></div>'+
        '<div class="nos-quote nos-ai-post"><div class="nos-note-name">'+esc(n.author||'')+'</div><div class="nos-note-content">'+esc(n.content)+'</div></div>'+
        '<div class="nos-ai-log">'+c.messages.map(function(m){
          return'<div class="nos-ai-msg nos-ai-'+(m.role==='user'?'user':'bot')+'">'+esc(m.content)+'</div>';
        }).join('')+(c.busy?'<div class="nos-ai-msg nos-ai-bot nos-ai-wait">'+esc(t('nos_ai_thinking'))+'</div>':'')+
          (!c.messages.length&&!c.busy&&!c.readonly&&c.mode==='question'?'<div class="nos-ai-hint">'+esc(t('nos_ai_ask_hint'))+'</div>':'')+'</div>'+
        (done?''
          :'<div class="nos-ai-foot"><textarea class="nos-ai-input" rows="2" placeholder="'+esc(t('nos_ai_placeholder'))+'"'+(c.busy?' disabled':'')+'></textarea>'+
            '<button type="button" class="primary nos-ai-send"'+(c.busy?' disabled':'')+'>'+esc(t('nos_ai_send'))+'</button></div>')+
        (c.chatId&&answers>0?'<div class="nos-ai-discuss"><button type="button" class="'+(done?'primary ':'')+'nos-ai-discuss-btn"'+(c.busy?' disabled':'')+'>💬 '+esc(t('nos_ai_discuss'))+'</button></div>':'')+
        '</div>';
      root.appendChild(wrap);
      var log=wrap.querySelector('.nos-ai-log');log.scrollTop=log.scrollHeight;
      wrap.querySelector('.nos-modal-close').onclick=closeAiChat;
      wrap.onclick=function(e){if(e.target===wrap)closeAiChat()};
      var dbtn=wrap.querySelector('.nos-ai-discuss-btn');if(dbtn)dbtn.onclick=discussAi;
      var input=wrap.querySelector('.nos-ai-input');
      if(input){
        input.value=c.draft||'';
        input.oninput=function(){c.draft=input.value};
        var send=function(){
          var text=input.value.trim();
          if(!text||c.busy)return;
          c.draft='';input.value='';sendAiTurn(text);
        };
        wrap.querySelector('.nos-ai-send').onclick=send;
        input.onkeydown=function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}};
        if(!c.busy)input.focus();
      }
    }
    function loadAiHistory(){
      if(aiHistory!==null||aiHistoryBusy)return;
      aiHistoryBusy=true;
      fetch(API+'/ai/history',{headers:{'X-Pub-Token':token}}).then(function(r){return r.ok?r.json():{chats:[]}}).then(function(d){
        aiHistory=d.chats||[];aiHistoryBusy=false;scheduleRender();
      }).catch(function(){aiHistory=[];aiHistoryBusy=false;scheduleRender()});
    }
    function aiHistoryHtml(){
      if(aiHistory===null)return'<div class="nos-empty">'+esc(t('nos_loading'))+'</div>';
      if(!aiHistory.length)return'<div class="nos-empty">'+esc(t('nos_ai_history_empty'))+'</div>';
      return aiHistory.map(function(c){
        return'<div class="nos-note nos-flat nos-ai-item" data-ai-chat="'+esc(c.id)+'"><div class="nos-note-head"><div class="nos-note-who"><span class="nos-note-name">'+(c.mode==='question'?'❓ ':'💡 ')+esc(c.author||'')+'</span>'+
          '<span class="nos-note-time">'+esc(formatTime(c.at))+' · '+esc(c.count)+'</span></div></div>'+
          '<div class="nos-note-content nos-ai-excerpt">'+esc(c.note)+'</div></div>';
      }).join('');
    }
    function actionsHtml(id){
      var s=stats[id]||{replies:0,reposts:0,likes:0,sats:0};
      // A note that trended did so across the whole network, while `stats` only
      // ever sees what the user's own handful of relays kept. Showing the larger
      // of the two keeps the number from collapsing to a fraction of the truth
      // the moment the local count starts coming in.
      var net=netStats[id];
      if(net)s={replies:Math.max(s.replies,net.replies),reposts:Math.max(s.reposts,net.reposts),
                likes:Math.max(s.likes,net.likes),sats:s.sats||0};
      var liked=!!myReactions[id],reposted=!!myReposts[id];
      var own=!!(noteCache[id]&&noteCache[id].pubkey===pubHex&&noteCache[id].kind===1);
      var zappable=!!(noteCache[id]&&noteCache[id].pubkey!==pubHex&&noteCache[id].kind===1&&profileCache[noteCache[id].pubkey]&&profileCache[noteCache[id].pubkey].lud16);
      var tr=translations[id];
      var translateLabel=tr&&tr.status==='done'?(tr.shown?t('nos_show_original'):t('nos_translate')):tr&&tr.status==='loading'?t('nos_translating'):t('nos_translate');
      return'<div class="nos-note-actions">'+
        '<button type="button" class="nos-act nos-a-reply" data-act="reply" data-id="'+esc(id)+'">💬 '+(s.replies||'')+'</button>'+
        '<button type="button" class="nos-act nos-a-repost'+(reposted?' on':'')+'" data-act="repostmenu" data-id="'+esc(id)+'" title="'+esc(t('nos_repost')+' / '+t('nos_quote'))+'">🔁 '+(s.reposts||'')+'</button>'+
        '<button type="button" class="nos-act nos-a-like'+(liked?' on':'')+'" data-act="like" data-id="'+esc(id)+'" title="'+esc(t('nos_like'))+'">'+(liked?'❤️':'🤍')+' '+(s.likes||'')+'</button>'+
        (zappable?'<button type="button" class="nos-act nos-a-zap'+(myZaps[id]?' on':'')+'" data-act="zap" data-id="'+esc(id)+'" title="'+esc(s.sats?t('nos_zap_total',{n:s.sats.toLocaleString()}):t('nos_zap'))+'" aria-label="'+esc(t('nos_zap'))+'">⚡'+(s.sats?' '+fmtSats(s.sats):'')+'</button>':'')+
        (aiEnabled?'<button type="button" class="nos-act nos-a-ai" data-act="aimenu" data-id="'+esc(id)+'" title="'+esc(t('nos_ai_btn'))+'" aria-label="'+esc(t('nos_ai_btn'))+'">✨</button>':'')+
        (deeplEnabled?'<button type="button" class="nos-act nos-a-translate'+(tr&&tr.status==='done'&&tr.shown?' on':'')+'" data-act="translate" data-id="'+esc(id)+'" title="'+esc(translateLabel)+'" aria-label="'+esc(translateLabel)+'"'+(tr&&tr.status==='loading'?' disabled':'')+'>🌐</button>':'')+
        (own?'<button type="button" class="nos-act nos-a-more" data-act="moremenu" data-id="'+esc(id)+'" title="'+esc(t('nos_more'))+'" aria-label="'+esc(t('nos_more'))+'">⋯</button>':'')+
        '</div>';
    }
    function quoteHtml(id){
      var note=noteCache[id];
      if(!note){ensureNote(id);return'<div class="nos-quote">'+esc(t(noteMissing[id]?'nos_note_unavailable':'nos_loading'))+'</div>'}
      ensureProfile(note.pubkey);
      return'<div class="nos-quote" data-note="'+esc(note.id)+'"><div class="nos-note-head">'+avatarHtml(note.pubkey)+
        '<div class="nos-note-who" data-user="'+esc(note.pubkey)+'"><span class="nos-note-name">'+esc(displayName(note.pubkey))+'</span><span class="nos-note-time">'+esc(formatTime(note.created_at))+'</span></div></div>'+
        '<div class="nos-note-content">'+renderContent(note.content)+'</div></div>';
    }
    function replyOfHtml(parent){
      return'<div class="nos-reply-of-wrap"><div class="nos-reply-of-label">'+esc(t('nos_reply_to'))+'</div>'+quoteHtml(parent)+'</div>';
    }
    function noteCardHtml(item,options){
      options=options||{};
      var note=noteCache[item.noteId];
      var keyAttr=' data-key="'+esc(item.key)+'"';
      if(!note)return'<div class="nos-note'+(options.flat?' nos-flat':'')+'"'+keyAttr+'><div class="nos-empty">'+esc(t('nos_loading'))+'</div></div>';
      var quoted=quotedId(note),parent=replyTarget(note);
      var isSelf=note.pubkey===pubHex,following=contactPubkeys.indexOf(note.pubkey)>=0;
      return'<div class="nos-note'+(options.flat?' nos-flat':'')+'"'+keyAttr+(options.clickable===false?'':' data-note="'+esc(note.id)+'"')+'>'+
        (item.boost?'<div class="nos-boost">🔁 '+esc(t('nos_reposted_by',{name:displayName(item.boost.pubkey)}))+'</div>':'')+
        '<div class="nos-note-head">'+avatarHtml(note.pubkey)+
          '<div class="nos-note-who" data-user="'+esc(note.pubkey)+'"><span class="nos-note-name">'+esc(displayName(note.pubkey))+'</span><span class="nos-note-time">'+esc(formatTime(note.created_at))+'</span></div>'+
          (isSelf||options.follow===false?'':'<button type="button" class="nos-mute-btn nos-a-more" data-act="usermenu" data-pubkey="'+esc(note.pubkey)+'" title="'+esc(t('nos_more'))+'" aria-label="'+esc(t('nos_more'))+'">⋯</button>')+
        '</div>'+
        (parent&&options.showParent!==false?replyOfHtml(parent):'')+
        '<div class="nos-note-content">'+renderContent(note.content,quoted)+'</div>'+
        (quoted?quoteHtml(quoted):previewHtml(firstPlainLink(note.content)))+
        (translations[note.id]&&translations[note.id].shown?'<div class="nos-note-translation">'+
          (translations[note.id].status==='loading'?esc(t('nos_translating')):
           translations[note.id].status==='error'?esc(t('nos_translate_error')):
           esc(translations[note.id].text))+'</div>':'')+
        (options.actions===false?'':actionsHtml(note.id))+
        '</div>';
    }
    function muteBtnHtml(pk,withText){
      var on=isMuted(pk),label=t(on?'nos_unmute':'nos_mute');
      return'<button type="button" class="nos-mute-btn'+(on?' on':'')+'" data-act="mute" data-pubkey="'+esc(pk)+'" title="'+esc(label)+'" aria-label="'+esc(label)+'">'+(on?'🔊':'🔇')+(withText?'<span class="nos-mute-text"> '+esc(label)+'</span>':'')+'</button>';
    }
    function listHtml(items,options){
      if(!options.showMuted)items=items.filter(visibleFeedItem);
      return items.map(function(item){return noteCardHtml(item,options)}).join('')}
    function visibleFeedItem(item){
      var note=noteCache[item.noteId];
      return!deletedIds[item.noteId]&&!(item.boost&&isMuted(item.boost.pubkey))&&!(note&&isMuted(note.pubkey));
    }

    function barHtml(){
      var back=stack.length?'<button type="button" class="nos-bar-btn nos-back">←</button>':'';
      var unread=unreadCount();
      function modes(){return [['following','nos_mode_following'],['trending','nos_mode_trending'],['discover','nos_mode_discover']].map(function(pair){
        var count=modeCounts[pair[0]];
        return'<button type="button" class="nos-mode'+(activeTab==='feed'&&!stack.length&&feedMode===pair[0]?' active':'')+'" data-mode="'+pair[0]+'" title="'+esc(t(pair[1]))+'" aria-label="'+esc(t(pair[1]))+'"><span class="nos-mode-icon" aria-hidden="true">'+({following:'👥',trending:'🔥',discover:'🧭'}[pair[0]])+'</span><span class="nos-mode-label">'+esc(t(pair[1]))+'</span>'+
          (feedMode!==pair[0]&&count?'<span class="nos-badge">'+(count>99?'99+':count)+'</span>':'')+'</button>';
      }).join('')}
      return'<div class="nos-bar"><div class="nos-bar-head">'+back+
        '<div class="nos-tabs">'+
          '<div class="nos-desktop-modes">'+modes()+'</div>'+
        '</div>'+
        '<button type="button" class="nos-bar-btn nos-new" title="'+esc(t('nos_new_note'))+'" aria-label="'+esc(t('nos_new_note'))+'"><svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10.5" fill="#4e9df5"/><path d="M12 6.5v11M6.5 12h11" stroke="#fff" stroke-width="2.5" stroke-linecap="round"/></svg></button>'+
        '<button type="button" class="nos-bar-btn nos-notifications-btn'+(activeTab==='notifications'&&!stack.length?' active':'')+'" title="'+esc(t('nos_tab_notifications'))+'" aria-label="'+esc(t('nos_tab_notifications'))+'">🔔'+(unread?'<span class="nos-badge">'+(unread>99?'99+':unread)+'</span>':'')+'</button>'+
        '<button type="button" class="nos-bar-btn nos-more-btn'+((activeTab==='relays'||activeTab==='profile'||activeTab==='zaps')&&!stack.length?' active':'')+'" title="'+esc(t('nos_tab_profile'))+'" aria-label="'+esc(t('nos_tab_profile'))+'" aria-haspopup="menu">'+avatarHtml(pubHex)+'</button>'+
        '</div>'+
        '</div>';
    }
    function bindBar(){
      root.querySelectorAll('.nos-tab').forEach(function(btn){btn.onclick=function(){switchTab(btn.dataset.tab)}});
      root.querySelectorAll('.nos-mode').forEach(function(btn){btn.onclick=function(){if(feedMode===btn.dataset.mode){if(activeTab!=='feed'||stack.length)switchTab('feed');return}feedMode=btn.dataset.mode;activeTab='feed';stack=[];try{localStorage.setItem(FEED_MODE_KEY,feedMode)}catch(_){}scrollReset=true;loadFeed();renderShell()}});
      root.querySelector('.nos-new').onclick=function(){openComposer('note')};
      root.querySelector('.nos-notifications-btn').onclick=function(){switchTab('notifications')};
      root.querySelector('.nos-more-btn').onclick=function(e){
        e.stopPropagation();
        var items=identities.map(function(identity){
          var hex=identity.npub===vaultInfo.npub?pubHex:npubDecode(identity.npub);
          if(hex)ensureProfile(hex);
          var label=hex?displayName(hex):shortNpub(identity.npub);
          return [label,function(){if(identity.npub!==vaultInfo.npub)switchIdentity(identity.npub)},{avatar:hex,current:identity.npub===vaultInfo.npub}];
        });
        items.push(['＋ '+t('nos_add_identity'),startAddIdentity]);
        items.push(null);
        items.push(['👤 '+t('nos_tab_profile'),function(){switchTab('profile')}]);
        items.push(['🔍 '+t('nos_search_title'),openSearch]);
        items.push(['⚡ '+t('nos_zaps_title'),function(){switchTab('zaps')}]);
        items.push(['📡 '+t('nos_tab_relays'),function(){switchTab('relays')}]);
        items.push(['🔒 '+t('nos_lock'),lockNow]);
        openActionMenu(e.currentTarget,null,items);
      };
      var back=root.querySelector('.nos-back');
      if(back)back.onclick=popView;
    }
    // Repainting an unread badge used to rebuild the entire widget from scratch.
    // That threw away the .nos-body element itself, and with it the reader's
    // scroll position — a background poll landing while someone was halfway down
    // a post snapped them straight back to the top. It also wiped any open
    // composer, so a reply being typed vanished on the next poll. Only the bar is
    // swapped now; the body element and any modal above it survive untouched.
    function renderShell(){
      if(!key)return;
      var bar=root.querySelector('.nos > .nos-bar');
      if(bar)bar.outerHTML=barHtml();
      else root.innerHTML='<div class="nos">'+barHtml()+'<div class="nos-body"></div></div>';
      bindBar();
      renderBody();
    }
    function switchTab(tab){
      stack=[];
      var prevTab=activeTab;
      activeTab=tab;
      if(tab==='notifications'){if(prevTab!=='notifications'||notifBase===null)notifBase=notifSeen;markNotifSeen()}
      if(tab==='profile'){profileSub='posts';loadUser(pubHex)}
      if(tab==='zaps')loadZaps();
      // Following and Discover keep an open subscription, so they are still
      // current when the reader comes back. Popular has none — the ranking cache
      // answers once and closes. While the feed is on screen the background poll
      // keeps it moving, but the poll stands down whenever something else is, so
      // coming back after a while asks the ranking again. As a refresh, not a
      // reload: what is new arrives behind the pill, and the reader keeps both
      // the list and their place in it.
      if(tab==='feed'&&!feedItems.length)loadFeed();
      else if(tab==='feed'&&feedMode==='trending'&&Date.now()-trendingAt>TRENDING_TTL)fetchTrending(0,true);
      scrollReset=true;
      renderShell();
    }
    // Navigating somewhere new should start at the top; a repaint of the view the
    // reader is already in must not move them. The difference is explicit now
    // that a repaint no longer resets the scroll by destroying the element.
    // The reader's place is a note, not a pixel offset. Every repaint rebuilds the
    // list, so images above the note being read start again at no height, and
    // they, videos and link previews keep resizing as they load — a scrollTop
    // kept as a number then pointed somewhere else and the note slid away. So
    // the first note at the top edge is remembered with its distance from that
    // edge, and after a repaint or any size change the scroll is corrected to
    // put it back. At the very top there is nothing to hold on to: that is where
    // the newest notes belong while the list is still arriving.
    var anchor=null,anchorObserver=('ResizeObserver'in window)?new ResizeObserver(function(){
      var body=root.querySelector('.nos-body');if(body)restoreAnchor(body);
    }):null;
    function captureAnchor(body){
      anchor=null;
      if(body.scrollTop<=0)return;
      var top=body.getBoundingClientRect().top,cards=body.querySelectorAll('.nos-note[data-key]');
      for(var i=0;i<cards.length;i++){
        var r=cards[i].getBoundingClientRect();
        if(r.bottom>top){anchor={key:cards[i].dataset.key,offset:r.top-top};return}
      }
    }
    function restoreAnchor(body){
      if(!anchor)return;
      var cards=body.querySelectorAll('.nos-note[data-key]');
      for(var i=0;i<cards.length;i++){
        if(cards[i].dataset.key!==anchor.key)continue;
        var delta=cards[i].getBoundingClientRect().top-body.getBoundingClientRect().top-anchor.offset;
        if(Math.abs(delta)>=1)body.scrollTop+=delta;
        return;
      }
    }
    function watchAnchor(body){
      body.onscroll=function(){
        captureAnchor(body);
        if(activeTab!=='feed'||stack.length||!feedLoaded||body.scrollHeight-body.scrollTop-body.clientHeight>500)return;
        var available=feedItems.filter(visibleFeedItem).length;
        if(feedVisible<available){feedVisible+=FEED_PAGE_SIZE;scheduleRender()}
        else loadOlderFeed();
      };
      if(!anchorObserver)return;
      anchorObserver.disconnect();
      body.querySelectorAll('.nos-note[data-key]').forEach(function(el){anchorObserver.observe(el)});
    }
    function renderBody(){
      var body=root.querySelector('.nos-body');
      if(!body)return;
      if(scrollReset)anchor=null;
      var scroll=scrollReset?0:body.scrollTop;
      scrollReset=false;
      var view=stack[stack.length-1];
      if(view&&view.type==='thread')renderThread(body,view);
      else if(view&&view.type==='user')renderUser(body,view);
      else if(view&&view.type==='people')renderPeople(body,view);
      else if(view&&view.type==='search')renderSearch(body);
      else if(activeTab==='feed')renderFeed(body);
      else if(activeTab==='notifications')renderNotifications(body);
      else if(activeTab==='profile')renderProfileTab(body);
      else if(activeTab==='zaps')renderZaps(body);
      else if(body.querySelector('.nos-relays'))renderRelayList();
      else renderRelaysTab(body);
      body.scrollTop=scroll;
      restoreAnchor(body);
      watchAnchor(body);
      bindImages(body);
    }
    function bindImages(container){
      container.querySelectorAll('.nos-avatar-img').forEach(function(img){img.onerror=function(){img.style.display='none'}});
      // A preview image that 404s or blocks hotlinking should leave the card's
      // text intact rather than a broken-image box.
      container.querySelectorAll('.nos-preview-img').forEach(function(img){img.onerror=function(){img.remove()}});
      container.querySelectorAll('.nos-preview[data-preview-url]').forEach(function(el){
        if(previewObserver)previewObserver.observe(el);
        else requestPreview(el.dataset.previewUrl);
      });
    }
    // One delegated handler per list beats a listener per button: the lists are
    // re-rendered on every incoming event, and re-binding hundreds of nodes each
    // time is what makes a live feed stutter.
    // A small popup under the pressed button. It is a child of the widget root so
    // it survives list re-renders, and any outside click or scroll closes it.
    function closeActionMenu(){var m=document.querySelector('.nos-menu');if(m)m.remove()}
    function openActionMenu(btn,id,items){
      closeActionMenu();
      var root=btn.closest('.nos');if(!root)return;
      var m=document.createElement('div');m.className='nos-menu';
      items.forEach(function(it){
        if(!it){var separator=document.createElement('div');separator.className='nos-menu-separator';separator.setAttribute('role','separator');m.appendChild(separator);return}
        var b=document.createElement('button');b.type='button';
        if(it[2]){
          b.className='nos-menu-identity';
          if(it[2].avatar)b.insertAdjacentHTML('beforeend',avatarHtml(it[2].avatar));
          var name=document.createElement('span');name.className='nos-menu-identity-name';name.textContent=it[0];b.appendChild(name);
          if(it[2].current){var mark=document.createElement('span');mark.textContent='✓';b.appendChild(mark)}
        }else b.textContent=it[0];
        b.onclick=function(e){e.stopPropagation();closeActionMenu();it[1]()};
        m.appendChild(b);
      });
      var rr=root.getBoundingClientRect(),br=btn.getBoundingClientRect();
      m.style.top=(br.bottom-rr.top+4)+'px';
      m.style.visibility='hidden';
      root.appendChild(m);
      // Fit within both the widget and the visible viewport, including its scrollbar.
      var leftEdge=Math.max(4,4-rr.left),rightEdge=Math.min(root.clientWidth,document.documentElement.clientWidth-rr.left)-4;
      m.style.maxWidth=Math.max(0,rightEdge-leftEdge)+'px';
      m.style.minWidth=Math.min(160,Math.max(0,rightEdge-leftEdge))+'px';
      var menuWidth=m.offsetWidth;
      m.style.left=Math.max(leftEdge,Math.min(br.right-rr.left-menuWidth,rightEdge-menuWidth))+'px';
      // Near the bottom edge the menu used to be cut off by the widget; open it
      // upwards there, or pin it inside the widget when neither side fits.
      var mh=m.offsetHeight,top=br.bottom-rr.top+4;
      if(top+mh>rr.height-4)top=br.top-rr.top-mh-4;
      m.style.top=Math.max(4,Math.min(top,rr.height-mh-4))+'px';
      m.style.visibility='';
      // It is positioned once against the button, so it cannot follow a scrolling
      // list: close it instead of leaving it hanging where the button used to be.
      var sc=root.querySelector('.nos-body');
      if(sc)sc.addEventListener('scroll',closeActionMenu,{once:true,passive:true});
      setTimeout(function(){document.addEventListener('click',closeActionMenu,{once:true})},0);
    }
    function bindList(container){
      container.onclick=function(e){
        var act=e.target.closest('[data-act]');
        if(act){
          e.stopPropagation();
          var id=act.dataset.id,pk=act.dataset.pubkey;
          if(act.dataset.act==='reply')openComposer('reply',id);
          else if(act.dataset.act==='repostmenu')openActionMenu(act,id,[[myReposts[id]?t('nos_unrepost'):t('nos_repost'),function(){toggleRepost(id)}],[t('nos_quote'),function(){openComposer('quote',id)}]]);
          else if(act.dataset.act==='aimenu')openActionMenu(act,id,[['💡 '+t('nos_ai_explain'),function(){openAiChat('explain',id)}],['❓ '+t('nos_ai_ask'),function(){openAiChat('question',id)}],['✍️ '+t('nos_ai_comment'),function(){suggestAiComment(id)}]]);
          else if(act.dataset.act==='moremenu')openActionMenu(act,id,[['✏️ '+t('nos_edit'),function(){openComposer('edit',id)}],['🗑 '+t('nos_delete'),function(){deleteNote(id)}]]);
          else if(act.dataset.act==='like')toggleLike(id);
          else if(act.dataset.act==='zap')openZap(id);
          else if(act.dataset.act==='follow'||act.dataset.act==='unfollow')toggleFollow(pk);
          else if(act.dataset.act==='mute')toggleMute(pk);
          else if(act.dataset.act==='usermenu')openActionMenu(act,id,[[(contactPubkeys.indexOf(pk)>=0?'➖ ':'➕ ')+t(contactPubkeys.indexOf(pk)>=0?'nos_unfollow':'nos_follow'),function(){toggleFollow(pk)}],[(isMuted(pk)?'🔊 ':'🔇 ')+t(isMuted(pk)?'nos_unmute':'nos_mute'),function(){toggleMute(pk)}]]);
          else if(act.dataset.act==='translate')translateNote(id);
          return;
        }
        // A note is clickable as a whole, so without this the play button, the
        // seek bar and the volume slider all opened the thread instead.
        if(e.target.closest('a,video,audio'))return;
        var user=e.target.closest('[data-user]');
        if(user){e.stopPropagation();openUser(user.dataset.user);return}
        var note=e.target.closest('[data-note]');
        if(note)openThread(note.dataset.note);
      };
    }
    function pendingHtml(){
      if(!pendingItems.length)return'';
      var seen={},authors=[];
      for(var i=pendingItems.length-1;i>=0&&authors.length<3;i--){
        var pk=pendingItems[i].boost?pendingItems[i].boost.pubkey:(noteCache[pendingItems[i].noteId]||{}).pubkey;
        if(pk&&!seen[pk]){seen[pk]=1;authors.push(pk)}
      }
      return'<div class="nos-newposts-bar"><button type="button" class="nos-newposts">'+
        '<span class="nos-newposts-avatars">'+authors.map(function(pk){return avatarHtml(pk)}).join('')+'</span>'+
        esc(t('nos_new_posts',{n:pendingItems.length}))+'</button></div>';
    }
    // Update existing cards in place so background metadata and counter updates
    // do not discard loaded media or change the reader's position.
    function patchFeedNode(oldNode,newNode){
      if(oldNode.nodeType!==newNode.nodeType||oldNode.nodeName!==newNode.nodeName){oldNode.replaceWith(newNode.cloneNode(true));return}
      if(oldNode.nodeType===3){if(oldNode.nodeValue!==newNode.nodeValue)oldNode.nodeValue=newNode.nodeValue;return}
      if(oldNode.nodeType!==1)return;
      Array.from(oldNode.attributes).forEach(function(a){if(!newNode.hasAttribute(a.name))oldNode.removeAttribute(a.name)});
      Array.from(newNode.attributes).forEach(function(a){if(oldNode.getAttribute(a.name)!==a.value)oldNode.setAttribute(a.name,a.value)});
      var i=0;
      while(i<newNode.childNodes.length){
        var next=newNode.childNodes[i],old=oldNode.childNodes[i];
        if(!old)oldNode.appendChild(next.cloneNode(true));
        else patchFeedNode(old,next);
        i++;
      }
      while(oldNode.childNodes.length>newNode.childNodes.length)oldNode.lastChild.remove();
    }
    function patchFeed(body,html){
      var draft=document.createElement('div');draft.innerHTML=html;
      var existing={};
      Array.from(body.children).forEach(function(el){if(el.matches('.nos-note[data-key]'))existing[el.dataset.key]=el});
      var wanted=Array.from(draft.children);
      wanted.forEach(function(fresh,i){
        var old=fresh.matches('.nos-note[data-key]')?existing[fresh.dataset.key]:null;
        if(!old&&fresh.classList.contains('nos-newposts-bar'))old=body.querySelector(':scope > .nos-newposts-bar');
        if(old){patchFeedNode(old,fresh);if(body.children[i]!==old)body.insertBefore(old,body.children[i]||null)}
        else body.insertBefore(fresh,body.children[i]||null);
      });
      while(body.children.length>wanted.length)body.lastElementChild.remove();
    }
    function renderFeed(body){
      var pending=pendingHtml();
      // The first answer is the list, however it trickles in — relay by relay,
      // or one signature check at a time on Popular. Painting it part-way meant
      // either growing it above the reader or, gated behind the pill, announcing
      // the rest of the very same answer as new posts. So nothing shows until it
      // is complete; "new" is only what arrives after that.
      if(!feedLoaded){
        body.innerHTML=pending+'<div class="nos-empty">'+esc(t('nos_loading'))+'</div>';
        return;
      }
      if(!feedItems.length){
        var emptyKey=feedMode==='following'?'nos_no_notes':feedMode==='trending'?(trendingFailed?'nos_trending_off':'nos_no_trending'):'nos_no_discover';
        body.innerHTML=pending+'<div class="nos-empty">'+esc(feedLoaded?t(emptyKey):t('nos_loading'))+'</div>';
        if(pending)body.querySelector('.nos-newposts').onclick=function(e){e.stopPropagation();acceptPending()};
        return;
      }
      var shown=feedItems.filter(visibleFeedItem).slice(0,feedVisible);
      patchFeed(body,pending+listHtml(shown,{}));
      if(pending)body.querySelector('.nos-newposts').onclick=function(e){e.stopPropagation();acceptPending()};
      bindList(body);
      refreshStats(shown.map(function(item){return item.noteId}));
    }
    // ---- zaps page ----
    // Built only from public receipts: the ones addressed to this person and the
    // ones whose embedded request was signed by them. Each receipt is checked the
    // same way as under a post. The wallet holds the exact history; this is an
    // overview of what the relays still know.
    function loadZaps(){
      pool.unsubscribe('zaps');clearTimeout(zapTimer);
      zapRows=[];zapRowKeys={};zapLoaded=false;
      var urls=readUrls();
      if(!urls.length){zapLoaded=true;return}
      zapTimer=setTimeout(function(){zapLoaded=true;if(activeTab==='zaps')scheduleRender()},9000);
      pool.subscribe(urls,'zaps',[{kinds:[9735],'#p':[pubHex],limit:500},{kinds:[9735],'#P':[pubHex],limit:500}],function(ev){
        if(zapRowKeys[ev.id])return;
        zapRowKeys[ev.id]=1;
        parseZapReceipt(ev).then(function(z){
          if(!z||!key)return;
          var dir=z.recipient===pubHex?(z.sender===pubHex?null:'in'):(z.sender===pubHex?'out':null);
          if(!dir)return;
          var other=dir==='in'?z.sender:z.recipient;
          ensureProfile(other);
          var tg=lastETag(ev);if(tg)ensureNote(tg);
          var row={id:ev.id,at:ev.created_at,dir:dir,sats:z.sats,other:other,comment:z.comment,note:tg||null};
          var j=0;while(j<zapRows.length&&zapRows[j].at>row.at)j++;
          zapRows.splice(j,0,row);
          scheduleRender();
        });
      },function(){zapLoaded=true;if(activeTab==='zaps')scheduleRender()});
    }
    function zapCutoff(){
      var day=86400,now=Math.floor(Date.now()/1000);
      return zapPeriod==='7'?now-7*day:zapPeriod==='30'?now-30*day:zapPeriod==='365'?now-365*day:0;
    }
    function renderZaps(body){
      var cut=zapCutoff();
      var rows=zapRows.filter(function(r){return r.at>=cut});
      var tot={in:{n:0,sats:0},out:{n:0,sats:0}};
      rows.forEach(function(r){tot[r.dir].n++;tot[r.dir].sats+=r.sats});
      var list=rows.filter(function(r){return r.dir===zapDir});
      var periods=[['all','nos_zaps_all'],['7','nos_zaps_7d'],['30','nos_zaps_30d'],['365','nos_zaps_year']];
      function card(dir,label){
        return'<div class="nos-zap-sum'+(zapDir===dir?' active':'')+'" data-zdir="'+dir+'" role="button" tabindex="0"><div class="nos-zap-sum-label">'+esc(label)+'</div><div class="nos-zap-sum-val">⚡ '+esc(tot[dir].sats.toLocaleString())+'</div><div class="nos-zap-sum-n">'+esc(t('nos_zaps_count',{n:tot[dir].n}))+'</div></div>';
      }
      body.innerHTML='<div class="nos-zap-page">'+
        '<div class="nos-zap-sums">'+card('in',t('nos_zaps_received'))+card('out',t('nos_zaps_sent'))+'</div>'+
        '<div class="nos-zap-periods">'+periods.map(function(p){return'<button type="button" class="nos-mode'+(zapPeriod===p[0]?' active':'')+'" data-zper="'+p[0]+'">'+esc(t(p[1]))+'</button>'}).join('')+'</div>'+
        (list.length?list.map(function(r){
          return'<div class="nos-notif"'+(r.note?' data-note="'+esc(r.note)+'"':'')+'>'+avatarHtml(r.other)+
            '<div class="nos-notif-body"><div class="nos-notif-line"><span aria-hidden="true" style="margin-right:.25rem">'+(r.dir==='in'?'⬇️':'⬆️')+'</span>'+esc(t(r.dir==='in'?'nos_zaps_from':'nos_zaps_to'))+' <b data-user="'+esc(r.other)+'">'+esc(displayName(r.other))+'</b> · <b>'+esc(r.sats.toLocaleString())+' sats</b></div>'+
            (r.comment?'<div class="nos-notif-quote">'+esc(r.comment.slice(0,180))+'</div>':'')+
            '<div class="nos-notif-time">'+esc(formatTime(r.at))+'</div></div></div>';
        }).join(''):'<div class="nos-empty">'+esc(t(zapLoaded?'nos_zaps_empty':'nos_loading'))+'</div>')+
        '<p class="nos-zap-foot">'+esc(t('nos_zaps_note'))+'</p></div>';
      bindList(body);
      var inner=body.onclick;
      body.onclick=function(e){
        var per=e.target.closest('[data-zper]');
        if(per){zapPeriod=per.dataset.zper;renderBody();return}
        var dir=e.target.closest('[data-zdir]');
        if(dir){zapDir=dir.dataset.zdir;renderBody();return}
        if(inner)inner.call(body,e);
      };
    }

    function renderNotifications(body){
      var shownNotifs=notifItems.concat(followerNotifs).filter(function(ev){return!isMuted(notifActor(ev))}).sort(function(a,b){return b.created_at-a.created_at});
      if(!shownNotifs.length){
        body.innerHTML='<div class="nos-empty">'+esc(notifLoaded?t('nos_no_notifications'):t('nos_loading'))+'</div>';
        return;
      }
      body.innerHTML=shownNotifs.map(function(ev){
        var target=ev.kind===3?null:targetOf(ev),note=target?noteCache[target]:null;
        var actor=notifActor(ev);
        var what=ev._zap?t('nos_notif_zap',{n:fmtSats(ev._zap.sats)}):ev.kind===3?t('nos_notif_follow'):ev.kind===7?t('nos_notif_like'):ev.kind===6?t('nos_notif_repost'):(target?t('nos_notif_reply'):t('nos_notif_mention'));
        var icon=ev._zap?'⚡':ev.kind===3?'👤':ev.kind===7?'❤️':ev.kind===6?'🔁':(target?'💬':'@');
        var preview=ev._zap?ev._zap.comment:ev.kind===1?ev.content:'';
        var onPost=note?note.content:'';
        return'<div class="nos-notif'+(notifBase!==null&&ev.created_at>notifBase?' nos-notif-new':'')+'"'+(target||ev.kind===1?' data-note="'+esc(ev.kind===1?ev.id:target)+'"':'')+'>'+avatarHtml(actor)+
          '<div class="nos-notif-body"><div class="nos-notif-line"><span class="nos-notif-icon" aria-hidden="true" style="margin-right:.25rem">'+icon+'</span><b data-user="'+esc(actor)+'">'+esc(displayName(actor))+'</b> '+esc(what)+'</div>'+
          (preview?'<div class="nos-notif-quote">'+esc(preview.slice(0,180))+'</div>':'')+
          (target?'<div class="nos-notif-on"><span>'+esc(t('nos_notif_on_post'))+':</span> '+esc(note?onPost.slice(0,140):t(noteMissing[target]?'nos_note_unavailable':'nos_loading'))+'</div>':'')+
          '<div class="nos-notif-time">'+esc(formatTime(ev.created_at))+'</div></div></div>';
      }).join('');
      bindList(body);
      markNotifSeen();
    }
    function renderThread(body,view){
      var note=noteCache[view.id];
      if(!note){body.innerHTML='<div class="nos-empty">'+esc(t('nos_loading'))+'</div>';return}
      var parent=replyTarget(note);
      body.innerHTML=(parent?noteCardHtml({key:'p',noteId:parent,boost:null},{flat:true,showParent:false}):'')+
        noteCardHtml({key:'root',noteId:view.id,boost:null},{showParent:false,clickable:false})+
        '<div class="nos-thread-replies">'+
          (threadReplies.length?listHtml(threadReplies.map(function(ev){return{key:ev.id,noteId:ev.id,boost:null}}),{flat:true,showParent:false})
            :'<div class="nos-empty">'+esc(threadLoaded?t('nos_no_replies'):t('nos_loading'))+'</div>')+
        '</div>';
      bindList(body);
      refreshStats([view.id].concat(threadReplies.map(function(ev){return ev.id})));
    }
    function peopleCountsHtml(pk){
      return'<div class="nos-people-stats">'+
        '<button type="button" class="nos-people-btn" data-people="following" data-pubkey="'+esc(pk)+'">'+
          '<b>'+(pk===pubHex?contactPubkeys.length:'…')+'</b> '+esc(t('nos_following'))+'</button>'+
        '<button type="button" class="nos-people-btn" data-people="followers" data-pubkey="'+esc(pk)+'">'+
          '<b>'+(followerCounts[pk]?followerCounts[pk].count:'…')+'</b> '+esc(t('nos_followers'))+'</button>'+
      '</div>';
    }
    function renderUser(body,view){
      var pk=view.pubkey,p=profileCache[pk]||{},following=contactPubkeys.indexOf(pk)>=0,isSelf=pk===pubHex;
      body.innerHTML='<div class="nos-user-head">'+
        (p.banner?'<img class="nos-banner" src="'+esc(p.banner)+'" referrerpolicy="no-referrer" alt="">':'<div class="nos-banner"></div>')+
        '<div class="nos-user-row">'+avatarHtml(pk,true)+
          '<div class="nos-user-meta"><div class="nos-user-name">'+esc(displayName(pk))+'</div>'+
          (p.nip05?'<div class="nos-nip05">'+esc(p.nip05)+'</div>':'')+(p.lud16?'<div class="nos-nip05 nos-lud16" title="'+esc(t('nos_lud16'))+'">⚡ '+esc(p.lud16)+'</div>':'')+'</div>'+
          (isSelf?'':'<button type="button" class="nos-follow-btn primary" data-act="'+(following?'unfollow':'follow')+'" data-pubkey="'+esc(pk)+'">'+esc(t(following?'nos_unfollow':'nos_follow'))+'</button>'+muteBtnHtml(pk,true))+
        '</div>'+
        (p.about?'<div class="nos-user-about">'+renderContent(p.about)+'</div>':'')+
        peopleCountsHtml(pk)+
        (p.website?'<div class="nos-user-stats"><a href="'+esc(p.website)+'" target="_blank" rel="noopener noreferrer">'+esc(p.website)+'</a></div>':'')+
        '<div class="nos-view-value nos-key-value">'+esc(npubEncode(pk)||'')+'</div>'+
      '</div>'+
      (userNotes.length?listHtml(userNotes.map(function(ev){return{key:ev.id,noteId:ev.id,boost:null}}),{follow:false,showMuted:true})
        :'<div class="nos-empty">'+esc(userLoaded?t('nos_no_notes'):t('nos_loading'))+'</div>');
      bindList(body);
      bindPeopleButtons(body);
      refreshStats(userNotes.map(function(ev){return ev.id}));
    }
    function renderPeople(body,view){
      body.innerHTML=(peopleList.length?peopleList.map(function(pk){
          return'<div class="nos-note nos-flat" data-user="'+esc(pk)+'"><div class="nos-note-head">'+avatarHtml(pk)+
            '<div class="nos-note-who" data-user="'+esc(pk)+'"><span class="nos-note-name">'+esc(displayName(pk))+'</span></div>'+
            (pk===pubHex?'':'<button type="button" class="nos-follow-btn" data-act="'+(contactPubkeys.indexOf(pk)>=0?'unfollow':'follow')+'" data-pubkey="'+esc(pk)+'">'+esc(t(contactPubkeys.indexOf(pk)>=0?'nos_unfollow':'nos_follow'))+'</button>'+muteBtnHtml(pk,false))+
          '</div></div>';
        }).join('')
        :'<div class="nos-empty">'+esc(peopleLoaded?t('nos_no_people'):t('nos_loading'))+'</div>');
      bindList(body);
    }
    function bindPeopleButtons(body){
      body.querySelectorAll('[data-people]').forEach(function(btn){
        btn.onclick=function(e){e.stopPropagation();openPeople(btn.dataset.people,btn.dataset.pubkey)};
      });
    }
    function aiReplyPrefsHtml(){
      if(!aiEnabled)return '';
      var prefs=aiPrefsDraft||_langPrefs,lang=prefs.ai_reply_lang||'POST';
      return '<div class="nos-ai-reply-prefs"><label>'+esc(t('nos_ai_reply_lang'))+
        '<select class="nos-p-ai-reply-lang"><option value="POST"'+(lang==='POST'?' selected':'')+'>'+esc(t('nos_ai_reply_post_lang'))+'</option>'+
        NOS_LANGS.map(function(l){return '<option value="'+esc(l.value)+'"'+(l.value===lang?' selected':'')+'>'+esc(l.label)+'</option>'}).join('')+'</select></label>'+
        '<label>'+esc(t('nos_ai_reply_style'))+'<textarea class="nos-p-ai-reply-style" maxlength="1000" placeholder="'+esc(t('nos_ai_reply_style_hint'))+'">'+esc(prefs.ai_reply_style||'')+'</textarea></label>'+
        '<button type="button" class="nos-ai-prefs-save"'+(aiPrefsSaving?' disabled':'')+'>'+esc(t('nos_save'))+'</button>'+
        '</div>';
    }
    function bindAiReplyPrefs(body){
      var lang=body.querySelector('.nos-p-ai-reply-lang'),style=body.querySelector('.nos-p-ai-reply-style');
      if(!lang||!style)return;
      function changed(){
        aiPrefsDraft={ai_reply_lang:lang.value,ai_reply_style:style.value};
      }
      lang.onchange=changed;style.oninput=changed;
      body.querySelector('.nos-ai-prefs-save').onclick=async function(){
        if(aiPrefsSaving)return;
        changed();var draft=aiPrefsDraft;
        var btn=body.querySelector('.nos-ai-prefs-save');
        aiPrefsSaving=true;btn.disabled=true;
        try{
          await api('/prefs',{method:'PUT',body:JSON.stringify(draft)});
          Object.assign(_langPrefs,draft);
          if(aiPrefsDraft===draft)aiPrefsDraft=null;showToast(t('nos_ai_reply_saved'))
        }catch(_){showToast(t('nos_save_error'))}
        aiPrefsSaving=false;btn.disabled=false;
      };
    }
    function renderProfileTab(body){
      var p=profileCache[pubHex]||{};
      var subs=aiEnabled?['posts','replies','ai','settings']:['posts','replies','settings'];
      if(profileSub==='ai'&&!aiEnabled)profileSub='posts';
      var subHtml='<div class="nos-subtabs">'+subs.map(function(s){
        return'<button type="button" class="nos-subtab'+(profileSub===s?' active':'')+'" data-sub="'+s+'">'+esc(t('nos_sub_'+s))+'</button>'}).join('')+'</div>';
      var headHtml='<div class="nos-user-head">'+
          (p.banner?'<img class="nos-banner" src="'+esc(p.banner)+'" referrerpolicy="no-referrer" alt="">':'<div class="nos-banner"></div>')+
          '<div class="nos-user-row">'+avatarHtml(pubHex,true)+'<div class="nos-user-meta"><div class="nos-user-name">'+esc(displayName(pubHex))+'</div>'+
          (p.nip05?'<div class="nos-nip05">'+esc(p.nip05)+'</div>':'')+(p.lud16?'<div class="nos-nip05 nos-lud16" title="'+esc(t('nos_lud16'))+'">⚡ '+esc(p.lud16)+'</div>':'')+'</div></div>'+
          (p.about?'<div class="nos-user-about">'+renderContent(p.about)+'</div>':'')+
          peopleCountsHtml(pubHex)+
        '</div>'+subHtml;
      function bindSubs(){
        body.querySelectorAll('.nos-subtab').forEach(function(btn){btn.onclick=function(){profileSub=btn.dataset.sub;if(profileSub==='ai')aiHistory=null;scrollReset=false;renderBody()}});
      }
      if(profileSub==='ai'){
        loadAiHistory();
        body.innerHTML=headHtml+aiHistoryHtml();
        bindSubs();bindPeopleButtons(body);bindImages(body);
        body.querySelectorAll('[data-ai-chat]').forEach(function(el){el.onclick=function(){openAiHistoryChat(el.dataset.aiChat)}});
        return;
      }
      if(profileSub!=='settings'){
        var mine=userNotes.filter(function(ev){return profileSub==='replies'?!!replyTarget(ev):!replyTarget(ev)});
        body.innerHTML=headHtml+(mine.length?listHtml(mine.map(function(ev){return{key:ev.id,noteId:ev.id,boost:null}}),{follow:false,showMuted:true})
          :'<div class="nos-empty">'+esc(userLoaded?t('nos_no_notes_here'):t('nos_loading'))+'</div>');
        bindList(body);bindSubs();bindPeopleButtons(body);bindImages(body);
        refreshStats(mine.map(function(ev){return ev.id}));
        return;
      }
      body.innerHTML=headHtml+'<div class="nos-profile-form">'+
        '<label>'+esc(t('nos_display_name'))+'</label><input class="nos-p-display" value="'+esc(p.name||'')+'">'+
        '<label>'+esc(t('nos_username'))+'</label><input class="nos-p-name" value="'+esc(p.handle||'')+'">'+
        '<label>'+esc(t('nos_about'))+'</label><textarea class="nos-p-about">'+esc(p.about||'')+'</textarea>'+
        '<label>'+esc(t('nos_picture_url'))+'</label><input class="nos-p-picture" value="'+esc(p.picture||'')+'">'+
        '<label>'+esc(t('nos_banner_url'))+'</label><input class="nos-p-banner" value="'+esc(p.banner||'')+'">'+
        '<label>'+esc(t('nos_website'))+'</label><input class="nos-p-website" value="'+esc(p.website||'')+'">'+
        '<label>'+esc(t('nos_nip05'))+'</label><input class="nos-p-nip05" value="'+esc(p.nip05||'')+'">'+
        '<label>'+esc(t('nos_lud16'))+'</label><input class="nos-p-lud16" type="text" inputmode="email" autocapitalize="off" autocomplete="off" spellcheck="false" placeholder="name@wallet.com" value="'+esc(p.lud16||'')+'">'+
        '<div class="nos-profile-meta" style="margin:.2rem 0 0">'+esc(t('nos_lud16_hint'))+'</div>'+
        '<button type="button" class="primary nos-profile-save">'+esc(t('nos_save'))+'</button>'+
        '<div class="nos-zap-prefs"><h3>⚡ '+esc(t('nos_zap_presets'))+'</h3><div class="nos-profile-meta" style="margin:0 0 .4rem">'+esc(t('nos_zap_presets_hint'))+'</div>'+
        '<div class="nos-zap-rows">'+zapPresets().map(function(pr){return zapRowHtml(pr)}).join('')+'</div>'+
        '<div class="nos-modal-foot" style="justify-content:flex-start;margin-top:.4rem"><button type="button" class="nos-zap-add">+ '+esc(t('nos_zap_add'))+'</button><button type="button" class="primary nos-zap-save">'+esc(t('nos_save'))+'</button></div></div>'+
        '<div class="nos-profile-meta">'+esc(t('nos_your_npub'))+'<div class="nos-view-value nos-key-value">'+esc(vaultInfo.npub)+'</div>'+
        '<div class="nos-identities-title">'+esc(t('nos_identities_title'))+'</div>'+
        identities.map(function(v){
          var active=v.npub===vaultInfo.npub;
          return'<div class="nos-identity-row"><span class="nos-identity-label">'+esc(shortNpub(v.npub))+(active?' — '+esc(t('nos_identity_current')):'')+'</span>'+
            '<span class="nos-identity-actions">'+
            (active?'<button type="button" class="nos-identity-logout" data-npub="'+esc(v.npub)+'">'+esc(t('nos_identity_logout'))+'</button>':
              '<button type="button" class="nos-identity-switch" data-npub="'+esc(v.npub)+'">'+esc(t('nos_switch_identity'))+'</button>')+
            '<button type="button" class="nos-identity-remove" data-npub="'+esc(v.npub)+'">'+esc(t('nos_identity_remove'))+'</button>'+
            '</span></div>';
        }).join('')+
        '<button type="button" class="nos-link nos-add-identity">'+esc(t('nos_add_identity'))+'</button>'+
        '</div>'+
        // Both of these choose a target language for a translation, so they
        // belong to the premium integration and go with it: the first is the
        // language the translate button renders a post into, the second the
        // one the composer translates a draft into before publishing. With no
        // integration there is nothing either could apply to.
        ((deeplEnabled||aiEnabled)?
          '<label>'+esc(t('nos_translate_lang_label'))+'</label>'+
          '<select class="nos-p-translate-lang">'+NOS_LANGS.map(function(l){return'<option value="'+esc(l.value)+'"'+(l.value===translateTargetLang()?' selected':'')+'>'+esc(l.label)+'</option>'}).join('')+'</select>'+
          (deeplEnabled?'<label>'+esc(t('nos_publish_lang_label'))+'</label>'+
          '<select class="nos-p-publish-lang">'+NOS_LANGS.map(function(l){return'<option value="'+esc(l.value)+'"'+(l.value===publishTargetLang()?' selected':'')+'>'+esc(l.label)+'</option>'}).join('')+'</select>':'')
        :'')+aiReplyPrefsHtml()+
        '</div>';
      bindAiReplyPrefs(body);
      function saveLangPref(field,value){
        var prev=_langPrefs[field];
        _langPrefs[field]=value;
        api('/prefs',{method:'PUT',body:JSON.stringify((function(o){o[field]=value;return o})({}))}).catch(function(){_langPrefs[field]=prev});
      }
      // Absent whenever the integration is off, and everything bound after
      // this — the identity buttons — would be left dead by the TypeError.
      var trLangSel=body.querySelector('.nos-p-translate-lang');
      if(trLangSel)trLangSel.onchange=function(e){saveLangPref('translate_lang',e.target.value)};
      var pubLangSel=body.querySelector('.nos-p-publish-lang');
      if(pubLangSel)pubLangSel.onchange=function(e){saveLangPref('publish_lang',e.target.value)};
      body.querySelector('.nos-add-identity').onclick=function(){addMode=true;obStep='choose';obPriv=null;onboardingScreen()};
      body.querySelectorAll('.nos-identity-switch').forEach(function(btn){btn.onclick=function(){switchIdentity(btn.dataset.npub)}});
      body.querySelectorAll('.nos-identity-logout').forEach(function(btn){btn.onclick=function(){logoutIdentity(btn.dataset.npub)}});
      body.querySelectorAll('.nos-identity-remove').forEach(function(btn){btn.onclick=function(){removeIdentity(btn.dataset.npub)}});
      bindPeopleButtons(body);bindSubs();
      var zapRows=body.querySelector('.nos-zap-rows');
      function bindZapRows(){zapRows.querySelectorAll('.nos-zp-del').forEach(function(b){b.onclick=function(){b.closest('.nos-zap-row').remove()}})}
      bindZapRows();
      body.querySelector('.nos-zap-add').onclick=function(){
        if(zapRows.children.length>=10)return;
        zapRows.insertAdjacentHTML('beforeend',zapRowHtml({sats:'',msg:''}));bindZapRows();
      };
      body.querySelector('.nos-zap-save').onclick=async function(){
        var btn=this,list=[];
        zapRows.querySelectorAll('.nos-zap-row').forEach(function(row){
          var n=Math.floor(Number(row.querySelector('.nos-zp-sats').value));
          if(n>=1&&n<=100000000)list.push({sats:n,msg:row.querySelector('.nos-zp-msg').value.trim().slice(0,100)});
        });
        btn.disabled=true;
        try{
          var r=await fetch(API+'/prefs',{method:'PUT',headers:{'Content-Type':'application/json','X-Pub-Token':token},body:JSON.stringify({zap_presets:list})});
          if(!r.ok)throw new Error('save');
          _langPrefs.zap_presets=list;
          showToast(t('nos_zap_presets_saved'));
        }catch(_){showToast(t('nos_zap_presets_error'))}
        btn.disabled=false;
      };
      body.querySelector('.nos-profile-save').onclick=async function(){
        var btn=body.querySelector('.nos-profile-save');
        var lud16=body.querySelector('.nos-p-lud16').value.trim();
        if(lud16&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(lud16)){showToast(t('nos_lud16_invalid'));return}
        btn.disabled=true;
        // Kind 0 is replaceable: publishing only the fields this form knows about
        // would silently delete anything another client put there, a lightning
        // address included. The last profile seen is the base; the form edits it.
        var edited=Object.assign({},ownProfileRaw,{
          display_name:body.querySelector('.nos-p-display').value.trim(),
          name:body.querySelector('.nos-p-name').value.trim(),
          about:body.querySelector('.nos-p-about').value.trim(),
          picture:body.querySelector('.nos-p-picture').value.trim(),
          banner:body.querySelector('.nos-p-banner').value.trim(),
          website:body.querySelector('.nos-p-website').value.trim(),
          nip05:body.querySelector('.nos-p-nip05').value.trim()
        });
        // An empty field removes the address; lud06 and other keys stay as they were.
        if(lud16)edited.lud16=lud16;else delete edited.lud16;
        try{
          var ev=await publish({kind:0,tags:[],content:JSON.stringify(edited)});
          // Without this the feed keeps showing the old avatar until a relay
          // happens to echo the new profile back.
          profileCache[pubHex]=parseProfile(ev);
          ownProfileRaw=edited;
          renderBody();
        }catch(_){showToast(t('nos_publish_error'))}
        btn.disabled=false;
      };
      bindImages(body);
    }
    function zapRowHtml(pr){
      return'<div class="nos-zap-row"><input class="nos-zp-sats" type="number" min="1" step="1" inputmode="numeric" placeholder="sats" value="'+esc(pr.sats)+'">'+
        '<input class="nos-zp-msg" type="text" maxlength="100" placeholder="'+esc(t('nos_zap_message'))+'" value="'+esc(pr.msg||'')+'">'+
        '<button type="button" class="nos-zp-del" title="✕">✕</button></div>';
    }
    var relaySaving=false;
    async function saveRelayChanges(next){
      if(relaySaving)return false;
      relaySaving=true;
      var panel=root.querySelector('.nos-relays');
      if(panel){panel.querySelector('.nos-relay-add-btn').disabled=true;panel.querySelector('.nos-relay-refresh').disabled=true}
      renderRelayList();
      try{
        if(next.some(function(r){return !r.read&&!r.write}))throw new Error('invalid_flags');
        if(!relayEvent&&!relayDiscoveryOK)throw new Error('relay_discovery_failed');
        var now=Math.floor(Date.now()/1000);
        if(relayEvent&&relayEvent.created_at>=now){
          if(relayEvent.created_at>now)throw new Error('future_relay_list');
          await new Promise(function(resolve){setTimeout(resolve,1100)});
        }
        var tags=(relayEvent?relayEvent.tags:[]).filter(function(tag){return !Array.isArray(tag)||tag[0]!=='r'||typeof tag[1]!=='string'||!/^wss?:\/\//.test(tag[1])||(tag[2]&&tag[2]!=='read'&&tag[2]!=='write')});
        next.forEach(function(r){tags.push(r.read&&r.write?['r',r.url]:['r',r.url,r.read?'read':'write'])});
        var ev=await finalizeEvent({kind:10002,tags:tags,content:relayEvent?relayEvent.content:''},privBytes);
        var urls=Array.from(new Set(RELAY_DISCOVERY.concat(DEFAULT_RELAYS,relays.map(function(r){return r.url}),next.map(function(r){return r.url}))));
        var results=await pool.publish(urls,ev);
        if(!results.some(function(r){return r.ok}))throw new Error('publish_failed');
        relayEvent=ev;relays=next;relayDiscoveryOK=true;cacheRelayEvent(ev);
        panel=root.querySelector('.nos-relays');if(panel){var hint=panel.querySelector('.nos-relay-hint');if(hint)hint.remove()}
        if(results.all)await results.all;
        pool.setRelayUrls(relays.map(function(r){return r.url}),[TRENDING_URL]);
        loadFeed();loadNotifications();startFollowerNotifications();
        return true;
      }catch(err){
        panel=root.querySelector('.nos-relays');
        if(panel)showToast(t(err.message==='relay_list_changed'?'nos_relay_changed':err.message==='relay_discovery_failed'?'nos_relay_discovery_error':err.message==='invalid_flags'?'nos_relay_flags_error':'nos_save_error'));
        return false;
      }finally{
        relaySaving=false;
        panel=root.querySelector('.nos-relays');
        if(panel){panel.querySelector('.nos-relay-add-btn').disabled=false;panel.querySelector('.nos-relay-refresh').disabled=false}
        renderRelayList();
      }
    }
    function renderRelayList(){
      var list=root.querySelector('.nos-relay-list');if(!list)return;
      list.innerHTML=relays.map(function(r,i){var st=pool.statusOf(r.url);
        return'<div class="nos-relay-row"><span class="nos-relay-dot nos-relay-'+st+'"></span><span class="nos-relay-url">'+esc(r.url)+'</span><label class="nos-check"><input type="checkbox" class="nos-relay-read" data-i="'+i+'" '+(r.read?'checked ':'')+(relaySaving?'disabled':'')+'> '+esc(t('nos_read'))+'</label><label class="nos-check"><input type="checkbox" class="nos-relay-write" data-i="'+i+'" '+(r.write?'checked ':'')+(relaySaving?'disabled':'')+'> '+esc(t('nos_write'))+'</label><button type="button" class="nos-relay-del" data-i="'+i+'" '+(relaySaving?'disabled':'')+'>🗑</button></div>'
      }).join('');
      function changeFlag(cb,flag){
        var next=relays.map(function(r){return Object.assign({},r)});
        next[Number(cb.dataset.i)][flag]=cb.checked?1:0;
        saveRelayChanges(next);
      }
      list.querySelectorAll('.nos-relay-read').forEach(function(cb){cb.onchange=function(){changeFlag(cb,'read')}});
      list.querySelectorAll('.nos-relay-write').forEach(function(cb){cb.onchange=function(){changeFlag(cb,'write')}});
      list.querySelectorAll('.nos-relay-del').forEach(function(btn){btn.onclick=function(){var next=relays.slice();next.splice(Number(btn.dataset.i),1);saveRelayChanges(next)}});
    }
    function renderRelaysTab(body){
      body.innerHTML='<div class="nos-relays">'+(!relayEvent?'<p class="nos-relay-hint">'+esc(t(relayDiscoveryOK?'nos_relay_defaults':'nos_relay_offline'))+'</p>':'')+'<button type="button" class="nos-relay-refresh" '+(relaySaving?'disabled':'')+'>'+esc(t('nos_relay_refresh'))+'</button><div class="nos-relay-list"></div><div class="nos-relay-add"><input class="nos-relay-url" placeholder="wss://relay.example.com"><button type="button" class="nos-relay-add-btn" '+(relaySaving?'disabled':'')+'>'+esc(t('nos_add'))+'</button></div></div>';
      renderRelayList();
      body.querySelector('.nos-relay-refresh').onclick=refreshRelays;
      body.querySelector('.nos-relay-add-btn').onclick=async function(){
        var input=body.querySelector('.nos-relay-add input'),url=input.value.trim();
        if(!/^wss?:\/\/.+/.test(url)){showToast(t('nos_invalid_relay'));return}
        if(relays.some(function(r){return r.url===url}))return;
        var next=relays.concat([{url:url,read:1,write:1}]);
        if(await saveRelayChanges(next))input.value='';
      };
    }

    function destroy(){
      destroyed=true;
      closeImagePreview();root.removeEventListener('click',onImageClick,true);
      clearTimeout(autoLockTimer);clearTimeout(renderTimer);clearTimeout(profileTimer);clearTimeout(noteTimer);
      clearTimeout(searchDebounce);
      stopModePolling();followerGeneration++;
      document.removeEventListener('visibilitychange',onVisible);
      pool.destroy();
    }
    // Switching/removing/logging out of an identity used to reload the whole
    // browser tab. On the public page that's just this one app's own tab, so
    // it's harmless — but on the desktop every app shares one page with the
    // rest of mvmOS, and a reload there wiped the whole running session, not
    // just this widget. Tear down and re-mount in place instead, there only.
    function remount(){if(opts.isDesktop){destroy();mount(root,opts)}else{location.reload()}}

    document.addEventListener('visibilitychange',onVisible);
    load();
    return{destroy:destroy};
  }

  window.NostradamusWidget={mount:mount};
})();
