// Git Manager for mvmOS v1.0.0

(function() {

function start() {

var t = window.t || function(k) { return k; };

var GM = {
  state: {
    repos: [], activeRepo: null, currentUser: '', foreignAccess: {}, sessionShown: {}, showOthers: false,
    terminals: {}, termOpen: localStorage.getItem('gm_term_open') === '1', termPos: localStorage.getItem('gm_term_pos') === 'right' ? 'right' : 'bottom',
  },
  body: null,
  listEl: null,
  contentEl: null,
};

GM.escape = function(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, function(ch) {
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch];
  });
};

// ── Markdown rendering (subset of GFM: headers, bold/italic, code, links,
//    quotes, lists, task lists) ─────────────────────────────────────────────────

GM.renderMarkdown = function(src, interactive) {
  var raw = String(src == null ? '' : src).replace(/\r\n/g, '\n');
  var lines = raw.split('\n');
  var out = [];
  var listStack = [];
  var checklistIndex = 0;
  var i = 0;

  function safeHref(url) {
    url = (url || '').trim();
    return /^(https?:|mailto:|#|\/)/i.test(url) ? url : '#';
  }

  function inline(s) {
    s = GM.escape(s);
    s = s.replace(/`([^`\n]+)`/g, function(m, code) { return '<code>' + code + '</code>'; });
    s = s.replace(/\*\*([^\n]+?)\*\*/g, '<strong>$1</strong>');
    s = s.replace(/__([^\n]+?)__/g, '<strong>$1</strong>');
    s = s.replace(/(^|[^*])\*([^*\n]+?)\*(?!\*)/g, function(m, pre, txt) { return pre + '<em>' + txt + '</em>'; });
    s = s.replace(/(^|[^_])_([^_\n]+?)_(?!_)/g, function(m, pre, txt) { return pre + '<em>' + txt + '</em>'; });
    s = s.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, function(m, text, url) {
      return '<a href="' + GM.escape(safeHref(url)) + '" target="_blank" rel="noopener noreferrer" style="color:var(--accent)">' + text + '</a>';
    });
    return s;
  }

  function closeLists() {
    while (listStack.length) out.push(listStack.pop() === 'ul' ? '</ul>' : '</ol>');
  }

  while (i < lines.length) {
    var line = lines[i];

    if (/^```/.test(line)) {
      closeLists();
      var codeLines = [];
      i++;
      while (i < lines.length && !/^```\s*$/.test(lines[i])) { codeLines.push(lines[i]); i++; }
      i++;
      out.push('<pre style="background:var(--bg,#1e1e2e);border-radius:6px;padding:8px 10px;overflow-x:auto;font-size:.8rem"><code>' + GM.escape(codeLines.join('\n')) + '</code></pre>');
      continue;
    }

    if (!line.trim()) { closeLists(); i++; continue; }

    var h = line.match(/^(#{1,6})\s+(.*)$/);
    if (h) {
      closeLists();
      var level = h[1].length;
      out.push('<h' + level + ' style="margin:10px 0 6px;font-size:' + (1.15 - level * 0.08) + 'rem">' + inline(h[2]) + '</h' + level + '>');
      i++; continue;
    }

    if (/^>\s?/.test(line)) {
      closeLists();
      var quoteLines = [];
      while (i < lines.length && /^>\s?/.test(lines[i])) { quoteLines.push(lines[i].replace(/^>\s?/, '')); i++; }
      out.push('<blockquote style="margin:6px 0;padding:4px 12px;border-left:3px solid var(--border);color:var(--text-dim)">' + inline(quoteLines.join('<br>')) + '</blockquote>');
      continue;
    }

    var task = line.match(/^\s*[-*+]\s+\[([ xX])\]\s+(.*)$/);
    if (task) {
      closeLists();
      var idx = checklistIndex++;
      var checked = task[1].toLowerCase() === 'x';
      out.push('<div class="gm-task-item" style="display:flex;align-items:flex-start;gap:6px;margin:2px 0">'
        + '<input type="checkbox" class="gm-task-checkbox" data-task-index="' + idx + '" ' + (checked ? 'checked ' : '') + (interactive ? '' : 'disabled ') + 'style="margin-top:3px;' + (interactive ? 'cursor:pointer' : 'cursor:default') + '">'
        + '<span style="' + (checked ? 'text-decoration:line-through;opacity:.6' : '') + '">' + inline(task[2]) + '</span></div>');
      i++; continue;
    }

    var ul = line.match(/^\s*[-*+]\s+(.*)$/);
    if (ul) {
      if (listStack[listStack.length - 1] !== 'ul') { closeLists(); out.push('<ul style="margin:4px 0;padding-left:22px">'); listStack.push('ul'); }
      out.push('<li>' + inline(ul[1]) + '</li>');
      i++; continue;
    }

    var ol = line.match(/^\s*\d+[.)]\s+(.*)$/);
    if (ol) {
      if (listStack[listStack.length - 1] !== 'ol') { closeLists(); out.push('<ol style="margin:4px 0;padding-left:22px">'); listStack.push('ol'); }
      out.push('<li>' + inline(ol[1]) + '</li>');
      i++; continue;
    }

    closeLists();
    var paraLines = [line];
    i++;
    while (i < lines.length && lines[i].trim() && !/^```/.test(lines[i]) && !/^#{1,6}\s/.test(lines[i]) && !/^>\s?/.test(lines[i]) && !/^\s*[-*+]\s+/.test(lines[i]) && !/^\s*\d+[.)]\s+/.test(lines[i])) {
      paraLines.push(lines[i]); i++;
    }
    out.push('<p style="margin:6px 0">' + inline(paraLines.join('<br>')) + '</p>');
  }
  closeLists();
  return out.join('\n');
};

// ── Markdown editor toolbar ──────────────────────────────────────────────────────

GM.mdToolbarHtml = function(targetId) {
  var btns = [
    { cmd: 'h', label: 'H', title: t('gm_md_heading') },
    { cmd: 'b', label: '<strong>B</strong>', title: t('gm_md_bold') },
    { cmd: 'i', label: '<em>I</em>', title: t('gm_md_italic') },
    { cmd: 'quote', label: '&#x275D;', title: t('gm_md_quote') },
    { cmd: 'code', label: '&lt;/&gt;', title: t('gm_md_code') },
    { cmd: 'link', label: '&#x1F517;', title: t('gm_md_link') },
    { cmd: 'ul', label: '&#x2022; &#x2261;', title: t('gm_md_bullet_list') },
    { cmd: 'ol', label: '1. &#x2261;', title: t('gm_md_numbered_list') },
    { cmd: 'task', label: '&#x2611;', title: t('gm_md_checklist') },
  ];
  var html = '<div class="gm-md-toolbar" data-target="' + targetId + '" style="display:flex;gap:2px;padding:4px;border:1px solid var(--border);border-bottom:none;border-radius:6px 6px 0 0;background:var(--surface2,#313244);flex-wrap:wrap">';
  btns.forEach(function(b) {
    html += '<button type="button" class="s-btn s-btn-sm gm-md-btn" data-cmd="' + b.cmd + '" title="' + b.title + '" style="padding:3px 9px;line-height:1.4">' + b.label + '</button>';
  });
  html += '</div>';
  return html;
};

GM.mdApply = function(ta, cmd) {
  function wrap(prefix, suffix, placeholder) {
    suffix = suffix == null ? prefix : suffix;
    var start = ta.selectionStart, end = ta.selectionEnd;
    var value = ta.value;
    var selected = value.slice(start, end) || placeholder || '';
    ta.value = value.slice(0, start) + prefix + selected + suffix + value.slice(end);
    var cs = start + prefix.length, ce = cs + selected.length;
    ta.focus(); ta.setSelectionRange(cs, ce);
  }
  function linePrefix(prefix) {
    var start = ta.selectionStart, end = ta.selectionEnd;
    var value = ta.value;
    var lineStart = value.lastIndexOf('\n', start - 1) + 1;
    var lineEndIdx = value.indexOf('\n', end);
    var lineEnd = lineEndIdx === -1 ? value.length : lineEndIdx;
    var block = value.slice(lineStart, lineEnd);
    var newBlock = block.split('\n').map(function(l) { return prefix + l; }).join('\n');
    ta.value = value.slice(0, lineStart) + newBlock + value.slice(lineEnd);
    ta.focus(); ta.setSelectionRange(lineStart, lineStart + newBlock.length);
  }
  if (cmd === 'h') linePrefix('## ');
  else if (cmd === 'b') wrap('**', '**', t('gm_md_bold_placeholder'));
  else if (cmd === 'i') wrap('_', '_', t('gm_md_italic_placeholder'));
  else if (cmd === 'quote') linePrefix('> ');
  else if (cmd === 'code') {
    var hasNewline = ta.value.slice(ta.selectionStart, ta.selectionEnd).indexOf('\n') !== -1;
    if (hasNewline) wrap('```\n', '\n```', t('gm_md_code_placeholder'));
    else wrap('`', '`', t('gm_md_code_placeholder'));
  }
  else if (cmd === 'link') {
    var start = ta.selectionStart, end = ta.selectionEnd;
    var value = ta.value;
    var selected = value.slice(start, end) || t('gm_md_link_text');
    var insertion = '[' + selected + '](url)';
    ta.value = value.slice(0, start) + insertion + value.slice(end);
    var urlStart = start + 1 + selected.length + 2;
    ta.focus(); ta.setSelectionRange(urlStart, urlStart + 3);
  }
  else if (cmd === 'ul') linePrefix('- ');
  else if (cmd === 'ol') linePrefix('1. ');
  else if (cmd === 'task') linePrefix('- [ ] ');
  ta.dispatchEvent(new Event('input'));
};

GM.wireMdToolbar = function(container, textarea) {
  var toolbar = container.querySelector('.gm-md-toolbar[data-target="' + textarea.id + '"]');
  if (!toolbar) return;
  Array.prototype.forEach.call(toolbar.querySelectorAll('.gm-md-btn'), function(btn) {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      GM.mdApply(textarea, btn.getAttribute('data-cmd'));
    });
  });
  GM.wireListContinuation(textarea);
};

// Pressing Enter inside a list line continues it (same bullet, next number,
// unchecked checkbox); pressing Enter on an empty list line clears the marker
// and exits the list instead of adding another empty item.
GM.wireListContinuation = function(ta) {
  ta.addEventListener('keydown', function(e) {
    if (e.key !== 'Enter' || e.shiftKey || e.ctrlKey || e.metaKey || e.altKey) return;
    var start = ta.selectionStart, end = ta.selectionEnd;
    if (start !== end) return;
    var value = ta.value;
    var lineStart = value.lastIndexOf('\n', start - 1) + 1;
    var line = value.slice(lineStart, start);

    var checklist = line.match(/^(\s*)([-*+])\s\[([ xX])\]\s?(.*)$/);
    var ordered = !checklist && line.match(/^(\s*)(\d+)([.)])\s(.*)$/);
    var bullet = !checklist && !ordered && line.match(/^(\s*)([-*+])\s(?!\[)(.*)$/);
    var match = checklist || ordered || bullet;
    if (!match) return;

    e.preventDefault();
    var content = checklist ? match[4] : (ordered ? match[4] : match[3]);
    if (!content.trim()) {
      ta.value = value.slice(0, lineStart) + value.slice(start);
      ta.setSelectionRange(lineStart, lineStart);
      ta.dispatchEvent(new Event('input'));
      return;
    }
    var indent = match[1], marker;
    if (checklist) marker = indent + match[2] + ' [ ] ';
    else if (ordered) marker = indent + (parseInt(match[2], 10) + 1) + match[3] + ' ';
    else marker = indent + match[2] + ' ';
    var insertion = '\n' + marker;
    ta.value = value.slice(0, start) + insertion + value.slice(end);
    var pos = start + insertion.length;
    ta.setSelectionRange(pos, pos);
    ta.dispatchEvent(new Event('input'));
  });
};

// ── API helper ────────────────────────────────────────────────────────────────

GM.api = async function(path, opts) {
  opts = opts || {};
  var res = await fetch('/api/apps/git-manager' + path, {
    method: opts.method || 'GET',
    headers: opts.json != null ? { 'Content-Type': 'application/json' } : {},
    body: opts.json != null ? JSON.stringify(opts.json) : undefined,
  });
  var data = await res.json().catch(function() { return {}; });
  if (!res.ok) throw new Error(data.detail || t('gm_error_status', { status: res.status }));
  return data;
};


// ── Branch dialog ─────────────────────────────────────────────────────────────
// Shared by the toolbar's "+ Branch" button and by the issue view, so both ask
// the same way where a branch comes from before anything is checked out.
// cfg: { title, info, choices:[{value,label,tag,hint}], name:{value,suggest},
//        confirmLabel, onConfirm(choice, name) }
GM.branchDialog = function(cfg) {
  var overlay = document.createElement('div');
  overlay.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:99;padding:16px;box-sizing:border-box';
  var choices = cfg.choices || [];
  overlay.innerHTML = '<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:20px;width:420px;max-width:100%;max-height:100%;overflow-y:auto;box-sizing:border-box;display:flex;flex-direction:column;gap:12px">'
    + '<div style="font-weight:600;font-size:.95rem">&#x1F33F; ' + GM.escape(cfg.title) + '</div>'
    + (cfg.info ? '<div style="font-size:.8rem;line-height:1.5;color:var(--text-dim);background:var(--surface2,#313244);border-radius:6px;padding:9px 11px">' + cfg.info + '</div>' : '')
    + (choices.length > 1 ? '<div><div style="font-size:.75rem;color:var(--text-dim);margin-bottom:6px">' + GM.escape(cfg.choicesLabel || '') + '</div>'
      + '<div style="display:flex;flex-direction:column;gap:4px">'
      + choices.map(function(c, i) {
          return '<label style="display:flex;align-items:center;gap:8px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;cursor:pointer;font-size:.83rem">'
            + '<input type="radio" name="gm-branch-choice" value="' + i + '"' + (i === 0 ? ' checked' : '') + '>'
            + '<span style="flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis' + (c.mono ? ';font-family:monospace' : '') + '">' + GM.escape(c.label) + '</span>'
            + (c.tag ? '<span style="font-size:.68rem;color:var(--text-dim);flex-shrink:0">' + GM.escape(c.tag) + '</span>' : '')
            + '</label>';
        }).join('')
      + '</div>'
      + '<div id="gm-branch-hint" style="font-size:.74rem;line-height:1.45;color:var(--text-dim);margin-top:6px"></div></div>'
      : '<div id="gm-branch-hint" style="font-size:.74rem;line-height:1.45;color:var(--text-dim)"></div>')
    + (cfg.name ? '<div><div style="font-size:.75rem;color:var(--text-dim);margin-bottom:4px">' + t('gm_branch_name') + '</div>'
      + '<input class="s-input" id="gm-branch-name" autocomplete="off" spellcheck="false"' + (cfg.name.readonly ? ' readonly' : '')
      + ' value="' + GM.escape(cfg.name.value || '') + '" style="width:100%;box-sizing:border-box;font-family:monospace' + (cfg.name.readonly ? ';opacity:.7' : '') + '"></div>' : '')
    + '<div id="gm-branch-err" style="color:#f38ba8;font-size:.82rem;display:none;white-space:pre-wrap"></div>'
    + '<div style="display:flex;gap:8px;justify-content:flex-end">'
    + '<button class="s-btn" id="gm-branch-cancel">' + t('gm_cancel') + '</button>'
    + '<button class="s-btn" id="gm-branch-ok" style="background:var(--accent);color:#fff;border-color:var(--accent)">' + GM.escape(cfg.confirmLabel) + '</button>'
    + '</div></div>';
  GM.contentEl.appendChild(overlay);

  var nameInput = overlay.querySelector('#gm-branch-name');
  var hint = overlay.querySelector('#gm-branch-hint');
  var okBtn = overlay.querySelector('#gm-branch-ok');
  var errEl = overlay.querySelector('#gm-branch-err');
  var suggestion = cfg.name ? (cfg.name.value || '') : '';

  function selected() {
    var checked = overlay.querySelector('input[name="gm-branch-choice"]:checked');
    return choices[checked ? parseInt(checked.value, 10) : 0] || {};
  }
  function onChange() {
    var c = selected();
    hint.textContent = c.hint || '';
    if (nameInput && !cfg.name.readonly && cfg.name.suggest) {
      var next = cfg.name.suggest(c) || '';
      if (!nameInput.value.trim() || nameInput.value === suggestion) nameInput.value = next;
      suggestion = next;
      nameInput.focus(); nameInput.select();
    }
  }
  Array.prototype.forEach.call(overlay.querySelectorAll('input[name="gm-branch-choice"]'), function(r) {
    r.addEventListener('change', onChange);
  });
  onChange();

  function close() { overlay.remove(); }
  overlay.querySelector('#gm-branch-cancel').addEventListener('click', close);
  if (nameInput && !cfg.name.readonly) {
    nameInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') confirm();
      else if (e.key === 'Escape') close();
    });
  }
  okBtn.addEventListener('click', confirm);
  if (cfg.disabled) { okBtn.disabled = true; okBtn.style.opacity = '.5'; }

  async function confirm() {
    var name = nameInput ? nameInput.value.trim() : '';
    if (nameInput && !name) { nameInput.focus(); return; }
    okBtn.disabled = true; okBtn.textContent = t('gm_branch_working');
    errEl.style.display = 'none';
    try {
      await cfg.onConfirm(selected(), name);
      close();
    } catch(e) {
      errEl.textContent = e.message; errEl.style.display = 'block';
      okBtn.disabled = false; okBtn.textContent = cfg.confirmLabel;
    }
  }
};

// ── Init ──────────────────────────────────────────────────────────────────────

GM.init = function(body) {
  GM.body = body;

  // Wrapper div вътре в body — height:100% наследява от window manager-а
  body.innerHTML = '<div id="gm-root" style="display:flex;height:100%;overflow:hidden;font-size:.85rem;position:relative">'
    + '<div id="gm-sidebar" class="as-sidebar" style="width:215px;min-width:180px;display:flex;flex-direction:column;border-right:1px solid var(--border);overflow:hidden;flex-shrink:0;background:var(--surface)">'
      + '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 10px 8px 12px;border-bottom:1px solid var(--border);flex-shrink:0">'
        + '<span style="font-size:.72rem;font-weight:600;color:var(--text-dim);letter-spacing:.05em">' + t('gm_repositories') + '</span>'
        + '<button id="gm-refresh" title="' + t('gm_refresh') + '" style="background:none;border:none;cursor:pointer;color:var(--text-dim);font-size:1rem;line-height:1;padding:2px 4px;border-radius:4px">&#x27F3;</button>'
      + '</div>'
      + '<div id="gm-repo-list" style="flex:1;overflow-y:auto"></div>'
      + '<div style="display:flex;gap:6px;padding:8px;border-top:1px solid var(--border);flex-shrink:0">'
        + '<button id="gm-clone-btn" class="s-btn" title="' + t('gm_clone') + '" aria-label="' + t('gm_clone') + '" style="flex:1;font-size:1.15rem;padding:6px 0;line-height:1">&#x2295;</button>'
        + '<button id="gm-init-btn" class="s-btn" title="' + t('gm_init') + '" aria-label="' + t('gm_init') + '" style="flex:1;font-size:1.15rem;padding:6px 0;line-height:1">&#x25CE;</button>'
        + '<button id="gm-ssh-btn" class="s-btn" title="' + t('gm_ssh_keys') + '" aria-label="' + t('gm_ssh_keys') + '" style="flex:1;font-size:1.15rem;padding:6px 0;line-height:1">&#x1F511;</button>'
      + '</div>'
    + '</div>'
    + '<div id="gm-content" style="flex:1;overflow:hidden;display:flex;flex-direction:column;position:relative;min-width:0">'
      + '<div id="gm-content-top" style="display:flex;align-items:center;justify-content:flex-end;gap:2px;padding:3px 6px;border-bottom:1px solid var(--border);flex-shrink:0">'
        + '<button id="gm-term-dock-bottom" title="' + t('gm_terminal_dock_bottom') + '" style="background:none;border:none;cursor:pointer;padding:4px;border-radius:4px;display:flex;color:var(--text-dim)">' + GM.termDockIcon('bottom') + '</button>'
        + '<button id="gm-term-dock-right" title="' + t('gm_terminal_dock_right') + '" style="background:none;border:none;cursor:pointer;padding:4px;border-radius:4px;display:flex;color:var(--text-dim)">' + GM.termDockIcon('right') + '</button>'
      + '</div>'
      + '<div id="gm-content-main" style="flex:1;overflow:hidden;display:flex;min-width:0;min-height:0">'
        + '<div id="gm-view" style="flex:1;overflow:hidden;display:flex;flex-direction:column;min-width:0;min-height:0"></div>'
        + '<div id="gm-term-right" style="display:none;flex:1;min-width:260px;border-left:1px solid var(--border);overflow:hidden;position:relative"></div>'
      + '</div>'
      + '<div id="gm-term-bottom" style="display:none;flex:1;min-height:120px;border-top:1px solid var(--border);overflow:hidden;position:relative"></div>'
      + '<button id="gm-term-fab" title="' + t('gm_terminal') + '" style="display:none;position:absolute;right:14px;bottom:14px;width:46px;height:46px;border-radius:50%;background:var(--accent);color:#fff;border:none;box-shadow:0 2px 10px rgba(0,0,0,.35);font-size:1.35rem;z-index:50;align-items:center;justify-content:center;cursor:pointer">&#x1F5A5;&#xFE0F;</button>'
      + '<div id="gm-term-mobile-overlay" style="display:none;position:absolute;inset:0;background:#0d1117;z-index:60;flex-direction:column">'
        + '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 10px;border-bottom:1px solid var(--border);flex-shrink:0">'
          + '<span style="font-size:.8rem;font-weight:600;color:var(--text-dim)">' + t('gm_terminal') + '</span>'
          + '<button id="gm-term-mobile-close" style="background:none;border:none;color:var(--text-dim);font-size:1.2rem;cursor:pointer;padding:2px 8px;line-height:1">&times;</button>'
        + '</div>'
        + '<div id="gm-term-mobile-body" style="flex:1;position:relative;overflow:hidden"></div>'
      + '</div>'
    + '</div>'
    + '</div>';

  var sidebar = body.querySelector('#gm-sidebar');
  var view = body.querySelector('#gm-view');

  GM.listEl = sidebar.querySelector('#gm-repo-list');
  GM.contentEl = view;

  // Repositories opened from the hidden list stay visible only while this
  // window is open; favorites are stored on the server and always shown.
  GM.state.sessionShown = {};
  GM.state.showOthers = false;
  // Terminal shell processes never survive closing the app, but whether the
  // panel was open and where it was docked is remembered per device via
  // localStorage, so it reopens (with a fresh shell) on the next launch.
  GM.closeAllTerminals();

  sidebar.querySelector('#gm-refresh').addEventListener('click', function() { GM.loadRepos(true); });
  sidebar.querySelector('#gm-clone-btn').addEventListener('click', function() { GM.showClone(); });
  sidebar.querySelector('#gm-init-btn').addEventListener('click', function() { GM.showInit(); });
  sidebar.querySelector('#gm-ssh-btn').addEventListener('click', function() {
    GM.state.activeRepo = null;
    GM.renderSidebar();
    GM.showSSH(GM.contentEl);
    GM.renderTermLayout();
  });

  body.querySelector('#gm-term-dock-bottom').addEventListener('click', function() { GM.toggleTermDock('bottom'); });
  body.querySelector('#gm-term-dock-right').addEventListener('click', function() { GM.toggleTermDock('right'); });
  body.querySelector('#gm-term-fab').addEventListener('click', function() { GM.toggleMobileTerm(); });
  body.querySelector('#gm-term-mobile-close').addEventListener('click', function() { GM.toggleMobileTerm(); });

  // The window manager has no onClose hook, so app-owned cleanup (killing
  // the live terminal shells) has to notice the window leaving the DOM itself.
  if (GM.state.termMutObserver) GM.state.termMutObserver.disconnect();
  GM.state.termMutObserver = new MutationObserver(function() {
    if (!body.isConnected) {
      GM.state.termMutObserver.disconnect();
      GM.closeAllTerminals();
      GM.stopStatusPoll();
    }
  });
  GM.state.termMutObserver.observe(document.body, { childList: true, subtree: true });

  if (GM.state.termResizeObserver) GM.state.termResizeObserver.disconnect();
  GM.state.termResizeObserver = new ResizeObserver(function() {
    var entry = GM.state.activeRepo && GM.state.terminals[GM.state.activeRepo.path];
    if (!entry) return;
    try { entry.fitAddon.fit(); } catch(e) {}
    if (entry.conn.isOpen())
      entry.conn.send(JSON.stringify({ type: 'resize', rows: entry.term.rows, cols: entry.term.cols }));
  });
  GM.state.termResizeObserver.observe(body);

  mvmOS.initMobileSidebar(body);
  GM.showWelcome();
  GM.renderTermLayout();
  GM.loadRepos();
};

// ── Terminal panel ───────────────────────────────────────────────────────────
// One real shell per repository, kept alive (and its scrollback with it) for
// as long as this app window stays open. Switching repos in the sidebar only
// moves the visible terminal's DOM node around — it never tears the process
// down — so coming back to a repo finds its terminal exactly as it was.

GM.isMobile = function() {
  return window.innerWidth < 768 || navigator.maxTouchPoints > 1;
};

GM.shQuote = function(s) {
  return "'" + String(s).replace(/'/g, "'\\''") + "'";
};

GM.termDockIcon = function(pos) {
  var fill = pos === 'right' ? '<rect x="9.5" y="1.5" width="5" height="13" fill="currentColor" opacity=".5"/>'
    : '<rect x="1.5" y="9.5" width="13" height="5" fill="currentColor" opacity=".5"/>';
  return '<svg width="15" height="15" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
    + '<rect x="1.5" y="1.5" width="13" height="13" rx="1.5" stroke="currentColor" stroke-width="1.3"/>'
    + fill + '</svg>';
};

GM.ensureTerminal = function(repo) {
  if (!repo) return null;
  var existing = GM.state.terminals[repo.path];
  if (existing) return existing;

  var wrapper = document.createElement('div');
  wrapper.style.cssText = 'position:absolute;inset:0;padding:4px;box-sizing:border-box;background:#0d1117';

  var term = new window.Terminal({
    fontFamily: "'Consolas', 'Menlo', 'Courier New', monospace",
    fontSize: 13,
    lineHeight: 1.2,
    theme: {
      background: '#0d1117', foreground: '#c9d1d9', cursor: '#c9d1d9',
      black: '#0d1117', red: '#ff5555', green: '#50fa7b',
      yellow: '#f1fa8c', blue: '#6272a4', magenta: '#ff79c6',
      cyan: '#8be9fd', white: '#f8f8f2',
    },
    cursorBlink: true,
    scrollback: 5000,
    allowProposedApi: true,
  });
  var fitAddon = new window.FitAddon.FitAddon();
  term.loadAddon(fitAddon);
  term.open(wrapper);

  var conn = GM.connectShell({
    onOpen: function(again) {
      if (again) term.write('\r\n\x1b[32m[' + t('gm_term_reconnected') + ']\x1b[0m\r\n');
      try { fitAddon.fit(); } catch(e) {}
      conn.send(JSON.stringify({ type: 'resize', rows: term.rows, cols: term.cols }));
      // Give the login shell a moment to settle before dropping it straight
      // into the repo, the same way it would if typed by hand. A reconnect
      // keeps the screen, so what was there before the drop stays readable.
      setTimeout(function() {
        if (conn.isOpen())
          conn.send(new TextEncoder().encode('cd ' + GM.shQuote(repo.path) + (again ? '' : ' && clear') + '\n'));
      }, 400);
    },
    onMessage: function(data) {
      term.write(data instanceof ArrayBuffer ? new Uint8Array(data) : data);
    },
    onLost: function() {
      term.write('\r\n\x1b[33m[' + t('gm_term_reconnecting') + ']\x1b[0m\r\n');
    },
  });

  var entry = { conn: conn, term: term, fitAddon: fitAddon, wrapper: wrapper };
  GM.state.terminals[repo.path] = entry;

  term.onData(function(data) { conn.send(new TextEncoder().encode(data)); });

  return entry;
};

// The connection to a shell can drop at any moment (the computer sleeps, the
// network changes, the server restarts) and would stay dead until the app is
// reopened. It reconnects on its own with a growing pause, and at once when
// the terminal is typed in, the tab comes back or the network returns. The
// shell behind a reconnect is always a new one.
GM.connectShell = function(h) {
  var proto = location.protocol === 'https:' ? 'wss' : 'ws';
  var ws = null, timer = null, retry = 0, everOpened = false, closed = false;

  function connect() {
    clearTimeout(timer);
    timer = null;
    ws = new WebSocket(proto + '://' + location.host + '/ws/terminal');
    ws.binaryType = 'arraybuffer';
    ws.onopen = function() {
      retry = 0;
      h.onOpen(everOpened);
      everOpened = true;
    };
    ws.onmessage = function(e) { h.onMessage(e.data); };
    ws.onclose = function() {
      if (closed) return;
      if (retry === 0) h.onLost();
      timer = setTimeout(connect, Math.min(30000, 1000 * Math.pow(2, retry++)));
    };
  }

  function wake() {
    if (closed || !ws) return;
    if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) return;
    connect();
  }
  function onVisible() { if (!document.hidden) wake(); }
  window.addEventListener('online', wake);
  document.addEventListener('visibilitychange', onVisible);
  connect();

  return {
    isOpen: function() { return ws.readyState === WebSocket.OPEN; },
    send: function(data) {
      if (ws.readyState === WebSocket.OPEN) ws.send(data);
      else wake();
    },
    close: function() {
      closed = true;
      clearTimeout(timer);
      window.removeEventListener('online', wake);
      document.removeEventListener('visibilitychange', onVisible);
      ws.onclose = ws.onmessage = null;
      ws.close();
    },
  };
};

GM.closeTerminal = function(path) {
  var entry = GM.state.terminals[path];
  if (!entry) return;
  delete GM.state.terminals[path];
  try { entry.conn.close(); } catch(e) {}
  try { entry.term.dispose(); } catch(e) {}
  if (entry.wrapper.parentNode) entry.wrapper.parentNode.removeChild(entry.wrapper);
};

GM.closeAllTerminals = function() {
  Object.keys(GM.state.terminals).forEach(GM.closeTerminal);
};

// Files changed by the terminal (e.g. a Claude Code session or any other
// shell command) never notify the app, so the open repo's status is polled
// while its view is visible — the only way to notice them without a manual
// refresh. Stopped whenever the view changes so at most one poll ever runs.
GM.stopStatusPoll = function() {
  if (GM.state.statusPollInterval) {
    clearInterval(GM.state.statusPollInterval);
    GM.state.statusPollInterval = null;
  }
};

GM.updateTermDockButtons = function() {
  ['bottom', 'right'].forEach(function(pos) {
    var btn = GM.body.querySelector('#gm-term-dock-' + pos);
    if (!btn) return;
    var active = GM.state.termOpen && GM.state.termPos === pos;
    btn.style.color = active ? 'var(--accent)' : 'var(--text-dim)';
    btn.style.background = active ? 'var(--accent-dim,rgba(99,102,241,.15))' : 'none';
    var disabled = !GM.state.activeRepo;
    btn.disabled = disabled;
    btn.style.opacity = disabled ? '.35' : '1';
    btn.style.cursor = disabled ? 'default' : 'pointer';
  });
};

// Detaches every live terminal from wherever it is mounted, then reattaches
// only the one that should currently be visible (if any) — the single place
// that decides what the panel looks like, on desktop and on mobile alike.
GM.renderTermLayout = function() {
  if (!GM.body) return;
  var bottom = GM.body.querySelector('#gm-term-bottom');
  var right = GM.body.querySelector('#gm-term-right');
  var overlay = GM.body.querySelector('#gm-term-mobile-overlay');
  var mbody = GM.body.querySelector('#gm-term-mobile-body');
  var fab = GM.body.querySelector('#gm-term-fab');
  var topbar = GM.body.querySelector('#gm-content-top');
  if (!bottom || !right || !overlay || !mbody) return;

  Object.keys(GM.state.terminals).forEach(function(path) {
    var entry = GM.state.terminals[path];
    if (entry.wrapper.parentNode) entry.wrapper.parentNode.removeChild(entry.wrapper);
  });

  var mobile = GM.isMobile();
  bottom.style.display = 'none';
  right.style.display = 'none';
  overlay.style.display = 'none';
  if (topbar) topbar.style.display = mobile ? 'none' : 'flex';
  if (fab) fab.style.display = mobile && GM.state.activeRepo ? 'flex' : 'none';

  if (GM.state.termOpen && GM.state.activeRepo) {
    var entry = GM.ensureTerminal(GM.state.activeRepo);
    var slot;
    if (mobile) { overlay.style.display = 'flex'; slot = mbody; }
    else { slot = GM.state.termPos === 'right' ? right : bottom; slot.style.display = 'block'; }
    slot.appendChild(entry.wrapper);
    requestAnimationFrame(function() {
      try { entry.fitAddon.fit(); } catch(e) {}
      if (entry.conn.isOpen())
        entry.conn.send(JSON.stringify({ type: 'resize', rows: entry.term.rows, cols: entry.term.cols }));
      entry.term.focus();
    });
  }

  GM.updateTermDockButtons();
};

GM.toggleTermDock = function(pos) {
  if (GM.state.termOpen && GM.state.termPos === pos) {
    GM.state.termOpen = false;
  } else {
    GM.state.termPos = pos;
    GM.state.termOpen = true;
    localStorage.setItem('gm_term_pos', pos);
  }
  localStorage.setItem('gm_term_open', GM.state.termOpen ? '1' : '0');
  GM.renderTermLayout();
};

GM.toggleMobileTerm = function() {
  GM.state.termOpen = !GM.state.termOpen;
  localStorage.setItem('gm_term_open', GM.state.termOpen ? '1' : '0');
  GM.renderTermLayout();
};

// ── Sidebar ───────────────────────────────────────────────────────────────────

GM.showWelcome = function() {
  GM.contentEl.innerHTML = '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;gap:10px;color:var(--text-dim)">'
    + '<div style="font-size:2.5rem;opacity:.4">&#x1F500;</div>'
    + '<div style="font-size:.85rem;opacity:.5">' + t('gm_select_repo') + '</div>'
    + '</div>';
};

GM.showLoading = function(msg) {
  GM.listEl.innerHTML = '<div style="padding:14px 10px;color:var(--text-dim);font-size:.8rem;text-align:center;opacity:.7">' + (msg || t('gm_scanning')) + '</div>';
};

GM.isPinned = function(repo) {
  return repo.favorite || !!GM.state.sessionShown[repo.path];
};

// Git state is read for favorites and repositories opened this session, or for
// all of them while the hidden list is expanded. scan=true also searches the
// disk for new repositories, which is the slow part.
GM.loadRepos = async function(scan) {
  GM.showLoading(t('gm_scanning'));
  try {
    var params = Object.keys(GM.state.sessionShown).map(function(p) { return 'extra=' + encodeURIComponent(p); });
    if (GM.state.showOthers) params.push('all=1');
    if (scan) params.push('scan=1');
    var query = '?' + params.join('&');
    var _reposData = await GM.api('/repos' + query);
    GM.state.currentUser = _reposData.current_user || '';
    GM.state.foreignAccess = _reposData.foreign_access || {};
    GM.state.repos = _reposData.repos || _reposData;
    // Without any favorites there is nothing to show on top, so the full list opens.
    if (!GM.state.showOthers && !GM.state.repos.some(GM.isPinned) && GM.state.repos.length) {
      GM.state.showOthers = true;
      return GM.loadRepos();
    }
    GM.renderSidebar();
    if (GM.state.activeRepo) {
      var still = GM.state.repos.filter(function(r) { return r.path === GM.state.activeRepo.path; })[0];
      if (still) {
        GM.state.activeRepo = still;
        if (!still.locked && !still.detailed) {
          GM.state.sessionShown[still.path] = true;
          return GM.loadRepos();
        }
        if (still.locked) GM.showLockedRepo(GM.contentEl, still);
        else GM.showRepoView(GM.contentEl, still);
      }
    }
  } catch(e) {
    GM.listEl.innerHTML = '<div style="padding:14px 10px;color:#f38ba8;font-size:.8rem">' + GM.escape(e.message) + '</div>';
  }
};

// The name a repository is shown under: the user's own alias when set,
// otherwise its folder name. Only ever visual — see GM.renameRepo.
GM.repoLabel = function(repo) {
  return repo.alias || repo.name;
};

GM.repoItem = function(repo) {
  var active = GM.state.activeRepo && GM.state.activeRepo.path === repo.path;
  var item = document.createElement('div');
  item.style.cssText = 'padding:7px 6px 7px 12px;cursor:pointer;border-bottom:1px solid var(--border);'
    + (repo.locked ? 'opacity:.62;' : '')
    + (active ? 'background:var(--accent-dim,rgba(99,102,241,.15))' : '');
  item.dataset.gmPath = repo.path;
  var sub = repo.locked ? t('gm_owned_by', { owner: GM.escape(repo.owner) })
    : repo.detailed ? '&#x1F33F; ' + GM.escape(repo.branch) : '&nbsp;';
  item.innerHTML = '<div style="display:flex;align-items:center;gap:5px">'
    + '<span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500;font-size:.83rem;pointer-events:none">' + GM.escape(GM.repoLabel(repo)) + '</span>'
    + (repo.locked ? '<span style="font-size:.72rem;flex-shrink:0;pointer-events:none" title="' + t('gm_locked') + '">&#x1F512;</span>' : '')
    + (repo.changes > 0 ? '<span class="gm-repo-badge" style="font-size:.68rem;background:var(--accent);color:#fff;border-radius:10px;padding:1px 5px;flex-shrink:0;pointer-events:none">' + repo.changes + '</span>' : '')
    + '<button class="gm-rename" data-gm-rename="' + GM.escape(repo.path) + '" title="' + t('gm_edit_repo') + '" style="background:none;border:none;cursor:pointer;padding:0 2px;font-size:.8rem;line-height:1;flex-shrink:0;color:var(--text-dim);opacity:.45">&#x270E;</button>'
    + '<button class="gm-fav" data-gm-fav="' + GM.escape(repo.path) + '" title="' + t(repo.favorite ? 'gm_favorite_remove' : 'gm_favorite_add') + '" style="background:none;border:none;cursor:pointer;padding:0 3px;font-size:.9rem;line-height:1;flex-shrink:0;color:' + (repo.favorite ? '#f9e2af' : 'var(--text-dim)') + ';opacity:' + (repo.favorite ? '1' : '.45') + '">' + (repo.favorite ? '&#x2605;' : '&#x2606;') + '</button>'
    + '</div>'
    + '<div style="font-size:.72rem;color:var(--text-dim);margin-top:2px;pointer-events:none">' + sub + '</div>'
    // rtl keeps the end of a long path (the folder's own name) visible and
    // cuts the start; the &lrm; marks stop the leading "/" jumping to the end.
    + '<div title="' + GM.escape(repo.path) + '" style="font-size:.72rem;color:var(--text-dim);margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;direction:rtl;text-align:left">&lrm;' + GM.escape(repo.path) + '&lrm;</div>';
  return item;
};

GM.updateRepoBadge = function(repo) {
  var item = GM.listEl.querySelector('[data-gm-path="' + repo.path.replace(/"/g, '\\"') + '"]');
  if (!item) return;
  var row = item.firstChild;
  var badge = row.querySelector('.gm-repo-badge');
  if (repo.changes > 0) {
    if (!badge) {
      badge = document.createElement('span');
      badge.className = 'gm-repo-badge';
      badge.style.cssText = 'font-size:.68rem;background:var(--accent);color:#fff;border-radius:10px;padding:1px 5px;flex-shrink:0;pointer-events:none';
      row.insertBefore(badge, row.querySelector('.gm-fav'));
    }
    badge.textContent = repo.changes;
  } else if (badge) {
    badge.remove();
  }
};

GM.renderSidebar = function() {
  var list = GM.listEl;
  list.innerHTML = '';
  if (!GM.state.repos.length) {
    list.innerHTML = '<div style="padding:14px 10px;color:var(--text-dim);font-size:.8rem;text-align:center;opacity:.7">' + t('gm_no_repos') + '</div>';
    return;
  }
  var byFavorite = function(a, b) { return (b.favorite ? 1 : 0) - (a.favorite ? 1 : 0); };
  var pinned = GM.state.repos.filter(GM.isPinned).sort(byFavorite);
  var others = GM.state.repos.filter(function(r) { return !GM.isPinned(r); });

  pinned.forEach(function(repo) { list.appendChild(GM.repoItem(repo)); });
  if (!pinned.length) {
    var hint = document.createElement('div');
    hint.style.cssText = 'padding:10px 12px;color:var(--text-dim);font-size:.74rem;line-height:1.4;opacity:.8;border-bottom:1px solid var(--border)';
    hint.innerHTML = t('gm_favorites_hint');
    list.appendChild(hint);
  }
  if (others.length) {
    var toggle = document.createElement('div');
    toggle.id = 'gm-others-toggle';
    toggle.style.cssText = 'padding:7px 12px;cursor:pointer;font-size:.74rem;font-weight:600;color:var(--text-dim);border-bottom:1px solid var(--border);user-select:none;background:var(--surface2,#313244)';
    toggle.innerHTML = (GM.state.showOthers ? '&#x25BE; ' : '&#x25B8; ') + t('gm_other_repos', { n: others.length });
    list.appendChild(toggle);
    if (GM.state.showOthers) others.forEach(function(repo) { list.appendChild(GM.repoItem(repo)); });
  }

  // Event delegation — един listener на целия list
  list.onclick = function(e) {
    if (e.target.closest('#gm-others-toggle')) {
      GM.state.showOthers = !GM.state.showOthers;
      if (GM.state.showOthers) GM.loadRepos();
      else GM.renderSidebar();
      return;
    }
    var fav = e.target.closest('[data-gm-fav]');
    if (fav) {
      e.stopPropagation();
      GM.toggleFavorite(fav.dataset.gmFav);
      return;
    }
    var rename = e.target.closest('[data-gm-rename]');
    if (rename) {
      e.stopPropagation();
      GM.renameRepo(rename.dataset.gmRename);
      return;
    }
    var item = e.target.closest('[data-gm-path]');
    if (!item) return;
    var repo = GM.state.repos.filter(function(r) { return r.path === item.dataset.gmPath; })[0];
    if (!repo) return;
    GM.openRepo(repo);
  };
};

GM.openRepo = function(repo) {
  GM.state.activeRepo = repo;
  if (!GM.isPinned(repo)) GM.state.sessionShown[repo.path] = true;
  // Picking any repository collapses the hidden list so it stays out of the way.
  GM.state.showOthers = false;
  GM.renderSidebar();
  if (repo.locked) GM.showLockedRepo(GM.contentEl, repo);
  else if (!repo.detailed) GM.loadRepos();
  else GM.showRepoView(GM.contentEl, repo, true);
  GM.renderTermLayout();
};

GM.toggleFavorite = async function(path) {
  var repo = GM.state.repos.filter(function(r) { return r.path === path; })[0];
  if (!repo) return;
  var favorite = !repo.favorite;
  try {
    await GM.api('/repos/favorite', { method: 'POST', json: { path: path, favorite: favorite } });
    repo.favorite = favorite;
    // Un-starring the open repository keeps it visible for the rest of the session.
    if (!favorite && GM.state.activeRepo && GM.state.activeRepo.path === path) GM.state.sessionShown[path] = true;
    GM.renderSidebar();
  } catch(e) {
    mvmOS.notify(t('gm_title'), e.message);
  }
};

// The repository's own settings in this window: the name it is shown under
// (only visual — the folder and the repository keep their real name) and the
// command its Deploy button runs. Entering the real name back shows the folder
// name again; an empty command hides the Deploy button.
GM.renameRepo = function(path) {
  var repo = GM.state.repos.filter(function(r) { return r.path === path; })[0];
  if (!repo) return;
  var overlay = document.createElement('div');
  overlay.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:99;padding:16px;box-sizing:border-box';
  overlay.innerHTML = '<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:20px;width:440px;max-width:100%;box-sizing:border-box;display:flex;flex-direction:column;gap:12px">'
    + '<div style="font-weight:600;font-size:.95rem">&#x270E; ' + t('gm_edit_repo') + '</div>'
    + '<div><div style="font-size:.75rem;color:var(--text-dim);margin-bottom:4px">' + t('gm_repo_display_name') + '</div>'
    + '<input class="s-input" id="gm-edit-alias" style="width:100%;box-sizing:border-box">'
    + '<div style="font-size:.72rem;color:var(--text-dim);margin-top:4px;line-height:1.45">' + t('gm_repo_display_name_hint', { name: GM.escape(repo.name) }) + '</div></div>'
    + '<div><div style="font-size:.75rem;color:var(--text-dim);margin-bottom:4px">' + t('gm_deploy_command') + ' <span style="opacity:.6">' + t('gm_optional') + '</span></div>'
    + '<input class="s-input" id="gm-edit-deploy" placeholder="php artisan deploy" spellcheck="false" autocomplete="off" style="width:100%;box-sizing:border-box;font-family:monospace">'
    + '<div style="font-size:.72rem;color:var(--text-dim);margin-top:4px;line-height:1.45">' + t('gm_deploy_command_hint') + '</div></div>'
    + '<div id="gm-edit-err" style="color:#f38ba8;font-size:.82rem;display:none"></div>'
    + '<div style="display:flex;gap:8px;justify-content:flex-end">'
    + '<button class="s-btn" id="gm-edit-cancel">' + t('gm_cancel') + '</button>'
    + '<button class="s-btn" id="gm-edit-ok" style="background:var(--accent);color:#fff;border-color:var(--accent)">' + t('gm_save') + '</button>'
    + '</div></div>';
  GM.contentEl.appendChild(overlay);
  var aliasInput = overlay.querySelector('#gm-edit-alias');
  var deployInput = overlay.querySelector('#gm-edit-deploy');
  aliasInput.value = GM.repoLabel(repo);
  deployInput.value = repo.deploy || '';
  aliasInput.focus(); aliasInput.select();
  overlay.querySelector('#gm-edit-cancel').addEventListener('click', function() { overlay.remove(); });

  var save = async function() {
    var btn = overlay.querySelector('#gm-edit-ok');
    var errEl = overlay.querySelector('#gm-edit-err');
    var value = aliasInput.value.trim();
    btn.disabled = true;
    try {
      var res = await GM.api('/repos/settings', { method: 'POST', json: {
        path: path, alias: value === repo.name ? '' : value, deploy: deployInput.value.trim() } });
      overlay.remove();
      repo.alias = res.alias;
      repo.deploy = res.deploy;
      GM.renderSidebar();
      // Only the title and the Deploy button change, so an open commit
      // message or tab survives.
      if (GM.state.activeRepo && GM.state.activeRepo.path === path) {
        var title = GM.contentEl.querySelector('.gm-repo-title');
        if (title) title.textContent = GM.repoLabel(repo);
        var deployBtn = GM.contentEl.querySelector('#gm-deploy');
        if (deployBtn) {
          deployBtn.style.display = repo.deploy ? '' : 'none';
          deployBtn.title = repo.deploy || '';
        }
      }
    } catch(e) {
      errEl.textContent = e.message; errEl.style.display = 'block';
      btn.disabled = false;
    }
  };
  overlay.querySelector('#gm-edit-ok').addEventListener('click', save);
  [aliasInput, deployInput].forEach(function(input) {
    input.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') save();
      else if (e.key === 'Escape') overlay.remove();
    });
  });
};

// Deploy runs the repository's command in a shell of its own, never in the
// repository's terminal: that one may be busy with anything (an editor, a
// Claude Code session) and the command would be typed into it. The window
// stays interactive, so a command that asks for confirmation or a password
// can be answered, and the output stays until the window is closed. Closing
// it ends the shell, and with it a command that is still running.
GM.runDeploy = async function(repo, onClose) {
  if (!repo || !repo.deploy) return;
  var ok = await mvmOS.confirm(t('gm_deploy_confirm', {
    command: '<code>' + GM.escape(repo.deploy) + '</code>', name: '<strong>' + GM.escape(GM.repoLabel(repo)) + '</strong>' }));
  if (!ok) return;

  var overlay = document.createElement('div');
  overlay.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:99;padding:16px;box-sizing:border-box';
  overlay.innerHTML = '<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;width:900px;max-width:100%;height:560px;max-height:100%;box-sizing:border-box;display:flex;flex-direction:column;overflow:hidden">'
    + '<div style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--border)">'
    + '<div style="flex:1;min-width:0"><div style="font-weight:600;font-size:.9rem">&#x1F680; ' + t('gm_deploy') + ' · ' + GM.escape(GM.repoLabel(repo)) + '</div>'
    + '<div style="font-size:.72rem;color:var(--text-dim);font-family:monospace;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + GM.escape(repo.deploy) + '</div></div>'
    + '<button class="s-btn s-btn-sm" id="gm-deploy-close">' + t('gm_close') + '</button></div>'
    + '<div style="flex:1;position:relative;background:#0d1117;min-height:0"><div id="gm-deploy-term" style="position:absolute;inset:0;padding:4px;box-sizing:border-box"></div></div>'
    + '</div>';
  GM.contentEl.appendChild(overlay);

  var term = new window.Terminal({
    fontFamily: "'Consolas', 'Menlo', 'Courier New', monospace",
    fontSize: 13,
    lineHeight: 1.2,
    theme: {
      background: '#0d1117', foreground: '#c9d1d9', cursor: '#c9d1d9',
      black: '#0d1117', red: '#ff5555', green: '#50fa7b',
      yellow: '#f1fa8c', blue: '#6272a4', magenta: '#ff79c6',
      cyan: '#8be9fd', white: '#f8f8f2',
    },
    cursorBlink: true,
    scrollback: 5000,
    allowProposedApi: true,
  });
  var fitAddon = new window.FitAddon.FitAddon();
  term.loadAddon(fitAddon);
  term.open(overlay.querySelector('#gm-deploy-term'));
  var fit = function() {
    try { fitAddon.fit(); } catch(e) {}
    if (conn && conn.isOpen()) conn.send(JSON.stringify({ type: 'resize', rows: term.rows, cols: term.cols }));
  };

  var command = repo.deploy;
  var conn = GM.connectShell({
    onOpen: function(again) {
      fit();
      // A reconnect is a new shell. The deploy already ran (or was cut off)
      // in the old one, so it is never started a second time on its own;
      // the new shell only goes back to the repository to run it by hand.
      if (again) term.write('\r\n\x1b[33m[' + t('gm_deploy_reconnected') + ']\x1b[0m\r\n');
      setTimeout(function() {
        if (conn.isOpen())
          conn.send(new TextEncoder().encode('cd ' + GM.shQuote(repo.path) + (again ? '' : ' && clear && ' + command) + '\n'));
      }, 400);
    },
    onMessage: function(data) {
      term.write(data instanceof ArrayBuffer ? new Uint8Array(data) : data);
    },
    onLost: function() {
      term.write('\r\n\x1b[33m[' + t('gm_term_reconnecting') + ']\x1b[0m\r\n');
    },
  });
  term.onData(function(data) { conn.send(new TextEncoder().encode(data)); });
  var onResize = function() { fit(); };
  window.addEventListener('resize', onResize);
  requestAnimationFrame(function() { fit(); term.focus(); });

  overlay.querySelector('#gm-deploy-close').addEventListener('click', function() {
    window.removeEventListener('resize', onResize);
    try { conn.close(); } catch(e) {}
    try { term.dispose(); } catch(e) {}
    overlay.remove();
    // The command usually pulls and may change files, so the view is refreshed.
    if (onClose) onClose();
  });
};

GM.showLockedRepo = function(container, repo) {
  GM.stopStatusPoll();
  var access = GM.state.foreignAccess || {};
  container.innerHTML = '<div style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--border);background:var(--surface)">'
    + '<div style="flex:1;min-width:0"><div class="gm-repo-title" style="font-weight:600;font-size:.9rem">' + GM.escape(GM.repoLabel(repo)) + '</div>'
    + '<div style="font-size:.72rem;color:var(--text-dim);margin-top:1px">' + t('gm_owned_by', { owner: repo.owner }) + '</div></div>'
    + '<span style="font-size:.75rem;background:var(--surface2,#313244);border-radius:12px;padding:3px 9px">&#x1F512; ' + t('gm_locked') + '</span></div>'
    + '<div style="flex:1;display:flex;align-items:center;justify-content:center;padding:24px">'
    + '<div style="max-width:480px;text-align:center;display:flex;flex-direction:column;align-items:center;gap:12px">'
    + '<div style="font-size:2.8rem;opacity:.65">&#x1F512;</div>'
    + '<div style="font-size:1rem;font-weight:700">' + t('gm_foreign_locked_title') + '</div>'
    + '<div style="font-size:.84rem;line-height:1.55;color:var(--text-dim)">' + t('gm_foreign_locked_body', { owner: repo.owner }) + '</div>'
    + (access.premium ? '' : '<div style="font-size:.78rem;line-height:1.5;color:var(--text-dim);padding:8px 12px;background:var(--surface2,#313244);border-radius:7px">' + t('gm_foreign_switch_profile', { owner: repo.owner }) + '</div>')
    + '<div id="gm-unlock-error" style="font-size:.8rem;color:#f38ba8;min-height:18px"></div>'
    + '<button id="gm-unlock-all" class="s-btn s-btn-sm" style="background:var(--accent);color:#fff;border-color:var(--accent)">'
    + (access.premium ? '&#x1F513; ' + t('gm_unlock_all') : '&#x1F48E; ' + t('gm_unlock_premium')) + '</button>'
    + '</div></div>';
  container.style.display = 'flex';
  container.style.flexDirection = 'column';

  var btn = container.querySelector('#gm-unlock-all');
  var err = container.querySelector('#gm-unlock-error');
  if (!access.premium) {
    btn.addEventListener('click', function() {
      window.dispatchEvent(new CustomEvent('open-subscription-settings'));
    });
    if (window.mvmOS && window.mvmOS.premiumGate) {
      window.mvmOS.premiumGate(btn, t('gm_foreign_premium_info'));
    }
    return;
  }
  if (!access.can_unlock) {
    btn.disabled = true;
    btn.style.opacity = '.5';
    err.textContent = t('gm_unlock_no_sudo');
    return;
  }
  btn.addEventListener('click', async function() {
    var password = await mvmOS.confirmPassword(t('gm_unlock_title'), t('gm_unlock_password_info'));
    if (!password) return;
    btn.disabled = true;
    btn.textContent = t('gm_unlocking');
    err.textContent = '';
    try {
      await GM.api('/repo/unlock', { method: 'POST', json: { password: password } });
      mvmOS.notify(t('gm_title'), t('gm_unlocked_all'));
      await GM.loadRepos();
    } catch(e) {
      err.textContent = e.message;
      btn.disabled = false;
      btn.innerHTML = '&#x1F513; ' + t('gm_unlock_all');
    }
  });
};

// ── Clone dialog ──────────────────────────────────────────────────────────────

GM.showClone = function() {
  var overlay = document.createElement('div');
  overlay.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:99';
  overlay.innerHTML = '<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:20px;width:380px;display:flex;flex-direction:column;gap:12px">'
    + '<div style="font-weight:600;font-size:.95rem">' + t('gm_clone_repo_title') + '</div>'
    + '<div><div style="font-size:.75rem;color:var(--text-dim);margin-bottom:4px">' + t('gm_repo_url') + '</div>'
    + '<input class="s-input" id="gm-clone-url" placeholder="git@github.com:user/repo.git" style="width:100%;box-sizing:border-box"></div>'
    + '<div><div style="font-size:.75rem;color:var(--text-dim);margin-bottom:4px">' + t('gm_dest_dir') + '</div>'
    + '<input class="s-input" id="gm-clone-dest" value="/var/www" style="width:100%;box-sizing:border-box"></div>'
    + '<div id="gm-clone-err" style="color:#f38ba8;font-size:.82rem;display:none"></div>'
    + '<div style="display:flex;gap:8px;justify-content:flex-end">'
    + '<button class="s-btn" id="gm-clone-cancel">' + t('gm_cancel') + '</button>'
    + '<button class="s-btn" id="gm-clone-ok" style="background:var(--accent);color:#fff;border-color:var(--accent)">' + t('gm_clone') + '</button>'
    + '</div></div>';
  GM.contentEl.appendChild(overlay);
  overlay.querySelector('#gm-clone-url').focus();
  overlay.querySelector('#gm-clone-cancel').addEventListener('click', function() { overlay.remove(); });

  var doClone = async function() {
    var url = overlay.querySelector('#gm-clone-url').value.trim();
    var dest = overlay.querySelector('#gm-clone-dest').value.trim();
    var errEl = overlay.querySelector('#gm-clone-err');
    var btn = overlay.querySelector('#gm-clone-ok');
    if (!url) { errEl.textContent = t('gm_url_required'); errEl.style.display = 'block'; return; }
    btn.textContent = t('gm_cloning'); btn.disabled = true;
    try {
      var r = await GM.api('/repo/clone', { method: 'POST', json: { url: url, dest: dest } });
      overlay.remove();
      var clonedName = url.replace(/\/+$/, '').split(/[\/:]/).pop().replace(/\.git$/, '');
      if (clonedName) GM.state.sessionShown[dest.replace(/\/+$/, '') + '/' + clonedName] = true;
      GM.loadRepos(true);
      mvmOS.notify(t('gm_title'), r.output || t('gm_cloned_ok'));
    } catch(e) {
      errEl.textContent = e.message; errEl.style.display = 'block';
      btn.textContent = t('gm_clone'); btn.disabled = false;
    }
  };

  overlay.querySelector('#gm-clone-ok').addEventListener('click', doClone);
  overlay.querySelector('#gm-clone-url').addEventListener('keydown', function(e) { if (e.key === 'Enter') doClone(); });
};

// ── Init dialog ───────────────────────────────────────────────────────────────

GM.showInit = function() {
  var overlay = document.createElement('div');
  overlay.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:99';
  overlay.innerHTML = '<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:20px;width:380px;display:flex;flex-direction:column;gap:12px">'
    + '<div style="font-weight:600;font-size:.95rem">&#x25CE; ' + t('gm_init_repo_title') + '</div>'
    + '<div><div style="font-size:.75rem;color:var(--text-dim);margin-bottom:4px">' + t('gm_dir_path') + '</div>'
    + '<input class="s-input" id="gm-init-path" placeholder="/var/www/my-project" style="width:100%;box-sizing:border-box"></div>'
    + '<div><div style="font-size:.75rem;color:var(--text-dim);margin-bottom:4px">' + t('gm_remote_url') + ' <span style="opacity:.6">' + t('gm_optional') + '</span></div>'
    + '<input class="s-input" id="gm-init-remote" placeholder="git@github.com:user/repo.git" style="width:100%;box-sizing:border-box"></div>'
    + '<div id="gm-init-err" style="color:#f38ba8;font-size:.82rem;display:none"></div>'
    + '<div style="display:flex;gap:8px;justify-content:flex-end">'
    + '<button class="s-btn" id="gm-init-cancel">' + t('gm_cancel') + '</button>'
    + '<button class="s-btn" id="gm-init-ok" style="background:var(--accent);color:#fff;border-color:var(--accent)">' + t('gm_init') + '</button>'
    + '</div></div>';
  GM.contentEl.appendChild(overlay);
  overlay.querySelector('#gm-init-path').focus();
  overlay.querySelector('#gm-init-cancel').addEventListener('click', function() { overlay.remove(); });

  var doInit = async function() {
    var path = overlay.querySelector('#gm-init-path').value.trim();
    var remote = overlay.querySelector('#gm-init-remote').value.trim();
    var errEl = overlay.querySelector('#gm-init-err');
    var btn = overlay.querySelector('#gm-init-ok');
    if (!path) { errEl.textContent = t('gm_dir_path_required'); errEl.style.display = 'block'; return; }
    btn.textContent = t('gm_initializing'); btn.disabled = true;
    try {
      var r = await GM.api('/repo/init', { method: 'POST', json: { path: path, remote: remote } });
      overlay.remove();
      GM.state.sessionShown[path.replace(/\/+$/, '')] = true;
      GM.loadRepos(true);
      mvmOS.notify(t('gm_title'), r.output || t('gm_initialized_ok', { path: path }));
    } catch(e) {
      errEl.textContent = e.message; errEl.style.display = 'block';
      btn.textContent = t('gm_init'); btn.disabled = false;
    }
  };

  overlay.querySelector('#gm-init-ok').addEventListener('click', doInit);
  overlay.querySelector('#gm-init-path').addEventListener('keydown', function(e) { if (e.key === 'Enter') doInit(); });
};

// ── Repo view ─────────────────────────────────────────────────────────────────

GM.showRepoView = function(container, repo, autoFetch) {
  GM.stopStatusPoll();
  var tab = 'status';
  var lastStatusSignature = null;
  var templateHintOpen = false;
  var defaultBranch = '';

  container.innerHTML = '<div style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--border);flex-shrink:0;background:var(--surface)">'
    + '<div style="flex:1;min-width:0">'
    + '<div class="gm-repo-title" style="font-weight:600;font-size:.9rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + GM.escape(GM.repoLabel(repo)) + '</div>'
    + '<div style="font-size:.72rem;color:var(--text-dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:1px">' + (repo.remote || '') + '</div>'
    + '</div>'
    + '<span id="gm-branch-btn" style="font-size:.75rem;background:var(--surface2,#313244);border-radius:12px;padding:2px 9px;white-space:nowrap;flex-shrink:0;cursor:pointer;user-select:none" title="' + t('gm_switch_branch') + '">&#x1F33F; ' + repo.branch + ' &#x25BE;</span>'
    + '<span id="gm-branch-local-badge" style="display:none;font-size:.68rem;background:#f9e2af;color:#1e1e2e;border-radius:10px;padding:1px 7px;flex-shrink:0;font-weight:600" title="' + t('gm_branch_local_only') + '">' + t('gm_branch_local_only') + '</span>'
    + '</div>'
    + '<div style="display:flex;flex-wrap:wrap;align-items:center;gap:6px;padding:8px 14px;border-bottom:1px solid var(--border);flex-shrink:0">'
    + '<button id="gm-deploy" class="s-btn s-btn-sm" title="' + GM.escape(repo.deploy || '') + '"' + (repo.deploy ? '' : ' style="display:none"') + '>&#x1F680; ' + t('gm_deploy') + '</button>'
    + '<button id="gm-pull" class="s-btn s-btn-sm">&#x2B07; ' + t('gm_pull') + '</button>'
    + '<button id="gm-push" class="s-btn s-btn-sm">&#x2B06; ' + t('gm_push') + '</button>'
    + '<button id="gm-fetch" class="s-btn s-btn-sm">&#x27F3; ' + t('gm_fetch') + '</button>'
    + '<button id="gm-new-branch" class="s-btn s-btn-sm">&#x2295; ' + t('gm_branch_new') + '</button>'
    + '<button id="gm-issues" class="s-btn s-btn-sm">'
    + ((GM.state.foreignAccess || {}).premium ? '&#x25C9; ' : '&#x1F48E; ') + t('gm_issues') + '</button>'
    + '<button id="gm-pr-toolbar" class="s-btn s-btn-sm" style="display:none">'
    + ((GM.state.foreignAccess || {}).premium ? '&#x1F500; ' : '&#x1F48E; ') + t('gm_issues_pull_request') + '</button>'
    + '<div id="gm-sync-info" style="font-size:.75rem;color:var(--text-dim);margin-left:4px"></div>'
    + '<div style="display:flex;border:1px solid var(--border);border-radius:6px;overflow:hidden;margin-left:auto;flex-shrink:0">'
    + '<button id="gm-tab-status" style="border:none;padding:3px 10px;cursor:pointer;font-size:.78rem;background:var(--accent);color:#fff">' + t('gm_status') + '</button>'
    + '<button id="gm-tab-log" style="border:none;padding:3px 10px;cursor:pointer;font-size:.78rem;background:none;color:var(--text-dim)">' + t('gm_log') + '</button>'
    + '</div></div>'
    + '<div id="gm-tab-content" style="flex:1;overflow-y:auto;padding:12px 14px"></div>'
    + '<div id="gm-action-output" style="display:none;padding:8px 14px;font-size:.78rem;font-family:monospace;background:var(--surface);border-top:1px solid var(--border);max-height:100px;overflow-y:auto;white-space:pre-wrap"></div>';

  container.style.display = 'flex';
  container.style.flexDirection = 'column';

  function switchTab(t) {
    tab = t;
    container.querySelector('#gm-tab-status').style.background = t === 'status' ? 'var(--accent)' : 'none';
    container.querySelector('#gm-tab-status').style.color = t === 'status' ? '#fff' : 'var(--text-dim)';
    container.querySelector('#gm-tab-log').style.background = t === 'log' ? 'var(--accent)' : 'none';
    container.querySelector('#gm-tab-log').style.color = t === 'log' ? '#fff' : 'var(--text-dim)';
    if (t === 'status') loadStatus();
    else loadLog();
  }

  var ACTION_ING_KEYS = { pull: 'gm_pulling', push: 'gm_pushing', fetch: 'gm_fetching' };

  async function doAction(action) {
    var btn = container.querySelector('#gm-' + action);
    var out = container.querySelector('#gm-action-output');
    btn.disabled = true; btn.style.opacity = '.5';
    out.style.display = 'block'; out.style.color = 'var(--text-dim)';
    out.textContent = t(ACTION_ING_KEYS[action] || action);
    try {
      var r = await GM.api('/repo/' + action, { method: 'POST', json: { path: repo.path } });
      out.textContent = r.output || t('gm_done');
      out.style.color = '#a6e3a1';
      if (action === 'fetch') loadStatus(true);
      else if (action === 'pull' || action === 'push') { loadStatus(); GM.loadRepos(); }
    } catch(e) {
      out.textContent = e.message; out.style.color = '#f38ba8';
    } finally {
      btn.disabled = false; btn.style.opacity = '';
    }
  }

  async function doCommit(msgInput, andPush) {
    var msg = msgInput.value.trim();
    if (!msg) { msgInput.focus(); return; }
    var buttons = [container.querySelector('#gm-commit-btn'), container.querySelector('#gm-commit-push-btn')];
    var out = container.querySelector('#gm-action-output');
    buttons.forEach(function(b) { if (b) b.disabled = true; });
    if (out) { out.style.display = 'block'; out.textContent = t('gm_committing'); out.style.color = 'var(--text-dim)'; }
    var committed = false;
    try {
      var r = await GM.api('/repo/commit', { method: 'POST', json: { path: repo.path, message: msg } });
      committed = true;
      msgInput.value = '';
      var output = r.output || '';
      if (andPush) {
        if (out) out.textContent = output + '\n\n' + t('gm_pushing');
        var p = await GM.api('/repo/push', { method: 'POST', json: { path: repo.path } });
        output += '\n\n' + (p.output || t('gm_done'));
      }
      if (out) { out.textContent = output; out.style.color = '#a6e3a1'; }
      loadStatus(); GM.loadRepos();
    } catch(e) {
      if (out) { out.textContent = e.message; out.style.color = '#f38ba8'; }
      // A failed push after a successful commit still has to show the new commit.
      if (committed) { loadStatus(); GM.loadRepos(); }
      else buttons.forEach(function(b) { if (b) b.disabled = false; });
    }
  }

  // A commit message the user can accept or rewrite. The issue number comes
  // from the branch name alone, so the button works without Premium; only the
  // issue title and its label need the GitHub access Premium provides.
  function issueNumberFromBranch(branch) {
    var m = /issue(\d+)$/i.exec(branch || '');
    return m ? parseInt(m[1], 10) : 0;
  }

  // Which GitHub closing keyword fits. The diff cannot tell a fix from a new
  // feature, but the issue's own label can, so that is what decides it.
  function closingKeyword(labels) {
    var names = (labels || []).map(function(l) { return String(l).toLowerCase(); });
    for (var i = 0; i < names.length; i++) {
      if (/bug|defect|error|regression|hotfix/.test(names[i])) return 'fix';
      if (/feature|enhancement|task|chore|improvement/.test(names[i])) return 'close';
    }
    return 'fix';
  }

  // Generated text stays English: the closing keyword has to be, and a commit
  // log is conventionally written in one language whatever the UI shows.
  function changeSummary(files) {
    var added = 0, updated = 0, deleted = 0, renamed = 0;
    (files || []).forEach(function(f) {
      var code = (f.code || '');
      if (code.indexOf('?') >= 0 || code.indexOf('A') >= 0) added++;
      else if (code.indexOf('D') >= 0) deleted++;
      else if (code.indexOf('R') >= 0) renamed++;
      else updated++;
    });
    var parts = [];
    if (added) parts.push(added + (added === 1 ? ' new file' : ' new files'));
    if (updated) parts.push(updated + ' updated');
    if (deleted) parts.push(deleted + ' deleted');
    if (renamed) parts.push(renamed + ' renamed');
    return parts.join(', ');
  }

  // Where the work happened, not what every file was. The commit itself lists
  // the files; the message only has to point at the corner of the tree.
  function touchedFolders(files) {
    var seen = [];
    (files || []).forEach(function(f) {
      var name = f.file || '';
      // A rename reads as "old -> new"; the new path is the one that matters.
      var arrow = name.indexOf(' -> ');
      if (arrow >= 0) name = name.slice(arrow + 4);
      var cut = name.lastIndexOf('/');
      // Everything loose at the top of the repository is named once, together.
      var where = cut > 0 ? name.slice(0, cut) : 'root';
      if (where && seen.indexOf(where) < 0) seen.push(where);
    });
    seen.sort();
    // The root comes first, where it reads as the top of the tree it is.
    var top = seen.indexOf('root');
    if (top > 0) { seen.splice(top, 1); seen.unshift('root'); }
    if (seen.length > 8) return seen.slice(0, 8).concat('…').join('\n');
    return seen.join('\n');
  }

  // The message prepared in the file git's commit.template setting points to,
  // the same text `git commit` would open its editor with.
  async function fillTemplateMessage(btn, msgInput) {
    btn.disabled = true;
    try {
      var r = await GM.api('/repo/commit-template?path=' + encodeURIComponent(repo.path));
      if (!r.message) return;
      msgInput.value = r.message;
      msgInput.focus();
    } catch(e) { /* the template went away since the status was read */ }
    finally {
      btn.disabled = false;
    }
  }

  async function fillSuggestedMessage(btn, msgInput, files, branch) {
    if (!files || !files.length) return;
    btn.disabled = true;
    try {
      var summary = changeSummary(files);
      var folders = touchedFolders(files);
      var number = issueNumberFromBranch(branch);
      var subject = summary, body = folders;

      // The issue half needs GitHub, which only Premium can reach. Without it
      // the message is simply about the changes, with no issue line at all.
      if (number && (GM.state.foreignAccess || {}).premium) {
        try {
          var data = await GM.api('/repo/issues/' + number + '?path=' + encodeURIComponent(repo.path));
          var issue = data.issue || {};
          if (issue.title) {
            subject = closingKeyword(issue.labels) + ' #' + number + ': ' + issue.title;
            body = folders ? summary + '\n\n' + folders : summary;
          }
        } catch(e) { /* no answer from GitHub — keep the plain change summary */ }
      }
      msgInput.value = body ? subject + '\n\n' + body : subject;
      msgInput.focus();
      msgInput.setSelectionRange(0, subject.indexOf('\n') < 0 ? subject.length : subject.indexOf('\n'));
    } finally {
      btn.disabled = false;
    }
  }

  async function loadStatus(onlyIfChanged) {
    var tc = container.querySelector('#gm-tab-content');
    if (!tc) return;
    if (!onlyIfChanged) tc.innerHTML = '<div style="color:var(--text-dim);font-size:.8rem;opacity:.7">' + t('gm_loading') + '</div>';
    try {
      var s = await GM.api('/repo/status?path=' + encodeURIComponent(repo.path));
      // Kept in sync on every poll, independent of the signature check below,
      // so the sidebar badge never lags behind changes made outside the app
      // (e.g. from the terminal) even while the status view itself is unchanged.
      if (repo.changes !== s.files.length) {
        repo.changes = s.files.length;
        GM.updateRepoBadge(repo);
      }
      var statusSignature = JSON.stringify(s);
      if (onlyIfChanged && statusSignature === lastStatusSignature) return;
      lastStatusSignature = statusSignature;
      defaultBranch = s.default_branch || '';
      if (s.branch && s.branch !== '?') repo.branch = s.branch;

      var syncInfo = container.querySelector('#gm-sync-info');
      if (syncInfo) {
        var parts = [];
        if (s.ahead > 0) parts.push('&#x2191; ' + t('gm_ahead', { n: s.ahead }));
        if (s.behind > 0) parts.push('&#x2193; ' + t('gm_behind', { n: s.behind }));
        syncInfo.innerHTML = parts.join('&nbsp;&nbsp;');
        syncInfo.style.color = s.behind > 0 ? '#f38ba8' : 'var(--text-dim)';
      }
      // A pull request only makes sense from a branch other than the one it merges into.
      var prToolbar = container.querySelector('#gm-pr-toolbar');
      if (prToolbar) prToolbar.style.display = repo.branch && repo.branch !== '?' && repo.branch !== 'HEAD' && repo.branch !== defaultBranch ? '' : 'none';
      var localBadge = container.querySelector('#gm-branch-local-badge');
      if (localBadge) localBadge.style.display = s.local_only ? 'inline-block' : 'none';

      var commitHtml = '<div style="border-top:1px solid var(--border);padding-top:12px;display:flex;flex-direction:column;gap:8px">'
        + '<div style="display:flex;align-items:center;gap:8px"><div style="font-size:.75rem;color:var(--text-dim);flex:1">' + t('gm_commit_message') + ' <span style="opacity:.6">' + t('gm_ctrl_enter') + '</span></div>'
        + '<button id="gm-commit-suggest" class="s-btn s-btn-sm" title="' + GM.escape(t('gm_suggest_message')) + '" aria-label="' + GM.escape(t('gm_suggest_message')) + '" style="padding:2px 8px;line-height:1.4">&#x2728;</button>'
        + (s.has_commit_template
          ? '<button id="gm-commit-template" class="s-btn s-btn-sm" title="' + GM.escape(t('gm_use_commit_template')) + '" aria-label="' + GM.escape(t('gm_use_commit_template')) + '" style="padding:2px 8px;line-height:1.4">&#x1F4C4;</button>'
          : '<button id="gm-commit-template-help" class="s-btn s-btn-sm" title="' + GM.escape(t('gm_commit_template_help')) + '" aria-label="' + GM.escape(t('gm_commit_template_help')) + '" style="padding:2px 8px;line-height:1.4;opacity:.45">&#x1F4C4;</button>')
        + '</div>'
        // Without a template the button explains the git setting instead, so
        // the feature can be found by people who have never heard of it.
        + (s.has_commit_template ? '' : '<div id="gm-commit-template-hint" style="display:' + (templateHintOpen ? 'block' : 'none') + ';font-size:.78rem;line-height:1.5;color:var(--text-dim);background:var(--surface-2, rgba(127,127,127,.08));border:1px solid var(--border);border-radius:6px;padding:8px 10px">'
          + GM.escape(t('gm_commit_template_hint'))
          + '<code style="display:block;margin-top:6px;padding:4px 6px;border-radius:4px;background:rgba(127,127,127,.12);font-size:.74rem;white-space:pre-wrap;word-break:break-all;user-select:all">git config commit.template ' + GM.escape(repo.path.replace(/\/+$/, '') + '/.git/commit-template.txt') + '</code></div>')
        + '<textarea id="gm-commit-msg" class="s-input" rows="4" placeholder="' + t('gm_describe_changes') + '" style="resize:vertical;flex:none;max-width:none;min-height:80px;font-family:inherit;font-size:.83rem;width:100%;box-sizing:border-box"></textarea>'
        + '<div style="display:flex;gap:6px;flex-wrap:wrap"><button id="gm-commit-btn" class="s-btn s-btn-sm" ' + (s.files.length ? 'style="background:var(--accent);color:#fff;border-color:var(--accent)"' : 'disabled') + '>&#x2713; ' + t('gm_commit_all') + '</button>'
        + '<button id="gm-commit-push-btn" class="s-btn s-btn-sm" ' + (s.files.length ? '' : 'disabled') + '>&#x2713;&#x2B06; ' + t('gm_commit_push') + '</button></div>'
        + '</div>';

      if (!s.files.length) {
        tc.innerHTML = '<div style="color:var(--text-dim);font-size:.82rem;opacity:.7;padding:20px 0;text-align:center">' + t('gm_nothing_to_commit') + '</div>' + commitHtml;
      } else {
        tc.innerHTML = '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">'
          + '<span style="font-size:.75rem;color:var(--text-dim)">' + t('gm_changed_files', { n: s.files.length, s: s.files.length !== 1 ? 's' : '' }) + '</span>'
          + '<button id="gm-discard-all" class="s-btn s-btn-sm" style="font-size:.72rem;color:#f38ba8;border-color:#f38ba8">&#x21BA; ' + t('gm_discard_all') + '</button>'
          + '</div>'
          + '<div id="gm-file-list" style="display:flex;flex-direction:column;gap:2px;margin-bottom:14px"></div>'
          + commitHtml;

        tc.querySelector('#gm-discard-all').addEventListener('click', async function() {
          if (!await mvmOS.confirm(t('gm_discard_all_confirm', { name: GM.escape(GM.repoLabel(repo)) }))) return;
          GM.api('/repo/discard', { method: 'POST', json: { path: repo.path } })
            .then(function() { loadStatus(); })
            .catch(function(e) { mvmOS.notify(t('gm_title'), e.message); });
        });

        var fl = tc.querySelector('#gm-file-list');
        s.files.forEach(function(f) {
          var code = f.code.trim();
          var color = code === 'M' || code === 'MM' ? '#fab387' : code === '??' ? 'var(--text-dim)' : code === 'A' ? '#a6e3a1' : code === 'D' ? '#f38ba8' : 'var(--text)';
          var canDiff = code !== '??';
          var canDiscard = code !== '??';

          var row = document.createElement('div');
          row.style.cssText = 'border-radius:4px;overflow:hidden;';

          var fileRow = document.createElement('div');
          fileRow.style.cssText = 'display:flex;align-items:center;gap:8px;padding:4px 8px;font-size:.8rem;font-family:monospace;'
            + (canDiff ? 'cursor:pointer;' : '');
          fileRow.innerHTML = '<span style="color:' + color + ';width:20px;flex-shrink:0">' + f.code + '</span>'
            + '<span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + f.file + '</span>'
            + (canDiscard ? '<button class="gm-discard-file s-btn s-btn-sm" style="font-size:.68rem;padding:1px 6px;opacity:.7" title="' + t('gm_discard') + '">&#x21BA;</button>' : '');

          if (canDiff) {
            fileRow.addEventListener('mouseenter', function() { this.style.background = 'var(--surface2,#313244)'; });
            fileRow.addEventListener('mouseleave', function() { this.style.background = ''; });
            fileRow.addEventListener('click', function(e) {
              if (e.target.classList.contains('gm-discard-file')) return;
              var existing = row.querySelector('.gm-diff-panel');
              if (existing) { existing.remove(); return; }
              var panel = document.createElement('div');
              panel.className = 'gm-diff-panel';
              panel.style.cssText = 'font-family:monospace;font-size:.74rem;padding:6px 8px;background:var(--bg,#1e1e2e);border-top:1px solid var(--border);max-height:260px;overflow-y:auto;white-space:pre';
              panel.textContent = t('gm_loading');
              row.appendChild(panel);
              GM.api('/repo/diff?path=' + encodeURIComponent(repo.path) + '&file=' + encodeURIComponent(f.file))
                .then(function(d) {
                  if (!d.diff) { panel.textContent = t('gm_no_diff'); return; }
                  panel.innerHTML = '';
                  d.diff.split('\n').forEach(function(line) {
                    var span = document.createElement('div');
                    span.textContent = line;
                    span.style.color = line.startsWith('+') && !line.startsWith('+++') ? '#a6e3a1'
                      : line.startsWith('-') && !line.startsWith('---') ? '#f38ba8'
                      : line.startsWith('@@') ? '#89dceb'
                      : 'var(--text-dim)';
                    panel.appendChild(span);
                  });
                })
                .catch(function(e) { panel.textContent = e.message; });
            });
          }

          if (canDiscard) {
            fileRow.querySelector('.gm-discard-file').addEventListener('click', async function(e) {
              e.stopPropagation();
              if (!await mvmOS.confirm(t('gm_discard_file_confirm', { file: f.file }))) return;
              GM.api('/repo/discard', { method: 'POST', json: { path: repo.path, file: f.file } })
                .then(function() { loadStatus(); })
                .catch(function(e) { mvmOS.notify(t('gm_title'), e.message); });
            });
          }

          row.appendChild(fileRow);
          fl.appendChild(row);
        });
      }

      var commitBtn = tc.querySelector('#gm-commit-btn');
      var msgInput = tc.querySelector('#gm-commit-msg');
      if (commitBtn && msgInput) {
        commitBtn.addEventListener('click', function() { doCommit(msgInput); });
        tc.querySelector('#gm-commit-push-btn').addEventListener('click', function() { doCommit(msgInput, true); });
        msgInput.addEventListener('keydown', function(e) { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') doCommit(msgInput); });
        var suggestBtn = tc.querySelector('#gm-commit-suggest');
        if (suggestBtn) suggestBtn.addEventListener('click', function() { fillSuggestedMessage(suggestBtn, msgInput, s.files, s.branch); });
        var templateBtn = tc.querySelector('#gm-commit-template');
        if (templateBtn) templateBtn.addEventListener('click', function() { fillTemplateMessage(templateBtn, msgInput); });
        var templateHelpBtn = tc.querySelector('#gm-commit-template-help');
        if (templateHelpBtn) templateHelpBtn.addEventListener('click', function() {
          templateHintOpen = !templateHintOpen;
          var hint = tc.querySelector('#gm-commit-template-hint');
          if (hint) hint.style.display = templateHintOpen ? 'block' : 'none';
        });
      }
    } catch(e) {
      tc.innerHTML = '<div style="color:#f38ba8;font-size:.82rem">' + e.message + '</div>';
    }
  }

  async function loadLog() {
    var tc = container.querySelector('#gm-tab-content');
    if (!tc) return;
    tc.innerHTML = '<div style="color:var(--text-dim);font-size:.8rem;opacity:.7">' + t('gm_loading') + '</div>';
    try {
      var entries = await GM.api('/repo/log?path=' + encodeURIComponent(repo.path));
      if (!entries.length) {
        tc.innerHTML = '<div style="color:var(--text-dim);font-size:.82rem;opacity:.7;padding:20px 0;text-align:center">' + t('gm_no_commits') + '</div>';
        return;
      }
      tc.innerHTML = '';
      entries.forEach(function(e) {
        var row = document.createElement('div');
        row.style.cssText = 'display:grid;grid-template-columns:52px 1fr 90px 100px;gap:8px;align-items:baseline;padding:5px 4px;border-bottom:1px solid var(--border);font-size:.79rem';
        row.innerHTML = '<span style="font-family:monospace;color:var(--accent);opacity:.8">' + e.hash + '</span>'
          + '<span style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + e.message + '</span>'
          + '<span style="color:var(--text-dim);font-size:.72rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + e.author + '</span>'
          + '<span style="color:var(--text-dim);font-size:.72rem;text-align:right;white-space:nowrap">' + e.date + '</span>';
        tc.appendChild(row);
      });
    } catch(e) {
      tc.innerHTML = '<div style="color:#f38ba8;font-size:.82rem">' + e.message + '</div>';
    }
  }

  function showIssues() {
    var tc = container.querySelector('#gm-tab-content');
    container.querySelector('#gm-tab-status').style.background = 'none';
    container.querySelector('#gm-tab-status').style.color = 'var(--text-dim)';
    container.querySelector('#gm-tab-log').style.background = 'none';
    container.querySelector('#gm-tab-log').style.color = 'var(--text-dim)';
    tc.innerHTML = '<div style="color:var(--text-dim);font-size:.8rem;opacity:.7">' + t('gm_loading') + '</div>';
    GM.api('/repo/issues/status?path=' + encodeURIComponent(repo.path)).then(function(status) {
      if (!status.connected) {
        renderIssueSetup(tc, status);
        return;
      }
      renderIssueList(tc, 'open', status);
    }).catch(function(e) {
      tc.innerHTML = '<div style="color:#f38ba8;font-size:.82rem">' + GM.escape(e.message) + '</div>';
    });
  }

  function renderIssueSetup(tc, status) {
    tc.innerHTML = '<div style="max-width:540px;margin:20px auto;background:var(--surface2,#313244);border-radius:9px;padding:18px;display:flex;flex-direction:column;gap:12px">'
      + '<div style="font-size:1rem;font-weight:700">' + t('gm_issues_connect_title') + '</div>'
      + '<div style="font-size:.82rem;line-height:1.5;color:var(--text-dim)">' + t('gm_issues_connect_body') + '</div>'
      + '<div style="font-size:.76rem;color:var(--text-dim)">' + (status.gh_installed ? t('gm_issues_gh_not_logged') : t('gm_issues_gh_missing')) + '</div>'
      + (status.error ? '<div style="font-size:.78rem;color:#f38ba8">' + GM.escape(status.error) + '</div>' : '')
      + '<input id="gm-issues-token" class="s-input" type="password" autocomplete="off" placeholder="' + t('gm_issues_token_placeholder') + '" style="width:100%;box-sizing:border-box">'
      + '<div id="gm-issues-token-error" style="display:none;color:#f38ba8;font-size:.78rem"></div>'
      + '<div><button id="gm-issues-token-save" class="s-btn s-btn-sm" style="background:var(--accent);color:#fff;border-color:var(--accent)">' + t('gm_issues_connect') + '</button></div>'
      + '</div>';
    tc.querySelector('#gm-issues-token-save').addEventListener('click', async function() {
      var token = tc.querySelector('#gm-issues-token').value.trim();
      var err = tc.querySelector('#gm-issues-token-error');
      if (!token) { err.textContent = t('gm_issues_token_required'); err.style.display = 'block'; return; }
      this.disabled = true; this.textContent = t('gm_issues_connecting'); err.style.display = 'none';
      try {
        await GM.api('/repo/issues/token', {method:'POST', json:{path:repo.path, token:token}});
        showIssues();
      } catch(e) {
        err.textContent = e.message; err.style.display = 'block';
        this.disabled = false; this.textContent = t('gm_issues_connect');
      }
    });
  }

  function renderIssueList(tc, state, status) {
    tc.innerHTML = '<div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">'
      + '<div style="display:flex;border:1px solid var(--border);border-radius:6px;overflow:hidden">'
      + '<button id="gm-issues-open" class="s-btn s-btn-sm" style="border:0;border-radius:0">' + t('gm_issues_open') + '</button>'
      + '<button id="gm-issues-closed" class="s-btn s-btn-sm" style="border:0;border-radius:0">' + t('gm_issues_closed') + '</button></div>'
      + '<span style="font-size:.72rem;color:var(--text-dim)">' + GM.escape(status.repository || '') + '</span>'
      + '<div style="flex:1"></div>'
      + '<button id="gm-issues-new" class="s-btn s-btn-sm" style="background:var(--accent);color:#fff;border-color:var(--accent)">+ ' + t('gm_issues_new') + '</button>'
      + '</div><div id="gm-issues-list"></div>';
    var openBtn = tc.querySelector('#gm-issues-open');
    var closedBtn = tc.querySelector('#gm-issues-closed');
    openBtn.style.background = state === 'open' ? 'var(--accent)' : 'none';
    openBtn.style.color = state === 'open' ? '#fff' : 'var(--text-dim)';
    closedBtn.style.background = state === 'closed' ? 'var(--accent)' : 'none';
    closedBtn.style.color = state === 'closed' ? '#fff' : 'var(--text-dim)';
    openBtn.onclick = function() { renderIssueList(tc, 'open', status); };
    closedBtn.onclick = function() { renderIssueList(tc, 'closed', status); };
    tc.querySelector('#gm-issues-new').onclick = function() { renderNewIssue(tc, status); };
    var list = tc.querySelector('#gm-issues-list');
    list.innerHTML = '<div style="color:var(--text-dim);font-size:.8rem">' + t('gm_loading') + '</div>';
    Promise.all([GM.api('/repo/issues?path=' + encodeURIComponent(repo.path) + '&state=' + state), GM.issueSettings()]).then(function(results) {
      var data = results[0], settings = results[1];
      var issues = data.issues || [];
      if (!issues.length) {
        list.innerHTML = '<div style="color:var(--text-dim);font-size:.82rem;text-align:center;padding:28px">' + t(state === 'open' ? 'gm_issues_no_open' : 'gm_issues_no_closed') + '</div>';
        return;
      }
      list.innerHTML = '';
      function issueRow(issue) {
        var row = document.createElement('button');
        row.className = 's-btn';
        row.style.cssText = 'width:100%;display:flex;align-items:flex-start;gap:10px;text-align:left;padding:9px 10px;margin-bottom:5px;background:var(--surface2,#313244);border-color:var(--border)';
        row.innerHTML = '<span style="color:' + (issue.state === 'open' ? '#a6e3a1' : '#a6adc8') + ';font-size:1rem">&#x25CF;</span>'
          + '<span style="flex:1;min-width:0"><span style="display:block;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + GM.escape(issue.title) + '</span>'
          + '<span style="display:block;font-size:.7rem;color:var(--text-dim);margin-top:3px">#' + issue.number + ' · ' + GM.escape(issue.author) + ' · ' + t('gm_issues_comments', {n:issue.comments || 0}) + '</span></span>';
        row.onclick = function() { renderIssueDetail(tc, issue.number, status, state, true); };
        return row;
      }
      function sectionHeader(text) {
        var h = document.createElement('div');
        h.textContent = text;
        h.style.cssText = 'font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--text-dim);margin:4px 0 6px';
        return h;
      }
      // The groups picked in the settings, in a fixed order. Nothing picked
      // shows every issue in one list; an issue that fits two groups shows
      // only in the first.
      var groups = settings.list_groups || [];
      if (!groups.length) {
        issues.forEach(function(issue) { list.appendChild(issueRow(issue)); });
        return;
      }
      var created = function(i) { return !!status.username && i.author === status.username; };
      var assigned = function(i) { return !!status.username && (i.assignees || []).indexOf(status.username) !== -1; };
      var sections = [];
      if (settings.list_merge_mine && groups.indexOf('created') !== -1 && groups.indexOf('assigned') !== -1) {
        sections.push({title: t('gm_issues_created_or_assigned'), fits: function(i) { return created(i) || assigned(i); }});
      } else {
        if (groups.indexOf('created') !== -1) sections.push({title: t('gm_issues_created'), fits: created});
        if (groups.indexOf('assigned') !== -1) sections.push({title: t('gm_issues_mine'), fits: assigned});
      }
      if (groups.indexOf('others') !== -1) sections.push({title: t('gm_issues_others'), fits: function(i) { return !created(i) && !assigned(i); }});
      var shown = [];
      sections.forEach(function(section) {
        var items = issues.filter(function(i) { return shown.indexOf(i) === -1 && section.fits(i); });
        if (!items.length) return;
        if (shown.length) {
          var divider = document.createElement('div');
          divider.style.cssText = 'border-top:1px solid var(--border);margin:10px 0';
          list.appendChild(divider);
        }
        list.appendChild(sectionHeader(section.title));
        items.forEach(function(issue) { shown.push(issue); list.appendChild(issueRow(issue)); });
      });
      if (!shown.length) {
        list.innerHTML = '<div style="color:var(--text-dim);font-size:.82rem;text-align:center;padding:28px">' + t('gm_issues_none_in_view') + '</div>';
      }
    }).catch(function(e) {
      list.innerHTML = '<div style="color:#f38ba8;font-size:.82rem">' + GM.escape(e.message) + '</div>';
    });
  }

  // Shared Assignees/Labels/Milestone block for the create and edit issue
  // forms. GitHub Issues have no local cache for these, so they're always
  // fetched fresh from the repo when the form opens.
  function issueMetaFieldsHtml() {
    return '<div style="display:flex;gap:10px;flex-wrap:wrap">'
      + '<div style="flex:1;min-width:160px"><div style="font-size:.75rem;color:var(--text-dim);margin-bottom:4px">' + t('gm_issues_assignees') + '</div>'
      + '<select id="gm-issue-assignees" class="s-input" multiple size="4" style="width:100%;max-width:none;box-sizing:border-box"></select></div>'
      + '<div style="flex:1;min-width:160px"><div style="font-size:.75rem;color:var(--text-dim);margin-bottom:4px">' + t('gm_issues_labels') + '</div>'
      + '<select id="gm-issue-labels" class="s-input" multiple size="4" style="width:100%;max-width:none;box-sizing:border-box"></select></div>'
      + '<div style="flex:1;min-width:160px"><div style="font-size:.75rem;color:var(--text-dim);margin-bottom:4px">' + t('gm_issues_milestone') + '</div>'
      + '<select id="gm-issue-milestone" class="s-input" style="width:100%;max-width:none;box-sizing:border-box"><option value="">' + t('gm_issues_no_milestone') + '</option></select></div>'
      + '</div>';
  }

  function loadIssueMeta(tc, selected) {
    selected = selected || {};
    var assigneesSel = tc.querySelector('#gm-issue-assignees');
    var labelsSel = tc.querySelector('#gm-issue-labels');
    var milestoneSel = tc.querySelector('#gm-issue-milestone');
    var selectedAssignees = selected.assignees || [];
    var selectedLabels = selected.labels || [];
    // The issue's current values are always present and selected — before the
    // repo metadata arrives, if it fails, and when GitHub no longer lists them
    // (e.g. a closed milestone) — so saving never silently clears them.
    function fill(assignees, labels, milestones) {
      assigneesSel.innerHTML = '';
      assignees.concat(selectedAssignees.filter(function(a) { return assignees.indexOf(a) === -1; })).forEach(function(login) {
        var opt = document.createElement('option');
        opt.value = login; opt.textContent = login;
        if (selectedAssignees.indexOf(login) !== -1) opt.selected = true;
        assigneesSel.appendChild(opt);
      });
      labelsSel.innerHTML = '';
      labels.concat(selectedLabels.filter(function(l) { return labels.indexOf(l) === -1; })).forEach(function(name) {
        var opt = document.createElement('option');
        opt.value = name; opt.textContent = name;
        if (selectedLabels.indexOf(name) !== -1) opt.selected = true;
        labelsSel.appendChild(opt);
      });
      milestoneSel.innerHTML = '<option value="">' + t('gm_issues_no_milestone') + '</option>';
      var ms = milestones.slice();
      if (selected.milestone && !ms.some(function(m) { return m.number === selected.milestone.number; })) ms.push(selected.milestone);
      ms.forEach(function(m) {
        var opt = document.createElement('option');
        opt.value = m.number; opt.textContent = m.title;
        if (selected.milestone && selected.milestone.number === m.number) opt.selected = true;
        milestoneSel.appendChild(opt);
      });
    }
    fill([], [], []);
    GM.api('/repo/issues/meta?path=' + encodeURIComponent(repo.path)).then(function(meta) {
      fill(meta.assignees || [], (meta.labels || []).map(function(l) { return l.name; }), meta.milestones || []);
    }).catch(function(e) {
      var err = tc.querySelector('#gm-issue-create-error') || tc.querySelector('#gm-issue-edit-error');
      if (err) { err.textContent = e.message; err.style.display = 'block'; }
    });
  }

  function selectedValues(sel) {
    return Array.prototype.map.call(sel.selectedOptions || [], function(o) { return o.value; });
  }

  function renderNewIssue(tc, status) {
    tc.innerHTML = '<div style="display:flex;align-items:center;gap:8px;margin-bottom:12px"><button id="gm-issues-back" class="s-btn s-btn-sm">&#x2190; ' + t('gm_back') + '</button>'
      + '<strong>' + t('gm_issues_new') + '</strong></div>'
      + '<div style="display:flex;flex-direction:column;gap:10px;max-width:700px">'
      + '<input id="gm-issue-title" class="s-input" placeholder="' + t('gm_issues_title_placeholder') + '">'
      + GM.mdToolbarHtml('gm-issue-body')
      + '<textarea id="gm-issue-body" class="s-input" rows="10" placeholder="' + t('gm_issues_body_placeholder') + '" style="resize:vertical;max-width:none;border-radius:0 0 6px 6px;margin-top:-1px"></textarea>'
      + issueMetaFieldsHtml()
      + '<div id="gm-issue-create-error" style="display:none;color:#f38ba8;font-size:.8rem"></div>'
      + '<div><button id="gm-issue-create" class="s-btn s-btn-sm" style="background:var(--accent);color:#fff;border-color:var(--accent)">' + t('gm_issues_create') + '</button></div></div>';
    tc.querySelector('#gm-issues-back').onclick = function() { renderIssueList(tc, 'open', status); };
    GM.wireMdToolbar(tc, tc.querySelector('#gm-issue-body'));
    loadIssueMeta(tc, {});
    tc.querySelector('#gm-issue-create').onclick = async function() {
      var title = tc.querySelector('#gm-issue-title').value.trim();
      var body = tc.querySelector('#gm-issue-body').value.trim();
      var err = tc.querySelector('#gm-issue-create-error');
      if (!title) { err.textContent = t('gm_issues_title_required'); err.style.display = 'block'; return; }
      var assignees = selectedValues(tc.querySelector('#gm-issue-assignees'));
      var labels = selectedValues(tc.querySelector('#gm-issue-labels'));
      var milestoneVal = tc.querySelector('#gm-issue-milestone').value;
      var milestone = milestoneVal ? parseInt(milestoneVal, 10) : null;
      this.disabled = true; this.textContent = t('gm_issues_creating');
      try {
        var data = await GM.api('/repo/issues', {method:'POST',json:{path:repo.path,title:title,body:body,assignees:assignees,labels:labels,milestone:milestone}});
        renderIssueDetail(tc, data.issue.number, status, 'open', true);
      } catch(e) {
        err.textContent = e.message; err.style.display = 'block'; this.disabled = false; this.textContent = t('gm_issues_create');
      }
    };
  }

  function issueBranchName(status, number) {
    var safe = (status.username || '').replace(/[^A-Za-z0-9_.-]/g, '-').replace(/^[.-]+/, '').replace(/[.-]+$/, '');
    return (safe || 'user') + '/issue' + number;
  }

  function updateIssueBranchButtons(tc, isOnBranch) {
    var brBtn = tc.querySelector('#gm-issue-branch');
    if (brBtn) brBtn.style.display = isOnBranch ? 'none' : '';
  }

  function showPRDialog(issue, headBranch) {
    container.style.position = 'relative';
    var overlay = document.createElement('div');
    overlay.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:99;padding:16px;box-sizing:border-box';
    overlay.innerHTML = '<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:20px;width:460px;max-width:100%;box-sizing:border-box;display:flex;flex-direction:column;gap:12px;max-height:100%;overflow-y:auto;overflow-x:hidden">'
      + '<div style="font-weight:600;font-size:.95rem">&#x1F500; ' + t('gm_pr_title_heading') + '</div>'
      + '<div id="gm-pr-existing" style="display:none;background:var(--surface2,#313244);border-radius:6px;padding:8px 10px"></div>'
      + '<div style="display:flex;gap:8px;align-items:center;font-size:.82rem">'
      + '<select id="gm-pr-head" class="s-input" style="flex:1;min-width:0;width:0;max-width:none;text-overflow:ellipsis"></select>'
      + '<span style="color:var(--text-dim);flex-shrink:0">&#x2192;</span>'
      + '<div style="position:relative;flex:1;min-width:0">'
      + '<input id="gm-pr-base" class="s-input" style="width:100%;box-sizing:border-box;max-width:none;text-overflow:ellipsis" autocomplete="off" placeholder="' + t('gm_search_branches') + '">'
      + '<div id="gm-pr-base-list" style="display:none;position:absolute;z-index:50;top:calc(100% + 4px);left:0;right:0;max-height:220px;overflow-y:auto;background:var(--surface);border:1px solid var(--border);border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.4)"></div>'
      + '</div>'
      + '</div>'
      + '<div><div style="font-size:.75rem;color:var(--text-dim);margin-bottom:4px">' + t('gm_pr_title_label') + '</div>'
      + '<input id="gm-pr-title" class="s-input" style="width:100%;max-width:none;box-sizing:border-box" placeholder="' + GM.escape(headBranch) + '" value="' + GM.escape(issue ? (issue.title || headBranch) : '') + '"></div>'
      + '<div><div style="font-size:.75rem;color:var(--text-dim);margin-bottom:4px">' + t('gm_pr_body_label') + '</div>'
      + '<textarea id="gm-pr-body" class="s-input" rows="6" style="resize:vertical;max-width:none;width:100%;box-sizing:border-box">' + GM.escape(issue ? (issue.body || '') : '') + '</textarea></div>'
      + '<div id="gm-pr-error" style="color:#f38ba8;font-size:.82rem;display:none"></div>'
      + '<div style="display:flex;gap:8px;justify-content:flex-end">'
      + '<button class="s-btn" id="gm-pr-cancel">' + t('gm_cancel') + '</button>'
      + '<button class="s-btn" id="gm-pr-create" style="background:var(--accent);color:#fff;border-color:var(--accent)">' + t('gm_pr_create') + '</button>'
      + '</div></div>';
    container.appendChild(overlay);

    var headSel = overlay.querySelector('#gm-pr-head');
    var baseInput = overlay.querySelector('#gm-pr-base');
    var baseList = overlay.querySelector('#gm-pr-base-list');
    var baseSel = { value: '' };
    headSel.innerHTML = '<option>' + t('gm_loading') + '</option>';
    baseInput.value = t('gm_loading'); baseInput.disabled = true;

    function fillSelect(sel, names, selected) {
      sel.innerHTML = '';
      names.forEach(function(name) {
        var opt = document.createElement('option');
        opt.value = name; opt.textContent = name;
        if (name === selected) opt.selected = true;
        sel.appendChild(opt);
      });
    }

    var baseNames = [];
    function setBase(name) { baseSel.value = name; baseInput.value = name; }
    function renderBaseList(names, filterText) {
      var f = (filterText || '').toLowerCase();
      baseList.innerHTML = '';
      var any = false;
      names.forEach(function(name) {
        if (f && name.toLowerCase().indexOf(f) === -1) return;
        any = true;
        var isSel = name === baseSel.value;
        var row = document.createElement('div');
        row.style.cssText = 'padding:7px 12px;cursor:pointer;font-size:.82rem;font-family:monospace;'
          + (isSel ? 'background:var(--accent-dim,rgba(99,102,241,.15));font-weight:600' : '');
        row.textContent = name;
        row.addEventListener('mouseenter', function() { if (!isSel) this.style.background = 'var(--surface2,#313244)'; });
        row.addEventListener('mouseleave', function() { if (!isSel) this.style.background = ''; });
        row.addEventListener('mousedown', function(e) {
          e.preventDefault();
          setBase(name);
          baseList.style.display = 'none';
        });
        baseList.appendChild(row);
      });
      if (!any) {
        var empty = document.createElement('div');
        empty.textContent = t('gm_no_matching_branches');
        empty.style.cssText = 'padding:8px 12px;font-size:.8rem;color:var(--text-dim)';
        baseList.appendChild(empty);
      }
    }
    baseInput.addEventListener('focus', function() { renderBaseList(baseNames, ''); baseList.style.display = 'block'; });
    baseInput.addEventListener('input', function() { renderBaseList(baseNames, baseInput.value); baseList.style.display = 'block'; });
    baseInput.addEventListener('keydown', function(e) { if (e.key === 'Escape') { baseInput.value = baseSel.value; baseList.style.display = 'none'; baseInput.blur(); } });
    baseInput.addEventListener('blur', function() {
      setTimeout(function() { baseList.style.display = 'none'; baseInput.value = baseSel.value; }, 150);
    });

    function loadExistingPRs(head) {
      var box = overlay.querySelector('#gm-pr-existing');
      if (!head) { box.style.display = 'none'; return; }
      GM.api('/repo/pr?path=' + encodeURIComponent(repo.path) + '&head=' + encodeURIComponent(head)).then(function(data) {
        var prs = data.prs || [];
        if (!prs.length) { box.style.display = 'none'; box.innerHTML = ''; return; }
        var colors = {open:'#a6e3a1', merged:'#cba6f7', closed:'#f38ba8'};
        box.style.display = 'block';
        box.innerHTML = '<div style="font-size:.75rem;color:var(--text-dim);margin-bottom:5px">' + t('gm_pr_existing_title') + '</div>'
          + prs.map(function(pr) {
              return '<div style="display:flex;align-items:center;gap:6px;font-size:.8rem;padding:3px 0">'
                + '<span style="color:' + (colors[pr.state] || 'var(--text-dim)') + '">&#x25CF;</span>'
                + '<span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">#' + pr.number + ' ' + GM.escape(pr.title) + ' &#x2192; ' + GM.escape(pr.base) + '</span>'
                + '<a href="' + GM.escape(pr.url) + '" target="_blank" rel="noopener noreferrer" style="color:var(--accent);flex-shrink:0;white-space:nowrap">' + t('gm_pr_open_link') + '</a></div>';
            }).join('');
      }).catch(function() { box.style.display = 'none'; });
    }
    loadExistingPRs(headBranch);
    headSel.addEventListener('change', function() { loadExistingPRs(headSel.value); });

    GM.api('/repo/branches?path=' + encodeURIComponent(repo.path)).then(function(data) {
      var names = [];
      var seen = {};
      (data.branches || []).forEach(function(b) {
        var name = b.indexOf('origin/') === 0 ? b.slice(7) : b;
        if (!name || name === 'HEAD' || seen[name]) return;
        seen[name] = true;
        names.push(name);
      });
      if (names.indexOf(headBranch) === -1) names.unshift(headBranch);
      fillSelect(headSel, names, headBranch);
      var fallbackBase = names.filter(function(n) { return n !== headBranch; })[0] || names[0];
      baseInput.disabled = false; baseInput.value = '';
      GM.api('/repo/status?path=' + encodeURIComponent(repo.path)).then(function(s) {
        var def = s.default_branch && names.indexOf(s.default_branch) !== -1 ? s.default_branch : fallbackBase;
        baseNames = names.slice().sort(function(a, b) {
          var rank = function(n) { return n === def ? 0 : 1; };
          return rank(a) - rank(b);
        });
        setBase(def);
      }).catch(function() { baseNames = names.slice(); setBase(fallbackBase); });
    }).catch(function(e) {
      fillSelect(headSel, [headBranch], headBranch);
      baseNames = [headBranch]; baseInput.disabled = false; setBase(headBranch);
      overlay.querySelector('#gm-pr-error').textContent = e.message;
      overlay.querySelector('#gm-pr-error').style.display = 'block';
    });

    overlay.querySelector('#gm-pr-cancel').addEventListener('click', function() { overlay.remove(); });
    overlay.querySelector('#gm-pr-create').addEventListener('click', async function() {
      var head = headSel.value, base = baseSel.value;
      var title = overlay.querySelector('#gm-pr-title').value.trim();
      var body = overlay.querySelector('#gm-pr-body').value;
      var err = overlay.querySelector('#gm-pr-error');
      var btn = this;
      if (!head || !base) { err.textContent = t('gm_pr_branches_required'); err.style.display = 'block'; return; }
      if (head === base) { err.textContent = t('gm_pr_same_branch'); err.style.display = 'block'; return; }
      btn.disabled = true; btn.textContent = t('gm_issues_creating'); err.style.display = 'none';
      try {
        var r = await GM.api('/repo/pr', {method:'POST', json:{path:repo.path, head:head, base:base, title:title, body:body}});
        var box = overlay.firstChild;
        box.innerHTML = '<div style="font-weight:600;font-size:.95rem">&#x1F500; ' + t('gm_pr_title_heading') + '</div>'
          + '<div style="color:#a6e3a1;font-size:.85rem">' + t(r.existing ? 'gm_pr_already_exists' : 'gm_pr_created', {number: r.number})
          + ' <a href="' + GM.escape(r.url) + '" target="_blank" rel="noopener noreferrer" style="color:var(--accent)">' + t('gm_pr_open_link') + '</a></div>'
          + '<div style="display:flex;justify-content:flex-end"><button class="s-btn" id="gm-pr-close">' + t('gm_close') + '</button></div>';
        box.querySelector('#gm-pr-close').addEventListener('click', function() { overlay.remove(); });
        loadStatus(true);
      } catch(e) {
        err.textContent = e.message; err.style.display = 'block';
        btn.disabled = false; btn.textContent = t('gm_pr_create');
      }
    });
  }

  // Asks before touching the working tree: an existing branch is switched to
  // (optionally pulled), a branch that only exists on origin is downloaded, and
  // a branch that exists nowhere is started from a base the user picks.
  async function showIssueBranchDialog(tc, issue) {
    var result = tc.querySelector('#gm-issue-action-result');
    result.style.color = 'var(--text-dim)';
    result.textContent = t('gm_issues_checking_branch');
    var state = await GM.api('/repo/issues/' + issue.number + '/branch?path=' + encodeURIComponent(repo.path));
    result.textContent = '';

    var choices, info, confirmLabel;
    if (state.local_exists) {
      info = t('gm_branch_exists_local', { branch: state.branch });
      confirmLabel = t('gm_branch_switch_confirm');
      choices = [{ mode: 'switch', label: t('gm_branch_switch_only'), hint: t('gm_branch_switch_only_hint', { branch: state.branch }) }];
      if (state.remote_exists) {
        choices.push({ mode: 'pull', label: t('gm_branch_switch_pull'), hint: t('gm_branch_switch_pull_hint', { branch: state.branch }) });
      }
    } else if (state.remote_exists) {
      info = t('gm_branch_exists_remote', { branch: state.branch });
      confirmLabel = t('gm_branch_download_confirm');
      choices = [{ mode: 'download', label: t('gm_branch_download_local'), hint: t('gm_branch_download_local_hint', { branch: state.branch }) }];
    } else {
      confirmLabel = t('gm_branch_create');
      defaultBranch = state.default_branch || defaultBranch;
      choices = branchBases().map(function(b) { b.mode = 'create'; return b; });
      info = choices.length > 1 ? t('gm_branch_issue_new', { branch: state.branch })
        : t('gm_branch_issue_new_single', { base: choices[0].label });
    }

    var blocked = state.dirty && state.current !== state.branch;
    GM.branchDialog({
      title: t('gm_branch_issue_title', { number: issue.number }),
      info: '<div style="font-family:monospace;font-size:.82rem;margin-bottom:6px">' + GM.escape(state.branch) + '</div>' + GM.escape(info)
        + (blocked ? '<div style="color:#f9e2af;margin-top:6px">' + GM.escape(t('gm_issues_dirty_no_switch')) + '</div>' : ''),
      choicesLabel: state.local_exists || state.remote_exists ? t('gm_branch_what_to_do') : t('gm_branch_from'),
      choices: choices,
      disabled: blocked,
      confirmLabel: confirmLabel,
      onConfirm: function(choice) {
        return activateIssueBranch(tc, issue, choice);
      }
    });
  }

  async function activateIssueBranch(tc, issue, choice) {
    choice = choice || {};
    var result = tc.querySelector('#gm-issue-action-result');
    result.style.color = 'var(--text-dim)';
    result.textContent = t('gm_issues_switching_branch');
    var data = await GM.api('/repo/issues/' + issue.number + '/branch', {method:'POST',
      json:{path:repo.path, mode:choice.mode || '', base:choice.branch || '', source:choice.source || 'remote'}});
    repo.branch = data.branch;
    container.querySelector('#gm-branch-btn').innerHTML = '&#x1F33F; ' + GM.escape(data.branch) + ' &#x25BE;';
    GM.renderSidebar();
    loadStatus();
    updateIssueBranchButtons(tc, repo.branch === data.branch);
    result.style.color = '#a6e3a1';
    if (data.created_fresh && data.base) {
      result.textContent = t('gm_branch_created_from', {branch: data.branch, base: data.base});
    } else {
      var msgKey = data.created_fresh ? 'gm_issues_branch_ready'
        : data.downloaded ? 'gm_issues_branch_downloaded'
        : data.pulled ? 'gm_issues_branch_synced'
        : 'gm_switched_to';
      result.textContent = t(msgKey, {branch:data.branch});
    }
    return data;
  }

  function renderEditIssue(tc, issue, status, previousState) {
    tc.innerHTML = '<div style="display:flex;align-items:center;gap:8px;margin-bottom:12px"><button id="gm-issue-edit-cancel" class="s-btn s-btn-sm">&#x2190; ' + t('gm_cancel') + '</button>'
      + '<strong>' + t('gm_issues_edit') + ' #' + issue.number + '</strong></div>'
      + '<div style="display:flex;flex-direction:column;gap:10px;max-width:700px">'
      + '<input id="gm-issue-edit-title" class="s-input" value="' + GM.escape(issue.title) + '">'
      + GM.mdToolbarHtml('gm-issue-edit-body')
      + '<textarea id="gm-issue-edit-body" class="s-input" rows="10" style="resize:vertical;max-width:none;border-radius:0 0 6px 6px;margin-top:-1px">' + GM.escape(issue.body || '') + '</textarea>'
      + issueMetaFieldsHtml()
      + '<div id="gm-issue-edit-error" style="display:none;color:#f38ba8;font-size:.8rem"></div>'
      + '<div style="display:flex;gap:8px"><button id="gm-issue-edit-save" class="s-btn s-btn-sm" style="background:var(--accent);color:#fff;border-color:var(--accent)">' + t('gm_save') + '</button></div></div>';
    var ta = tc.querySelector('#gm-issue-edit-body');
    GM.wireMdToolbar(tc, ta);
    loadIssueMeta(tc, {assignees: issue.assignees || [], labels: issue.labels || [], milestone: issue.milestone || null});
    tc.querySelector('#gm-issue-edit-cancel').onclick = function() { renderIssueDetail(tc, issue.number, status, previousState, false); };
    tc.querySelector('#gm-issue-edit-save').onclick = async function() {
      var title = tc.querySelector('#gm-issue-edit-title').value.trim();
      var body = ta.value;
      var err = tc.querySelector('#gm-issue-edit-error');
      if (!title) { err.textContent = t('gm_issues_title_required'); err.style.display = 'block'; return; }
      var assignees = selectedValues(tc.querySelector('#gm-issue-assignees'));
      var labels = selectedValues(tc.querySelector('#gm-issue-labels'));
      var milestoneVal = tc.querySelector('#gm-issue-milestone').value;
      var milestone = milestoneVal ? parseInt(milestoneVal, 10) : null;
      this.disabled = true; this.textContent = t('gm_saving');
      try {
        await GM.api('/repo/issues/' + issue.number, {method:'PATCH',json:{path:repo.path,title:title,body:body,assignees:assignees,labels:labels,milestone:milestone}});
        renderIssueDetail(tc, issue.number, status, previousState, false, {ok:true, text:t('gm_issues_updated')});
      } catch(e) {
        err.textContent = e.message; err.style.display = 'block'; this.disabled = false; this.textContent = t('gm_save');
      }
    };
  }

  function renderIssueDetail(tc, number, status, previousState, autoBranch, notice) {
    tc.innerHTML = '<div style="color:var(--text-dim);font-size:.8rem">' + t('gm_loading') + '</div>';
    GM.api('/repo/issues/' + number + '?path=' + encodeURIComponent(repo.path)).then(function(data) {
      var issue = data.issue;
      var issueBranch = issueBranchName(status, issue.number);
      var onIssueBranch = repo.branch === issueBranch;
      tc.innerHTML = '<div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">'
        + '<button id="gm-issues-back" class="s-btn s-btn-sm">&#x2190; ' + t('gm_back') + '</button><strong style="flex:1">#' + issue.number + ' ' + GM.escape(issue.title) + '</strong>'
        + '<button id="gm-issue-edit" class="s-btn s-btn-sm">&#x270E; ' + t('gm_issues_edit') + '</button>'
        + '<button id="gm-issue-branch" class="s-btn s-btn-sm" style="display:' + (onIssueBranch ? 'none' : '') + '">&#x1F33F; ' + t('gm_issues_create_branch') + '</button>'
        + '<button id="gm-issue-state" class="s-btn s-btn-sm">' + t(issue.state === 'open' ? 'gm_issues_close' : 'gm_issues_reopen') + '</button></div>'
        + '<div style="font-size:.74rem;color:var(--text-dim);margin-bottom:12px">' + GM.escape(issue.author) + ' · ' + GM.escape(issue.state) + '</div>'
        + '<div id="gm-issue-body-view" class="gm-md" style="line-height:1.5;background:var(--surface2,#313244);border-radius:8px;padding:12px;min-height:48px">'
        + (issue.body ? GM.renderMarkdown(issue.body, true) : '<span style="opacity:.6">' + t('gm_issues_no_description') + '</span>') + '</div>'
        + '<div id="gm-issue-action-result" style="font-size:.78rem;margin-top:10px"></div>'
        + '<div style="font-weight:600;margin:16px 0 8px">' + t('gm_issues_comments_title') + '</div><div id="gm-issue-comments"></div>';
      tc.querySelector('#gm-issues-back').onclick = function() { renderIssueList(tc, previousState || issue.state, status); };
      tc.querySelector('#gm-issue-edit').onclick = function() { renderEditIssue(tc, issue, status, previousState); };
      var actionResult = tc.querySelector('#gm-issue-action-result');
      if (notice) {
        actionResult.style.color = notice.ok ? '#a6e3a1' : '#f9e2af';
        actionResult.textContent = notice.text;
      }
      Array.prototype.forEach.call(tc.querySelectorAll('#gm-issue-body-view .gm-task-checkbox'), function(cb) {
        cb.addEventListener('change', async function() {
          var idx = parseInt(cb.getAttribute('data-task-index'), 10);
          var checked = cb.checked;
          cb.disabled = true;
          try {
            var data = await GM.api('/repo/issues/' + issue.number + '/checklist', {method:'PATCH',json:{path:repo.path,index:idx,checked:checked}});
            issue.body = data.issue.body;
            var span = cb.parentElement.querySelector('span');
            if (span) span.style.cssText = checked ? 'text-decoration:line-through;opacity:.6' : '';
            cb.disabled = false;
          } catch(e) {
            cb.checked = !checked;
            cb.disabled = false;
            mvmOS.notify(t('gm_title'), e.message);
          }
        });
      });
      var comments = tc.querySelector('#gm-issue-comments');
      if (!(issue.comments_list || []).length) comments.innerHTML = '<div style="font-size:.8rem;color:var(--text-dim)">' + t('gm_issues_no_comments') + '</div>';
      (issue.comments_list || []).forEach(function(comment) {
        var item = document.createElement('div');
        item.style.cssText = 'background:var(--surface2,#313244);border-radius:7px;padding:10px;margin-bottom:7px';
        item.innerHTML = '<div style="font-size:.7rem;color:var(--text-dim);margin-bottom:6px">' + GM.escape(comment.author) + '</div><div class="gm-md" style="line-height:1.45">' + GM.renderMarkdown(comment.body, false) + '</div>';
        comments.appendChild(item);
      });
      tc.querySelector('#gm-issue-state').onclick = async function() {
        var next = issue.state === 'open' ? 'closed' : 'open';
        this.disabled = true;
        try {
          await GM.api('/repo/issues/' + issue.number + '/state', {method:'PATCH',json:{path:repo.path,state:next}});
          renderIssueDetail(tc, issue.number, status, next, false);
        } catch(e) { this.disabled = false; tc.querySelector('#gm-issue-action-result').textContent = e.message; }
      };
      tc.querySelector('#gm-issue-branch').onclick = async function() {
        var result = tc.querySelector('#gm-issue-action-result');
        var btn = this;
        btn.disabled = true; btn.textContent = t('gm_issues_checking_branch');
        try {
          await showIssueBranchDialog(tc, issue);
        } catch(e) { result.style.color = '#f38ba8'; result.textContent = e.message; }
        btn.innerHTML = '&#x1F33F; ' + t('gm_issues_create_branch'); btn.disabled = false;
        updateIssueBranchButtons(tc, repo.branch === issueBranch);
      };
      if (autoBranch) {
        actionResult.style.color = 'var(--text-dim)';
        actionResult.textContent = t('gm_issues_checking_branch');
        GM.api('/repo/issues/' + issue.number + '/branch/sync', {method:'POST',json:{path:repo.path}}).then(function(state) {
          if (state.fetch_error) {
            actionResult.style.color = '#f38ba8'; actionResult.textContent = state.fetch_error; return;
          }
          if (state.switched || state.redirected_default) {
            repo.branch = state.current;
            container.querySelector('#gm-branch-btn').innerHTML = '&#x1F33F; ' + GM.escape(state.current) + ' &#x25BE;';
            GM.renderSidebar();
            loadStatus();
            updateIssueBranchButtons(tc, repo.branch === issueBranch);
          }
          if (state.dirty && state.auto) {
            actionResult.style.color = '#f9e2af'; actionResult.textContent = t('gm_issues_dirty_no_switch'); return;
          }
          if (!state.auto && state.local_exists) {
            actionResult.style.color = 'var(--text-dim)';
            actionResult.textContent = state.current === state.branch ? '' : t('gm_issues_branch_exists_no_switch', {branch: state.branch});
            return;
          }
          if (state.local_exists) {
            actionResult.style.color = '#a6e3a1';
            actionResult.textContent = t(state.pulled ? 'gm_issues_branch_synced' : 'gm_switched_to', {branch: state.branch});
            return;
          }
          if (state.remote_exists) {
            actionResult.style.color = 'var(--text-dim)';
            actionResult.innerHTML = t('gm_issues_branch_available_remote', {branch: GM.escape(state.branch)})
              + ' <button id="gm-issue-download-branch" class="s-btn s-btn-sm" style="margin-left:6px">' + t('gm_issues_download_branch') + '</button>';
            actionResult.querySelector('#gm-issue-download-branch').addEventListener('click', async function() {
              var dlBtn = this;
              dlBtn.disabled = true; dlBtn.textContent = t('gm_issues_downloading_branch');
              try {
                var data = await GM.api('/repo/issues/' + issue.number + '/branch/download', {method:'POST',json:{path:repo.path}});
                repo.branch = data.branch;
                container.querySelector('#gm-branch-btn').innerHTML = '&#x1F33F; ' + GM.escape(data.branch) + ' &#x25BE;';
                GM.renderSidebar(); loadStatus();
                updateIssueBranchButtons(tc, repo.branch === issueBranch);
                actionResult.style.color = '#a6e3a1';
                actionResult.textContent = t('gm_issues_branch_downloaded', {branch:data.branch});
              } catch(e) {
                actionResult.style.color = '#f38ba8'; actionResult.textContent = e.message;
              }
            });
            return;
          }
          if (state.redirected_default) {
            actionResult.style.color = 'var(--text-dim)';
            actionResult.textContent = t('gm_issues_switched_default', {branch: state.redirected_default});
          } else {
            actionResult.textContent = '';
          }
        }).catch(function(e) {
          actionResult.style.color = '#f38ba8'; actionResult.textContent = e.message;
        });
      }
    }).catch(function(e) { tc.innerHTML = '<div style="color:#f38ba8;font-size:.82rem">' + GM.escape(e.message) + '</div>'; });
  }

  container.querySelector('#gm-deploy').addEventListener('click', function() {
    GM.runDeploy(repo, function() { loadStatus(); GM.loadRepos(); });
  });
  container.querySelector('#gm-pull').addEventListener('click', function() { doAction('pull'); });
  container.querySelector('#gm-push').addEventListener('click', function() { doAction('push'); });
  container.querySelector('#gm-fetch').addEventListener('click', function() { doAction('fetch'); });
  container.querySelector('#gm-new-branch').addEventListener('click', function() { showNewBranch(); });

  // Offers the main branch (local copy first, then the remote one) and, when
  // the user is somewhere else, a copy of the current branch.
  function branchBases() {
    var current = repo.branch && repo.branch !== '?' && repo.branch !== 'HEAD' ? repo.branch : '';
    var bases = [];
    var remoteDefault = defaultBranch ? { branch: defaultBranch, source: 'remote', label: 'origin/' + defaultBranch, mono: true,
      tag: t('gm_branch_kind_default') + ' · ' + t('gm_branch_source_remote'),
      hint: t('gm_branch_from_default_hint', { branch: defaultBranch }) } : null;
    if (defaultBranch && defaultBranch !== current) {
      bases.push({ branch: defaultBranch, source: 'local', label: defaultBranch, mono: true,
        tag: t('gm_branch_kind_default') + ' · ' + t('gm_branch_source_local'),
        hint: t('gm_branch_from_local_hint', { branch: defaultBranch }) });
      bases.push(remoteDefault);
    }
    bases.push({ branch: current, source: 'local', label: current || 'HEAD', mono: true,
      tag: t('gm_branch_kind_current'),
      hint: t('gm_branch_from_current_hint', { branch: current || 'HEAD' }) });
    // On the default branch itself its local copy is the current branch, but
    // the version on origin is still a different starting point.
    if (defaultBranch && defaultBranch === current) bases.push(remoteDefault);
    return bases;
  }

  function showNewBranch() {
    var bases = branchBases();
    GM.branchDialog({
      title: t('gm_branch_new_title'),
      choicesLabel: t('gm_branch_from'),
      choices: bases,
      name: { value: '', suggest: function(c) { return c.tag === t('gm_branch_kind_current') && c.branch ? c.branch + '_copy' : ''; } },
      confirmLabel: t('gm_branch_create'),
      onConfirm: async function(choice, name) {
        var r = await GM.api('/repo/branch/create', { method: 'POST',
          json: { path: repo.path, name: name, base: choice.branch, source: choice.source } });
        repo.branch = r.branch;
        container.querySelector('#gm-branch-btn').innerHTML = '&#x1F33F; ' + GM.escape(r.branch) + ' &#x25BE;';
        GM.renderSidebar(); loadStatus();
        var out = container.querySelector('#gm-action-output');
        if (out) {
          var msg = t('gm_branch_created_from', { branch: r.branch, base: r.base });
          if (r.local_only) msg += ' — ' + t('gm_branch_local_only');
          out.style.display = 'block'; out.textContent = msg; out.style.color = '#a6e3a1';
        }
      }
    });
  }

  var issuesBtn = container.querySelector('#gm-issues');
  if (!(GM.state.foreignAccess || {}).premium) {
    issuesBtn.addEventListener('click', function() {
      window.dispatchEvent(new CustomEvent('open-subscription-settings'));
    });
    if (window.mvmOS && window.mvmOS.premiumGate) {
      window.mvmOS.premiumGate(issuesBtn, t('gm_issues_premium_info'));
    }
  } else {
    issuesBtn.addEventListener('click', showIssues);
  }

  // On an issue branch the pull request takes its title and description from
  // that issue; on any other branch it starts empty.
  var prToolbarBtn = container.querySelector('#gm-pr-toolbar');
  if (!(GM.state.foreignAccess || {}).premium) {
    prToolbarBtn.addEventListener('click', function() {
      window.dispatchEvent(new CustomEvent('open-subscription-settings'));
    });
    if (window.mvmOS && window.mvmOS.premiumGate) {
      window.mvmOS.premiumGate(prToolbarBtn, t('gm_issues_premium_info'));
    }
  } else {
    prToolbarBtn.addEventListener('click', async function() {
      var head = repo.branch;
      var number = issueNumberFromBranch(head);
      var issue = null;
      if (number) {
        prToolbarBtn.disabled = true;
        try {
          var data = await GM.api('/repo/issues/' + number + '?path=' + encodeURIComponent(repo.path));
          issue = data.issue || null;
        } catch(e) { /* no such issue on GitHub — open the plain dialog */ }
        prToolbarBtn.disabled = false;
      }
      showPRDialog(issue, head);
    });
  }
  container.querySelector('#gm-tab-status').addEventListener('click', function() { switchTab('status'); });
  container.querySelector('#gm-tab-log').addEventListener('click', function() { switchTab('log'); });

  container.querySelector('#gm-branch-btn').addEventListener('click', function(e) {
    e.stopPropagation();
    var existing = document.getElementById('gm-branch-dropdown');
    if (existing) { existing.remove(); return; }

    var btn = container.querySelector('#gm-branch-btn');
    var rect = btn.getBoundingClientRect();

    var dd = document.createElement('div');
    dd.id = 'gm-branch-dropdown';
    dd.style.cssText = 'position:fixed;z-index:999;background:var(--surface);border:1px solid var(--border);border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.4);min-width:180px;overflow:hidden;top:' + (rect.bottom + 4) + 'px;left:' + rect.left + 'px';
    dd.style.width = Math.min(300, window.innerWidth - 16) + 'px';
    dd.style.minWidth = '0';
    dd.style.left = Math.max(8, Math.min(rect.right - 300, window.innerWidth - 308)) + 'px';
    const below = window.innerHeight - rect.bottom - 12;
    const above = rect.top - 12;
    const height = Math.min(320, Math.max(below, above));
    dd.style.maxHeight = height + 'px';
    if (below < 200 && above > below) { dd.style.top = 'auto'; dd.style.bottom = (window.innerHeight - rect.top + 4) + 'px'; }
    dd.style.display = 'flex'; dd.style.flexDirection = 'column';
    dd.addEventListener('click', function(event) { event.stopPropagation(); });
    dd.innerHTML = '<div style="padding:6px 10px;font-size:.72rem;color:var(--text-dim);border-bottom:1px solid var(--border)">' + t('gm_loading_branches') + '</div>';
    document.body.appendChild(dd);

    GM.api('/repo/branches?path=' + encodeURIComponent(repo.path)).then(function(data) {
      if (!dd.isConnected) return;
      dd.innerHTML = '';
      var search = document.createElement('input');
      search.type = 'search'; search.placeholder = t('gm_search_branches');
      search.setAttribute('aria-label', t('gm_search_branches'));
      search.style.cssText = 'box-sizing:border-box;width:calc(100% - 16px);margin:8px;padding:7px;flex-shrink:0;background:var(--surface2);color:var(--text);border:1px solid var(--border);border-radius:5px';
      var items = document.createElement('div');
      items.style.cssText = 'overflow-y:auto;min-height:0;overscroll-behavior:contain';
      dd.append(search, items);
      var empty = document.createElement('div');
      empty.textContent = t('gm_no_matching_branches'); empty.hidden = true;
      empty.style.cssText = 'padding:10px;font-size:.8rem;color:var(--text-dim)';
      dd.appendChild(empty);
      search.addEventListener('input', function() {
        var count = 0;
        items.querySelectorAll('[data-branch]').forEach(function(row) {
          var match = row.dataset.branch.toLowerCase().includes(search.value.trim().toLowerCase());
          row.style.display = match ? 'flex' : 'none'; if (match) count++;
        });
        empty.hidden = count > 0;
      });
      search.addEventListener('keydown', function(event) { if (event.key === 'Escape') { close(); btn.focus(); } });
      search.focus();
      var branches = data.branches.slice();
      if (defaultBranch) {
        var branchRank = function(b) {
          if (b === defaultBranch) return 0;
          if (b === 'origin/' + defaultBranch) return 1;
          return 2;
        };
        branches.sort(function(a, b) { return branchRank(a) - branchRank(b); });
      }
      branches.forEach(function(b) {
        var isRemote = b.startsWith('origin/');
        var label = isRemote ? GM.escape(b.replace('origin/', '')) + ' <span style="font-size:.68rem;opacity:.6">' + t('gm_remote_badge') + '</span>' : GM.escape(b);
        var row = document.createElement('div');
        var isCurrent = b === data.current || (isRemote && b.replace('origin/', '') === data.current);
        row.style.cssText = 'padding:7px 12px;cursor:pointer;font-size:.82rem;display:flex;align-items:center;gap:6px;'
          + (isCurrent ? 'background:var(--accent-dim,rgba(99,102,241,.15));font-weight:600' : '');
        row.innerHTML = (isCurrent ? '<span style="color:var(--accent)">&#x2713;</span> ' : '<span style="width:14px;display:inline-block"></span> ') + label;
        if (!isCurrent) {
          row.addEventListener('mouseenter', function() { this.style.background = 'var(--surface2,#313244)'; });
          row.addEventListener('mouseleave', function() { this.style.background = ''; });
          row.addEventListener('click', function() {
            dd.remove();
            var out = container.querySelector('#gm-action-output');
            if (out) { out.style.display = 'block'; out.style.color = 'var(--text-dim)'; out.textContent = t('gm_switching_to', { branch: b }); }
            GM.api('/repo/checkout', { method: 'POST', json: { path: repo.path, branch: b } }).then(function(r) {
              repo.branch = r.branch;
              btn.innerHTML = '&#x1F33F; ' + GM.escape(r.branch) + ' &#x25BE;';
              if (out) { out.textContent = r.output || t('gm_switched_to', { branch: r.branch }); out.style.color = '#a6e3a1'; }
              GM.loadRepos();
              loadStatus();
            }).catch(function(e) {
              if (out) { out.style.display = 'block'; out.textContent = e.message; out.style.color = '#f38ba8'; }
            });
          });
        }
        row.dataset.branch = b;
        items.appendChild(row);
      });
    }).catch(function(e) {
      dd.innerHTML = '<div style="padding:8px 12px;color:#f38ba8;font-size:.82rem">' + e.message + '</div>';
    });

    var close = function() { dd.remove(); document.removeEventListener('click', close); };
    setTimeout(function() { document.addEventListener('click', close); }, 0);
  });

  var initialStatus = loadStatus();
  if (autoFetch) initialStatus.then(function() { doAction('fetch'); });

  GM.state.statusPollInterval = setInterval(function() {
    if (!container.isConnected || GM.state.activeRepo !== repo) { GM.stopStatusPoll(); return; }
    loadStatus(true);
  }, 4000);
};

// ── SSH view ──────────────────────────────────────────────────────────────────

GM.showSSH = function(container) {
  GM.stopStatusPoll();
  container.innerHTML = '<div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid var(--border);flex-shrink:0;background:var(--surface)">'
    + '<div style="font-weight:600;font-size:.9rem">' + t('gm_ssh_keys') + '</div>'
    + '<button id="gm-ssh-gen" class="s-btn s-btn-sm">&#xFF0B; ' + t('gm_generate_new_key') + '</button>'
    + '</div>'
    + '<div id="gm-ssh-content" style="flex:1;overflow-y:auto;padding:16px 14px;display:flex;flex-direction:column;gap:14px"></div>';
  container.style.display = 'flex';
  container.style.flexDirection = 'column';

  container.querySelector('#gm-ssh-gen').addEventListener('click', function() { showGenerate(container); });
  loadKeys(container);

  function loadKeys(container) {
    var c = container.querySelector('#gm-ssh-content');
    c.innerHTML = '<div style="color:var(--text-dim);font-size:.8rem;opacity:.7">' + t('gm_loading') + '</div>';
    GM.api('/ssh').then(function(keys) {
      c.innerHTML = '';
      if (!keys.length) {
        c.innerHTML = '<div style="color:var(--text-dim);font-size:.85rem;text-align:center;padding:24px 0;opacity:.7">' + t('gm_no_ssh_keys') + '</div>';
        return;
      }
      keys.forEach(function(key) {
        var parts = key.public_key.split(' ');
        var comment = parts[2] || '';
        var card = document.createElement('div');
        card.style.cssText = 'background:var(--surface2,#313244);border-radius:8px;padding:14px;display:flex;flex-direction:column;gap:10px';
        card.innerHTML = '<div style="display:flex;align-items:center;gap:8px">'
          + '<span style="font-size:1.1rem">&#x1F511;</span>'
          + '<div style="flex:1"><div style="font-weight:600;font-size:.85rem">' + key.type + '</div>'
          + (comment ? '<div style="font-size:.75rem;color:var(--text-dim)">' + comment + '</div>' : '')
          + '</div><span style="font-size:.7rem;background:#a6e3a1;color:#1e1e2e;border-radius:10px;padding:2px 8px;font-weight:600">' + t('gm_active') + '</span></div>'
          + '<div style="font-family:monospace;font-size:.72rem;color:var(--text-dim);background:var(--surface);border-radius:5px;padding:7px 10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'
          + key.public_key.substring(0, key.type.length + 49) + '...</div>'
          + '<div style="display:flex;gap:6px;flex-wrap:wrap">'
          + '<button class="s-btn s-btn-sm gm-copy-key">&#x1F4CB; ' + t('gm_copy_public_key') + '</button>'
          + '<button class="s-btn s-btn-sm gm-test-gh">' + t('gm_test_github') + '</button>'
          + '<button class="s-btn s-btn-sm gm-test-gl">' + t('gm_test_gitlab') + '</button>'
          + '<button class="s-btn s-btn-sm gm-test-custom">' + t('gm_test_other') + '</button>'
          + '</div>'
          + '<div class="gm-test-result" style="display:none;font-size:.78rem;padding:6px 10px;border-radius:5px;font-family:monospace"></div>';

        card.querySelector('.gm-copy-key').addEventListener('click', function() {
          var btn = this;
          navigator.clipboard.writeText(key.public_key).then(function() {
            btn.textContent = '✓ ' + t('gm_copied');
            setTimeout(function() { btn.textContent = '📋 ' + t('gm_copy_public_key'); }, 2000);
          });
        });

        function testSSH(host) {
          var result = card.querySelector('.gm-test-result');
          result.style.display = 'block';
          result.style.background = 'var(--surface)';
          result.style.color = 'var(--text-dim)';
          result.textContent = t('gm_testing_host', { host: host });
          GM.api('/ssh/test', { method: 'POST', json: { host: host } }).then(function(r) {
            result.textContent = r.output || (r.ok ? t('gm_connection_ok') : t('gm_connection_failed'));
            result.style.color = r.ok ? '#a6e3a1' : '#f38ba8';
            result.style.background = r.ok ? 'rgba(166,227,161,.1)' : 'rgba(243,139,168,.1)';
          }).catch(function(e) {
            result.textContent = e.message; result.style.color = '#f38ba8';
          });
        }

        card.querySelector('.gm-test-gh').addEventListener('click', function() { testSSH('github.com'); });
        card.querySelector('.gm-test-gl').addEventListener('click', function() { testSSH('gitlab.com'); });
        card.querySelector('.gm-test-custom').addEventListener('click', async function() {
          var host = await mvmOS.prompt(t('gm_hostname_prompt'), t('gm_hostname_placeholder'));
          if (host) testSSH(host);
        });
        c.appendChild(card);
      });

      var note = document.createElement('div');
      note.style.cssText = 'font-size:.78rem;color:var(--text-dim);padding:4px 0;opacity:.8';
      note.innerHTML = t('gm_ssh_tip');
      c.appendChild(note);
    }).catch(function(e) {
      c.innerHTML = '<div style="color:#f38ba8;font-size:.82rem">' + e.message + '</div>';
    });
  }

  function showGenerate(container) {
    var overlay = document.createElement('div');
    overlay.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:99';
    overlay.innerHTML = '<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:20px;width:360px;display:flex;flex-direction:column;gap:12px">'
      + '<div style="font-weight:600;font-size:.95rem">' + t('gm_generate_ssh_key_title') + '</div>'
      + '<div><div style="font-size:.75rem;color:var(--text-dim);margin-bottom:4px">' + t('gm_comment_optional') + '</div>'
      + '<input class="s-input" id="gm-gen-comment" placeholder="' + t('gm_comment_placeholder') + '" style="width:100%;box-sizing:border-box"></div>'
      + '<div style="font-size:.78rem;color:var(--text-dim);background:var(--surface2,#313244);border-radius:6px;padding:8px 10px">' + t('gm_gen_key_note') + '</div>'
      + '<div id="gm-gen-err" style="color:#f38ba8;font-size:.82rem;display:none"></div>'
      + '<div style="display:flex;gap:8px;justify-content:flex-end">'
      + '<button class="s-btn" id="gm-gen-cancel">' + t('gm_cancel') + '</button>'
      + '<button class="s-btn" id="gm-gen-ok" style="background:var(--accent);color:#fff;border-color:var(--accent)">' + t('gm_generate') + '</button>'
      + '</div></div>';
    container.style.position = 'relative';
    container.appendChild(overlay);
    overlay.querySelector('#gm-gen-comment').focus();
    overlay.querySelector('#gm-gen-cancel').addEventListener('click', function() { overlay.remove(); });
    overlay.querySelector('#gm-gen-ok').addEventListener('click', function() {
      var comment = overlay.querySelector('#gm-gen-comment').value.trim();
      var errEl = overlay.querySelector('#gm-gen-err');
      var btn = overlay.querySelector('#gm-gen-ok');
      btn.textContent = t('gm_generating'); btn.disabled = true;
      GM.api('/ssh/generate', { method: 'POST', json: { comment: comment } }).then(function() {
        overlay.remove();
        loadKeys(container);
      }).catch(function(e) {
        errEl.textContent = e.message; errEl.style.display = 'block';
        btn.textContent = t('gm_generate'); btn.disabled = false;
      });
    });
  }
};

// ── Settings (the app's panel in the Store) ──────────────────────────────────

GM.openSettings = function() {
  AppStore.openWindow({ section: 'my-apps', appId: 'git-manager' });
};

// The folders searched for repositories are for everyone. What opening an
// issue does to the branch and how the issue list is split belong to Issues,
// so they are Premium: without it the choices are shown but a click opens
// the Premium dialog, and the server refuses to store them anyway.
GM.issueSettings = function() {
  return fetch('/api/apps/git-manager/settings/issues').then(function(r) { return r.json(); })
    .catch(function() { return { premium: false, switch_mode: 'off', list_groups: [], list_merge_mine: false }; });
};

GM.renderSettingsExtra = async function(wrap) {
  var results = await Promise.all([GM.issueSettings(),
    fetch('/api/apps/git-manager/settings/repos').then(function(r) { return r.json(); }).catch(function() { return { roots: [], folders: [] }; })]);
  var data = results[0], scan = results[1];
  wrap.style.cssText = 'display:flex;flex-direction:column;gap:16px';
  var reposBox = document.createElement('div');
  reposBox.style.cssText = 'display:flex;flex-direction:column;gap:8px';
  reposBox.innerHTML = '<div style="font-size:.82rem;font-weight:700">' + t('gm_settings_repos_title') + '</div>'
    + '<div style="font-size:.8rem;color:var(--text-dim)">' + t('gm_settings_scan_label') + '</div>'
    + '<textarea class="s-input" name="gm-scan-folders" rows="4" spellcheck="false" autocomplete="off" placeholder="/srv/projects" '
    + 'style="width:100%;max-width:none;box-sizing:border-box;font-family:monospace;resize:vertical"></textarea>'
    + '<div style="font-size:.75rem;color:var(--text-dim);line-height:1.5">'
    + t('gm_settings_scan_hint', { roots: (scan.roots || []).map(GM.escape).join(', ') }) + '</div>'
    + '<div data-gm-scan-error style="display:none;color:#f38ba8;font-size:.78rem"></div>';
  var folders = reposBox.querySelector('textarea');
  folders.value = (scan.folders || []).join('\n');
  folders.dataset.saved = folders.value;
  wrap.appendChild(reposBox);
  var issuesBox = document.createElement('div');
  wrap.appendChild(issuesBox);
  GM.renderIssueSettings(issuesBox, data);
};

GM.renderIssueSettings = function(wrap, data) {
  var off = data.premium ? '' : ' disabled';
  var option = function(type, name, value, checked, label) {
    return '<label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:.85rem">'
      + '<input type="' + type + '" name="' + name + '" value="' + value + '"' + (checked ? ' checked' : '') + off + '> ' + label + '</label>';
  };
  var hint = function(key) { return '<div style="font-size:.75rem;color:var(--text-dim);line-height:1.5">' + t(key) + '</div>'; };
  wrap.style.cssText = 'display:flex;flex-direction:column;gap:8px';
  wrap.innerHTML = '<div style="font-size:.82rem;font-weight:700">' + t('gm_settings_issues_title') + '</div>'
    + '<div style="font-size:.8rem;color:var(--text-dim)">' + t('gm_settings_switch_label') + '</div>'
    + ['off', 'other_issue', 'always'].map(function(mode) {
      return option('radio', 'gm-switch-mode', mode, data.switch_mode === mode, t('gm_settings_switch_' + mode));
    }).join('')
    + hint('gm_settings_switch_hint')
    + '<div style="font-size:.8rem;color:var(--text-dim);margin-top:6px">' + t('gm_settings_list_label') + '</div>'
    + ['created', 'assigned', 'others'].map(function(group) {
      return option('checkbox', 'gm-list-group', group, (data.list_groups || []).indexOf(group) !== -1, t('gm_settings_list_' + group));
    }).join('')
    + hint('gm_settings_list_hint')
    + option('checkbox', 'gm-list-merge', '1', data.list_merge_mine, t('gm_settings_list_merge'));
  // Joining only means something while both of those groups are picked.
  var merge = wrap.querySelector('input[name="gm-list-merge"]');
  var syncMerge = function() {
    var picked = ['created', 'assigned'].every(function(g) { return wrap.querySelector('input[name="gm-list-group"][value="' + g + '"]').checked; });
    merge.disabled = !data.premium || !picked;
    merge.parentNode.style.opacity = picked ? '' : '.5';
  };
  syncMerge();
  wrap.addEventListener('change', syncMerge);
  if (!data.premium && window.mvmOS && window.mvmOS.premiumGate) window.mvmOS.premiumGate(wrap, t('gm_issues_premium_info'));
};

GM.saveSettingsExtra = async function(panel) {
  var folders = panel.querySelector('textarea[name="gm-scan-folders"]');
  if (folders && folders.value !== folders.dataset.saved) {
    var error = panel.querySelector('[data-gm-scan-error]');
    var saved = await fetch('/api/apps/git-manager/settings/repos', {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ folders: folders.value.split('\n') }),
    }).catch(function() { return null; });
    if (saved && saved.ok) {
      folders.dataset.saved = folders.value;
      error.style.display = 'none';
    } else {
      var detail = saved ? (await saved.json().catch(function() { return {}; })).detail : '';
      error.textContent = t(detail === 'not_absolute' || detail === 'too_many' ? 'gm_settings_scan_' + detail : 'gm_settings_scan_failed');
      error.style.display = 'block';
    }
  }
  var picked = panel.querySelector('input[name="gm-switch-mode"]:checked');
  if (!picked || picked.disabled) return;
  var groups = Array.prototype.map.call(panel.querySelectorAll('input[name="gm-list-group"]:checked'), function(el) { return el.value; });
  var merge = panel.querySelector('input[name="gm-list-merge"]');
  var res = await fetch('/api/apps/git-manager/settings/issues', {
    method: 'PUT', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ switch_mode: picked.value, list_groups: groups, list_merge_mine: !!(merge && merge.checked) }),
  });
  if (!res.ok) throw new Error('premium_required');
};

// ── Register ──────────────────────────────────────────────────────────────────

mvmOS.registerApp({
  id: 'git-manager',
  name: t('gm_title'),
  icon: '🔀',
  category: 'Developer Tools',
  width: 900,
  height: 580,
  settings: [],
  appSettings: true,
  onAppSettings: GM.openSettings,
  renderSettingsExtra: function(wrap) { return GM.renderSettingsExtra(wrap); },
  saveSettingsExtra: function(panel) { return GM.saveSettingsExtra(panel); },

  launch: function() {
    mvmOS.createWindow({
      id: 'git-manager',
      title: '🔀 ' + t('gm_title'),
      icon: '🔀',
      width: 900,
      height: 580,
      minWidth: 640,
      minHeight: 400,
      appSettings: true,
      onAppSettings: GM.openSettings,
      onMount: function(body) {
        body.innerHTML = '';
        GM.init(body);
      }
    });
  }
});

// ── Public API for other apps (e.g. mvmAI's project file tree) to jump
//    straight into a specific repo, already selected and fetched ───────────
window.GitManager = {
  openRepo: function(path) {
    mvmOS.createWindow({
      id: 'git-manager',
      title: '🔀 ' + t('gm_title'),
      icon: '🔀',
      width: 900,
      height: 580,
      minWidth: 640,
      minHeight: 400,
      appSettings: true,
      onAppSettings: GM.openSettings,
      onMount: function(body) {
        body.innerHTML = '';
        GM.init(body);
      }
    });
    var tries = 0;
    var iv = setInterval(function() {
      tries++;
      var repo = (GM.state.repos || []).filter(function(r) { return r.path === path; })[0];
      if (repo) {
        clearInterval(iv);
        GM.openRepo(repo);
      } else if (tries > 40) {
        clearInterval(iv);
      }
    }, 50);
  }
};

}

if (window.GIT_MANAGER_I18N) {
  start();
} else {
  var i18nScript = document.createElement('script');
  i18nScript.src = '/apps/git-manager/i18n.js?_=' + Date.now();
  i18nScript.onload = start;
  i18nScript.onerror = start;
  document.head.appendChild(i18nScript);
}

})();
