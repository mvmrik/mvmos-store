// mvmOS App: RSS Reader v1.0.0

const _rssi18n = {
  en: {
    title:          'RSS Reader',
    fetch:          '↻ Fetch',
    settings:       '⚙ Settings',
    all_feeds:      'All feeds',
    unread:         'Unread',
    read:           'Read',
    all_filter:     'All',
    add_feed:       '+ Add Feed',
    no_feeds:       'No feeds yet. Add one in Settings.',
    no_articles:    'No articles.',
    back:           '← Back',
    back_list:      '← Back',
    open_original:  'Open original ↗',
    mark_all_read:  'Mark all read',
    del_feed:       'Delete',
    feed_url_ph:    'RSS / Atom URL',
    add:            'Add',
    cancel:         'Cancel',
    settings_title: 'Settings',
    feeds_title:    'Feeds',
    fetch_interval: 'Auto-fetch every',
    public_page:    'Public reading list',
    public_url:     'Public URL',
    copy:           'Copy',
    copied:         'Copied!',
    save:           'Save',
    fetching:       'Fetching…',
    feed_added:     'Feed added.',
    settings_saved: 'Settings saved.',
    min5:  '5 minutes',  min15: '15 minutes', min30: '30 minutes',
    h1:    '1 hour',     h2:    '2 hours',    h6:    '6 hours',
    h12:   '12 hours',   h24:   '24 hours',
    filter_label:   'Show:',
    source_label:   'Source:',
    just_now:       'just now',
    ago_min:        'min ago',
    ago_h:          'h ago',
    ago_d:          'd ago',
    saved:          'Saved',
    error_label:    'Error',
    fetched_label:  'Last fetched',
    public_hint:    'When enabled, anyone with the link can see your unread articles. Reading an article marks it as read.',
    ai_section:     'AI Buttons',
    ai_source_lbl:  'AI source',
    ai_off:         'Disabled',
    ai_mvmai:       'mvmAI — configured provider',
    ai_cli:         'mvmAI — Claude CLI',
    ai_btn_name_ph: 'Button name (e.g. Summarize)',
    ai_btn_prmt_ph: 'Prompt (e.g. Summarize this article in Bulgarian in 3-4 sentences.)',
    ai_add_btn:     '+ Add button',
    ai_no_btns:     'No buttons yet.',
    ai_examples:    'Examples: "Summarize in Bulgarian in 3-4 sentences." · "Translate fully to Bulgarian." · "TL;DR in English in 2 sentences."',
    ai_running:     'Working…',
    ai_result_close:'Close',
    ai_scope_lbl:   'Show in',
    ai_scope_list:  'List',
    ai_scope_reader:'Reader',
    ai_scope_both:  'Both',
  },
  bg: {
    title:          'RSS четец',
    fetch:          '↻ Обнови',
    settings:       '⚙ Настройки',
    all_feeds:      'Всички',
    unread:         'Непрочетени',
    read:           'Прочетени',
    all_filter:     'Всички',
    add_feed:       '+ Добави',
    no_feeds:       'Няма добавени източници. Добави в Настройки.',
    no_articles:    'Няма статии.',
    back:           '← Назад',
    back_list:      '← Назад',
    open_original:  'Отвори оригинала ↗',
    mark_all_read:  'Маркирай всички прочетени',
    del_feed:       'Изтрий',
    feed_url_ph:    'RSS / Atom URL',
    add:            'Добави',
    cancel:         'Отказ',
    settings_title: 'Настройки',
    feeds_title:    'Източници',
    fetch_interval: 'Проверявай на всеки',
    public_page:    'Публичен списък за четене',
    public_url:     'Публичен линк',
    copy:           'Копирай',
    copied:         'Копирано!',
    save:           'Запази',
    fetching:       'Зареждане…',
    feed_added:     'Изворът е добавен.',
    settings_saved: 'Настройките са запазени.',
    min5:  '5 минути',  min15: '15 минути', min30: '30 минути',
    h1:    '1 час',     h2:    '2 часа',    h6:    '6 часа',
    h12:   '12 часа',   h24:   '24 часа',
    filter_label:   'Покажи:',
    source_label:   'Извор:',
    just_now:       'сега',
    ago_min:        'мин. назад',
    ago_h:          'ч. назад',
    ago_d:          'д. назад',
    saved:          'Запазени',
    error_label:    'Грешка',
    fetched_label:  'Последно обновен',
    public_hint:    'При активиране всеки с линка вижда непрочетените ти статии. Отварянето на статия я маркира като прочетена.',
    ai_section:     'AI бутони',
    ai_source_lbl:  'AI провайдър',
    ai_off:         'Изключено',
    ai_mvmai:       'mvmAI — настроен провайдър',
    ai_cli:         'mvmAI — Claude CLI',
    ai_btn_name_ph: 'Наименование (напр. Резюме)',
    ai_btn_prmt_ph: 'Промпт (напр. Резюмирай на български в 3-4 изречения.)',
    ai_add_btn:     '+ Добави бутон',
    ai_no_btns:     'Няма бутони.',
    ai_examples:    'Примери: "Резюмирай на български в 3-4 изречения." · "Преведи изцяло на български." · "TL;DR на 2 изречения."',
    ai_running:     'Обработва…',
    ai_result_close:'Затвори',
    ai_scope_lbl:   'Показвай в',
    ai_scope_list:  'Списък',
    ai_scope_reader:'Reader',
    ai_scope_both:  'И двете',
  },
};
function _rsst(key) {
  const lang = window.mvmOS?.lang || 'en';
  return (_rssi18n[lang] || _rssi18n.en)[key] || key;
}

mvmOS.registerApp({
  id: 'rssfeed',
  name: 'RSS Reader',
  icon: '📰',
  category: 'Utilities',
  launch() {
    mvmOS.createWindow({
      id: 'rssfeed',
      title: '📰 RSS Reader',
      width: 820,
      height: 580,
      onMount(body) {
        body.style.padding = '0';
        body.style.overflow = 'hidden';
        RSS.mount(body);
      },
    });
  },
});

const RSS = (() => {
  const _t = _rsst;
  let _root, _view = 'list';
  let _feeds = [], _articles = [], _settings = {};
  let _selFeed = 0;       // 0 = all
  let _filterRead = 0;    // -1=all, 0=unread, 1=read
  let _filterSaved = false;
  let _selArticle = null;
  let _fetching = false;
  let _pendingAiButtons = null; // initialized from settings when entering settings view

  // ── API ───────────────────────────────────────────────────────────────────

  async function _api(method, path, body) {
    const opts = { method, headers: {} };
    if (body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    const r = await fetch(`/api/apps/rssfeed${path}`, opts);
    if (!r.ok) {
      const txt = await r.text().catch(() => '');
      throw new Error(txt || r.statusText);
    }
    return r.json();
  }

  async function _reload() {
    const q = _filterSaved
      ? `feed_id=${_selFeed}&is_saved=1`
      : `feed_id=${_selFeed}&is_read=${_filterRead}`;
    [_feeds, _articles, _settings] = await Promise.all([
      _api('GET', '/feeds'),
      _api('GET', `/articles?${q}&limit=200`),
      _api('GET', '/settings'),
    ]);
  }

  async function _reloadArticles() {
    const q = _filterSaved
      ? `feed_id=${_selFeed}&is_saved=1`
      : `feed_id=${_selFeed}&is_read=${_filterRead}`;
    _articles = await _api('GET', `/articles?${q}&limit=200`);
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  function _esc(s) {
    return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function _stripHtml(html) {
    const d = document.createElement('div');
    d.innerHTML = html || '';
    return d.textContent || d.innerText || '';
  }
  function _relTime(dateStr) {
    if (!dateStr) return '';
    try {
      const dt  = new Date(dateStr);
      const sec = Math.floor((Date.now() - dt.getTime()) / 1000);
      if (sec < 90)   return _t('just_now');
      if (sec < 3600) return `${Math.floor(sec/60)} ${_t('ago_min')}`;
      if (sec < 86400) return `${Math.floor(sec/3600)} ${_t('ago_h')}`;
      return `${Math.floor(sec/86400)} ${_t('ago_d')}`;
    } catch { return ''; }
  }
  function _wrap()  { return _root?.querySelector('#rss-wrap'); }
  function _btnS(type) {
    const b = 'padding:5px 11px;border-radius:4px;cursor:pointer;font-size:.82rem;font-family:inherit;';
    if (type === 'primary')   return b + 'border:none;background:var(--accent);color:#fff;';
    if (type === 'ghost')     return b + 'border:1px solid var(--border);background:transparent;color:var(--text-dim);';
    if (type === 'link')      return 'background:none;border:none;cursor:pointer;font-size:.82rem;color:var(--accent);padding:0;font-family:inherit;';
    return b + 'border:1px solid var(--border);background:var(--surface);color:var(--text);';
  }

  // ── AI ────────────────────────────────────────────────────────────────────

  async function _runAI(prompt, article) {
    const body = `${prompt}\n\n---\nTitle: ${article.title || ''}\n\n${_stripHtml(article.description || '').slice(0, 1200)}`;
    const messages = [{ role: 'user', content: body }];
    const source = _settings.ai_source || 'off';
    if (source === 'claude-cli') {
      const r = await fetch('/api/mvmai/cli-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ provider_id: 'claude-cli', messages }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || r.statusText);
      return d.content || '';
    }
    const r = await fetch('/api/mvmai/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages, tools_enabled: false }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || r.statusText);
    return d.message?.content || '';
  }

  // ── Main render ───────────────────────────────────────────────────────────

  function _render() {
    const w = _wrap();
    if (!w) return;
    if (_view === 'settings') { _renderSettings(w); return; }
    _renderMain(w);
  }

  function _renderMain(w) {
    const totalUnread = _feeds.reduce((s, f) => s + (f.unread_count || 0), 0);

    w.innerHTML = `
      <div style="display:flex;align-items:center;gap:8px;padding:8px 14px;border-bottom:1px solid var(--border);flex-shrink:0">
        <span style="font-weight:700;font-size:.95rem;flex:1">${_t('title')}</span>
        <button id="rss-fetch" style="${_btnS('ghost')}">${_t('fetch')}</button>
        <button id="rss-settings" style="${_btnS('ghost')}">${_t('settings')}</button>
      </div>
      <div style="display:flex;flex:1;overflow:hidden">

        <!-- Sidebar -->
        <div style="width:200px;flex-shrink:0;border-right:1px solid var(--border);overflow-y:auto;padding:8px 0">
          ${_feedItem(0, _t('all_feeds'), totalUnread, _selFeed === 0)}
          ${_feeds.map(f => _feedItem(f.id, f.name, f.unread_count || 0, _selFeed === f.id)).join('')}
        </div>

        <!-- Content area -->
        <div style="flex:1;display:flex;flex-direction:column;overflow:hidden">
          ${_selArticle ? _readerHtml() : _listHtml()}
        </div>
      </div>
    `;

    // Sidebar clicks
    w.querySelectorAll('.rss-feed-item').forEach(el => {
      el.onclick = async () => {
        _selFeed    = parseInt(el.dataset.id);
        _selArticle = null;
        await _reloadArticles();
        _render();
      };
    });

    // Header buttons
    w.querySelector('#rss-fetch').onclick = _doFetch;
    w.querySelector('#rss-settings').onclick = () => { _view = 'settings'; _render(); };

    if (_selArticle) {
      _bindReader(w);
    } else {
      _bindList(w);
    }
  }

  function _feedItem(id, name, unread, selected) {
    const bg = selected ? 'background:var(--accent);color:#fff;' : '';
    const cnt = unread > 0 ? `<span style="background:var(--accent);color:#fff;border-radius:99px;font-size:.65rem;padding:1px 6px;margin-left:4px;${selected?'background:rgba(255,255,255,.35)':''}">${unread}</span>` : '';
    return `<div class="rss-feed-item" data-id="${id}"
      style="padding:7px 14px;cursor:pointer;font-size:.82rem;display:flex;align-items:center;gap:4px;${bg}border-radius:4px;margin:0 4px;${!selected?'':''}"
      onmouseenter="if(!${selected})this.style.background='var(--surface)'"
      onmouseleave="if(!${selected})this.style.background=''">
      <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${_esc(name)}</span>${cnt}
    </div>`;
  }

  // ── Article list ──────────────────────────────────────────────────────────

  function _listHtml() {
    const aiSource = _settings.ai_source || 'off';
    let _allAiBtns = [];
    if (aiSource !== 'off') { try { _allAiBtns = JSON.parse(_settings.ai_buttons || '[]'); } catch {} }
    const listBtns = _allAiBtns.filter(b => (b.scope||'reader') === 'list' || b.scope === 'both');
    const filters = [
      { v: -1,      saved: false, lbl: _t('all_filter') },
      { v: 0,       saved: false, lbl: _t('unread') },
      { v: 1,       saved: false, lbl: _t('read') },
      { v: -1,      saved: true,  lbl: _t('saved') },
    ];
    const filterBar = `
      <div style="display:flex;gap:8px;align-items:center;padding:8px 12px;border-bottom:1px solid var(--border);flex-shrink:0;flex-wrap:wrap">
        <span style="font-size:.76rem;color:var(--text-dim)">${_t('filter_label')}</span>
        ${filters.map((f, fi) => {
          const active = f.saved ? _filterSaved : (!_filterSaved && _filterRead === f.v);
          return `<button class="rss-filter" data-fi="${fi}" style="${_btnS(active?'primary':'ghost')}">${f.lbl}</button>`;
        }).join('')}
        <div style="flex:1"></div>
        <button id="rss-mark-all" style="${_btnS('ghost')} font-size:.78rem">${_t('mark_all_read')}</button>
      </div>`;

    if (_articles.length === 0) {
      return filterBar + `<div style="text-align:center;color:var(--text-dim);padding:48px 16px;font-size:.85rem">${_t('no_articles')}</div>`;
    }

    const items = _articles.map(a => {
      const unread  = !a.is_read;
      const excerpt = _stripHtml(a.description || '');
      const rel     = _relTime(a.pub_date || a.fetched_at);
      const showFeed = _selFeed === 0;
      return `
        <div class="rss-art" data-id="${a.id}" style="padding:11px 14px;border-bottom:1px solid var(--border);cursor:pointer;transition:background .1s"
          onmouseenter="this.style.background='var(--surface)'"
          onmouseleave="this.style.background=''">
          <div style="display:flex;align-items:flex-start;gap:8px">
            <span style="width:7px;height:7px;border-radius:50%;flex-shrink:0;margin-top:6px;display:inline-block;${unread?'background:var(--accent)':''}"></span>
            <div style="flex:1;min-width:0">
              <div style="font-size:.86rem;font-weight:${unread?'600':'400'};color:${unread?'var(--text)':'var(--text-dim)'};line-height:1.4;word-break:break-word">${_esc(a.title || '(no title)')}</div>
              ${excerpt ? `<div style="font-size:.75rem;color:var(--text-dim);margin-top:3px;line-height:1.4;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical">${_esc(excerpt)}</div>` : ''}
              <div style="font-size:.7rem;color:var(--text-dim);margin-top:4px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
                ${showFeed ? `<span style="color:var(--accent)">${_esc(a.feed_name)}</span>` : ''}
                ${rel ? `<span>${rel}</span>` : ''}
                ${listBtns.map((b, bi) => `<button class="rss-list-ai-btn" data-aid="${a.id}" data-bi="${bi}" style="background:none;border:1px solid var(--border);border-radius:3px;padding:1px 7px;font-size:.7rem;cursor:pointer;color:var(--text-dim);font-family:inherit" onclick="event.stopPropagation()">${_esc(b.name)}</button>`).join('')}
              </div>
              <div class="rss-list-ai-result" data-aid="${a.id}" style="display:none;margin-top:7px;background:var(--surface);border:1px solid var(--border);border-radius:4px;padding:8px 10px;font-size:.78rem;line-height:1.6;white-space:pre-wrap;word-break:break-word"></div>
            </div>
            <button class="rss-star" data-id="${a.id}" onclick="event.stopPropagation()"
              style="background:none;border:none;cursor:pointer;font-size:1.05rem;padding:2px 4px;flex-shrink:0;line-height:1;color:${a.is_saved?'#f59e0b':'var(--text-dim)'}">
              ${a.is_saved ? '★' : '☆'}
            </button>
          </div>
        </div>`;
    }).join('');

    return filterBar + `<div style="flex:1;overflow-y:auto">${items}</div>`;
  }

  const _filterDefs = [
    { v: -1, saved: false },
    { v: 0,  saved: false },
    { v: 1,  saved: false },
    { v: -1, saved: true  },
  ];

  function _bindList(w) {
    w.querySelectorAll('.rss-filter').forEach(btn => {
      btn.onclick = async () => {
        const f = _filterDefs[parseInt(btn.dataset.fi)];
        _filterSaved = f.saved;
        _filterRead  = f.v;
        await _reloadArticles();
        _render();
      };
    });

    w.querySelectorAll('.rss-star').forEach(btn => {
      btn.onclick = async (e) => {
        e.stopPropagation();
        const id = parseInt(btn.dataset.id);
        const res = await _api('POST', `/articles/${id}/save`).catch(() => null);
        if (!res) return;
        const a = _articles.find(x => x.id === id);
        if (a) a.is_saved = res.is_saved;
        btn.textContent = res.is_saved ? '★' : '☆';
        btn.style.color = res.is_saved ? '#f59e0b' : 'var(--text-dim)';
        if (_filterSaved && !res.is_saved) {
          _articles = _articles.filter(x => x.id !== id);
          _render();
        }
      };
    });
    w.querySelectorAll('.rss-art').forEach(el => {
      el.onclick = async () => {
        const id = parseInt(el.dataset.id);
        _selArticle = _articles.find(a => a.id === id) || null;
        if (_selArticle && !_selArticle.is_read) {
          await _api('POST', `/articles/${id}/read`).catch(() => {});
          _selArticle.is_read = 1;
          const feed = _feeds.find(f => f.id === _selArticle.feed_id);
          if (feed && feed.unread_count > 0) feed.unread_count--;
        }
        _render();
      };
    });
    // List AI buttons
    let _allAiBtns2 = [];
    try { _allAiBtns2 = JSON.parse(_settings.ai_buttons || '[]'); } catch {}
    const _listBtns2 = _allAiBtns2.filter(b => (b.scope||'reader') === 'list' || b.scope === 'both');
    w.querySelectorAll('.rss-list-ai-btn').forEach(btn => {
      btn.onclick = async (e) => {
        e.stopPropagation();
        const aid = parseInt(btn.dataset.aid);
        const bi  = parseInt(btn.dataset.bi);
        const b   = _listBtns2[bi];
        if (!b) return;
        const a   = _articles.find(x => x.id === aid);
        if (!a) return;
        const orig = btn.textContent;
        btn.disabled = true;
        btn.textContent = _t('ai_running');
        const resultEl = w.querySelector(`.rss-list-ai-result[data-aid="${aid}"]`);
        try {
          const text = await _runAI(b.prompt, { title: a.title, description: _stripHtml(a.description || '').slice(0, 150) });
          if (resultEl) { resultEl.textContent = text; resultEl.style.display = ''; }
        } catch (err) {
          if (resultEl) { resultEl.textContent = String(err); resultEl.style.display = ''; }
        } finally {
          btn.disabled = false;
          btn.textContent = orig;
        }
      };
    });

    const mAll = w.querySelector('#rss-mark-all');
    if (mAll) mAll.onclick = async () => {
      await _api('POST', '/articles/read-all', { feed_id: _selFeed }).catch(() => {});
      await _reload();
      _selArticle = null;
      _render();
    };
  }

  // ── Reader ────────────────────────────────────────────────────────────────

  function _readerHtml() {
    const a   = _selArticle;
    const rel = _relTime(a.pub_date || a.fetched_at);
    const aiSource = _settings.ai_source || 'off';
    let aiButtons = [];
    if (aiSource !== 'off') {
      try {
        const all = JSON.parse(_settings.ai_buttons || '[]');
        aiButtons = all.filter(b => (b.scope||'reader') === 'reader' || b.scope === 'both');
      } catch {}
    }
    const aiRow = aiButtons.length > 0 ? `
      <div id="rss-ai-btns" style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px">
        ${aiButtons.map((b, i) => `<button class="rss-ai-btn" data-i="${i}" style="${_btnS('ghost')} font-size:.78rem;padding:4px 10px">${_esc(b.name)}</button>`).join('')}
      </div>
      <div id="rss-ai-result" style="display:none;background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:12px 14px;margin-bottom:16px;font-size:.84rem;line-height:1.7">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <span id="rss-ai-result-label" style="font-size:.72rem;font-weight:600;color:var(--accent)"></span>
          <button id="rss-ai-close" style="background:none;border:none;cursor:pointer;color:var(--text-dim);font-size:.9rem;padding:0;font-family:inherit">${_t('ai_result_close')}</button>
        </div>
        <div id="rss-ai-result-text" style="white-space:pre-wrap;word-break:break-word"></div>
      </div>` : '';
    return `
      <div style="flex:1;overflow-y:auto;padding:20px 22px">
        <div style="margin-bottom:14px">
          <button id="rss-back-list" style="${_btnS('ghost')}">${_t('back_list')}</button>
        </div>
        <div style="font-size:.72rem;color:var(--accent);margin-bottom:6px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
          <span>${_esc(a.feed_name || '')}</span>
          ${rel ? `<span style="color:var(--text-dim)">${rel}</span>` : ''}
        </div>
        <h2 style="font-size:1rem;font-weight:700;line-height:1.45;margin-bottom:14px;word-break:break-word">${_esc(a.title || '(no title)')}</h2>
        ${aiRow}
        <div id="rss-content" style="font-size:.86rem;line-height:1.7;color:var(--text);word-break:break-word;max-width:640px">
          ${a.description || '<span style="color:var(--text-dim)">—</span>'}
        </div>
        ${a.link ? `
        <div style="margin-top:20px">
          <a href="${_esc(a.link)}" target="_blank" rel="noopener" style="color:var(--accent);font-size:.84rem;text-decoration:none">${_t('open_original')}</a>
        </div>` : ''}
      </div>`;
  }

  function _bindReader(w) {
    w.querySelector('#rss-back-list').onclick = () => {
      _selArticle = null;
      _render();
    };
    w.querySelectorAll('.rss-ai-btn').forEach(btn => {
      btn.onclick = async () => {
        let aiButtons = [];
        try { aiButtons = JSON.parse(_settings.ai_buttons || '[]'); } catch {}
        const b = aiButtons[parseInt(btn.dataset.i)];
        if (!b) return;
        const orig = btn.textContent;
        btn.disabled = true;
        btn.textContent = _t('ai_running');
        try {
          const text = await _runAI(b.prompt, _selArticle);
          const box   = w.querySelector('#rss-ai-result');
          w.querySelector('#rss-ai-result-label').textContent = b.name;
          w.querySelector('#rss-ai-result-text').textContent  = text;
          box.style.display = '';
        } catch (e) {
          mvmOS.notify('RSS Reader', String(e));
        } finally {
          btn.disabled = false;
          btn.textContent = orig;
        }
      };
    });
    const closeBtn = w.querySelector('#rss-ai-close');
    if (closeBtn) closeBtn.onclick = () => { w.querySelector('#rss-ai-result').style.display = 'none'; };
  }

  // ── Fetch now ─────────────────────────────────────────────────────────────

  async function _doFetch() {
    if (_fetching) return;
    _fetching = true;
    const btn = _wrap()?.querySelector('#rss-fetch');
    if (btn) btn.textContent = _t('fetching');
    try {
      await _api('POST', '/fetch');
      await _reload();
      _selArticle = null;
      _render();
    } catch (e) {
      mvmOS.notify('RSS Reader', String(e));
    } finally {
      _fetching = false;
    }
  }

  // ── Settings ──────────────────────────────────────────────────────────────

  function _renderAiBtnList(container, btns, onDelete) {
    container.innerHTML = btns.length === 0
      ? `<div style="font-size:.8rem;color:var(--text-dim)">${_t('ai_no_btns')}</div>`
      : btns.map((b, i) => `
        <div style="display:flex;align-items:flex-start;gap:8px;padding:7px 10px;background:var(--surface);border:1px solid var(--border);border-radius:4px">
          <div style="flex:1;min-width:0">
            <div style="font-size:.84rem;font-weight:600">${_esc(b.name)} <span style="font-size:.7rem;color:var(--text-dim);font-weight:400">${_t('ai_scope_' + (b.scope||'reader'))}</span></div>
            <div style="font-size:.75rem;color:var(--text-dim);margin-top:2px;word-break:break-word">${_esc(b.prompt)}</div>
          </div>
          <button class="rss-ai-del" data-i="${i}" style="${_btnS('ghost')} font-size:.73rem;padding:3px 8px;flex-shrink:0">${_t('del_feed')}</button>
        </div>`).join('');
    container.querySelectorAll('.rss-ai-del').forEach(btn => {
      btn.onclick = async () => {
        _pendingAiButtons.splice(parseInt(btn.dataset.i), 1);
        _renderAiBtnList(container, _pendingAiButtons, onDelete);
        if (onDelete) await onDelete();
      };
    });
  }

  function _renderSettings(w) {
    const pubEnabled = _settings.public_enabled === '1';
    const interval   = _settings.fetch_interval || '30';
    const pubUrl     = `${location.origin}/pub/rssfeed/`;
    if (_pendingAiButtons === null) {
      try { _pendingAiButtons = JSON.parse(_settings.ai_buttons || '[]'); } catch { _pendingAiButtons = []; }
    }
    const aiSource = _settings.ai_source || 'off';

    const intervals = [
      ['5','min5'],['15','min15'],['30','min30'],
      ['60','h1'],['120','h2'],['360','h6'],['720','h12'],['1440','h24'],
    ];

    const feedRows = _feeds.length === 0
      ? `<div style="color:var(--text-dim);font-size:.83rem">${_t('no_feeds')}</div>`
      : _feeds.map(f => `
        <div style="display:flex;align-items:center;gap:8px;padding:7px 10px;background:var(--surface);border:1px solid var(--border);border-radius:4px">
          <div style="flex:1;min-width:0">
            <div style="font-size:.84rem;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${_esc(f.name)}</div>
            <div style="font-size:.72rem;color:var(--text-dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${_esc(f.url)}</div>
            ${f.error ? `<div style="font-size:.7rem;color:#f38ba8;margin-top:2px">${_t('error_label')}: ${_esc(f.error)}</div>` : ''}
          </div>
          <button class="rss-del-feed" data-id="${f.id}" style="${_btnS('ghost')} font-size:.73rem;padding:3px 8px">${_t('del_feed')}</button>
        </div>`).join('');

    w.innerHTML = `
      <div style="display:flex;align-items:center;gap:8px;padding:8px 14px;border-bottom:1px solid var(--border);flex-shrink:0">
        <button id="rss-gs-back" style="${_btnS('ghost')}">${_t('back')}</button>
        <span style="font-weight:600;font-size:.93rem;flex:1">${_t('settings_title')}</span>
      </div>
      <div style="flex:1;overflow-y:auto;padding:16px 16px 24px">

        <!-- General -->
        <div style="max-width:420px;display:flex;flex-direction:column;gap:12px">
          <label style="display:flex;flex-direction:column;gap:4px;font-size:.82rem">
            <span style="color:var(--text-dim)">${_t('fetch_interval')}</span>
            <select id="rss-interval" style="padding:6px 10px;background:var(--surface);border:1px solid var(--border);border-radius:4px;color:var(--text);font-size:.85rem">
              ${intervals.map(([v,k]) => `<option value="${v}" ${interval===v?'selected':''}>${_t(k)}</option>`).join('')}
            </select>
          </label>

          <div style="display:flex;flex-direction:column;gap:6px">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:.85rem">
              <input type="checkbox" id="rss-pub-toggle" ${pubEnabled?'checked':''}>
              <span>${_t('public_page')}</span>
            </label>
            <div style="font-size:.76rem;color:var(--text-dim);line-height:1.5">${_t('public_hint')}</div>
            <div id="rss-pub-url-row" style="display:${pubEnabled?'flex':'none'};gap:6px;margin-top:4px">
              <input id="rss-pub-url" readonly value="${_esc(pubUrl)}" style="flex:1;padding:6px 10px;background:var(--surface);border:1px solid var(--border);border-radius:4px;color:var(--text);font-size:.78rem">
              <button id="rss-pub-copy" style="${_btnS('ghost')}">${_t('copy')}</button>
            </div>
          </div>
        </div>

        <!-- AI Buttons -->
        <div style="margin-top:24px;border-top:1px solid var(--border);padding-top:18px">
          <div style="font-weight:600;font-size:.88rem;margin-bottom:12px">${_t('ai_section')}</div>
          <div style="max-width:420px;display:flex;flex-direction:column;gap:10px">
            <label style="display:flex;flex-direction:column;gap:4px;font-size:.82rem">
              <span style="color:var(--text-dim)">${_t('ai_source_lbl')}</span>
              <select id="rss-ai-source" style="padding:6px 10px;background:var(--surface);border:1px solid var(--border);border-radius:4px;color:var(--text);font-size:.85rem">
                <option value="off"      ${aiSource==='off'      ?'selected':''}>${_t('ai_off')}</option>
                <option value="mvmai"    ${aiSource==='mvmai'    ?'selected':''}>${_t('ai_mvmai')}</option>
                <option value="claude-cli" ${aiSource==='claude-cli'?'selected':''}>${_t('ai_cli')}</option>
              </select>
            </label>
            <div id="rss-ai-status"></div>
            <div id="rss-ai-btn-list" style="display:flex;flex-direction:column;gap:6px"></div>
            <div style="border-top:1px solid var(--border);padding-top:10px;display:flex;flex-direction:column;gap:6px">
              <input id="rss-ai-name" placeholder="${_t('ai_btn_name_ph')}"
                style="padding:6px 10px;background:var(--surface);border:1px solid var(--border);border-radius:4px;color:var(--text);font-size:.84rem;outline:none">
              <textarea id="rss-ai-prompt" placeholder="${_t('ai_btn_prmt_ph')}" rows="2"
                style="padding:6px 10px;background:var(--surface);border:1px solid var(--border);border-radius:4px;color:var(--text);font-size:.84rem;outline:none;resize:vertical;font-family:inherit"></textarea>
              <div style="font-size:.72rem;color:var(--text-dim);line-height:1.55">${_t('ai_examples')}</div>
              <label style="display:flex;align-items:center;gap:8px;font-size:.82rem">
                <span style="color:var(--text-dim)">${_t('ai_scope_lbl')}:</span>
                <select id="rss-ai-scope" style="padding:4px 8px;background:var(--surface);border:1px solid var(--border);border-radius:4px;color:var(--text);font-size:.82rem">
                  <option value="reader">${_t('ai_scope_reader')}</option>
                  <option value="list">${_t('ai_scope_list')}</option>
                  <option value="both">${_t('ai_scope_both')}</option>
                </select>
              </label>
              <button id="rss-ai-add" style="${_btnS('ghost')} align-self:flex-start">${_t('ai_add_btn')}</button>
            </div>
          </div>
        </div>

        <!-- Feeds -->
        <div style="margin-top:24px;border-top:1px solid var(--border);padding-top:18px">
          <div style="font-weight:600;font-size:.88rem;margin-bottom:10px">${_t('feeds_title')}</div>
          <div style="display:flex;gap:8px;margin-bottom:12px">
            <input id="rss-new-url" placeholder="${_t('feed_url_ph')}" style="flex:1;padding:6px 10px;background:var(--surface);border:1px solid var(--border);border-radius:4px;color:var(--text);font-size:.84rem;outline:none">
            <button id="rss-add-feed" style="${_btnS('primary')}">${_t('add_feed')}</button>
          </div>
          <div id="rss-feed-list" style="display:flex;flex-direction:column;gap:6px">${feedRows}</div>
        </div>
      </div>
    `;

    // Render AI buttons list
    _renderAiBtnList(w.querySelector('#rss-ai-btn-list'), _pendingAiButtons, _saveSettings);

    // Async: check mvmAI availability and update status hint
    (async () => {
      const statusEl = w.querySelector('#rss-ai-status');
      if (!statusEl) return;
      const dim = 'font-size:.76rem;margin-top:4px;';
      try {
        const st = await fetch('/api/mvmai/status').then(r => r.ok ? r.json() : null);
        if (!st) {
          statusEl.innerHTML = `<span style="${dim}color:#f38ba8">⚠ mvmAI app is not installed. Install it from the Store to use AI features.</span>`;
          return;
        }
        const lines = [];
        if (!st.has_key) lines.push(`<span style="${dim}color:#f9a825">⚠ mvmAI has no provider configured. Open the mvmAI app to set one up.</span>`);
        else lines.push(`<span style="${dim}color:var(--text-dim)">✓ mvmAI: ${st.provider}${st.model ? ' / ' + st.model : ''}</span>`);
        try {
          const cli = await fetch('/api/mvmai/cli-providers').then(r => r.json());
          const hasCli = (cli.cli_providers || []).some(p => p.id === 'claude-cli');
          lines.push(`<span style="${dim}color:var(--text-dim)">${hasCli ? '✓' : '✗'} Claude CLI: ${hasCli ? 'available' : 'not installed'}</span>`);
        } catch {}
        statusEl.innerHTML = lines.join('');
      } catch {
        statusEl.innerHTML = `<span style="${dim}color:#f38ba8">⚠ mvmAI app is not installed.</span>`;
      }
    })();

    async function _saveSettings() {
      const interval = w.querySelector('#rss-interval').value;
      const pubEn    = w.querySelector('#rss-pub-toggle').checked ? '1' : '0';
      const aiSrc    = w.querySelector('#rss-ai-source').value;
      const aiBtns   = JSON.stringify(_pendingAiButtons || []);
      await _api('POST', '/settings', { fetch_interval: interval, public_enabled: pubEn, ai_source: aiSrc, ai_buttons: aiBtns }).catch(() => {});
      _settings.fetch_interval = interval;
      _settings.public_enabled = pubEn;
      _settings.ai_source      = aiSrc;
      _settings.ai_buttons     = aiBtns;
    }

    w.querySelector('#rss-gs-back').onclick = async () => {
      _pendingAiButtons = null;
      _view = 'list';
      await _reload();
      _render();
    };

    w.querySelector('#rss-interval').onchange  = _saveSettings;
    w.querySelector('#rss-ai-source').onchange = _saveSettings;
    w.querySelector('#rss-pub-toggle').onchange = async () => {
      const on = w.querySelector('#rss-pub-toggle').checked;
      w.querySelector('#rss-pub-url-row').style.display = on ? 'flex' : 'none';
      await _saveSettings();
    };

    w.querySelector('#rss-ai-add').onclick = async () => {
      const nameEl   = w.querySelector('#rss-ai-name');
      const promptEl = w.querySelector('#rss-ai-prompt');
      const name     = nameEl.value.trim();
      const prompt   = promptEl.value.trim();
      if (!name || !prompt) return;
      const scope = w.querySelector('#rss-ai-scope').value || 'reader';
      _pendingAiButtons.push({ name, prompt, scope });
      nameEl.value   = '';
      promptEl.value = '';
      _renderAiBtnList(w.querySelector('#rss-ai-btn-list'), _pendingAiButtons, _saveSettings);
      await _saveSettings();
    };

    const copyBtn = w.querySelector('#rss-pub-copy');
    if (copyBtn) copyBtn.onclick = async () => {
      await navigator.clipboard.writeText(pubUrl).catch(() => {});
      const orig = copyBtn.textContent;
      copyBtn.textContent = _t('copied');
      setTimeout(() => copyBtn.textContent = orig, 1800);
    };

    w.querySelector('#rss-add-feed').onclick = async () => {
      const urlEl = w.querySelector('#rss-new-url');
      const url   = urlEl.value.trim();
      if (!url) return;
      const btn   = w.querySelector('#rss-add-feed');
      btn.disabled = true;
      btn.textContent = _t('fetching');
      try {
        const res = await _api('POST', '/feeds', { url });
        urlEl.value = '';
        await _reload();
        mvmOS.notify('RSS Reader', `${_t('feed_added')} "${res.name}"`);
        _renderSettings(w);
      } catch (e) {
        mvmOS.notify('RSS Reader', String(e));
        btn.disabled = false;
        btn.textContent = _t('add_feed');
      }
    };

    w.querySelectorAll('.rss-del-feed').forEach(btn => {
      btn.onclick = async () => {
        const id   = parseInt(btn.dataset.id);
        const feed = _feeds.find(f => f.id === id);
        if (!await mvmOS.confirm(`${_t('del_feed')} "${feed?.name}"?`)) return;
        await _api('DELETE', `/feeds/${id}`);
        await _reload();
        _renderSettings(w);
      };
    });
  }

  // ── Mount ─────────────────────────────────────────────────────────────────

  function mount(root) {
    _root = root;
    root.innerHTML = `<div id="rss-wrap" style="display:flex;flex-direction:column;height:100%;background:var(--bg);color:var(--text);font-family:inherit;overflow:hidden"></div>`;
    _reload().then(_render).catch(e => {
      const w = _wrap();
      if (w) w.innerHTML = `<div style="padding:20px;color:var(--text-dim)">${String(e)}</div>`;
    });
  }

  return { mount };
})();
