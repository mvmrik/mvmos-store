import json
import os
import re
import sqlite3
import subprocess
import shutil
import urllib.request
from datetime import datetime, timezone

from fastapi import APIRouter
from fastapi.responses import HTMLResponse, Response, RedirectResponse
from pydantic import BaseModel

router = APIRouter()

_DB_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "..", "apps", "rssfeed", "data.db"
)
_MVMAI_DB = os.path.join(
    os.path.dirname(__file__), "..", "..", "..", "apps", "mvmai", "data.db"
)

_MVMAI_PROVIDERS = {
    "gemini":     "https://generativelanguage.googleapis.com/v1beta/openai/",
    "openai":     "https://api.openai.com/v1/",
    "groq":       "https://api.groq.com/openai/v1/",
    "openrouter": "https://openrouter.ai/api/v1/",
    "deepseek":   "https://api.deepseek.com/",
    "qwen":       "https://dashscope-intl.aliyuncs.com/compatible-mode/v1/",
    "mistral":    "https://api.mistral.ai/v1/",
    "ollama":     "http://localhost:11434/v1/",
}

_S = {
    "en": {
        "title":    "Reading List",
        "empty":    "Nothing to read right now.",
        "footer":   "Powered by mvmOS RSS Reader",
        "open":     "Open original ↗",
        "disabled": "Public reading list is not enabled.",
        "back":     "← Back",
        "loading":  "Loading…",
        "ai_running": "Working…",
        "ai_close": "Close",
    },
    "bg": {
        "title":    "Списък за четене",
        "empty":    "Няма нови статии.",
        "footer":   "mvmOS RSS Reader",
        "open":     "Отвори оригинала ↗",
        "disabled": "Публичната страница не е активирана.",
        "back":     "← Назад",
        "loading":  "Зареждане…",
        "ai_running": "Обработва…",
        "ai_close": "Затвори",
    },
}


def _esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _get_conn():
    if not os.path.isfile(_DB_PATH):
        return None
    c = sqlite3.connect(_DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def _cfg(conn):
    rows = conn.execute("SELECT key, value FROM cfg").fetchall()
    return {r["key"]: r["value"] for r in rows}


def _strip(html):
    return re.sub(r"<[^>]+>", "", html or "").strip()


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/", response_class=HTMLResponse)
async def index():
    conn = _get_conn()
    if not conn:
        return Response("Not configured", status_code=404)
    cfg = _cfg(conn)
    conn.close()

    lang = cfg.get("public_lang", "en")
    if lang not in _S:
        lang = "en"
    s = _S[lang]

    if cfg.get("public_enabled", "0") != "1":
        return HTMLResponse(_disabled_page(s))

    ai_source = cfg.get("ai_source", "off")
    ai_buttons = cfg.get("ai_buttons", "[]") if ai_source != "off" else "[]"

    return HTMLResponse(_spa(s, lang, ai_buttons))


@router.get("/articles")
async def get_articles(filter: str = "unread"):
    conn = _get_conn()
    if not conn:
        return Response("[]", media_type="application/json")
    cfg = _cfg(conn)
    if cfg.get("public_enabled", "0") != "1":
        conn.close()
        return Response("[]", media_type="application/json")
    where = {
        "unread": "WHERE a.is_read=0",
        "read":   "WHERE a.is_read=1",
        "saved":  "WHERE a.is_saved=1",
    }.get(filter, "")
    rows = conn.execute(
        "SELECT a.id, a.title, a.link, a.description, a.pub_date, a.is_read, a.is_saved, f.name as feed_name "
        f"FROM articles a JOIN feeds f ON f.id=a.feed_id {where} "
        "ORDER BY COALESCE(a.pub_date, a.fetched_at) DESC LIMIT 200"
    ).fetchall()
    conn.close()
    return Response(json.dumps([dict(r) for r in rows]), media_type="application/json")


@router.post("/read/{article_id}")
async def mark_read(article_id: int):
    conn = _get_conn()
    if not conn:
        return Response("{}", media_type="application/json", status_code=404)
    conn.execute("UPDATE articles SET is_read=1 WHERE id=?", (article_id,))
    conn.commit()
    conn.close()
    return Response('{"ok":true}', media_type="application/json")


@router.post("/save/{article_id}")
async def toggle_save(article_id: int):
    conn = _get_conn()
    if not conn:
        return Response("{}", media_type="application/json", status_code=404)
    conn.execute("UPDATE articles SET is_saved = 1 - is_saved WHERE id=?", (article_id,))
    conn.commit()
    row = conn.execute("SELECT is_saved FROM articles WHERE id=?", (article_id,)).fetchone()
    conn.close()
    saved = row["is_saved"] if row else 0
    return Response(json.dumps({"ok": True, "is_saved": saved}), media_type="application/json")


@router.get("/read/{article_id}")
async def mark_and_redirect(article_id: int):
    conn = _get_conn()
    if not conn:
        return Response("Not found", status_code=404)
    row = conn.execute("SELECT link FROM articles WHERE id=?", (article_id,)).fetchone()
    if not row:
        conn.close()
        return Response("Not found", status_code=404)
    link = row["link"]
    conn.execute("UPDATE articles SET is_read=1 WHERE id=?", (article_id,))
    conn.commit()
    conn.close()
    if link:
        return RedirectResponse(url=link, status_code=302)
    return Response("No link", status_code=404)


class AIBody(BaseModel):
    prompt: str
    title: str = ""
    description: str = ""


@router.post("/ai")
async def ai_proxy(body: AIBody):
    conn = _get_conn()
    if not conn:
        return Response('{"error":"not configured"}', media_type="application/json", status_code=400)
    cfg = _cfg(conn)
    conn.close()

    if cfg.get("public_enabled", "0") != "1":
        return Response('{"error":"disabled"}', media_type="application/json", status_code=403)

    ai_source = cfg.get("ai_source", "off")
    if ai_source == "off":
        return Response('{"error":"AI not enabled"}', media_type="application/json", status_code=400)

    text = f"{body.prompt}\n\n---\nTitle: {body.title}\n\n{_strip(body.description)[:1200]}"

    if ai_source == "claude-cli":
        claude = shutil.which("claude")
        if not claude:
            return Response('{"error":"Claude CLI not found"}', media_type="application/json", status_code=400)
        try:
            proc = subprocess.run([claude, "--print", text], capture_output=True, text=True, timeout=120)
            if proc.returncode != 0 and not proc.stdout.strip():
                err = json.dumps({"error": proc.stderr.strip() or f"exit {proc.returncode}"})
                return Response(err, media_type="application/json", status_code=502)
            return Response(json.dumps({"content": proc.stdout.strip()}), media_type="application/json")
        except subprocess.TimeoutExpired:
            return Response('{"error":"timed out"}', media_type="application/json", status_code=504)
        except Exception as e:
            return Response(json.dumps({"error": str(e)}), media_type="application/json", status_code=502)

    # mvmAI provider — read config directly from mvmAI DB
    if not os.path.isfile(_MVMAI_DB):
        return Response('{"error":"mvmAI not installed"}', media_type="application/json", status_code=400)

    mc = sqlite3.connect(_MVMAI_DB)
    mc.row_factory = sqlite3.Row
    mcfg = {r["key"]: r["value"] for r in mc.execute("SELECT key, value FROM cfg").fetchall()}
    mc.close()

    provider = mcfg.get("provider", "gemini")
    api_key  = mcfg.get("api_key", "")
    model    = mcfg.get("model", "")
    base_url = mcfg.get("base_url") or _MVMAI_PROVIDERS.get(provider, "")
    if base_url and not base_url.endswith("/"):
        base_url += "/"

    if not base_url:
        return Response('{"error":"No provider configured in mvmAI"}', media_type="application/json", status_code=400)

    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    payload = json.dumps({"model": model, "messages": [{"role": "user", "content": text}]}).encode()
    req = urllib.request.Request(base_url + "chat/completions", data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            data = json.loads(r.read())
        content = data["choices"][0]["message"]["content"]
        return Response(json.dumps({"content": content}), media_type="application/json")
    except Exception as e:
        return Response(json.dumps({"error": str(e)}), media_type="application/json", status_code=502)


# ── HTML ──────────────────────────────────────────────────────────────────────

def _disabled_page(s):
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{_esc(s['title'])}</title>
<style>body{{font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;background:#f7f8fa;color:#999}}</style>
</head><body><p>{_esc(s['disabled'])}</p></body></html>"""


def _spa(s, lang, ai_buttons_json):
    ai_btns_js = ai_buttons_json.replace("</", "<\\/")
    return f"""<!DOCTYPE html>
<html lang="{lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{_esc(s['title'])}</title>
<style>
  *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    background: #f7f8fa; color: #1a1a2e;
    min-height: 100vh; padding: 28px 16px 60px;
  }}
  .card {{
    background: #fff; border: 1px solid #e2e4ea; border-radius: 10px;
    max-width: 680px; margin: 0 auto;
    box-shadow: 0 2px 12px rgba(0,0,0,.06); overflow: hidden;
  }}
  .card-header {{ padding: 18px 28px 14px; border-bottom: 1px solid #e2e4ea; display:flex; align-items:center; gap:10px; }}
  .brand {{ font-size:.72rem; color:#aaa; text-transform:uppercase; letter-spacing:.06em; margin-bottom:3px; }}
  h1 {{ font-size:1.1rem; font-weight:700; flex:1; }}
  .card-body {{ padding: 0; }}
  /* List */
  .feed-group {{ }}
  .feed-name {{ font-size:.68rem; text-transform:uppercase; letter-spacing:.06em; color:#999; padding:10px 28px 4px; }}
  ul {{ list-style:none; }}
  li {{ border-bottom: 1px solid #f0f1f5; }}
  li:last-child {{ border-bottom: none; }}
  .art-row {{
    display:block; padding:12px 28px; text-decoration:none; color:inherit; cursor:pointer;
    transition:background .12s;
  }}
  .art-row:hover {{ background:#f7f8fa; }}
  .art-title {{ font-size:.88rem; font-weight:600; line-height:1.4; }}
  .art-excerpt {{ font-size:.78rem; color:#777; margin-top:3px; line-height:1.4;
    overflow:hidden; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; }}
  .art-meta {{ font-size:.72rem; color:#bbb; margin-top:4px; display:flex; gap:8px; }}
  .art-feed {{ color:#6366f1; }}
  .filter-btn {{
    background:#f3f4f6; border:1px solid #e5e7eb; border-radius:16px;
    padding:3px 12px; font-size:.76rem; cursor:pointer; color:#374151;
  }}
  .filter-btn.active {{ background:#6366f1; border-color:#6366f1; color:#fff; }}
  .filter-btn:hover:not(.active) {{ background:#e5e7eb; }}
  .list-ai-btn {{
    border:1px solid #e2e4ea; background:#fff; border-radius:3px; padding:1px 7px;
    font-size:.7rem; cursor:pointer; font-family:inherit; color:#555;
  }}
  .list-ai-btn:hover {{ background:#f7f8fa; }}
  .list-ai-btn:disabled {{ opacity:.5; cursor:default; }}
  .list-ai-result {{
    margin-top:6px; background:#f7f8fa; border:1px solid #e2e4ea; border-radius:4px;
    padding:8px 10px; font-size:.79rem; line-height:1.6; white-space:pre-wrap; word-break:break-word;
  }}
  .empty {{ padding:40px 28px; color:#999; font-size:.88rem; text-align:center; }}
  /* Reader */
  .reader {{ padding:20px 28px 28px; display:none; }}
  .reader-back {{ background:none; border:1px solid #e2e4ea; border-radius:5px; padding:5px 12px; cursor:pointer; font-size:.82rem; color:#555; font-family:inherit; margin-bottom:16px; }}
  .reader-back:hover {{ background:#f7f8fa; }}
  .reader-feed {{ font-size:.72rem; color:#6366f1; margin-bottom:4px; }}
  .reader-title {{ font-size:1rem; font-weight:700; line-height:1.45; margin-bottom:14px; word-break:break-word; }}
  .reader-content {{ font-size:.86rem; line-height:1.75; color:#333; word-break:break-word; max-width:620px; }}
  .reader-content img {{ max-width:100%; height:auto; border-radius:4px; margin:8px 0; }}
  .reader-link {{ margin-top:18px; }}
  .reader-link a {{ color:#6366f1; font-size:.84rem; text-decoration:none; }}
  .reader-link a:hover {{ text-decoration:underline; }}
  /* AI */
  .ai-btns {{ display:flex; gap:6px; flex-wrap:wrap; margin-bottom:14px; }}
  .ai-btn {{
    border:1px solid #e2e4ea; background:#fff; border-radius:5px; padding:5px 12px;
    font-size:.78rem; cursor:pointer; font-family:inherit; color:#333;
    transition:background .1s;
  }}
  .ai-btn:hover {{ background:#f7f8fa; }}
  .ai-btn:disabled {{ opacity:.5; cursor:default; }}
  .ai-result {{
    background:#f7f8fa; border:1px solid #e2e4ea; border-radius:6px;
    padding:12px 14px; margin-bottom:14px; font-size:.84rem; line-height:1.7;
    display:none;
  }}
  .ai-result-header {{ display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; }}
  .ai-result-label {{ font-size:.72rem; font-weight:600; color:#6366f1; }}
  .ai-result-close {{ background:none; border:none; cursor:pointer; color:#aaa; font-size:.85rem; font-family:inherit; padding:0; }}
  .ai-result-text {{ white-space:pre-wrap; word-break:break-word; }}
  /* Footer */
  .footer {{ padding:12px 28px; border-top:1px solid #e2e4ea; font-size:.72rem; color:#ccc; text-align:right; }}
  @media (max-width:480px) {{
    .card-header, .art-row, .feed-name, .footer, .reader {{ padding-left:16px; padding-right:16px; }}
  }}
</style>
</head>
<body>
<div class="card" id="card">
  <div class="card-header">
    <div style="flex:1">
      <div class="brand">mvmOS RSS Reader</div>
      <h1>{_esc(s['title'])}</h1>
    </div>
  </div>
  <div class="card-body" id="list-view">
    <div class="empty" id="loading">{_esc(s['loading'])}</div>
  </div>
  <div class="reader" id="reader-view">
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:2px">
      <button class="reader-back" id="back-btn" style="margin-bottom:0">{_esc(s['back'])}</button>
      <div style="flex:1"></div>
      <button id="reader-star-btn" onclick="toggleReaderStar()" style="background:none;border:none;cursor:pointer;font-size:1.3rem;padding:2px 4px;color:#9ca3af"></button>
    </div>
    <div class="reader-feed" id="reader-feed"></div>
    <div class="reader-title" id="reader-title"></div>
    <div class="ai-btns" id="ai-btns" style="display:none"></div>
    <div class="ai-result" id="ai-result">
      <div class="ai-result-header">
        <span class="ai-result-label" id="ai-result-label"></span>
        <button class="ai-result-close" id="ai-result-close">{_esc(s['ai_close'])}</button>
      </div>
      <div class="ai-result-text" id="ai-result-text"></div>
    </div>
    <div class="reader-content" id="reader-content"></div>
    <div class="reader-link" id="reader-link"></div>
  </div>
  <div class="footer">{_esc(s['footer'])}</div>
</div>

<script>
const _ALL_BTNS  = {ai_btns_js};
const AI_BTNS    = _ALL_BTNS.filter(b => (b.scope||'reader') === 'reader' || b.scope === 'both');
const LIST_BTNS  = _ALL_BTNS.filter(b => (b.scope||'reader') === 'list'   || b.scope === 'both');
const STR_RUNNING = {json.dumps(s['ai_running'])};
const STR_OPEN    = {json.dumps(s['open'])};
const STR_EMPTY   = {json.dumps(s['empty'])};

let articles = [];
let _curFilter = 'unread';

const FILTER_LABELS = {{unread:'Unread', read:'Read', all:'All', saved:'Saved'}};

function esc(s) {{
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}}
function relTime(d) {{
  if (!d) return '';
  const sec = Math.floor((Date.now() - new Date(d)) / 1000);
  if (sec < 90)    return 'just now';
  if (sec < 3600)  return Math.floor(sec/60) + ' min ago';
  if (sec < 86400) return Math.floor(sec/3600) + 'h ago';
  return Math.floor(sec/86400) + 'd ago';
}}

function renderFilterBar() {{
  const bar = document.getElementById('filter-bar');
  if (!bar) return;
  bar.innerHTML = ['unread','read','all','saved'].map(f =>
    `<button class="filter-btn${{_curFilter===f?' active':''}}" data-f="${{f}}">${{FILTER_LABELS[f]}}</button>`
  ).join('');
  bar.querySelectorAll('.filter-btn').forEach(btn => {{
    btn.onclick = async () => {{
      _curFilter = btn.dataset.f;
      await load();
    }};
  }});
}}

async function load() {{
  renderFilterBar();
  const r = await fetch('/pub/rssfeed/articles?filter=' + _curFilter);
  articles = await r.json();
  renderList();
}}

function renderList() {{
  const el = document.getElementById('list-view');
  let filterBarHtml = '<div id="filter-bar" style="display:flex;gap:6px;padding:10px 14px;border-bottom:1px solid #e5e7eb;flex-wrap:wrap"></div>';
  if (!articles.length) {{
    el.innerHTML = filterBarHtml + '<div class="empty">' + esc(STR_EMPTY) + '</div>';
    renderFilterBar();
    return;
  }}
  const groups = {{}};
  articles.forEach(a => {{ (groups[a.feed_name] = groups[a.feed_name] || []).push(a); }});
  let html = filterBarHtml;
  for (const [feed, items] of Object.entries(groups)) {{
    html += '<div class="feed-group"><div class="feed-name">' + esc(feed) + '</div><ul>';
    items.forEach(a => {{
      const excerpt = a.description ? a.description.replace(/<[^>]+>/g,'') : '';
      const starColor = a.is_saved ? '#f59e0b' : '#9ca3af';
      const starChar  = a.is_saved ? '★' : '☆';
      html += `<li><div class="art-row" data-id="${{a.id}}" style="display:flex;align-items:flex-start;gap:6px">
        <div style="flex:1;min-width:0">
          <div class="art-title">${{esc(a.title||'(no title)')}}</div>
          ${{excerpt ? '<div class="art-excerpt">' + esc(excerpt) + '</div>' : ''}}
          <div class="art-meta">
            <span class="art-feed">${{esc(a.feed_name)}}</span>
            ${{relTime(a.pub_date) ? '<span>' + relTime(a.pub_date) + '</span>' : ''}}
            ${{LIST_BTNS.map((b,bi) => `<button class="list-ai-btn" data-aid="${{a.id}}" data-bi="${{bi}}">${{esc(b.name)}}</button>`).join('')}}
          </div>
          <div class="list-ai-result" id="lair-${{a.id}}" style="display:none"></div>
        </div>
        <button class="star-btn" data-id="${{a.id}}" style="background:none;border:none;cursor:pointer;font-size:1.1rem;padding:0 2px;flex-shrink:0;color:${{starColor}}">${{starChar}}</button>
      </div></li>`;
    }});
    html += '</ul></div>';
  }}
  el.innerHTML = html;
  renderFilterBar();
  el.querySelectorAll('.art-row').forEach(row => {{
    row.onclick = (e) => {{
      if (e.target.closest('.star-btn,.list-ai-btn')) return;
      openArticle(parseInt(row.dataset.id));
    }};
  }});
  el.querySelectorAll('.star-btn').forEach(btn => {{
    btn.onclick = async (e) => {{
      e.stopPropagation();
      const id = parseInt(btn.dataset.id);
      const res = await fetch('/pub/rssfeed/save/' + id, {{method:'POST'}}).then(r=>r.json()).catch(()=>null);
      if (!res) return;
      const a = articles.find(x => x.id === id);
      if (a) a.is_saved = res.is_saved;
      btn.textContent = res.is_saved ? '★' : '☆';
      btn.style.color = res.is_saved ? '#f59e0b' : '#9ca3af';
      if (_curFilter === 'saved' && !res.is_saved) {{
        articles = articles.filter(x => x.id !== id);
        renderList();
      }}
    }};
  }});
  el.querySelectorAll('.list-ai-btn').forEach(btn => {{
    btn.onclick = async (e) => {{
      e.stopPropagation();
      const a  = articles.find(x => x.id === parseInt(btn.dataset.aid));
      const b  = LIST_BTNS[parseInt(btn.dataset.bi)];
      if (!a || !b) return;
      const orig = btn.textContent;
      btn.disabled = true;
      btn.textContent = STR_RUNNING;
      const resultEl = document.getElementById('lair-' + a.id);
      try {{
        const r = await fetch('/pub/rssfeed/ai', {{
          method: 'POST',
          headers: {{'Content-Type':'application/json'}},
          body: JSON.stringify({{prompt: b.prompt, title: a.title||'', description: (a.description||'').replace(/<[^>]+>/g,'').slice(0,150)}})
        }});
        const d = await r.json();
        if (resultEl) {{ resultEl.textContent = d.content || d.error || '—'; resultEl.style.display = ''; }}
      }} catch(err) {{
        if (resultEl) {{ resultEl.textContent = String(err); resultEl.style.display = ''; }}
      }} finally {{
        btn.disabled = false;
        btn.textContent = orig;
      }}
    }};
  }});
}}

function openArticle(id) {{
  const a = articles.find(x => x.id === id);
  if (!a) return;
  fetch('/pub/rssfeed/read/' + id, {{method:'POST'}});
  if (_curFilter === 'unread') articles = articles.filter(x => x.id !== id);
  else {{ const found = articles.find(x => x.id === id); if (found) found.is_read = 1; }}

  document.getElementById('reader-feed').textContent    = a.feed_name || '';
  document.getElementById('reader-title').textContent   = a.title || '(no title)';
  document.getElementById('reader-content').innerHTML   = a.description || '—';
  document.getElementById('reader-link').innerHTML      = a.link
    ? '<a href="' + esc(a.link) + '" target="_blank" rel="noopener">' + STR_OPEN + '</a>' : '';

  const aiResult = document.getElementById('ai-result');
  aiResult.style.display = 'none';

  const aiBtnsEl = document.getElementById('ai-btns');
  if (AI_BTNS.length > 0) {{
    aiBtnsEl.style.display = 'flex';
    aiBtnsEl.innerHTML = AI_BTNS.map((b,i) =>
      `<button class="ai-btn" data-i="${{i}}">${{esc(b.name)}}</button>`
    ).join('');
    aiBtnsEl.querySelectorAll('.ai-btn').forEach(btn => {{
      btn.onclick = async () => {{
        const b = AI_BTNS[parseInt(btn.dataset.i)];
        const orig = btn.textContent;
        btn.disabled = true;
        btn.textContent = STR_RUNNING;
        try {{
          const r = await fetch('/pub/rssfeed/ai', {{
            method: 'POST',
            headers: {{'Content-Type':'application/json'}},
            body: JSON.stringify({{prompt: b.prompt, title: a.title||'', description: a.description||''}})
          }});
          const d = await r.json();
          document.getElementById('ai-result-label').textContent = b.name;
          document.getElementById('ai-result-text').textContent  = d.content || d.error || '—';
          aiResult.style.display = '';
        }} catch(e) {{
          document.getElementById('ai-result-label').textContent = b.name;
          document.getElementById('ai-result-text').textContent  = String(e);
          aiResult.style.display = '';
        }} finally {{
          btn.disabled = false;
          btn.textContent = orig;
        }}
      }};
    }});
  }} else {{
    aiBtnsEl.style.display = 'none';
  }}

  const starBtn = document.getElementById('reader-star-btn');
  starBtn.dataset.id = a.id;
  starBtn.textContent = a.is_saved ? '★' : '☆';
  starBtn.style.color = a.is_saved ? '#f59e0b' : '#9ca3af';

  document.getElementById('list-view').style.display   = 'none';
  document.getElementById('reader-view').style.display = 'block';
}}

async function toggleReaderStar() {{
  const btn = document.getElementById('reader-star-btn');
  const id  = parseInt(btn.dataset.id);
  const res = await fetch('/pub/rssfeed/save/' + id, {{method:'POST'}}).then(r=>r.json()).catch(()=>null);
  if (!res) return;
  const a = articles.find(x => x.id === id);
  if (a) a.is_saved = res.is_saved;
  btn.textContent = res.is_saved ? '★' : '☆';
  btn.style.color = res.is_saved ? '#f59e0b' : '#9ca3af';
}}

document.getElementById('back-btn').onclick = () => {{
  document.getElementById('reader-view').style.display = 'none';
  document.getElementById('list-view').style.display   = '';
  renderList();
}};

document.getElementById('ai-result-close').onclick = () => {{
  document.getElementById('ai-result').style.display = 'none';
}};

load();
</script>
</body>
</html>"""
