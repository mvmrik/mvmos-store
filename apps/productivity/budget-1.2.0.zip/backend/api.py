"""
Budget's app-to-app API — the only way another app should touch Budget data.
Loaded by Apps Hub via hub.call_app_api("budget", ...) once an admin enables
it at Apps Hub -> Settings -> App APIs. Reuses public.py's already-running
DB and helpers via sys.modules["app_public_budget"] (public.py is exec'd
into that module name by backend/public_loader.py at startup, so this file
never re-implements schema/balance/membership logic of its own).

user_id here is always an Apps Hub public_users.id, the same identity space
category_members/transactions already key on — the caller is expected to
already know which Apps Hub user it's acting on behalf of.
"""

import sqlite3
import sys
import uuid
from datetime import datetime, timezone


def _pub():
    return sys.modules.get("app_public_budget")


def list_categories(user_id: str):
    """Top-level categories the given user is a member of, with balance/role."""
    pub = _pub()
    if pub is None:
        raise RuntimeError("budget public.py not loaded")
    with pub._db() as conn:
        rows = conn.execute(
            "SELECT c.* FROM categories c JOIN category_members cm ON cm.category_id=c.id "
            "WHERE cm.user_id=? AND c.archived=0 AND c.parent_id IS NULL ORDER BY c.created_at",
            (user_id,),
        ).fetchall()
        return [pub._row_to_category(conn, r, user_id) for r in rows]


def add_to_category(user_id: str, category_id: str, amount: float,
                     reason: str = "", idempotency_key: str = None):
    """Add (amount > 0) or withdraw (amount < 0) money in a category the user
    is a member of. Raises ValueError if the category doesn't exist, the user
    isn't a member, or it holds subcategories (same rules as the normal
    add-transaction route). Safe to retry with the same idempotency_key —
    replaying it returns the original result instead of inserting twice."""
    pub = _pub()
    if pub is None:
        raise RuntimeError("budget public.py not loaded")
    if amount == 0:
        raise ValueError("amount must be non-zero")

    with pub._db() as conn:
        if idempotency_key:
            row = conn.execute(
                "SELECT * FROM transactions WHERE idempotency_key=?", (idempotency_key,)
            ).fetchone()
            if row is not None:
                return {**dict(row), "balance": pub._balance(conn, row["category_id"])}

        if not pub._my_role(conn, category_id, user_id):
            raise ValueError("category not found or user is not a member")
        if pub._child_ids(conn, category_id):
            raise ValueError("category has subcategories")

        tid = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()
        try:
            conn.execute(
                "INSERT INTO transactions(id,category_id,user_id,amount,note,batch_id,created_at,idempotency_key) "
                "VALUES(?,?,?,?,?,NULL,?,?)",
                (tid, category_id, user_id, amount, (reason or "").strip()[:300], now, idempotency_key),
            )
            conn.commit()
        except sqlite3.IntegrityError:
            # Lost the race on the idempotency key to a concurrent identical call.
            row = conn.execute(
                "SELECT * FROM transactions WHERE idempotency_key=?", (idempotency_key,)
            ).fetchone()
            if row is not None:
                return {**dict(row), "balance": pub._balance(conn, row["category_id"])}
            raise

        row = conn.execute("SELECT * FROM transactions WHERE id=?", (tid,)).fetchone()
        return {**dict(row), "balance": pub._balance(conn, category_id)}
