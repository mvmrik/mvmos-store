(function () {
  'use strict';

  const BASE = '/api/pub/gamehub';
  const TOKEN_KEY = 'gh_token';

  let _player = null;
  let _token  = localStorage.getItem(TOKEN_KEY);

  function _esc(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
  }

  function _setToken(token, player) {
    _token  = token;
    _player = player;
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else       localStorage.removeItem(TOKEN_KEY);
  }

  async function _initSession() {
    if (!_token) return null;
    try {
      const r = await fetch(BASE + '/me', { headers: { 'X-GH-Token': _token } });
      if (r.ok) { _player = await r.json(); return _player; }
    } catch(e) {}
    _setToken(null, null);
    return null;
  }

  function _ensureStyle() {
    if (document.getElementById('gh-widget-css')) return;
    const s = document.createElement('style');
    s.id = 'gh-widget-css';
    s.textContent = `
      .gh-w { font-family:var(--font,system-ui,sans-serif);color:var(--fg,#cdd6f4) }
      .gh-w input{background:var(--surface2,#313244);color:var(--fg,#cdd6f4);border:1px solid var(--border,#45475a);border-radius:6px;padding:6px 10px;font-size:13px;width:100%;box-sizing:border-box;outline:none}
      .gh-w input:focus{border-color:var(--accent,#89b4fa)}
      .gh-w .gh-btn{border:none;border-radius:6px;padding:7px 14px;cursor:pointer;font-size:13px;width:100%;transition:opacity .1s}
      .gh-w .gh-btn:hover{opacity:.85}
      .gh-w .gh-p{background:var(--accent,#89b4fa);color:#1e1e2e;font-weight:600}
      .gh-w .gh-s{background:var(--surface2,#313244);color:var(--fg,#cdd6f4)}
      .gh-w .gh-err{color:#f38ba8;font-size:12px;margin-top:2px;display:none}
      .gh-w .gh-back{color:var(--accent,#89b4fa);cursor:pointer;font-size:12px;text-decoration:underline;background:none;border:none;padding:0}
    `;
    document.head.appendChild(s);
  }

  function _box(inner) {
    return `<div class="gh-w" style="padding:14px;background:var(--surface1,#181825);border-radius:8px;border:1px solid var(--border,#45475a);display:flex;flex-direction:column;gap:8px">${inner}</div>`;
  }

  function renderWidget(container, opts) {
    opts = opts || {};
    const onReady    = opts.onReady    || function(){};
    const guestText  = opts.guestText  || 'Play as Guest';

    _ensureStyle();

    function _widgetAvatar(player, size) {
      return renderAvatar(player, size);
    }

    function showLoggedIn(player) {
      container.innerHTML = _box(`
        <div style="display:flex;align-items:center;gap:10px">
          ${_widgetAvatar(player, 36)}
          <div style="flex:1">
            <div style="font-weight:600;font-size:14px">${_esc(player.display_name)}</div>
            <div style="font-size:11px;color:var(--fg2,#a6adc8)">@${_esc(player.username)}</div>
          </div>
          <button class="gh-btn gh-s" id="gh-w-out" style="width:auto;font-size:11px;padding:4px 8px">Logout</button>
        </div>
        <button class="gh-btn gh-p" id="gh-w-ready">Ready ▶</button>
      `);
      container.querySelector('#gh-w-ready').onclick = () => onReady(player);
      container.querySelector('#gh-w-out').onclick   = async () => {
        if (_token) fetch(BASE + '/logout', { method:'POST', headers:{'X-GH-Token':_token} }).catch(()=>{});
        _setToken(null, null);
        showChoice();
      };
    }

    function showChoice() {
      container.innerHTML = _box(`
        <div style="font-size:14px;font-weight:600;margin-bottom:2px">🎮 Game Hub</div>
        <button class="gh-btn gh-p" id="gh-w-to-login">Log in</button>
        <button class="gh-btn gh-s" id="gh-w-to-reg">Register</button>
        <button class="gh-btn gh-s" id="gh-w-to-guest">${_esc(guestText)}</button>
      `);
      container.querySelector('#gh-w-to-login').onclick = showLogin;
      container.querySelector('#gh-w-to-reg').onclick   = showRegister;
      container.querySelector('#gh-w-to-guest').onclick = showGuest;
    }

    function showLogin() {
      container.innerHTML = _box(`
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:2px">
          <button class="gh-back" id="gh-w-back">← Back</button>
          <span style="font-size:14px;font-weight:600">Log in</span>
        </div>
        <input id="gh-w-user" placeholder="Username" autocomplete="username">
        <input id="gh-w-pass" type="password" placeholder="Password" autocomplete="current-password">
        <div class="gh-err" id="gh-w-err"></div>
        <button class="gh-btn gh-p" id="gh-w-sub">Log in</button>
      `);
      container.querySelector('#gh-w-back').onclick = showChoice;
      const submit = async () => {
        const u = container.querySelector('#gh-w-user').value.trim();
        const p = container.querySelector('#gh-w-pass').value;
        if (!u || !p) return;
        const r = await fetch(BASE + '/login', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({username:u, password:p}) });
        if (r.ok) { const d = await r.json(); _setToken(d.token, d.player); showLoggedIn(d.player); }
        else { const e = container.querySelector('#gh-w-err'); e.textContent = 'Invalid username or password'; e.style.display = 'block'; }
      };
      container.querySelector('#gh-w-sub').onclick = submit;
      container.querySelector('#gh-w-pass').onkeydown = e => { if(e.key==='Enter') submit(); };
    }

    function showRegister() {
      container.innerHTML = _box(`
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:2px">
          <button class="gh-back" id="gh-w-back">← Back</button>
          <span style="font-size:14px;font-weight:600">Register</span>
        </div>
        <input id="gh-w-dname" placeholder="Display name">
        <input id="gh-w-user"  placeholder="Username (lowercase)" autocomplete="username">
        <input id="gh-w-pass"  type="password" placeholder="Password (min 4 chars)" autocomplete="new-password">
        <div class="gh-err" id="gh-w-err"></div>
        <button class="gh-btn gh-p" id="gh-w-sub">Register</button>
      `);
      container.querySelector('#gh-w-back').onclick = showChoice;
      const submit = async () => {
        const dname = container.querySelector('#gh-w-dname').value.trim();
        const uname = container.querySelector('#gh-w-user').value.trim();
        const pass  = container.querySelector('#gh-w-pass').value;
        if (!dname || !uname || !pass) return;
        const r = await fetch(BASE + '/register', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({display_name:dname, username:uname, password:pass}) });
        if (r.ok) { const d = await r.json(); _setToken(d.token, d.player); showLoggedIn(d.player); }
        else {
          const d2 = await r.json().catch(()=>({}));
          const e  = container.querySelector('#gh-w-err');
          e.textContent = d2.detail || 'Error'; e.style.display = 'block';
        }
      };
      container.querySelector('#gh-w-sub').onclick = submit;
    }

    function showGuest() {
      container.innerHTML = _box(`
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:2px">
          <button class="gh-back" id="gh-w-back">← Back</button>
          <span style="font-size:14px;font-weight:600">Play as Guest</span>
        </div>
        <input id="gh-w-gname" placeholder="Your name">
        <div class="gh-err" id="gh-w-err"></div>
        <button class="gh-btn gh-p" id="gh-w-sub">Continue →</button>
      `);
      container.querySelector('#gh-w-back').onclick = showChoice;
      const submit = () => {
        const name = container.querySelector('#gh-w-gname').value.trim();
        if (!name) { const e = container.querySelector('#gh-w-err'); e.textContent = 'Enter a name'; e.style.display = 'block'; return; }
        onReady({ id:null, display_name:name, guest_name:name, is_guest:true });
      };
      container.querySelector('#gh-w-sub').onclick = submit;
      container.querySelector('#gh-w-gname').onkeydown = e => { if(e.key==='Enter') submit(); };
    }

    _initSession().then(player => {
      if (player) showLoggedIn(player);
      else        showChoice();
    });
  }

  function renderAvatar(player, size) {
    size = size || 36;
    if (!player) player = {};
    if (player.avatar_svg) {
      return player.avatar_svg.replace(/width="\d+"/, `width="${size}"`).replace(/height="\d+"/, `height="${size}"`);
    }
    const letter = _esc(((player.display_name || '?')[0]).toUpperCase());
    const color  = _esc(player.avatar_color || '#585b70');
    return `<svg viewBox="0 0 100 100" width="${size}" height="${size}" style="border-radius:50%;display:block;flex-shrink:0" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="50" fill="${color}"/><text x="50" y="67" font-family="system-ui,sans-serif" font-size="54" font-weight="700" fill="#1e1e2e" text-anchor="middle">${letter}</text></svg>`;
  }

  async function renderInviteSection(container, gameId, roomUrl) {
    if (!container) return;
    if (!_token) { container.innerHTML = ''; return; }
    try {
      const r = await fetch(BASE + '/players');
      if (!r.ok) { container.innerHTML = ''; return; }
      const players = await r.json();
      const myId    = _player?.id;
      const list    = players.filter(p => p.id !== myId);
      if (!list.length) { container.innerHTML = ''; return; }

      _ensureStyle();
      container.innerHTML = `
        <div class="gh-w" style="display:flex;flex-direction:column;gap:6px">
          <div style="font-size:.72rem;color:#a6adc8;text-transform:uppercase;letter-spacing:.5px">Invite players</div>
          <div style="display:flex;flex-direction:column;gap:4px;max-height:160px;overflow-y:auto" id="gh-inv-list">
            ${list.map(p => `
              <div style="display:flex;align-items:center;gap:8px;background:var(--surface2,#313244);border-radius:6px;padding:5px 8px">
                ${renderAvatar(p, 20)}
                <span style="flex:1;font-size:.82rem">${_esc(p.display_name)}</span>
                <button class="gh-btn gh-s gh-inv-btn" style="width:auto;padding:3px 10px;font-size:.75rem" data-pid="${p.id}">Invite</button>
              </div>`).join('')}
          </div>
        </div>`;

      container.querySelectorAll('.gh-inv-btn').forEach(btn => {
        btn.onclick = async () => {
          btn.disabled = true; btn.textContent = '⏳';
          try {
            const res = await fetch(BASE + '/invite', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'X-GH-Token': _token },
              body: JSON.stringify({ to_ids: [btn.dataset.pid], game_id: gameId, room_url: roomUrl }),
            });
            btn.textContent = res.ok ? '✓ Invited' : '✕';
            if (!res.ok) setTimeout(() => { btn.disabled = false; btn.textContent = 'Invite'; }, 2000);
          } catch(_) { btn.disabled = false; btn.textContent = 'Invite'; }
        };
      });
    } catch(_) { container.innerHTML = ''; }
  }

  window.GameHub = {
    isLoggedIn:    () => !!_player,
    currentPlayer: () => _player,
    getToken:      () => _token,
    init:          () => _initSession(),
    renderAvatar,
    logout: async () => {
      if (_token) {
        await fetch(BASE + '/logout', { method:'POST', headers:{'X-GH-Token':_token} }).catch(()=>{});
        _setToken(null, null);
      }
    },
    renderWidget,
    renderInviteSection,
    recordSession: (data) => fetch(BASE + '/session', {
      method:  'POST',
      headers: {'Content-Type':'application/json'},
      body:    JSON.stringify(data),
    }),
  };

  if (_token) _initSession();
})();
