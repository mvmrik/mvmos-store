import hashlib, json, os, secrets, sqlite3, sys, uuid
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException, Header
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional

get_current_session = sys.modules["backend.auth"].get_current_session

_admin = APIRouter(prefix="/api/gamehub",     tags=["gamehub"])
_pub   = APIRouter(prefix="/api/pub/gamehub", tags=["gamehub-pub"])

# Combined router exposed to the loader
router = APIRouter()

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "apps", "gamehub", "data.db")
TOKEN_DAYS = 30
AVATAR_COLORS = ['#89b4fa','#a6e3a1','#f38ba8','#fab387','#f9e2af','#cba6f7','#94e2d5','#f5c2e7','#74c7ec','#eba0ac']

def _db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS players (
            id            TEXT PRIMARY KEY,
            username      TEXT UNIQUE NOT NULL,
            display_name  TEXT NOT NULL,
            avatar_color  TEXT NOT NULL DEFAULT '#89b4fa',
            password_hash TEXT,
            created_at    TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS gh_tokens (
            token      TEXT PRIMARY KEY,
            player_id  TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS game_sessions (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            game_id          TEXT NOT NULL,
            mode             TEXT NOT NULL DEFAULT 'multiplayer',
            played_at        TEXT NOT NULL,
            duration_seconds INTEGER,
            metadata         TEXT NOT NULL DEFAULT '{}'
        );
        CREATE TABLE IF NOT EXISTS session_players (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
            player_id  TEXT REFERENCES players(id) ON DELETE SET NULL,
            guest_name TEXT,
            score      REAL,
            rank       INTEGER,
            is_winner  INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS hub_settings (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS invites (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            from_id    TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
            to_id      TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
            game_id    TEXT NOT NULL,
            room_url   TEXT NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS player_favourites (
            player_id    TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
            favourite_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
            created_at   TEXT NOT NULL,
            PRIMARY KEY (player_id, favourite_id)
        );
        CREATE INDEX IF NOT EXISTS idx_sp_player  ON session_players(player_id);
        CREATE INDEX IF NOT EXISTS idx_sp_session ON session_players(session_id);
        CREATE INDEX IF NOT EXISTS idx_gs_game    ON game_sessions(game_id, played_at);
        CREATE INDEX IF NOT EXISTS idx_tok_player ON gh_tokens(player_id);
        CREATE INDEX IF NOT EXISTS idx_inv_to     ON invites(to_id, expires_at);
    """)
    conn.execute("INSERT OR IGNORE INTO hub_settings(key,value) VALUES('public','false')")
    conn.execute("INSERT OR IGNORE INTO hub_settings(key,value) VALUES('allow_registrations','true')")
    conn.commit()
    # migrations
    pcols = {r[1] for r in conn.execute("PRAGMA table_info(players)").fetchall()}
    if "password_hash" not in pcols:
        conn.execute("ALTER TABLE players ADD COLUMN password_hash TEXT")
    if "avatar_data" not in pcols:
        conn.execute("ALTER TABLE players ADD COLUMN avatar_data TEXT")
    if "avatar_svg" not in pcols:
        conn.execute("ALTER TABLE players ADD COLUMN avatar_svg TEXT")
    gcols = {r[1] for r in conn.execute("PRAGMA table_info(game_sessions)").fetchall()}
    if "mode" not in gcols:
        conn.execute("ALTER TABLE game_sessions ADD COLUMN mode TEXT NOT NULL DEFAULT 'multiplayer'")
    conn.commit()
    return conn

# ── Password helpers ──────────────────────────────────────────

def _hash_pw(pw: str) -> str:
    salt = secrets.token_bytes(32)
    key  = hashlib.pbkdf2_hmac('sha256', pw.encode(), salt, 100000)
    return salt.hex() + ':' + key.hex()

def _verify_pw(stored: str, pw: str) -> bool:
    try:
        salt_hex, key_hex = stored.split(':')
        key = hashlib.pbkdf2_hmac('sha256', pw.encode(), bytes.fromhex(salt_hex), 100000)
        return secrets.compare_digest(key.hex(), key_hex)
    except Exception:
        return False

def _resolve_token(x_gh_token: Optional[str]) -> Optional[dict]:
    if not x_gh_token:
        return None
    now = datetime.now(timezone.utc).isoformat()
    with _db() as conn:
        row = conn.execute(
            "SELECT p.* FROM players p JOIN gh_tokens t ON t.player_id=p.id WHERE t.token=? AND t.expires_at>?",
            (x_gh_token, now)
        ).fetchone()
    return dict(row) if row else None

def _issue_token(player_id: str) -> str:
    token = secrets.token_urlsafe(32)
    now   = datetime.now(timezone.utc)
    exp   = (now + timedelta(days=TOKEN_DAYS)).isoformat()
    with _db() as conn:
        conn.execute("INSERT INTO gh_tokens(token,player_id,created_at,expires_at) VALUES(?,?,?,?)",
                     (token, player_id, now.isoformat(), exp))
        conn.commit()
    return token

# ── Public auth endpoints ─────────────────────────────────────

class RegisterBody(BaseModel):
    username:     str
    display_name: str
    password:     str
    avatar_color: str = '#89b4fa'

@_pub.post("/register")
async def register(body: RegisterBody):
    if len(body.password) < 4:
        raise HTTPException(400, detail="Password too short")
    pid  = str(uuid.uuid4())[:8]
    now  = datetime.now(timezone.utc).isoformat()
    try:
        with _db() as conn:
            conn.execute("INSERT INTO players(id,username,display_name,avatar_color,password_hash,created_at) VALUES(?,?,?,?,?,?)",
                         (pid, body.username.strip().lower(), body.display_name.strip(), body.avatar_color, _hash_pw(body.password), now))
            conn.commit()
    except sqlite3.IntegrityError:
        raise HTTPException(400, detail="Username already exists")
    token = _issue_token(pid)
    return JSONResponse({"token": token, "player": {"id": pid, "username": body.username.strip().lower(),
                          "display_name": body.display_name.strip(), "avatar_color": body.avatar_color}})

class LoginBody(BaseModel):
    username: str
    password: str

@_pub.post("/login")
async def login(body: LoginBody):
    with _db() as conn:
        row = conn.execute("SELECT * FROM players WHERE username=?", (body.username.strip().lower(),)).fetchone()
    if not row or not row["password_hash"] or not _verify_pw(row["password_hash"], body.password):
        raise HTTPException(401, detail="Invalid username or password")
    token = _issue_token(row["id"])
    return JSONResponse({"token": token, "player": {"id": row["id"], "username": row["username"],
                          "display_name": row["display_name"], "avatar_color": row["avatar_color"]}})

@_pub.post("/logout")
async def logout(x_gh_token: Optional[str] = Header(default=None)):
    if x_gh_token:
        with _db() as conn:
            conn.execute("DELETE FROM gh_tokens WHERE token=?", (x_gh_token,))
            conn.commit()
    return JSONResponse({"ok": True})

@_pub.get("/me")
async def me(x_gh_token: Optional[str] = Header(default=None)):
    p = _resolve_token(x_gh_token)
    if not p:
        raise HTTPException(401)
    return JSONResponse({"id": p["id"], "username": p["username"],
                         "display_name": p["display_name"], "avatar_color": p["avatar_color"],
                         "avatar_data": p["avatar_data"], "avatar_svg": p["avatar_svg"]})

class MeUpdateBody(BaseModel):
    display_name: Optional[str] = None
    password:     Optional[str] = None
    avatar_data:  Optional[str] = None
    avatar_svg:   Optional[str] = None

@_pub.put("/me")
async def update_me(body: MeUpdateBody, x_gh_token: Optional[str] = Header(default=None)):
    p = _resolve_token(x_gh_token)
    if not p:
        raise HTTPException(401)
    with _db() as conn:
        fields, vals = [], []
        if body.display_name is not None:
            dn = body.display_name.strip()
            if not dn:
                raise HTTPException(400, detail="Display name required")
            fields.append("display_name=?"); vals.append(dn)
        if body.password:
            fields.append("password_hash=?"); vals.append(_hash_pw(body.password))
        if body.avatar_data is not None:
            fields.append("avatar_data=?"); vals.append(body.avatar_data)
        if body.avatar_svg is not None:
            fields.append("avatar_svg=?"); vals.append(body.avatar_svg)
        if fields:
            vals.append(p["id"])
            conn.execute(f"UPDATE players SET {','.join(fields)} WHERE id=?", vals)
            conn.commit()
    return JSONResponse({"ok": True})

@_pub.get("/favourites")
async def get_favourites(x_gh_token: Optional[str] = Header(default=None)):
    p = _resolve_token(x_gh_token)
    if not p:
        raise HTTPException(401)
    with _db() as conn:
        rows = conn.execute("""
            SELECT pl.id,pl.username,pl.display_name,pl.avatar_color,pl.avatar_data,pl.avatar_svg
            FROM player_favourites f JOIN players pl ON f.favourite_id=pl.id
            WHERE f.player_id=? ORDER BY pl.display_name
        """, (p["id"],)).fetchall()
    return JSONResponse([dict(r) for r in rows])

@_pub.post("/favourites/{fav_id}")
async def add_favourite(fav_id: str, x_gh_token: Optional[str] = Header(default=None)):
    p = _resolve_token(x_gh_token)
    if not p:
        raise HTTPException(401)
    if fav_id == p["id"]:
        raise HTTPException(400, detail="Cannot favourite yourself")
    now = datetime.now(timezone.utc).isoformat()
    with _db() as conn:
        target = conn.execute("SELECT id FROM players WHERE id=?", (fav_id,)).fetchone()
        if not target:
            raise HTTPException(404, detail="Player not found")
        conn.execute("INSERT OR IGNORE INTO player_favourites(player_id,favourite_id,created_at) VALUES(?,?,?)",
                     (p["id"], fav_id, now))
        conn.commit()
    return JSONResponse({"ok": True})

@_pub.delete("/favourites/{fav_id}")
async def remove_favourite(fav_id: str, x_gh_token: Optional[str] = Header(default=None)):
    p = _resolve_token(x_gh_token)
    if not p:
        raise HTTPException(401)
    with _db() as conn:
        conn.execute("DELETE FROM player_favourites WHERE player_id=? AND favourite_id=?", (p["id"], fav_id))
        conn.commit()
    return JSONResponse({"ok": True})

@_pub.get("/players")
async def players_public():
    with _db() as conn:
        rows = conn.execute("SELECT id,username,display_name,avatar_color,avatar_data,avatar_svg FROM players ORDER BY display_name").fetchall()
    return JSONResponse([dict(r) for r in rows])

@_pub.get("/stats")
async def stats_public():
    return await _build_stats()

# ── Public session recording ──────────────────────────────────

class SessionPlayer(BaseModel):
    player_id:  Optional[str] = None
    guest_name: Optional[str] = None
    score:      Optional[float] = None
    rank:       Optional[int] = None
    is_winner:  bool = False

class SessionBody(BaseModel):
    game_id:          str
    mode:             str = 'multiplayer'
    players:          list[SessionPlayer]
    duration_seconds: Optional[int] = None
    metadata:         dict = {}

@_pub.post("/session")
async def record_session(body: SessionBody):
    now = datetime.now(timezone.utc).isoformat()
    with _db() as conn:
        cur = conn.execute(
            "INSERT INTO game_sessions(game_id,mode,played_at,duration_seconds,metadata) VALUES(?,?,?,?,?)",
            (body.game_id, body.mode, now, body.duration_seconds, json.dumps(body.metadata))
        )
        sid = cur.lastrowid
        for p in body.players:
            if not p.player_id and not p.guest_name:
                continue
            conn.execute(
                "INSERT INTO session_players(session_id,player_id,guest_name,score,rank,is_winner) VALUES(?,?,?,?,?,?)",
                (sid, p.player_id or None, p.guest_name or None, p.score, p.rank, 1 if p.is_winner else 0)
            )
        conn.commit()
    return JSONResponse({"ok": True, "session_id": sid})

# ── Admin player management (mvmOS session required) ─────────

@_admin.get("/players")
async def list_players(session=Depends(get_current_session)):
    with _db() as conn:
        rows = conn.execute("SELECT id,username,display_name,avatar_color,avatar_data,avatar_svg,created_at FROM players ORDER BY display_name").fetchall()
    return JSONResponse([dict(r) for r in rows])

class PlayerBody(BaseModel):
    username:     str
    display_name: str
    avatar_color: str = '#89b4fa'
    password:     Optional[str] = None

@_admin.post("/players")
async def create_player(body: PlayerBody, session=Depends(get_current_session)):
    pid  = str(uuid.uuid4())[:8]
    now  = datetime.now(timezone.utc).isoformat()
    phash = _hash_pw(body.password) if body.password else None
    try:
        with _db() as conn:
            conn.execute("INSERT INTO players(id,username,display_name,avatar_color,password_hash,created_at) VALUES(?,?,?,?,?,?)",
                         (pid, body.username.strip().lower(), body.display_name.strip(), body.avatar_color, phash, now))
            conn.commit()
    except sqlite3.IntegrityError:
        raise HTTPException(400, detail="Username already exists")
    return JSONResponse({"id": pid})

@_admin.put("/players/{pid}")
async def update_player(pid: str, body: PlayerBody, session=Depends(get_current_session)):
    try:
        with _db() as conn:
            if body.password:
                conn.execute("UPDATE players SET username=?,display_name=?,avatar_color=?,password_hash=? WHERE id=?",
                             (body.username.strip().lower(), body.display_name.strip(), body.avatar_color, _hash_pw(body.password), pid))
            else:
                conn.execute("UPDATE players SET username=?,display_name=?,avatar_color=? WHERE id=?",
                             (body.username.strip().lower(), body.display_name.strip(), body.avatar_color, pid))
            conn.commit()
    except sqlite3.IntegrityError:
        raise HTTPException(400, detail="Username already exists")
    return JSONResponse({"ok": True})

@_admin.delete("/players/{pid}")
async def delete_player(pid: str, session=Depends(get_current_session)):
    with _db() as conn:
        conn.execute("DELETE FROM players WHERE id=?", (pid,))
        conn.commit()
    return JSONResponse({"ok": True})

@_admin.get("/stats")
async def get_stats(session=Depends(get_current_session)):
    return await _build_stats()

# ── Stats builder ─────────────────────────────────────────────

async def _build_stats():
    # Fetch plugin metadata (name, icon) from main DB
    import sqlite3 as _sqlite3
    _main_db = os.path.join(os.path.dirname(__file__), "..", "..", "..", "data.db")
    _plugin_meta = {}
    try:
        _pc = _sqlite3.connect(_main_db)
        _pc.row_factory = _sqlite3.Row
        for r in _pc.execute("SELECT id,name,icon FROM plugins").fetchall():
            _plugin_meta[r["id"]] = {"name": r["name"], "icon": r["icon"]}
        _pc.close()
    except Exception:
        pass

    with _db() as conn:
        games   = [r["game_id"] for r in conn.execute("SELECT DISTINCT game_id FROM game_sessions ORDER BY game_id").fetchall()]
        players = {r["id"]: dict(r) for r in conn.execute("SELECT id,username,display_name,avatar_color,avatar_data,avatar_svg FROM players").fetchall()}

        leaderboard = {}
        for game_id in games:
            rows = conn.execute("""
                SELECT sp.player_id, p.display_name, p.avatar_color,
                       COUNT(*) as played, SUM(sp.is_winner) as wins,
                       MAX(sp.score) as best_score, AVG(sp.score) as avg_score
                FROM session_players sp JOIN players p ON sp.player_id=p.id
                WHERE sp.player_id IS NOT NULL
                  AND sp.session_id IN (SELECT id FROM game_sessions WHERE game_id=?)
                GROUP BY sp.player_id ORDER BY wins DESC, avg_score DESC
            """, (game_id,)).fetchall()
            leaderboard[game_id] = [dict(r) for r in rows]

        recent = conn.execute("""
            SELECT id,game_id,mode,played_at,duration_seconds,metadata FROM game_sessions
            ORDER BY played_at DESC LIMIT 50
        """).fetchall()
        recent_out = []
        for gs in recent:
            sp = conn.execute("""
                SELECT sp.player_id,sp.guest_name,sp.score,sp.is_winner,p.display_name,p.avatar_color
                FROM session_players sp LEFT JOIN players p ON sp.player_id=p.id
                WHERE sp.session_id=? ORDER BY sp.rank,sp.score DESC
            """, (gs["id"],)).fetchall()
            recent_out.append({**dict(gs), "players": [dict(p) for p in sp]})

        h2h_rows = conn.execute("""
            SELECT a.player_id as p1, b.player_id as p2,
                   SUM(CASE WHEN a.is_winner=1 THEN 1 ELSE 0 END) as p1_wins,
                   SUM(CASE WHEN b.is_winner=1 THEN 1 ELSE 0 END) as p2_wins,
                   COUNT(*) as total
            FROM session_players a
            JOIN session_players b ON a.session_id=b.session_id AND a.player_id < b.player_id
            WHERE a.player_id IS NOT NULL AND b.player_id IS NOT NULL
            GROUP BY a.player_id, b.player_id
        """).fetchall()

    return JSONResponse({
        "games": games,
        "game_meta": _plugin_meta,
        "leaderboard": leaderboard,
        "recent": recent_out,
        "head2head": [dict(r) for r in h2h_rows],
        "players": list(players.values()),
    })

# ── Hub settings ─────────────────────────────────────────────

def _get_hub_settings(conn) -> dict:
    rows = conn.execute("SELECT key,value FROM hub_settings").fetchall()
    s = {r["key"]: r["value"] for r in rows}
    return {
        "public":               s.get("public", "false") == "true",
        "allow_registrations":  s.get("allow_registrations", "true") == "true",
    }

@_pub.get("/config")
async def hub_config():
    with _db() as conn:
        return JSONResponse(_get_hub_settings(conn))

class HubSettingsBody(BaseModel):
    public:              bool
    allow_registrations: bool

@_admin.get("/settings")
async def get_hub_settings_admin(session=Depends(get_current_session)):
    with _db() as conn:
        return JSONResponse(_get_hub_settings(conn))

@_admin.put("/settings")
async def update_hub_settings(body: HubSettingsBody, session=Depends(get_current_session)):
    with _db() as conn:
        conn.execute("INSERT OR REPLACE INTO hub_settings(key,value) VALUES('public',?)",
                     ("true" if body.public else "false",))
        conn.execute("INSERT OR REPLACE INTO hub_settings(key,value) VALUES('allow_registrations',?)",
                     ("true" if body.allow_registrations else "false",))
        conn.commit()
    return JSONResponse({"ok": True})

# ── Invites ───────────────────────────────────────────────────

class InviteBody(BaseModel):
    to_ids:   list[str]
    game_id:  str
    room_url: str

@_pub.post("/invite")
async def send_invite(body: InviteBody, x_gh_token: Optional[str] = Header(default=None)):
    p = _resolve_token(x_gh_token)
    if not p:
        raise HTTPException(401)
    now = datetime.now(timezone.utc)
    exp = (now + timedelta(hours=2)).isoformat()
    now_s = now.isoformat()
    with _db() as conn:
        # delete old pending invites from this sender for same room
        conn.execute("DELETE FROM invites WHERE from_id=? AND room_url=?", (p["id"], body.room_url))
        for to_id in body.to_ids:
            if to_id == p["id"]:
                continue
            exists = conn.execute("SELECT id FROM players WHERE id=?", (to_id,)).fetchone()
            if not exists:
                continue
            conn.execute(
                "INSERT INTO invites(from_id,to_id,game_id,room_url,created_at,expires_at) VALUES(?,?,?,?,?,?)",
                (p["id"], to_id, body.game_id, body.room_url, now_s, exp)
            )
        conn.commit()
    return JSONResponse({"ok": True})

@_pub.get("/invites")
async def get_invites(x_gh_token: Optional[str] = Header(default=None)):
    p = _resolve_token(x_gh_token)
    if not p:
        raise HTTPException(401)
    now = datetime.now(timezone.utc).isoformat()
    with _db() as conn:
        rows = conn.execute("""
            SELECT i.id, i.game_id, i.room_url, i.created_at,
                   pl.display_name as from_name, pl.avatar_color as from_color
            FROM invites i JOIN players pl ON pl.id = i.from_id
            WHERE i.to_id=? AND i.expires_at>?
            ORDER BY i.created_at DESC
        """, (p["id"], now)).fetchall()
    return JSONResponse([dict(r) for r in rows])

@_pub.delete("/invites/{invite_id}")
async def dismiss_invite(invite_id: int, x_gh_token: Optional[str] = Header(default=None)):
    p = _resolve_token(x_gh_token)
    if not p:
        raise HTTPException(401)
    with _db() as conn:
        conn.execute("DELETE FROM invites WHERE id=? AND to_id=?", (invite_id, p["id"]))
        conn.commit()
    return JSONResponse({"ok": True})

@_pub.delete("/invites")
async def cancel_my_invites(room_url: str, x_gh_token: Optional[str] = Header(default=None)):
    p = _resolve_token(x_gh_token)
    if not p:
        raise HTTPException(401)
    with _db() as conn:
        conn.execute("DELETE FROM invites WHERE from_id=? AND room_url=?", (p["id"], room_url))
        conn.commit()
    return JSONResponse({"ok": True})

# Combine into single router for the loader
router.include_router(_admin)
router.include_router(_pub)
