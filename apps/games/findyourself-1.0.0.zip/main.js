// mvmOS App: FindYourself v1.0.0
const _fyi18n = {
  en: {
    title: 'FindYourself', play: 'Play', settings_btn: '⚙ Settings',
    no_api: 'Enter your Google Maps API key in App Settings to play.',
    round: 'Round', of: 'of', score: 'Score', time: 'Time',
    click_map: 'Click on the map to place your guess',
    submit: 'Submit Guess', next_round: 'Next Round', see_result: 'See Result',
    finish: 'Finish Game', play_again: 'Play Again',
    distance: 'Distance', points: 'Points',
    result_title: 'Round Result',
    final_title: 'Game Over',
    total_score: 'Total Score',
    best: 'Best', rounds_label: 'rounds',
    loading: 'Loading Street View…',
    no_sv: 'No Street View found nearby, trying another location…',
  },
  bg: {
    title: 'FindYourself', play: 'Играй', settings_btn: '⚙ Настройки',
    no_api: 'Въведи Google Maps API ключ в App Settings за да играеш.',
    round: 'Рунд', of: 'от', score: 'Точки', time: 'Време',
    click_map: 'Кликни на картата за да отбележиш позицията си',
    submit: 'Потвърди', next_round: 'Следващ рунд', see_result: 'Виж резултата',
    finish: 'Приключи', play_again: 'Играй пак',
    distance: 'Разстояние', points: 'Точки',
    result_title: 'Резултат',
    final_title: 'Край на играта',
    total_score: 'Общо точки',
    best: 'Рекорд', rounds_label: 'рунда',
    loading: 'Зареждане на Street View…',
    no_sv: 'Няма Street View наблизо, опитваме друга локация…',
  },
};
function _fyt(key) { const l = window.mvmOS?.lang || 'en'; return (_fyi18n[l] || _fyi18n.en)[key] || key; }

mvmOS.registerApp({
  id: 'findyourself',
  name: 'FindYourself',
  icon: '🌍',
  category: 'Games',
  settings: [
    { key: 'api_key', label: 'Google Maps API Key', type: 'password', default: '' },
    { key: 'rounds',  label: 'Rounds per game',     type: 'number',  default: 5, min: 1, max: 10 },
    { key: 'time',    label: 'Time per round (sec, 0 = unlimited)', type: 'number', default: 60, min: 0 },
  ],
  launch() {
    mvmOS.createWindow({
      id: 'findyourself',
      title: '🌍 FindYourself',
      icon: '🌍',
      width: 1000,
      height: 640,
      appSettings: true,
      onAppSettings() { AppStore.openWindow({ section: 'my-apps', appId: 'findyourself' }); },
      onMount(body) {
        body.style.padding = '0';
        body.style.overflow = 'hidden';
        (window.mvmOS?.i18nReady || Promise.resolve()).then(() => FY.mount(body));
      },
    });
  },
});

const FY = (() => {
  const _db = mvmOS.db('findyourself');
  let _root = null;
  let _cfg = { api_key: '', rounds: 5, time: 60 };
  let _sv = null;       // Street View panorama
  let _map = null;      // guess map
  let _marker = null;   // player's guess marker
  let _guess = null;    // { lat, lng }
  let _actual = null;   // { lat, lng }
  let _round = 0;
  let _totalScore = 0;
  let _roundScores = [];
  let _locations = [];  // pre-generated coords for this game
  let _timerInterval = null;
  let _timeLeft = 0;
  let _mapsLoaded = false;

  // ── Random locations ──────────────────────────────────────────────────────
  // Weighted list of land bounding boxes [minLat, maxLat, minLng, maxLng, weight]
  const _BOXES = [
    [35, 71, -10, 40, 25],   // Europe
    [25, 50, 60, 140, 20],   // Asia
    [-35, 37, -18, 52, 15],  // Africa
    [25, 50, -125, -65, 15], // North America
    [-55, 15, -82, -34, 10], // South America
    [-45, -10, 110, 155, 8], // Australia
    [0, 25, 100, 140, 7],    // SE Asia
  ];

  function _randomCoord() {
    const total = _BOXES.reduce((s, b) => s + b[4], 0);
    let r = Math.random() * total;
    for (const [minLat, maxLat, minLng, maxLng, w] of _BOXES) {
      r -= w;
      if (r <= 0) {
        return {
          lat: minLat + Math.random() * (maxLat - minLat),
          lng: minLng + Math.random() * (maxLng - minLng),
        };
      }
    }
    return { lat: Math.random() * 140 - 70, lng: Math.random() * 360 - 180 };
  }

  // ── Score calculation (GeoGuessr-style) ───────────────────────────────────
  function _calcScore(distKm) {
    if (distKm < 0.05) return 5000;
    return Math.round(5000 * Math.exp(-distKm / 2000));
  }

  function _distKm(a, b) {
    const R = 6371;
    const dLat = (b.lat - a.lat) * Math.PI / 180;
    const dLng = (b.lng - a.lng) * Math.PI / 180;
    const x = Math.sin(dLat/2)**2 + Math.cos(a.lat*Math.PI/180) * Math.cos(b.lat*Math.PI/180) * Math.sin(dLng/2)**2;
    return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1-x));
  }

  function _fmtDist(km) {
    if (km < 1) return Math.round(km * 1000) + ' m';
    if (km < 100) return km.toFixed(1) + ' km';
    return Math.round(km) + ' km';
  }

  // ── Google Maps loader ────────────────────────────────────────────────────
  function _loadMaps(apiKey) {
    return new Promise((resolve, reject) => {
      if (_mapsLoaded && window.google?.maps) { resolve(); return; }
      if (window._fyMapsLoading) { window._fyMapsResolvers.push(resolve); return; }
      window._fyMapsLoading = true;
      window._fyMapsResolvers = [resolve];
      window._fyMapsCallback = () => {
        _mapsLoaded = true;
        window._fyMapsLoading = false;
        window._fyMapsResolvers.forEach(r => r());
      };
      const s = document.createElement('script');
      s.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&callback=_fyMapsCallback`;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  // ── Mount ─────────────────────────────────────────────────────────────────
  async function mount(body) {
    _root = body;
    await _initDb();
    await _loadCfg();
    _showSetup();
    window.addEventListener('settings-changed', async e => {
      if (e.detail?.app === 'findyourself') { await _loadCfg(); }
    });
  }

  async function _initDb() {
    await _db.run(`CREATE TABLE IF NOT EXISTS cfg (key TEXT PRIMARY KEY, value TEXT)`);
    await _db.run(`CREATE TABLE IF NOT EXISTS scores
      (id INTEGER PRIMARY KEY AUTOINCREMENT, total INTEGER, rounds INTEGER, date TEXT)`);
  }

  async function _loadCfg() {
    const rows = await _db.query('SELECT key, value FROM cfg');
    const s = {};
    rows.forEach(r => { try { s[r.key] = JSON.parse(r.value); } catch(_) { s[r.key] = r.value; } });
    _cfg = {
      api_key: s.api_key || '',
      rounds:  parseInt(s.rounds) || 5,
      time:    parseInt(s.time) || 0,
    };
  }

  // ── Setup screen ──────────────────────────────────────────────────────────
  async function _showSetup() {
    _stopTimer();
    const best = await _getBest();
    _root.innerHTML = `
      <div class="fy-root">
        <div class="fy-screen">
          <div style="font-size:3rem">🌍</div>
          <h1>${_fyt('title')}</h1>
          <p>Drop into a random Street View location anywhere in the world and guess where you are on the map.</p>
          ${best ? `<div style="font-size:.82rem;color:#a6adc8">${_fyt('best')}: <strong>${best.total}</strong> pts / ${best.rounds} ${_fyt('rounds_label')}</div>` : ''}
          ${!_cfg.api_key ? `
            <p style="color:#f38ba8;font-size:.82rem">${_fyt('no_api')}</p>
            <a href="https://console.cloud.google.com/apis/library/maps-backend.googleapis.com" target="_blank" style="font-size:.78rem;color:#89b4fa">Get API key from Google Cloud Console →</a>
            <button class="fy-btn secondary" onclick="AppStore?.openWindow({section:'my-apps',appId:'findyourself'})">${_fyt('settings_btn')}</button>
          ` : `
            <div style="display:flex;gap:10px;align-items:center;font-size:.85rem;color:#a6adc8">
              <span>${_cfg.rounds} rounds</span>
              <span>·</span>
              <span>${_cfg.time > 0 ? _cfg.time + 's / round' : 'No time limit'}</span>
            </div>
            <button class="fy-btn" id="fy-start">${_fyt('play')} 🌍</button>
          `}
        </div>
      </div>`;
    _root.querySelector('#fy-start')?.addEventListener('click', _startGame);
  }

  async function _getBest() {
    const rows = await _db.query('SELECT * FROM scores ORDER BY total DESC LIMIT 1');
    return rows[0] || null;
  }

  // ── Game ──────────────────────────────────────────────────────────────────
  async function _startGame() {
    _round = 0;
    _totalScore = 0;
    _roundScores = [];
    _locations = Array.from({ length: _cfg.rounds }, _randomCoord);
    _root.innerHTML = `<div class="fy-root"><div class="fy-game" id="fy-game"></div></div>`;
    try {
      await _loadMaps(_cfg.api_key);
    } catch(e) {
      _root.innerHTML = `<div class="fy-root"><div class="fy-screen"><p style="color:#f38ba8">Failed to load Google Maps. Check your API key.</p><button class="fy-btn secondary" id="fy-back">← Back</button></div></div>`;
      _root.querySelector('#fy-back').addEventListener('click', _showSetup);
      return;
    }
    _nextRound();
  }

  async function _nextRound() {
    _guess = null;
    _round++;
    const gameEl = _root.querySelector('#fy-game');
    if (!gameEl) return;

    gameEl.innerHTML = `
      <div class="fy-hud">
        <div class="fy-hud-pill">${_fyt('round')} <strong>${_round}</strong> ${_fyt('of')} <strong>${_cfg.rounds}</strong></div>
        <div class="fy-hud-pill">${_fyt('score')}: <strong>${_totalScore}</strong></div>
        ${_cfg.time > 0 ? `<div class="fy-hud-pill fy-timer" id="fy-timer">${_cfg.time}s</div>` : ''}
      </div>
      <div id="fy-sv" class="fy-sv"></div>
      <div class="fy-map-wrap" id="fy-map-wrap">
        <div id="fy-map" class="fy-map"></div>
      </div>
      <button class="fy-guess-btn" id="fy-submit" disabled>${_fyt('submit')}</button>
      <div id="fy-sv-loading" style="position:absolute;inset:0;background:#1e1e2e;display:flex;align-items:center;justify-content:center;z-index:5;font-size:.9rem;color:#a6adc8">${_fyt('loading')}</div>
    `;

    await _loadRoundLocation(gameEl);

    _root.querySelector('#fy-submit')?.addEventListener('click', () => _submitGuess(false));
  }

  async function _loadRoundLocation(gameEl, attempt = 0) {
    if (attempt > 10) {
      const loading = gameEl.querySelector('#fy-sv-loading');
      if (loading) loading.textContent = 'Could not find Street View. Skipping round…';
      setTimeout(() => _submitGuess(true), 1500);
      return;
    }

    const coord = attempt === 0 ? _locations[_round - 1] : _randomCoord();
    if (attempt > 0) _locations[_round - 1] = coord;

    const svService = new google.maps.StreetViewService();
    svService.getPanorama({ location: coord, radius: 50000, source: google.maps.StreetViewSource.OUTDOOR }, (data, status) => {
      if (status !== 'OK') {
        _loadRoundLocation(gameEl, attempt + 1);
        return;
      }
      _actual = { lat: data.location.latLng.lat(), lng: data.location.latLng.lng() };

      const svEl = gameEl.querySelector('#fy-sv');
      _sv = new google.maps.StreetViewPanorama(svEl, {
        position: _actual,
        pov: { heading: Math.random() * 360, pitch: 0 },
        addressControl: false,
        showRoadLabels: false,
        motionTracking: false,
        motionTrackingControl: false,
        fullscreenControl: false,
      });

      const mapEl = gameEl.querySelector('#fy-map');
      _map = new google.maps.Map(mapEl, {
        zoom: 2,
        center: { lat: 20, lng: 0 },
        streetViewControl: false,
        fullscreenControl: false,
        mapTypeControl: false,
        zoomControl: true,
        gestureHandling: 'greedy',
        styles: [{ featureType: 'all', elementType: 'labels.text', stylers: [{ visibility: 'on' }] }],
      });
      _marker = null;
      _map.addListener('click', e => {
        _guess = { lat: e.latLng.lat(), lng: e.latLng.lng() };
        if (_marker) _marker.setMap(null);
        _marker = new google.maps.Marker({ position: _guess, map: _map, title: 'Your guess' });
        const btn = _root.querySelector('#fy-submit');
        if (btn) btn.disabled = false;
      });

      const loading = gameEl.querySelector('#fy-sv-loading');
      if (loading) loading.remove();
      if (_cfg.time > 0) _startTimer(gameEl);
    });
  }

  function _startTimer(gameEl) {
    _stopTimer();
    _timeLeft = _cfg.time;
    _timerInterval = setInterval(() => {
      _timeLeft--;
      const el = gameEl.querySelector('#fy-timer');
      if (el) {
        el.textContent = _timeLeft + 's';
        el.classList.toggle('urgent', _timeLeft <= 10);
      }
      if (_timeLeft <= 0) { _stopTimer(); _submitGuess(false); }
    }, 1000);
  }

  function _stopTimer() {
    if (_timerInterval) { clearInterval(_timerInterval); _timerInterval = null; }
  }

  function _submitGuess(noGuess = false) {
    _stopTimer();
    const gameEl = _root.querySelector('#fy-game');
    if (!gameEl) return;

    let dist = 0, score = 0;
    if (!noGuess && _guess && _actual) {
      dist = _distKm(_guess, _actual);
      score = _calcScore(dist);
    }
    _totalScore += score;
    _roundScores.push({ score, dist, actual: _actual, guess: _guess });

    // Show result overlay with map
    const isLast = _round >= _cfg.rounds;
    const overlay = document.createElement('div');
    overlay.className = 'fy-result-overlay';
    overlay.innerHTML = `
      <div class="fy-result-box" style="min-width:400px">
        <h2>${_fyt('result_title')}</h2>
        <div class="fy-result-score">+${score} ${_fyt('points')}</div>
        <div class="fy-result-dist">${noGuess || !_guess ? 'No guess — 0 points' : _fyt('distance') + ': ' + _fmtDist(dist)}</div>
        <div class="fy-result-map" id="fy-result-map"></div>
        <div style="display:flex;gap:8px;justify-content:center">
          <button class="fy-btn" id="fy-next">${isLast ? _fyt('finish') : _fyt('next_round')}</button>
        </div>
      </div>
    `;
    gameEl.appendChild(overlay);

    // Show result map with actual + guess lines
    setTimeout(() => {
      const resultMapEl = document.getElementById('fy-result-map');
      if (!resultMapEl || !_actual) return;
      const bounds = new google.maps.LatLngBounds();
      const rMap = new google.maps.Map(resultMapEl, {
        streetViewControl: false, fullscreenControl: false,
        mapTypeControl: false, zoomControl: false,
        gestureHandling: 'none',
      });
      // Actual location marker
      new google.maps.Marker({
        position: _actual, map: rMap,
        icon: { path: google.maps.SymbolPath.CIRCLE, scale: 8, fillColor: '#a6e3a1', fillOpacity: 1, strokeColor: '#fff', strokeWeight: 2 },
        title: 'Actual location',
      });
      bounds.extend(_actual);
      if (_guess) {
        new google.maps.Marker({
          position: _guess, map: rMap,
          icon: { path: google.maps.SymbolPath.CIRCLE, scale: 8, fillColor: '#f38ba8', fillOpacity: 1, strokeColor: '#fff', strokeWeight: 2 },
          title: 'Your guess',
        });
        new google.maps.Polyline({
          path: [_actual, _guess], map: rMap,
          strokeColor: '#f1fa8c', strokeOpacity: .8, strokeWeight: 2,
        });
        bounds.extend(_guess);
      }
      rMap.fitBounds(bounds, 40);
    }, 100);

    overlay.querySelector('#fy-next').addEventListener('click', () => {
      overlay.remove();
      if (isLast) _showFinal();
      else _nextRound();
    });
  }

  async function _showFinal() {
    _stopTimer();
    await _db.run('INSERT INTO scores (total, rounds, date) VALUES (?,?,?)',
      [_totalScore, _cfg.rounds, new Date().toISOString()]);

    const best = await _getBest();
    _root.innerHTML = `
      <div class="fy-root">
        <div class="fy-screen">
          <div style="font-size:2.5rem">🌍</div>
          <h1>${_fyt('final_title')}</h1>
          <div class="fy-result-score">${_totalScore} ${_fyt('points')}</div>
          <div class="fy-scores">
            ${_roundScores.map((r, i) => `
              <div class="fy-score-row">
                <span class="rank">${i+1}.</span>
                <span class="sname">${r.dist != null ? _fmtDist(r.dist) : 'No guess'}</span>
                <span class="spts">+${r.score}</span>
              </div>
            `).join('')}
          </div>
          ${best ? `<div style="font-size:.8rem;color:#a6adc8">${_fyt('best')}: <strong>${best.total}</strong> pts</div>` : ''}
          <div style="display:flex;gap:10px">
            <button class="fy-btn" id="fy-again">${_fyt('play_again')}</button>
            <button class="fy-btn secondary" id="fy-home">← Menu</button>
          </div>
        </div>
      </div>`;
    _root.querySelector('#fy-again').addEventListener('click', _startGame);
    _root.querySelector('#fy-home').addEventListener('click', _showSetup);
  }

  return { mount };
})();
