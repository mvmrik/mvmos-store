"""
FindYourself — server-authoritative multiplayer backend.

Game state lives entirely on the server. Players disconnect and reconnect freely.
Multiplayer requires a Game Hub account. Single-player needs no backend.

Routes are under /api/pub/findyourself/ (public, no mvmOS session required).
Game Hub token is used for player identity in multiplayer.
"""

import asyncio
import json
import math
import os
import random
import sqlite3
import string
import time
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Request
from fastapi.responses import JSONResponse, HTMLResponse

router = APIRouter(prefix="/api/pub/findyourself")

_BASE = os.path.dirname(__file__)
DB_PATH    = os.path.join(_BASE, "..", "..", "apps", "findyourself", "data.db")
GH_DB_PATH = os.path.join(_BASE, "..", "..", "apps", "gamehub",     "data.db")

PLAYER_COLORS = [
    "#89b4fa","#f38ba8","#a6e3a1","#f9e2af",
    "#cba6f7","#fab387","#94e2d5","#f5c2e7",
    "#74c7ec","#eba0ac","#b4befe","#f2cdcd",
]
RESULT_WAIT    = 12   # seconds to display round results before auto-advancing
GAME_TTL       = 7200 # 2 h — clean up old games


# ── Database ──────────────────────────────────────────────────────────────────

def _db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def _init_db():
    with _db() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS cfg
                (key TEXT PRIMARY KEY, value TEXT);
            CREATE TABLE IF NOT EXISTS scores
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 total INTEGER, rounds INTEGER, date TEXT);

            CREATE TABLE IF NOT EXISTS fy_games (
                id             TEXT PRIMARY KEY,
                status         TEXT    NOT NULL DEFAULT 'waiting',
                rounds_total   INTEGER NOT NULL DEFAULT 5,
                time_per_round INTEGER NOT NULL DEFAULT 60,
                current_round  INTEGER NOT NULL DEFAULT 0,
                round_started_at REAL  NOT NULL DEFAULT 0,
                result_at      REAL    NOT NULL DEFAULT 0,
                created_at     REAL    NOT NULL,
                api_key        TEXT    NOT NULL DEFAULT '',
                creator_id     TEXT    NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS fy_invites (
                game_id      TEXT NOT NULL,
                gh_player_id TEXT NOT NULL,
                PRIMARY KEY (game_id, gh_player_id)
            );
            CREATE TABLE IF NOT EXISTS fy_locations (
                game_id  TEXT    NOT NULL,
                round    INTEGER NOT NULL,
                lat      REAL    NOT NULL,
                lng      REAL    NOT NULL,
                heading  REAL    NOT NULL,
                PRIMARY KEY (game_id, round)
            );
            CREATE TABLE IF NOT EXISTS fy_players (
                game_id      TEXT NOT NULL,
                gh_player_id TEXT NOT NULL,
                display_name TEXT NOT NULL,
                avatar_svg   TEXT,
                avatar_color TEXT NOT NULL DEFAULT '#89b4fa',
                total_score  INTEGER NOT NULL DEFAULT 0,
                connected    INTEGER NOT NULL DEFAULT 0,
                joined_at    REAL    NOT NULL,
                PRIMARY KEY (game_id, gh_player_id)
            );
            CREATE TABLE IF NOT EXISTS fy_guesses (
                game_id      TEXT    NOT NULL,
                gh_player_id TEXT    NOT NULL,
                round        INTEGER NOT NULL,
                lat          REAL,
                lng          REAL,
                dist_km      REAL,
                dist_score   INTEGER NOT NULL DEFAULT 0,
                time_bonus   INTEGER NOT NULL DEFAULT 0,
                score        INTEGER NOT NULL DEFAULT 0,
                submitted_at REAL    NOT NULL,
                PRIMARY KEY (game_id, gh_player_id, round)
            );
        """)
        conn.commit()
        # migrations
        for sql in [
            "ALTER TABLE fy_games ADD COLUMN creator_id TEXT NOT NULL DEFAULT ''",
        ]:
            try:
                conn.execute(sql)
                conn.commit()
            except Exception:
                pass


_init_db()


# ── Game Hub auth ─────────────────────────────────────────────────────────────

def _get_gh_player(token: str) -> dict | None:
    """Validate GH token and return player dict, or None."""
    if not token:
        return None
    try:
        conn = sqlite3.connect(GH_DB_PATH)
        conn.row_factory = sqlite3.Row
        row = conn.execute("""
            SELECT p.id, p.display_name, p.avatar_color
            FROM gh_tokens t JOIN players p ON t.player_id = p.id
            WHERE t.token = ? AND t.expires_at > datetime('now')
        """, (token,)).fetchone()
        conn.close()
        return dict(row) if row else None
    except Exception:
        return None


def _get_gh_avatar_svg(gh_player_id: str) -> str | None:
    try:
        conn = sqlite3.connect(GH_DB_PATH)
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT avatar_svg FROM players WHERE id=?", (gh_player_id,)).fetchone()
        conn.close()
        return row["avatar_svg"] if row else None
    except Exception:
        return None


# ── DB helpers ────────────────────────────────────────────────────────────────

def _get_game(game_id: str) -> dict | None:
    with _db() as conn:
        row = conn.execute("SELECT * FROM fy_games WHERE id=?", (game_id,)).fetchone()
        return dict(row) if row else None


def _get_players(game_id: str, connected_only: bool = False) -> list:
    with _db() as conn:
        if connected_only:
            rows = conn.execute(
                "SELECT * FROM fy_players WHERE game_id=? AND connected=1 ORDER BY joined_at",
                (game_id,)
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM fy_players WHERE game_id=? ORDER BY joined_at",
                (game_id,)
            ).fetchall()
        return [dict(r) for r in rows]


def _get_location(game_id: str, round_num: int) -> dict | None:
    with _db() as conn:
        row = conn.execute(
            "SELECT * FROM fy_locations WHERE game_id=? AND round=?",
            (game_id, round_num)
        ).fetchone()
        return dict(row) if row else None


def _get_guesses(game_id: str, round_num: int) -> list:
    with _db() as conn:
        rows = conn.execute(
            "SELECT * FROM fy_guesses WHERE game_id=? AND round=?",
            (game_id, round_num)
        ).fetchall()
        return [dict(r) for r in rows]


def _player_info(p: dict) -> dict:
    return {
        "gh_player_id": p["gh_player_id"],
        "display_name": p["display_name"],
        "avatar_svg":   p.get("avatar_svg"),
        "avatar_color": p["avatar_color"],
        "total_score":  p["total_score"],
        "connected":    p["connected"],
    }


# ── Score helpers ─────────────────────────────────────────────────────────────

_TIME_BONUS_MAX    = 1000
_TIME_BONUS_WINDOW = 200


def _calc_dist_score(dist_km: float) -> int:
    if dist_km < 0.05:
        return 5000
    return round(5000 * math.exp(-dist_km / 2000))


def _calc_time_bonus(elapsed: float) -> int:
    b = _TIME_BONUS_MAX * (1 - elapsed / _TIME_BONUS_WINDOW)
    return max(0, round(b))


def _haversine(lat1, lng1, lat2, lng2) -> float:
    R = 6371
    dl = (lat2 - lat1) * math.pi / 180
    dg = (lng2 - lng1) * math.pi / 180
    a  = math.sin(dl/2)**2 + math.cos(lat1*math.pi/180)*math.cos(lat2*math.pi/180)*math.sin(dg/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))


def _make_id(n=10):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=n))


# ── WebSocket pool ────────────────────────────────────────────────────────────

# game_id → { gh_player_id: WebSocket }
_ws: dict[str, dict[str, WebSocket]] = {}


async def _send_one(ws: WebSocket, msg: dict):
    try:
        await ws.send_text(json.dumps(msg))
    except Exception:
        pass


async def _broadcast(game_id: str, msg: dict, exclude: str | None = None):
    pool = _ws.get(game_id, {})
    data = json.dumps(msg)
    for pid, ws in list(pool.items()):
        if pid != exclude:
            try:
                await ws.send_text(data)
            except Exception:
                pass


# ── Round lifecycle ───────────────────────────────────────────────────────────

async def _end_round(game_id: str):
    """Called when all connected players submitted OR timer expired."""
    game = _get_game(game_id)
    if not game or game["status"] != "playing":
        return
    r    = game["current_round"]
    loc  = _get_location(game_id, r)
    if not loc:
        return

    players = _get_players(game_id)
    guesses = {g["gh_player_id"]: g for g in _get_guesses(game_id, r)}

    results = []
    with _db() as conn:
        for p in players:
            pid   = p["gh_player_id"]
            g     = guesses.get(pid)
            score = g["score"] if g else 0
            new_total = p["total_score"] + score
            conn.execute(
                "UPDATE fy_players SET total_score=? WHERE game_id=? AND gh_player_id=?",
                (new_total, game_id, pid)
            )
            results.append({
                "gh_player_id": pid,
                "display_name": p["display_name"],
                "avatar_svg":   p.get("avatar_svg"),
                "avatar_color": p["avatar_color"],
                "lat":         g["lat"]        if g else None,
                "lng":         g["lng"]        if g else None,
                "dist_km":     g["dist_km"]    if g else None,
                "dist_score":  g["dist_score"] if g else 0,
                "time_bonus":  g["time_bonus"] if g else 0,
                "score":       score,
                "total":       new_total,
            })
        now = time.time()
        conn.execute(
            "UPDATE fy_games SET result_at=? WHERE id=?",
            (now, game_id)
        )
        conn.commit()

    await _broadcast(game_id, {
        "type":       "round_end",
        "round":      r,
        "total":      game["rounds_total"],
        "actual":     {"lat": loc["lat"], "lng": loc["lng"]},
        "results":    results,
        "creator_id": game["creator_id"],
    })

    # No auto-advance — creator must manually start next round


async def _advance_round(game_id: str):
    """Start next round, or end game if all rounds done."""
    game = _get_game(game_id)
    if not game or game["status"] != "playing":
        return

    next_r = game["current_round"] + 1
    if next_r > game["rounds_total"]:
        await _finish_game(game_id)
        return

    loc = _get_location(game_id, next_r)
    if not loc:
        return

    now = time.time()
    with _db() as conn:
        conn.execute(
            "UPDATE fy_games SET current_round=?, round_started_at=?, result_at=0 WHERE id=?",
            (next_r, now, game_id)
        )
        conn.commit()

    players = _get_players(game_id, connected_only=True)
    await _broadcast(game_id, {
        "type":            "round_start",
        "round":           next_r,
        "total":           game["rounds_total"],
        "time":            game["time_per_round"],
        "lat":             loc["lat"],
        "lng":             loc["lng"],
        "heading":         loc["heading"],
        "api_key":         game["api_key"],
        "round_started_at": now,
        "actual":          {"lat": float(loc["lat"]), "lng": float(loc["lng"])},
        "player_count":    len(players),
    })

    if game["time_per_round"] > 0:
        asyncio.create_task(_round_timer(game_id, next_r, game["time_per_round"]))


async def _finish_game(game_id: str):
    players = _get_players(game_id)
    standings = sorted(
        [_player_info(p) for p in players],
        key=lambda p: p["total_score"], reverse=True
    )
    with _db() as conn:
        conn.execute("UPDATE fy_games SET status='finished' WHERE id=?", (game_id,))
        conn.commit()
    await _broadcast(game_id, {"type": "game_over", "standings": standings})
    _ws.pop(game_id, None)


async def _check_round_end(game_id: str):
    """End the round if all currently-connected players have submitted."""
    game = _get_game(game_id)
    if not game or game["status"] != "playing" or game["result_at"] > 0:
        return
    r        = game["current_round"]
    players  = _get_players(game_id)
    connected = [p for p in players if p["connected"]]
    if not connected:
        return
    guesses  = {g["gh_player_id"] for g in _get_guesses(game_id, r)}
    if all(p["gh_player_id"] in guesses for p in connected):
        await _end_round(game_id)


async def _round_timer(game_id: str, round_num: int, delay: int):
    await asyncio.sleep(delay)
    game = _get_game(game_id)
    if game and game["status"] == "playing" and game["current_round"] == round_num and game["result_at"] == 0:
        await _end_round(game_id)


async def _result_timer(game_id: str, round_num: int):
    await asyncio.sleep(RESULT_WAIT)
    game = _get_game(game_id)
    if game and game["status"] == "playing" and game["current_round"] == round_num and game["result_at"] > 0:
        await _advance_round(game_id)


# ── REST endpoints ────────────────────────────────────────────────────────────

@router.post("/games")
async def create_game(request: Request, body: dict):
    """Create a new game room. Requires gh_token in body or X-GH-Token header."""
    token = body.get("gh_token") or request.headers.get("X-GH-Token", "")
    player = _get_gh_player(token)
    if not player:
        return JSONResponse({"error": "unauthorized"}, status_code=401)

    # Clean up stale games
    with _db() as conn:
        conn.execute(
            "DELETE FROM fy_games WHERE created_at < ? AND status IN ('waiting','finished')",
            (time.time() - GAME_TTL,)
        )
        conn.commit()

    game_id = _make_id(10)
    with _db() as conn:
        conn.execute(
            "INSERT INTO fy_games(id, rounds_total, time_per_round, created_at, api_key, creator_id) VALUES(?,?,?,?,?,?)",
            (
                game_id,
                max(1, min(50, int(body.get("rounds", 5)))),
                max(0, int(body.get("time", 60))),
                time.time(),
                body.get("api_key", ""),
                str(player["id"]),
            )
        )
        conn.commit()

    link = f"/api/pub/findyourself/play/{game_id}"
    return {"game_id": game_id, "link": link}


@router.get("/games")
async def list_games():
    """List open and active games (last 2 hours)."""
    with _db() as conn:
        rows = conn.execute("""
            SELECT g.id, g.status, g.rounds_total, g.time_per_round,
                   g.current_round, g.created_at,
                   COUNT(p.gh_player_id) AS player_count
            FROM fy_games g
            LEFT JOIN fy_players p ON g.id = p.game_id
            WHERE g.status IN ('waiting','playing')
              AND g.created_at > ?
            GROUP BY g.id
            ORDER BY g.created_at DESC
            LIMIT 30
        """, (time.time() - GAME_TTL,)).fetchall()
    return [dict(r) for r in rows]


@router.post("/games/{game_id}/start")
async def start_game(game_id: str, body: dict):
    """Start the game — caller provides pre-resolved locations."""
    player = _get_gh_player(body.get("gh_token", ""))
    if not player:
        return JSONResponse({"error": "unauthorized"}, status_code=401)

    game = _get_game(game_id)
    if not game:
        return JSONResponse({"error": "not found"}, status_code=404)
    if game["status"] != "waiting":
        return JSONResponse({"error": "already started"}, status_code=409)
    if str(player["id"]) != str(game["creator_id"]):
        return JSONResponse({"error": "only creator can start"}, status_code=403)
    connected = len(_ws.get(game_id, {}))
    if connected < 2:
        return JSONResponse({"error": "need at least 2 players"}, status_code=400)

    locations = body.get("locations", [])
    if len(locations) < game["rounds_total"]:
        return JSONResponse({"error": "not enough locations"}, status_code=400)

    now = time.time()
    with _db() as conn:
        for i, loc in enumerate(locations[: game["rounds_total"]]):
            conn.execute(
                "INSERT OR REPLACE INTO fy_locations(game_id, round, lat, lng, heading) VALUES(?,?,?,?,?)",
                (game_id, i + 1, float(loc["lat"]), float(loc["lng"]), float(loc["heading"]))
            )
        conn.execute(
            "UPDATE fy_games SET status='playing', current_round=1, round_started_at=?, result_at=0 WHERE id=?",
            (now, game_id)
        )
        conn.commit()

    players = _get_players(game_id, connected_only=True)
    loc = locations[0]
    await _broadcast(game_id, {
        "type":            "round_start",
        "round":           1,
        "total":           game["rounds_total"],
        "time":            game["time_per_round"],
        "lat":             float(loc["lat"]),
        "lng":             float(loc["lng"]),
        "heading":         float(loc["heading"]),
        "api_key":         game["api_key"],
        "round_started_at": now,
        "actual":          {"lat": float(loc["lat"]), "lng": float(loc["lng"])},
        "player_count":    len(players),
    })

    if game["time_per_round"] > 0:
        asyncio.create_task(_round_timer(game_id, 1, game["time_per_round"]))

    return {"ok": True}


@router.post("/games/{game_id}/invite")
async def invite_player(game_id: str, request: Request, body: dict):
    """Creator invites a player to the game."""
    token = body.get("gh_token") or request.headers.get("X-GH-Token", "")
    player = _get_gh_player(token)
    if not player:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    game = _get_game(game_id)
    if not game:
        return JSONResponse({"error": "not found"}, status_code=404)
    if str(player["id"]) != str(game["creator_id"]):
        return JSONResponse({"error": "only creator can invite"}, status_code=403)
    invitee_id = str(body.get("player_id", ""))
    if not invitee_id:
        return JSONResponse({"error": "player_id required"}, status_code=400)
    with _db() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO fy_invites(game_id, gh_player_id) VALUES(?,?)",
            (game_id, invitee_id)
        )
        conn.commit()
    return {"ok": True}


@router.get("/play/{game_id}", response_class=HTMLResponse)
async def play_page(game_id: str):
    game = _get_game(game_id)
    if not game:
        return HTMLResponse("<h2>Game not found or expired.</h2>", status_code=404)
    import os as _os, time as _t
    mtime = int(_os.path.getmtime(
        _os.path.join(_BASE, "..", "..", "..", "apps", "findyourself", "main.js")
    ))
    return HTMLResponse(_play_html(game_id, mtime))


def _play_html(game_id: str, mtime: int) -> str:
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>FindYourself</title>
  <style>
    *{{box-sizing:border-box;margin:0;padding:0}}
    body{{background:#1e1e2e;color:#cdd6f4;
      font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
      display:flex;flex-direction:column;height:100dvh;overflow:hidden}}
    #mp-app{{flex:1;min-height:0;display:flex;flex-direction:column}}
  </style>
</head>
<body>
  <div id="mp-app"></div>
  <script>
    window.mvmOS = {{
      lang: navigator.language?.startsWith('bg') ? 'bg' : 'en',
      createWindow: function(opts) {{
        const body = document.getElementById('mp-app');
        body.style.cssText = 'flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden;background:#1e1e2e;padding:0';
        if (opts.onMount) opts.onMount(body);
        return {{ id: opts.id }};
      }},
      registerApp: function(def) {{ window._mpAppDef = def; }},
    }};
  </script>
  <script src="/apps/findyourself/main.js?v={mtime}"></script>
  <script src="/apps/findyourself/style.css?_=0" onerror="void 0"></script>
  <link rel="stylesheet" href="/apps/findyourself/style.css?v={mtime}">
  <script>
    if (window._mpAppDef)
      window._mpAppDef.launch({{ multiplayer: true, gameId: '{game_id}' }});
  </script>
</body>
</html>"""


# ── WebSocket ─────────────────────────────────────────────────────────────────

@router.websocket("/games/{game_id}/ws")
async def game_ws(websocket: WebSocket, game_id: str):
    game = _get_game(game_id)
    if not game or game["status"] == "finished":
        await websocket.close(code=4004)
        return

    await websocket.accept()
    gh_player_id = None
    heartbeat_task = None

    try:
        # First message must be join with GH token
        try:
            first_raw = await asyncio.wait_for(websocket.receive_text(), timeout=10.0)
            first_msg = json.loads(first_raw)
        except asyncio.TimeoutError:
            await websocket.close()
            return

        if first_msg.get("type") != "join":
            await _send_one(websocket, {"type": "error", "message": "expected join"})
            await websocket.close()
            return

        player = _get_gh_player(first_msg.get("gh_token", ""))
        if not player:
            await _send_one(websocket, {"type": "error", "message": "unauthorized"})
            await websocket.close()
            return

        gh_player_id = str(player["id"])

        # Check if player is allowed (creator or invited)
        with _db() as conn:
            is_creator = str(game["creator_id"]) == gh_player_id
            is_invited = conn.execute(
                "SELECT 1 FROM fy_invites WHERE game_id=? AND gh_player_id=?",
                (game_id, gh_player_id)
            ).fetchone() is not None
            already_in = conn.execute(
                "SELECT 1 FROM fy_players WHERE game_id=? AND gh_player_id=?",
                (game_id, gh_player_id)
            ).fetchone() is not None
        if not is_creator and not is_invited and not already_in:
            await _send_one(websocket, {"type": "error", "message": "not_invited"})
            await websocket.close()
            return

        # Register or reconnect player
        with _db() as conn:
            existing = conn.execute(
                "SELECT * FROM fy_players WHERE game_id=? AND gh_player_id=?",
                (game_id, gh_player_id)
            ).fetchone()
            avatar_svg = _get_gh_avatar_svg(gh_player_id)
            if existing:
                conn.execute(
                    "UPDATE fy_players SET connected=1, display_name=?, avatar_svg=? WHERE game_id=? AND gh_player_id=?",
                    (player["display_name"], avatar_svg, game_id, gh_player_id)
                )
                is_reconnect = True
            else:
                count = conn.execute(
                    "SELECT COUNT(*) AS n FROM fy_players WHERE game_id=?", (game_id,)
                ).fetchone()["n"]
                color = PLAYER_COLORS[count % len(PLAYER_COLORS)]
                conn.execute(
                    """INSERT INTO fy_players
                       (game_id, gh_player_id, display_name, avatar_svg, avatar_color, connected, joined_at)
                       VALUES(?,?,?,?,?,1,?)""",
                    (game_id, gh_player_id, player["display_name"], avatar_svg, color, time.time())
                )
                is_reconnect = False
            conn.commit()

        # Add to WS pool
        if game_id not in _ws:
            _ws[game_id] = {}
        _ws[game_id][gh_player_id] = websocket

        # Build and send full state
        game    = _get_game(game_id)
        players = _get_players(game_id)
        connected_count = sum(1 for p in players if p["connected"])
        state   = {
            "type":       "state",
            "game_id":    game_id,
            "status":     game["status"],
            "round":      game["current_round"],
            "total":      game["rounds_total"],
            "time":       game["time_per_round"],
            "api_key":    game["api_key"],
            "result_at":  game["result_at"],
            "round_started_at": game["round_started_at"],
            "your_id":    gh_player_id,
            "creator_id": game["creator_id"],
            "players":    [_player_info(p) for p in players],
            "connected_count": connected_count,
        }
        if game["status"] == "playing" and game["current_round"] > 0:
            loc = _get_location(game_id, game["current_round"])
            if loc:
                state["location"] = {"lat": loc["lat"], "lng": loc["lng"], "heading": loc["heading"]}
            state["guesses"] = _get_guesses(game_id, game["current_round"])
            if game["result_at"] > 0:
                state["results"] = _build_results(game_id, game["current_round"])
        await _send_one(websocket, state)

        # Notify others
        ev_type = "player_reconnected" if is_reconnect else "player_joined"
        p_row   = next((p for p in players if p["gh_player_id"] == gh_player_id), None)
        if p_row:
            await _broadcast(game_id, {"type": ev_type, "player": _player_info(p_row)}, exclude=gh_player_id)

        # Heartbeat
        async def _hb():
            while True:
                await asyncio.sleep(25)
                try:
                    await websocket.send_text('{"type":"ping"}')
                except Exception:
                    break

        heartbeat_task = asyncio.create_task(_hb())

        # Main message loop
        while True:
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
            except Exception:
                continue

            t = msg.get("type")

            if t == "pong":
                continue

            elif t == "guess":
                await _handle_guess(game_id, gh_player_id, msg)

            elif t == "next_round":
                game_now = _get_game(game_id)
                if game_now and str(game_now["creator_id"]) == gh_player_id:
                    await _handle_next_round(game_id)

    except (WebSocketDisconnect, Exception):
        pass
    finally:
        if heartbeat_task:
            heartbeat_task.cancel()
        if gh_player_id:
            if game_id in _ws:
                _ws[game_id].pop(gh_player_id, None)
            with _db() as conn:
                conn.execute(
                    "UPDATE fy_players SET connected=0 WHERE game_id=? AND gh_player_id=?",
                    (game_id, gh_player_id)
                )
                conn.commit()
            await _broadcast(game_id, {"type": "player_disconnected", "gh_player_id": gh_player_id})
            await _check_round_end(game_id)


# ── Message handlers ──────────────────────────────────────────────────────────

async def _handle_guess(game_id: str, gh_player_id: str, msg: dict):
    game = _get_game(game_id)
    if not game or game["status"] != "playing" or game["result_at"] > 0:
        return

    r   = game["current_round"]
    loc = _get_location(game_id, r)
    if not loc:
        return

    elapsed    = time.time() - game["round_started_at"]
    lat        = msg.get("lat")
    lng        = msg.get("lng")
    dist_km    = None
    dist_score = 0
    time_bonus = 0

    if lat is not None and lng is not None:
        try:
            dist_km    = _haversine(float(lat), float(lng), loc["lat"], loc["lng"])
            dist_score = _calc_dist_score(dist_km)
            time_bonus = _calc_time_bonus(elapsed)
        except Exception:
            pass

    score = dist_score + time_bonus

    with _db() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO fy_guesses
               (game_id, gh_player_id, round, lat, lng, dist_km, dist_score, time_bonus, score, submitted_at)
               VALUES(?,?,?,?,?,?,?,?,?,?)""",
            (game_id, gh_player_id, r, lat, lng, dist_km, dist_score, time_bonus, score, time.time())
        )
        conn.commit()

    # Notify other players that this player has guessed (for live map update)
    player_row = next((p for p in _get_players(game_id) if p["gh_player_id"] == gh_player_id), None)
    await _broadcast(game_id, {
        "type":         "guess_update",
        "gh_player_id": gh_player_id,
        "lat":          lat,
        "lng":          lng,
        "display_name": player_row["display_name"] if player_row else "",
        "avatar_svg":   player_row.get("avatar_svg") if player_row else None,
        "avatar_color": player_row["avatar_color"] if player_row else "#89b4fa",
    }, exclude=gh_player_id)

    await _check_round_end(game_id)


async def _handle_next_round(game_id: str):
    game = _get_game(game_id)
    if not game or game["status"] != "playing" or game["result_at"] == 0:
        return
    await _advance_round(game_id)


def _build_results(game_id: str, round_num: int) -> list:
    players = {p["gh_player_id"]: p for p in _get_players(game_id)}
    guesses = {g["gh_player_id"]: g for g in _get_guesses(game_id, round_num)}
    loc     = _get_location(game_id, round_num)
    results = []
    for pid, p in players.items():
        g = guesses.get(pid)
        results.append({
            "gh_player_id": pid,
            "display_name": p["display_name"],
            "avatar_svg":   p.get("avatar_svg"),
            "avatar_color": p["avatar_color"],
            "lat":          g["lat"]        if g else None,
            "lng":          g["lng"]        if g else None,
            "dist_km":      g["dist_km"]    if g else None,
            "dist_score":   g["dist_score"] if g else 0,
            "time_bonus":   g["time_bonus"] if g else 0,
            "score":        g["score"]      if g else 0,
            "total":        p["total_score"],
        })
    return sorted(results, key=lambda r: r["score"], reverse=True)
