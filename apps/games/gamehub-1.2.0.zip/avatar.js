// Game Hub — SVG Avatar renderer + builder
// Exposes: window.GHAvatar = { avatarSvg, renderAvatar, showBuilder }
(function () {
  'use strict';

  const BG_COLS   = ['#89b4fa','#a6e3a1','#f38ba8','#fab387','#f9e2af','#cba6f7','#94e2d5','#89dceb','#585b70','#313244'];
  const SKIN_COLS = ['#ffd5a8','#f2c08a','#e0a070','#c07840','#8b5530','#4a2c14'];
  const HAIR_COLS = ['#0a0602','#2c1810','#5c3a1e','#9b6b3a','#d4a96a','#f5e6c8','#c0392b','#8e44ad','#2980b9','#95a5a6'];
  const EYE_COLS  = ['#1a0f0a','#2d5a27','#1e3d6b','#6b4c35','#4a4a6a','#c0392b'];

  const DEFAULTS = { bg:'#89b4fa', skin:'#ffd5a8', face:0, ears:0, hair:0, hc:'#2c1810', eyes:0, ec:'#1a0f0a', brows:0, nose:0, mouth:0 };

  function avatarSvg(data, sz) {
    sz = sz || 80;
    const d = Object.assign({}, DEFAULTS, data || {});
    const S=d.skin, H=d.hc, E=d.ec, BG=d.bg, DK='#1a0f0a';

    const faces = [
      `<ellipse cx="50" cy="55" rx="27" ry="27" fill="${S}"/>`,
      `<ellipse cx="50" cy="56" rx="22" ry="30" fill="${S}"/>`,
      `<ellipse cx="50" cy="54" rx="30" ry="23" fill="${S}"/>`,
      `<path d="M50,82 Q31,73 27,56 Q25,39 50,28 Q75,39 73,56 Q69,73 50,82Z" fill="${S}"/>`,
    ];

    const earParts = [
      '',
      `<ellipse cx="22" cy="55" rx="5" ry="6.5" fill="${S}"/><ellipse cx="78" cy="55" rx="5" ry="6.5" fill="${S}"/>`,
      `<ellipse cx="19" cy="56" rx="7.5" ry="9.5" fill="${S}"/><ellipse cx="81" cy="56" rx="7.5" ry="9.5" fill="${S}"/>`,
      `<path d="M26,50 L18,40 L21,62Z" fill="${S}"/><path d="M74,50 L82,40 L79,62Z" fill="${S}"/>`,
    ];

    const hairBack = [
      '',
      `<ellipse cx="50" cy="35" rx="28" ry="18" fill="${H}"/>`,
      `<ellipse cx="50" cy="32" rx="28" ry="19" fill="${H}"/><rect x="21" y="44" width="8" height="42" rx="4" fill="${H}"/><rect x="71" y="44" width="8" height="42" rx="4" fill="${H}"/>`,
      `<ellipse cx="50" cy="30" rx="33" ry="28" fill="${H}"/>`,
      `<path d="M45,46 L44,24 Q50,14 56,24 L55,46Z" fill="${H}"/>`,
    ];

    const hairFront = [
      '',
      `<path d="M23,50 Q30,35 50,33 Q70,35 77,50 Q66,41 50,39 Q34,41 23,50Z" fill="${H}"/>`,
      `<path d="M23,50 Q28,33 50,29 Q72,33 77,50 Q66,37 50,35 Q34,37 23,50Z" fill="${H}"/>`,
      `<path d="M20,48 C22,32 30,26 38,32 C40,20 46,18 50,24 C54,18 60,20 62,32 C70,26 78,32 80,48 C74,38 66,38 62,38 C60,28 54,26 50,30 C46,26 40,28 38,38 C34,38 26,38 20,48Z" fill="${H}"/>`,
      '',
    ];

    const eyeParts = [
      `<circle cx="40" cy="52" r="3.5" fill="${E}"/><circle cx="60" cy="52" r="3.5" fill="${E}"/>`,
      `<ellipse cx="40" cy="52" rx="5.5" ry="3.8" fill="${E}"/><ellipse cx="60" cy="52" rx="5.5" ry="3.8" fill="${E}"/>`,
      `<circle cx="40" cy="52" r="5.5" fill="white"/><circle cx="40" cy="52" r="3.5" fill="${E}"/><circle cx="60" cy="52" r="5.5" fill="white"/><circle cx="60" cy="52" r="3.5" fill="${E}"/>`,
      `<path d="M36,52 Q40,48 44,52" stroke="${E}" stroke-width="2.8" fill="none" stroke-linecap="round"/><path d="M56,52 Q60,48 64,52" stroke="${E}" stroke-width="2.8" fill="none" stroke-linecap="round"/>`,
      `<path d="M36,52 Q40,49.5 44,52 Q40,55 36,52Z" fill="${E}"/><path d="M56,52 Q60,49.5 64,52 Q60,55 56,52Z" fill="${E}"/>`,
    ];

    const eyeShine = d.eyes < 3
      ? `<circle cx="42" cy="50.5" r="1.3" fill="white" opacity="0.9"/><circle cx="62" cy="50.5" r="1.3" fill="white" opacity="0.9"/>`
      : '';

    const browParts = [
      `<path d="M36,46.5 Q40,45 44,46.5" stroke="${DK}" stroke-width="1.8" fill="none" stroke-linecap="round"/><path d="M56,46.5 Q60,45 64,46.5" stroke="${DK}" stroke-width="1.8" fill="none" stroke-linecap="round"/>`,
      `<path d="M36,47 Q40,43 44,47" stroke="${DK}" stroke-width="1.8" fill="none" stroke-linecap="round"/><path d="M56,47 Q60,43 64,47" stroke="${DK}" stroke-width="1.8" fill="none" stroke-linecap="round"/>`,
      `<path d="M36,45 Q40,41.5 43.5,43.5" stroke="${DK}" stroke-width="1.8" fill="none" stroke-linecap="round"/><path d="M56.5,43.5 Q60,41.5 64,45" stroke="${DK}" stroke-width="1.8" fill="none" stroke-linecap="round"/>`,
      `<path d="M36.5,44.5 Q40,47 43.5,44.5" stroke="${DK}" stroke-width="1.8" fill="none" stroke-linecap="round"/><path d="M56.5,44.5 Q60,47 63.5,44.5" stroke="${DK}" stroke-width="1.8" fill="none" stroke-linecap="round"/>`,
      '',
    ];

    const noseParts = [
      '',
      `<circle cx="47.5" cy="62" r="1.8" fill="${DK}" opacity="0.38"/><circle cx="52.5" cy="62" r="1.8" fill="${DK}" opacity="0.38"/>`,
      `<path d="M50,57 L47,63 Q50,65 53,63 Z" fill="${DK}" opacity="0.24"/>`,
      `<circle cx="50" cy="61" r="2.2" fill="${DK}" opacity="0.22"/>`,
    ];

    const mouthParts = [
      `<path d="M42,68 Q50,75 58,68" stroke="${DK}" stroke-width="2" fill="none" stroke-linecap="round"/>`,
      `<path d="M40,67 Q50,78 60,67 Q50,75 40,67Z" fill="white" stroke="${DK}" stroke-width="1.5" stroke-linejoin="round"/>`,
      `<path d="M43,68 L57,68" stroke="${DK}" stroke-width="2" fill="none" stroke-linecap="round"/>`,
      `<path d="M43,68 Q49,73 55,67" stroke="${DK}" stroke-width="2" fill="none" stroke-linecap="round"/>`,
      `<ellipse cx="50" cy="70" rx="4.5" ry="4" fill="${DK}" opacity="0.6"/>`,
    ];

    const f  = faces[d.face%4];
    const ea = earParts[d.ears%4];
    const hb = hairBack[d.hair%5];
    const hf = hairFront[d.hair%5];
    const ey = eyeParts[d.eyes%5];
    const br = browParts[d.brows%5];
    const ns = noseParts[d.nose%4];
    const mo = mouthParts[d.mouth%5];

    return `<svg viewBox="0 0 100 100" width="${sz}" height="${sz}" style="border-radius:50%;display:block;flex-shrink:0" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="50" fill="${BG}"/>${ea}${hb}${f}${hf}${ey}${eyeShine}${br}${ns}${mo}</svg>`;
  }

  function renderAvatar(player, size) {
    size = size || 36;
    if (player && player.avatar_data) {
      let data = player.avatar_data;
      if (typeof data === 'string') { try { data = JSON.parse(data); } catch(e) { data = null; } }
      if (data) return avatarSvg(data, size);
    }
    const color = (player && player.avatar_color) || '#585b70';
    const letter = ((player && player.display_name && player.display_name[0]) || '?').toUpperCase();
    return `<svg viewBox="0 0 100 100" width="${size}" height="${size}" style="border-radius:50%;display:block;flex-shrink:0" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="50" fill="${color}"/><text x="50" y="67" font-family="system-ui,sans-serif" font-size="54" font-weight="700" fill="#1e1e2e" text-anchor="middle">${letter}</text></svg>`;
  }

  function showBuilder(currentData, avatarColor, onSave) {
    let d = Object.assign({}, DEFAULTS);
    if (avatarColor) d.bg = avatarColor;
    if (currentData) {
      try { Object.assign(d, typeof currentData === 'string' ? JSON.parse(currentData) : currentData); } catch(e) {}
    }

    const ov = document.createElement('div');
    ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);z-index:9999;display:flex;align-items:flex-start;justify-content:center;padding:16px;box-sizing:border-box;overflow-y:auto';

    const box = document.createElement('div');
    box.style.cssText = 'background:var(--surface1,#1e1e2e);border:1px solid var(--border,#45475a);border-radius:14px;width:100%;max-width:400px;padding:18px;display:flex;flex-direction:column;gap:13px;box-sizing:border-box;margin:auto';
    ov.appendChild(box);
    document.body.appendChild(ov);
    ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });

    function lbl(text) {
      return `<div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:var(--fg2,#a6adc8);margin-bottom:6px">${text}</div>`;
    }

    function colSwatches(cols, field) {
      return `<div style="display:flex;flex-wrap:wrap;gap:7px">${
        cols.map(c => `<div data-f="${field}" data-c="${c}" style="width:24px;height:24px;border-radius:50%;background:${c};cursor:pointer;outline:3px solid ${d[field]===c?'#fff':'transparent'};outline-offset:2px;flex-shrink:0"></div>`).join('')
      }</div>`;
    }

    function optBtns(count, field) {
      let html = `<div style="display:flex;flex-wrap:wrap;gap:6px">`;
      for (let i = 0; i < count; i++) {
        const sel = d[field] === i;
        html += `<div data-f="${field}" data-o="${i}" style="cursor:pointer;border-radius:8px;border:2px solid ${sel?'var(--accent,#6366f1)':'var(--border,#45475a)'};padding:2px;line-height:0;flex-shrink:0">${avatarSvg(Object.assign({},d,{[field]:i}),38)}</div>`;
      }
      return html + '</div>';
    }

    function rebuild() {
      box.innerHTML = `
        <div style="display:flex;align-items:center;gap:8px">
          <div style="font-weight:700;font-size:15px;flex:1">Customize Avatar</div>
          <button id="av-x" style="background:none;border:none;color:var(--fg,#cdd6f4);cursor:pointer;font-size:20px;line-height:1;padding:2px 8px">✕</button>
        </div>
        <div style="text-align:center;padding:4px 0">${avatarSvg(d, 96)}</div>
        <div>${lbl('Background')}${colSwatches(BG_COLS,'bg')}</div>
        <div>${lbl('Skin')     }${colSwatches(SKIN_COLS,'skin')}</div>
        <div>${lbl('Face')     }${optBtns(4,'face')}</div>
        <div>${lbl('Ears')     }${optBtns(4,'ears')}</div>
        <div>${lbl('Hair')     }${optBtns(5,'hair')}</div>
        <div>${lbl('Hair color')}${colSwatches(HAIR_COLS,'hc')}</div>
        <div>${lbl('Eyes')     }${optBtns(5,'eyes')}</div>
        <div>${lbl('Eye color')}${colSwatches(EYE_COLS,'ec')}</div>
        <div>${lbl('Eyebrows') }${optBtns(5,'brows')}</div>
        <div>${lbl('Nose')     }${optBtns(4,'nose')}</div>
        <div>${lbl('Mouth')    }${optBtns(5,'mouth')}</div>
        <button id="av-save" style="background:var(--accent,#6366f1);color:#fff;border:none;border-radius:8px;padding:12px;font-size:14px;font-weight:600;cursor:pointer;width:100%;margin-top:2px">Save Avatar</button>`;

      box.querySelector('#av-x').onclick    = () => ov.remove();
      box.querySelector('#av-save').onclick = () => { ov.remove(); onSave(JSON.stringify(d)); };

      box.querySelectorAll('[data-c]').forEach(el => {
        el.onclick = () => { d[el.dataset.f] = el.dataset.c; rebuild(); };
      });
      box.querySelectorAll('[data-o]').forEach(el => {
        el.onclick = () => { d[el.dataset.f] = parseInt(el.dataset.o); rebuild(); };
      });
    }

    rebuild();
  }

  window.GHAvatar = { avatarSvg, renderAvatar, showBuilder, DEFAULTS };
})();
