{
 "q0001": {
  "q": "In welchem Land liegt der Berg Fuji?",
  "a": [
   "Japan",
   "China",
   "Südkorea",
   "Thailand"
  ]
 },
 "q0002": {
  "q": "In welchem Land befinden sich die Inka-Ruinen von Machu Picchu?",
  "a": [
   "Peru",
   "Mexiko",
   "Bolivien",
   "Chile"
  ]
 },
 "q0003": {
  "q": "Welcher Fluss fließt durch Kairo in Ägypten?",
  "a": [
   "Nil",
   "Tigris",
   "Euphrat",
   "Jordan"
  ]
 },
 "q0004": {
  "q": "In welcher Stadt wurde der Komponist Wolfgang Amadeus Mozart im Jahr 1756 geboren?",
  "a": [
   "Salzburg",
   "Wien",
   "Prag",
   "München"
  ]
 },
 "q0005": {
  "q": "Auf welchem Kontinent liegt Brasilien?",
  "a": [
   "Südamerika",
   "Nordamerika",
   "Afrika",
   "Europa"
  ]
 },
 "q0006": {
  "q": "In welches Meer mündet die Donau?",
  "a": [
   "Schwarzes Meer",
   "Ostsee",
   "Adriatisches Meer",
   "Nordsee"
  ]
 },
 "q0007": {
  "q": "Welche Meerenge trennt die japanische Insel Hokkaidō von der russischen Insel Sachalin?",
  "a": [
   "La-Pérouse-Straße",
   "Tsugaru-Straße",
   "Tatarensund",
   "Koreastraße"
  ]
 },
 "q0008": {
  "q": "Auf welcher Insel der Kapverden liegt Cidade Velha, das früher Ribeira Grande hieß?",
  "a": [
   "Santiago",
   "São Vicente",
   "Santo Antão",
   "Fogo"
  ]
 },
 "q0009": {
  "q": "In welcher chilenischen Stadt wurde die Dichterin Gabriela Mistral 1889 geboren?",
  "a": [
   "Vicuña",
   "La Serena",
   "Temuco",
   "Chillán"
  ]
 },
 "q0010": {
  "q": "In welchem Land liegen die Seen, in denen der Axolotl heimisch ist?",
  "a": [
   "Mexiko",
   "Brasilien",
   "Peru",
   "Costa Rica"
  ]
 },
 "q0011": {
  "q": "Welches Land ist die ursprüngliche Heimat des Ginkgobaums?",
  "a": [
   "China",
   "Japan",
   "Indien",
   "Südkorea"
  ]
 },
 "q0012": {
  "q": "Was stoßen riffbildende Korallen bei einer hitzebedingten Korallenbleiche aus ihrem Gewebe aus?",
  "a": [
   "Symbiotische Algen",
   "Kalziumkarbonatkristalle",
   "Eizellen zur Fortpflanzung",
   "Nesselzellen"
  ]
 },
 "q0013": {
  "q": "Wer betrat 1969 als erster Mensch den Mond?",
  "a": [
   "Neil Armstrong",
   "Juri Gagarin",
   "Buzz Aldrin",
   "John Glenn"
  ]
 },
 "q0014": {
  "q": "In welchem Land ließen Herrscher der Antike die Pyramiden von Gizeh erbauen?",
  "a": [
   "Ägypten",
   "Griechenland",
   "Mexiko",
   "Irak"
  ]
 },
 "q0015": {
  "q": "Von welchem Land wurde Napoleon Bonaparte 1804 Kaiser?",
  "a": [
   "Frankreich",
   "Spanien",
   "Deutschland",
   "Russland"
  ]
 },
 "q0016": {
  "q": "Welcher japanische Begriff bezeichnet das Familienregister, in dem Geburten, Eheschließungen und Todesfälle erfasst werden?",
  "a": [
   "Koseki",
   "Juminhyo",
   "Hanko",
   "Nenkin"
  ]
 },
 "q0017": {
  "q": "Welcher Begriff bezeichnet die traditionelle gemeinschaftliche Arbeit, die in indigenen Gemeinden in Oaxaca, Mexiko, zum Wohl der Allgemeinheit geleistet wird?",
  "a": [
   "Tequio",
   "Ejido",
   "Cabildo",
   "Mayordomia"
  ]
 },
 "q0018": {
  "q": "Welcher Begriff bezeichnet bei den Akan in Ghana einen Clan, dessen Zugehörigkeit über die Mutter vererbt wird?",
  "a": [
   "Abusua",
   "Ntoro",
   "Asafo",
   "Oman"
  ]
 },
 "q0019": {
  "q": "Welches antike Königreich wurde vom Pharao Tutanchamun regiert?",
  "a": [
   "Ägypten",
   "Persien",
   "Babylonien",
   "Makedonien"
  ]
 },
 "q0020": {
  "q": "Wie wurden die Angehörigen der erblichen Kriegerklasse Japans genannt?",
  "a": [
   "Samurai",
   "Mandarine",
   "Janitscharen",
   "Kosaken"
  ]
 },
 "q0021": {
  "q": "Von welchem europäischen Land erklärte Brasilien 1822 seine Unabhängigkeit?",
  "a": [
   "Portugal",
   "Spanien",
   "Frankreich",
   "Großbritannien"
  ]
 },
 "q0022": {
  "q": "Welcher Aufstand begann 1838 in der brasilianischen Provinz Maranhão, nachdem eine bewaffnete Gruppe das Gefängnis in Vila da Manga angegriffen hatte?",
  "a": [
   "Balaiada",
   "Cabanagem",
   "Sabinada",
   "Praieira-Aufstand"
  ]
 },
 "q0023": {
  "q": "Welcher japanische Shōgun lockerte 1720 das Bücherverbot, um die Einfuhr von Büchern zu weltlichen Themen zu erlauben?",
  "a": [
   "Tokugawa Yoshimune",
   "Tokugawa Tsunayoshi",
   "Tokugawa Ienobu",
   "Tokugawa Ieshige"
  ]
 },
 "q0024": {
  "q": "Welche Sprache wurde für die meisten Inschriften auf den Goldmünzen des antiken Aksum im Gebiet von Äthiopien und Eritrea verwendet?",
  "a": [
   "Griechisch",
   "Latein",
   "Geʽez",
   "Sabäisch"
  ]
 },
 "q0025": {
  "q": "Welcher japanische Künstler schuf den Holzschnitt „Die große Welle vor Kanagawa“?",
  "a": [
   "Katsushika Hokusai",
   "Utagawa Hiroshige",
   "Kitagawa Utamaro",
   "Ogata Kōrin"
  ]
 },
 "q0026": {
  "q": "Für das Spielen welches Instruments war der indische Musiker Ravi Shankar am bekanntesten?",
  "a": [
   "Sitar",
   "Tabla",
   "Sarod",
   "Bansuri"
  ]
 },
 "q0027": {
  "q": "Welcher Architekt baute die Casa Batlló in Barcelona zwischen 1904 und 1906 um?",
  "a": [
   "Antoni Gaudí",
   "Lluís Domènech i Montaner",
   "Josep Puig i Cadafalch",
   "Santiago Calatrava"
  ]
 },
 "q0028": {
  "q": "Auf welcher kanadischen Insel befinden sich die Überreste der nordischen Siedlung in L'Anse aux Meadows?",
  "a": [
   "Neufundland",
   "Baffininsel",
   "Prinz-Edward-Insel",
   "Kap-Breton-Insel"
  ]
 },
 "q0029": {
  "q": "In welchem Gebirge Bulgariens liegt der Gipfel Musala?",
  "a": [
   "Rila",
   "Pirin",
   "Rhodopen",
   "Balkangebirge"
  ]
 },
 "q0030": {
  "q": "In welchem chilenischen Tal liegt Vicuña, der Geburtsort der Dichterin Gabriela Mistral?",
  "a": [
   "Elqui-Tal",
   "Limarí-Tal",
   "Maipo-Tal",
   "Aconcagua-Tal"
  ]
 },
 "q0031": {
  "q": "Welche Tiere verwendete der russische Physiologe Iwan Pawlow in seinen berühmten Untersuchungen zum konditionierten Speichelfluss?",
  "a": [
   "Hunde",
   "Katzen",
   "Kaninchen",
   "Affen"
  ]
 },
 "q0032": {
  "q": "Welches Phänomen untersuchte der indische Physiker C. V. Raman in der Arbeit, für die er 1930 den Nobelpreis für Physik erhielt?",
  "a": [
   "Lichtstreuung",
   "Radioaktiver Zerfall",
   "Kernspaltung",
   "Supraleitung"
  ]
 },
 "q0033": {
  "q": "Welche Hauptschicht des Erdinneren besteht aus flüssigem Metall?",
  "a": [
   "Äußerer Erdkern",
   "Innerer Erdkern",
   "Erdmantel",
   "Erdkruste"
  ]
 },
 "q0034": {
  "q": "Welche in Polen geborene Wissenschaftlerin erhielt 1903 gemeinsam mit anderen den Nobelpreis für Physik für die Erforschung der Radioaktivität?",
  "a": [
   "Marie Curie",
   "Albert Einstein",
   "Isaac Newton",
   "Charles Darwin"
  ]
 },
 "q0035": {
  "q": "Welches Organ pumpt Blut durch den menschlichen Körper?",
  "a": [
   "Herz",
   "Leber",
   "Lunge",
   "Niere"
  ]
 },
 "q0036": {
  "q": "Welcher Planet ist der sechste von der Sonne aus?",
  "a": [
   "Saturn",
   "Jupiter",
   "Uranus",
   "Neptun"
  ]
 },
 "q0037": {
  "q": "Welche Wüste in Namibia und Angola ist die natürliche Heimat von Welwitschia mirabilis, einer Pflanze mit 2 kontinuierlich wachsenden Blättern?",
  "a": [
   "Namib",
   "Kalahari",
   "Danakil",
   "Sahara"
  ]
 },
 "q0038": {
  "q": "Das massenhafte Fruchten welches Baumes trägt dazu bei, bei Kakapos im Süden Neuseelands die Fortpflanzung auszulösen?",
  "a": [
   "Rimu",
   "Kauri",
   "Tōtara",
   "Pōhutukawa"
  ]
 },
 "q0039": {
  "q": "Welcher in Wien geborene Wissenschaftler entschlüsselte, wie Honigbienen durch Tänze die Lage von Futterquellen mitteilen?",
  "a": [
   "Karl von Frisch",
   "Konrad Lorenz",
   "Nikolaas Tinbergen",
   "Iwan Pawlow"
  ]
 },
 "q0040": {
  "q": "Wer wurde Ghanas erster Premierminister, als das Land 1957 die Unabhängigkeit erlangte?",
  "a": [
   "Kwame Nkrumah",
   "Julius Nyerere",
   "Jomo Kenyatta",
   "Patrice Lumumba"
  ]
 },
 "q0041": {
  "q": "In welcher deutschen Stadt druckte Johannes Gutenberg um 1455 seine Bibel?",
  "a": [
   "Mainz",
   "Nürnberg",
   "Augsburg",
   "Köln"
  ]
 },
 "q0042": {
  "q": "Welcher Inka-Herrscher wurde 1532 von Francisco Pizarros Truppen in Cajamarca gefangen genommen?",
  "a": [
   "Atahualpa",
   "Huayna Cápac",
   "Pachacútec",
   "Túpac Inca Yupanqui"
  ]
 },
 "q0043": {
  "q": "Welche 2 japanischen Instrumente sind die Soloinstrumente in Tōru Takemitsus Orchesterwerk November Steps von 1967?",
  "a": [
   "Biwa und Shakuhachi",
   "Koto und Shō",
   "Shamisen und Taiko",
   "Hichiriki und Tsuzumi"
  ]
 },
 "q0044": {
  "q": "Welcher brasilianische Bildhauer schuf die 12 Propheten aus Speckstein am Heiligtum Bom Jesus in Congonhas?",
  "a": [
   "Aleijadinho",
   "Mestre Valentim",
   "Victor Brecheret",
   "Bruno Giorgi"
  ]
 },
 "q0045": {
  "q": "Welcher Architekt entwarf die Wallfahrtskirche des heiligen Johannes von Nepomuk auf dem Zelená Hora in Tschechien mit einem Grundriss in Form eines 5-zackigen Sterns?",
  "a": [
   "Jan Blažej Santini-Aichel",
   "Johann Bernhard Fischer von Erlach",
   "Kilian Ignaz Dientzenhofer",
   "Johann Lucas von Hildebrandt"
  ]
 },
 "q0046": {
  "q": "Welches Plateau in Indien liegt zwischen den Westghats und den Ostghats?",
  "a": [
   "Dekkan-Plateau",
   "Malwa-Plateau",
   "Chota-Nagpur-Plateau",
   "Shillong-Plateau"
  ]
 },
 "q0047": {
  "q": "In welchem Land liegt die Altstadt von Lamu, eine historische Handelsniederlassung der Swahili, die aus Korallenstein und Mangrovenholz erbaut wurde?",
  "a": [
   "Kenia",
   "Tansania",
   "Mosambik",
   "Somalia"
  ]
 },
 "q0048": {
  "q": "In welcher deutschen Stadt wurde der Schriftsteller Hermann Hesse 1877 geboren?",
  "a": [
   "Calw",
   "Tübingen",
   "Marbach am Neckar",
   "Weimar"
  ]
 },
 "q0049": {
  "q": "Welcher humanitär engagierte Schweizer schrieb das Buch „Eine Erinnerung an Solferino“, das zur Gründung des Roten Kreuzes anregte?",
  "a": [
   "Henry Dunant",
   "Gustave Moynier",
   "Albert Schweitzer",
   "Frédéric Passy"
  ]
 },
 "q0050": {
  "q": "Wie heißt das traditionelle genossenschaftliche Bewässerungssystem auf Bali in Indonesien, das um Wassertempel herum organisiert ist?",
  "a": [
   "Subak",
   "Banjar",
   "Adat",
   "Gotong royong"
  ]
 },
 "q0051": {
  "q": "Wie heißt das koreanische Ritual zum ersten Geburtstag, bei dem ein Kind einen Gegenstand auswählt, der seine Zukunft vorhersagen soll?",
  "a": [
   "Doljabi",
   "Baekil",
   "Pyebaek",
   "Jesa"
  ]
 },
 "q0052": {
  "q": "In welchem Land wurde der Märchenschriftsteller Hans Christian Andersen geboren?",
  "a": [
   "Dänemark",
   "Schweden",
   "Norwegen",
   "Deutschland"
  ]
 },
 "q0053": {
  "q": "Wie heißt der Junge, der in Rudyard Kiplings „Das Dschungelbuch“ von Wölfen im indischen Dschungel aufgezogen wird?",
  "a": [
   "Mogli",
   "Tarzan",
   "Peter Pan",
   "Pinocchio"
  ]
 },
 "q0054": {
  "q": "Welcher spanische Schriftsteller schuf Don Quijote?",
  "a": [
   "Miguel de Cervantes",
   "Federico García Lorca",
   "Gabriel García Márquez",
   "Pablo Neruda"
  ]
 },
 "q0055": {
  "q": "Welche Stadt in Angola diente als politische und geistliche Hauptstadt des Königreichs Kongo?",
  "a": [
   "Mbanza Kongo",
   "Luanda",
   "Benguela",
   "Cabinda"
  ]
 },
 "q0056": {
  "q": "Welcher koreanische König schuf 1443 das Hangul-Alphabet?",
  "a": [
   "Sejong",
   "Taejo",
   "Jeongjo",
   "Gojong"
  ]
 },
 "q0057": {
  "q": "Welcher mexikanische Hafen war der amerikanische Endpunkt des Handels mit den Manila-Galeonen, der von 1565 bis 1815 betrieben wurde?",
  "a": [
   "Acapulco",
   "Veracruz",
   "Mazatlán",
   "Campeche"
  ]
 },
 "q0058": {
  "q": "Wie viele Jahre übt im traditionellen Gada-System der Oromo in Äthiopien jede herrschende Altersklasse die Macht aus, bevor die nächste sie übernimmt?",
  "a": [
   "8",
   "6",
   "10",
   "12"
  ]
 },
 "q0059": {
  "q": "Welche brasilianische Verfechterin der Frauenbildung veröffentlichte 1832 Direitos das Mulheres e Injustiça dos Homens?",
  "a": [
   "Nísia Floresta",
   "Júlia Lopes de Almeida",
   "Josefina Álvares de Azevedo",
   "Francisca Senhorinha da Motta Diniz"
  ]
 },
 "q0060": {
  "q": "Wie heißt das heilige weiße Unterhemd der Parsen in Indien, das bei der Navjote-Initiationszeremonie zum ersten Mal angelegt wird?",
  "a": [
   "Sudreh",
   "Kameez",
   "Angarkha",
   "Jama"
  ]
 },
 "q0061": {
  "q": "Welche deutsche Erfinderin entwickelte 1908 in Dresden einen Kaffeefilter aus Papier?",
  "a": [
   "Melitta Bentz",
   "Josephine Cochrane",
   "Mary Anderson",
   "Maria Telkes"
  ]
 },
 "q0062": {
  "q": "Welches Öl wird traditionell mit Olivenöl kombiniert, um Aleppo-Seife in Syrien herzustellen?",
  "a": [
   "Lorbeeröl",
   "Sesamöl",
   "Mandelöl",
   "Rizinusöl"
  ]
 },
 "q0063": {
  "q": "Wie lautet die traditionelle koreanische Bezeichnung für ein Tuch, das zum Verpacken von Geschenken und zum Tragen von Haushaltsgegenständen verwendet wird?",
  "a": [
   "Bojagi",
   "Furoshiki",
   "Khata",
   "Futa"
  ]
 },
 "q0064": {
  "q": "Welche japanische Hofschriftstellerin verfasste die Essaysammlung Das Kopfkissenbuch?",
  "a": [
   "Sei Shōnagon",
   "Murasaki Shikibu",
   "Izumi Shikibu",
   "Ono no Komachi"
  ]
 },
 "q0065": {
  "q": "Welche Stadt besucht Juan Preciado in Juan Rulfos mexikanischem Roman Pedro Páramo auf der Suche nach seinem Vater?",
  "a": [
   "Comala",
   "Macondo",
   "Santa María",
   "Yoknapatawpha"
  ]
 },
 "q0066": {
  "q": "Welcher bulgarische Autor schrieb den Roman Unter dem Joch?",
  "a": [
   "Iwan Wasow",
   "Aleko Konstantinow",
   "Elin Pelin",
   "Jordan Jowkow"
  ]
 },
 "q0067": {
  "q": "Welches Getreide bildet die Grundlage von traditionellem japanischem Sushi?",
  "a": [
   "Reis",
   "Weizen",
   "Gerste",
   "Mais"
  ]
 },
 "q0068": {
  "q": "Was bedeutet die französische Begrüßung „bonjour“?",
  "a": [
   "Guten Tag",
   "Auf Wiedersehen",
   "Danke",
   "Bitte"
  ]
 },
 "q0069": {
  "q": "Welches Haushaltsgerät ist dafür ausgelegt, Lebensmittel gefroren zu halten?",
  "a": [
   "Gefrierschrank",
   "Backofen",
   "Geschirrspüler",
   "Toaster"
  ]
 },
 "q0070": {
  "q": "Welcher See in den Anden liegt an der Grenze zwischen Peru und Bolivien?",
  "a": [
   "Titicacasee",
   "Maracaibo-See",
   "Chapalasee",
   "Nicaraguasee"
  ]
 },
 "q0071": {
  "q": "Welche japanische Stadt wurde im Jahr 794 unter dem Namen Heian-kyō zur kaiserlichen Hauptstadt?",
  "a": [
   "Kyoto",
   "Osaka",
   "Nara",
   "Kamakura"
  ]
 },
 "q0072": {
  "q": "In welchem Land liegt Żelazowa Wola, der Geburtsort des Komponisten Frédéric Chopin?",
  "a": [
   "Polen",
   "Frankreich",
   "Österreich",
   "Ungarn"
  ]
 },
 "q0073": {
  "q": "Welcher Planet hat die Nummer 1, von der Sonne aus gezählt?",
  "a": [
   "Merkur",
   "Mars",
   "Erde",
   "Jupiter"
  ]
 },
 "q0074": {
  "q": "Welche Nummer hat Merkur, von der Sonne aus gezählt?",
  "a": [
   "1",
   "7",
   "2",
   "8"
  ]
 },
 "q0075": {
  "q": "Welcher Planet hat die Nummer 2, von der Sonne aus gezählt?",
  "a": [
   "Venus",
   "Neptun",
   "Saturn",
   "Merkur"
  ]
 },
 "q0076": {
  "q": "Welche Nummer hat Venus, von der Sonne aus gezählt?",
  "a": [
   "2",
   "4",
   "6",
   "1"
  ]
 },
 "q0077": {
  "q": "Welcher Planet hat die Nummer 3, von der Sonne aus gezählt?",
  "a": [
   "Erde",
   "Saturn",
   "Venus",
   "Merkur"
  ]
 },
 "q0078": {
  "q": "Welche Nummer hat Erde, von der Sonne aus gezählt?",
  "a": [
   "3",
   "1",
   "5",
   "7"
  ]
 },
 "q0079": {
  "q": "Welcher Planet hat die Nummer 4, von der Sonne aus gezählt?",
  "a": [
   "Mars",
   "Merkur",
   "Venus",
   "Neptun"
  ]
 },
 "q0080": {
  "q": "Welche Nummer hat Mars, von der Sonne aus gezählt?",
  "a": [
   "4",
   "6",
   "5",
   "1"
  ]
 },
 "q0081": {
  "q": "Welcher Planet hat die Nummer 5, von der Sonne aus gezählt?",
  "a": [
   "Jupiter",
   "Neptun",
   "Saturn",
   "Merkur"
  ]
 },
 "q0082": {
  "q": "Welche Nummer hat Jupiter, von der Sonne aus gezählt?",
  "a": [
   "5",
   "2",
   "7",
   "6"
  ]
 },
 "q0083": {
  "q": "Welcher Planet hat die Nummer 6, von der Sonne aus gezählt?",
  "a": [
   "Saturn",
   "Merkur",
   "Jupiter",
   "Uranus"
  ]
 },
 "q0084": {
  "q": "Welche Nummer hat Saturn, von der Sonne aus gezählt?",
  "a": [
   "6",
   "4",
   "1",
   "2"
  ]
 },
 "q0085": {
  "q": "Welcher Planet hat die Nummer 7, von der Sonne aus gezählt?",
  "a": [
   "Uranus",
   "Merkur",
   "Jupiter",
   "Venus"
  ]
 },
 "q0086": {
  "q": "Welche Nummer hat Uranus, von der Sonne aus gezählt?",
  "a": [
   "7",
   "3",
   "4",
   "2"
  ]
 },
 "q0087": {
  "q": "Welcher Planet hat die Nummer 8, von der Sonne aus gezählt?",
  "a": [
   "Neptun",
   "Jupiter",
   "Merkur",
   "Uranus"
  ]
 },
 "q0088": {
  "q": "Welche Nummer hat Neptun, von der Sonne aus gezählt?",
  "a": [
   "8",
   "3",
   "5",
   "2"
  ]
 },
 "q0089": {
  "q": "Welcher Monat ist der 1. des Jahres?",
  "a": [
   "Januar",
   "März",
   "November",
   "Mai"
  ]
 },
 "q0090": {
  "q": "Der wievielte Monat des Jahres ist Januar?",
  "a": [
   "1",
   "7",
   "3",
   "10"
  ]
 },
 "q0091": {
  "q": "Welcher Monat ist der 2. des Jahres?",
  "a": [
   "Februar",
   "März",
   "November",
   "Januar"
  ]
 },
 "q0092": {
  "q": "Der wievielte Monat des Jahres ist Februar?",
  "a": [
   "2",
   "11",
   "5",
   "9"
  ]
 },
 "q0093": {
  "q": "Welcher Monat ist der 3. des Jahres?",
  "a": [
   "März",
   "Dezember",
   "Oktober",
   "August"
  ]
 },
 "q0094": {
  "q": "Der wievielte Monat des Jahres ist März?",
  "a": [
   "3",
   "7",
   "9",
   "11"
  ]
 },
 "q0095": {
  "q": "Welcher Monat ist der 4. des Jahres?",
  "a": [
   "April",
   "Juli",
   "Juni",
   "Mai"
  ]
 },
 "q0096": {
  "q": "Der wievielte Monat des Jahres ist April?",
  "a": [
   "4",
   "3",
   "5",
   "2"
  ]
 },
 "q0097": {
  "q": "Welcher Monat ist der 5. des Jahres?",
  "a": [
   "Mai",
   "November",
   "Juni",
   "Oktober"
  ]
 },
 "q0098": {
  "q": "Der wievielte Monat des Jahres ist Mai?",
  "a": [
   "5",
   "9",
   "7",
   "12"
  ]
 },
 "q0099": {
  "q": "Welcher Monat ist der 6. des Jahres?",
  "a": [
   "Juni",
   "Mai",
   "November",
   "Februar"
  ]
 },
 "q0100": {
  "q": "Der wievielte Monat des Jahres ist Juni?",
  "a": [
   "6",
   "2",
   "10",
   "8"
  ]
 },
 "q0101": {
  "q": "Welcher Monat ist der 7. des Jahres?",
  "a": [
   "Juli",
   "März",
   "Juni",
   "Dezember"
  ]
 },
 "q0102": {
  "q": "Der wievielte Monat des Jahres ist Juli?",
  "a": [
   "7",
   "9",
   "8",
   "1"
  ]
 },
 "q0103": {
  "q": "Welcher Monat ist der 8. des Jahres?",
  "a": [
   "August",
   "Dezember",
   "Februar",
   "Oktober"
  ]
 },
 "q0104": {
  "q": "Der wievielte Monat des Jahres ist August?",
  "a": [
   "8",
   "11",
   "6",
   "12"
  ]
 },
 "q0105": {
  "q": "Welcher Monat ist der 9. des Jahres?",
  "a": [
   "September",
   "Juni",
   "November",
   "August"
  ]
 },
 "q0106": {
  "q": "Der wievielte Monat des Jahres ist September?",
  "a": [
   "9",
   "11",
   "8",
   "2"
  ]
 },
 "q0107": {
  "q": "Welcher Monat ist der 10. des Jahres?",
  "a": [
   "Oktober",
   "Februar",
   "Mai",
   "August"
  ]
 },
 "q0108": {
  "q": "Der wievielte Monat des Jahres ist Oktober?",
  "a": [
   "10",
   "12",
   "2",
   "1"
  ]
 },
 "q0109": {
  "q": "Welcher Monat ist der 11. des Jahres?",
  "a": [
   "November",
   "Mai",
   "Oktober",
   "August"
  ]
 },
 "q0110": {
  "q": "Der wievielte Monat des Jahres ist November?",
  "a": [
   "11",
   "5",
   "7",
   "6"
  ]
 },
 "q0111": {
  "q": "Welcher Monat ist der 12. des Jahres?",
  "a": [
   "Dezember",
   "Januar",
   "August",
   "Juni"
  ]
 },
 "q0112": {
  "q": "Der wievielte Monat des Jahres ist Dezember?",
  "a": [
   "12",
   "3",
   "10",
   "2"
  ]
 },
 "q0113": {
  "q": "Wenn man die Woche mit Montag als Tag 1 zählt, welcher Tag hat die Nummer 1?",
  "a": [
   "Montag",
   "Freitag",
   "Dienstag",
   "Mittwoch"
  ]
 },
 "q0114": {
  "q": "Wenn man die Woche mit Montag als Tag 1 zählt, welcher Tag hat die Nummer 2?",
  "a": [
   "Dienstag",
   "Donnerstag",
   "Mittwoch",
   "Samstag"
  ]
 },
 "q0115": {
  "q": "Wenn man die Woche mit Montag als Tag 1 zählt, welcher Tag hat die Nummer 3?",
  "a": [
   "Mittwoch",
   "Freitag",
   "Sonntag",
   "Samstag"
  ]
 },
 "q0116": {
  "q": "Wenn man die Woche mit Montag als Tag 1 zählt, welcher Tag hat die Nummer 4?",
  "a": [
   "Donnerstag",
   "Montag",
   "Dienstag",
   "Freitag"
  ]
 },
 "q0117": {
  "q": "Wenn man die Woche mit Montag als Tag 1 zählt, welcher Tag hat die Nummer 5?",
  "a": [
   "Freitag",
   "Donnerstag",
   "Samstag",
   "Mittwoch"
  ]
 },
 "q0118": {
  "q": "Wenn man die Woche mit Montag als Tag 1 zählt, welcher Tag hat die Nummer 6?",
  "a": [
   "Samstag",
   "Dienstag",
   "Donnerstag",
   "Mittwoch"
  ]
 },
 "q0119": {
  "q": "Wenn man die Woche mit Montag als Tag 1 zählt, welcher Tag hat die Nummer 7?",
  "a": [
   "Sonntag",
   "Samstag",
   "Donnerstag",
   "Mittwoch"
  ]
 },
 "q0120": {
  "q": "Wie viele Seiten hat ein Dreieck?",
  "a": [
   "3",
   "10",
   "5",
   "12"
  ]
 },
 "q0121": {
  "q": "Welche Figur hat genau 3 Seiten?",
  "a": [
   "Dreieck",
   "Fünfeck",
   "Zwölfeck",
   "Zehneck"
  ]
 },
 "q0122": {
  "q": "Wie viele Seiten hat ein Viereck?",
  "a": [
   "4",
   "7",
   "9",
   "5"
  ]
 },
 "q0123": {
  "q": "Welche Figur hat genau 4 Seiten?",
  "a": [
   "Viereck",
   "Dreieck",
   "Siebeneck",
   "Achteck"
  ]
 },
 "q0124": {
  "q": "Wie viele Seiten hat ein Fünfeck?",
  "a": [
   "5",
   "6",
   "12",
   "10"
  ]
 },
 "q0125": {
  "q": "Welche Figur hat genau 5 Seiten?",
  "a": [
   "Fünfeck",
   "Dreieck",
   "Viereck",
   "Siebeneck"
  ]
 },
 "q0126": {
  "q": "Wie viele Seiten hat ein Sechseck?",
  "a": [
   "6",
   "9",
   "8",
   "10"
  ]
 },
 "q0127": {
  "q": "Welche Figur hat genau 6 Seiten?",
  "a": [
   "Sechseck",
   "Neuneck",
   "Viereck",
   "Zwölfeck"
  ]
 },
 "q0128": {
  "q": "Wie viele Seiten hat ein Siebeneck?",
  "a": [
   "7",
   "3",
   "6",
   "9"
  ]
 },
 "q0129": {
  "q": "Welche Figur hat genau 7 Seiten?",
  "a": [
   "Siebeneck",
   "Zehneck",
   "Sechseck",
   "Zwölfeck"
  ]
 },
 "q0130": {
  "q": "Wie viele Seiten hat ein Achteck?",
  "a": [
   "8",
   "10",
   "3",
   "6"
  ]
 },
 "q0131": {
  "q": "Welche Figur hat genau 8 Seiten?",
  "a": [
   "Achteck",
   "Zehneck",
   "Dreieck",
   "Viereck"
  ]
 },
 "q0132": {
  "q": "Wie viele Seiten hat ein Neuneck?",
  "a": [
   "9",
   "4",
   "12",
   "6"
  ]
 },
 "q0133": {
  "q": "Welche Figur hat genau 9 Seiten?",
  "a": [
   "Neuneck",
   "Fünfeck",
   "Dreieck",
   "Zwölfeck"
  ]
 },
 "q0134": {
  "q": "Wie viele Seiten hat ein Zehneck?",
  "a": [
   "10",
   "3",
   "12",
   "9"
  ]
 },
 "q0135": {
  "q": "Welche Figur hat genau 10 Seiten?",
  "a": [
   "Zehneck",
   "Fünfeck",
   "Siebeneck",
   "Dreieck"
  ]
 },
 "q0136": {
  "q": "Wie viele Seiten hat ein Zwölfeck?",
  "a": [
   "12",
   "8",
   "7",
   "3"
  ]
 },
 "q0137": {
  "q": "Welche Figur hat genau 12 Seiten?",
  "a": [
   "Zwölfeck",
   "Viereck",
   "Neuneck",
   "Zehneck"
  ]
 },
 "q0138": {
  "q": "Für welche Zahl steht die römische Zahl IV?",
  "a": [
   "4",
   "14",
   "10",
   "5"
  ]
 },
 "q0139": {
  "q": "Für welche Zahl steht die römische Zahl VI?",
  "a": [
   "6",
   "12",
   "7",
   "106"
  ]
 },
 "q0140": {
  "q": "Für welche Zahl steht die römische Zahl IX?",
  "a": [
   "9",
   "19",
   "13",
   "5"
  ]
 },
 "q0141": {
  "q": "Für welche Zahl steht die römische Zahl XII?",
  "a": [
   "12",
   "8",
   "32",
   "13"
  ]
 },
 "q0142": {
  "q": "Für welche Zahl steht die römische Zahl XIV?",
  "a": [
   "14",
   "34",
   "114",
   "13"
  ]
 },
 "q0143": {
  "q": "Für welche Zahl steht die römische Zahl XIX?",
  "a": [
   "19",
   "15",
   "18",
   "9"
  ]
 },
 "q0144": {
  "q": "Für welche Zahl steht die römische Zahl XL?",
  "a": [
   "40",
   "44",
   "41",
   "50"
  ]
 },
 "q0145": {
  "q": "Für welche Zahl steht die römische Zahl XLIV?",
  "a": [
   "44",
   "40",
   "64",
   "24"
  ]
 },
 "q0146": {
  "q": "Für welche Zahl steht die römische Zahl LXX?",
  "a": [
   "70",
   "69",
   "90",
   "74"
  ]
 },
 "q0147": {
  "q": "Für welche Zahl steht die römische Zahl XC?",
  "a": [
   "90",
   "86",
   "110",
   "70"
  ]
 },
 "q0148": {
  "q": "Für welche Zahl steht die römische Zahl CD?",
  "a": [
   "400",
   "410",
   "399",
   "380"
  ]
 },
 "q0149": {
  "q": "Für welche Zahl steht die römische Zahl CM?",
  "a": [
   "900",
   "899",
   "910",
   "901"
  ]
 },
 "q0150": {
  "q": "Für welche Zahl steht die römische Zahl MCM?",
  "a": [
   "1900",
   "1890",
   "1901",
   "1896"
  ]
 },
 "q0151": {
  "q": "Für welche Zahl steht die römische Zahl MMXX?",
  "a": [
   "2020",
   "2030",
   "2120",
   "2040"
  ]
 },
 "q0152": {
  "q": "Für welche Zahl steht die römische Zahl DCCC?",
  "a": [
   "800",
   "801",
   "796",
   "820"
  ]
 },
 "q0153": {
  "q": "Wie lautet das chemische Symbol von Wasserstoff?",
  "a": [
   "H",
   "Hg",
   "O",
   "Ca"
  ]
 },
 "q0154": {
  "q": "Welches Element hat das chemische Symbol H?",
  "a": [
   "Wasserstoff",
   "Gold",
   "Quecksilber",
   "Sauerstoff"
  ]
 },
 "q0155": {
  "q": "Wie lautet das chemische Symbol von Helium?",
  "a": [
   "He",
   "O",
   "Fe",
   "Cl"
  ]
 },
 "q0156": {
  "q": "Welches Element hat das chemische Symbol He?",
  "a": [
   "Helium",
   "Kalium",
   "Gold",
   "Wasserstoff"
  ]
 },
 "q0157": {
  "q": "Wie lautet das chemische Symbol von Kohlenstoff?",
  "a": [
   "C",
   "H",
   "Hg",
   "Na"
  ]
 },
 "q0158": {
  "q": "Welches Element hat das chemische Symbol C?",
  "a": [
   "Kohlenstoff",
   "Chlor",
   "Natrium",
   "Sauerstoff"
  ]
 },
 "q0159": {
  "q": "Wie lautet das chemische Symbol von Stickstoff?",
  "a": [
   "N",
   "Au",
   "Cu",
   "K"
  ]
 },
 "q0160": {
  "q": "Welches Element hat das chemische Symbol N?",
  "a": [
   "Stickstoff",
   "Chlor",
   "Quecksilber",
   "Gold"
  ]
 },
 "q0161": {
  "q": "Wie lautet das chemische Symbol von Sauerstoff?",
  "a": [
   "O",
   "K",
   "Sn",
   "He"
  ]
 },
 "q0162": {
  "q": "Welches Element hat das chemische Symbol O?",
  "a": [
   "Sauerstoff",
   "Stickstoff",
   "Helium",
   "Zinn"
  ]
 },
 "q0163": {
  "q": "Wie lautet das chemische Symbol von Natrium?",
  "a": [
   "Na",
   "Cl",
   "N",
   "K"
  ]
 },
 "q0164": {
  "q": "Welches Element hat das chemische Symbol Na?",
  "a": [
   "Natrium",
   "Stickstoff",
   "Chlor",
   "Kupfer"
  ]
 },
 "q0165": {
  "q": "Wie lautet das chemische Symbol von Kalium?",
  "a": [
   "K",
   "Sn",
   "Cu",
   "H"
  ]
 },
 "q0166": {
  "q": "Welches Element hat das chemische Symbol K?",
  "a": [
   "Kalium",
   "Chlor",
   "Silber",
   "Natrium"
  ]
 },
 "q0167": {
  "q": "Wie lautet das chemische Symbol von Calcium?",
  "a": [
   "Ca",
   "Hg",
   "Ag",
   "He"
  ]
 },
 "q0168": {
  "q": "Welches Element hat das chemische Symbol Ca?",
  "a": [
   "Calcium",
   "Blei",
   "Silber",
   "Helium"
  ]
 },
 "q0169": {
  "q": "Wie lautet das chemische Symbol von Chlor?",
  "a": [
   "Cl",
   "Sn",
   "K",
   "Hg"
  ]
 },
 "q0170": {
  "q": "Welches Element hat das chemische Symbol Cl?",
  "a": [
   "Chlor",
   "Gold",
   "Quecksilber",
   "Stickstoff"
  ]
 },
 "q0171": {
  "q": "Wie lautet das chemische Symbol von Eisen?",
  "a": [
   "Fe",
   "Ca",
   "C",
   "K"
  ]
 },
 "q0172": {
  "q": "Welches Element hat das chemische Symbol Fe?",
  "a": [
   "Eisen",
   "Quecksilber",
   "Silber",
   "Natrium"
  ]
 },
 "q0173": {
  "q": "Wie lautet das chemische Symbol von Kupfer?",
  "a": [
   "Cu",
   "He",
   "Hg",
   "Au"
  ]
 },
 "q0174": {
  "q": "Welches Element hat das chemische Symbol Cu?",
  "a": [
   "Kupfer",
   "Kalium",
   "Calcium",
   "Zinn"
  ]
 },
 "q0175": {
  "q": "Wie lautet das chemische Symbol von Silber?",
  "a": [
   "Ag",
   "Au",
   "He",
   "Sn"
  ]
 },
 "q0176": {
  "q": "Welches Element hat das chemische Symbol Ag?",
  "a": [
   "Silber",
   "Kohlenstoff",
   "Zinn",
   "Blei"
  ]
 },
 "q0177": {
  "q": "Wie lautet das chemische Symbol von Gold?",
  "a": [
   "Au",
   "H",
   "C",
   "Fe"
  ]
 },
 "q0178": {
  "q": "Welches Element hat das chemische Symbol Au?",
  "a": [
   "Gold",
   "Zinn",
   "Calcium",
   "Quecksilber"
  ]
 },
 "q0179": {
  "q": "Wie lautet das chemische Symbol von Quecksilber?",
  "a": [
   "Hg",
   "Cu",
   "C",
   "Fe"
  ]
 },
 "q0180": {
  "q": "Welches Element hat das chemische Symbol Hg?",
  "a": [
   "Quecksilber",
   "Blei",
   "Eisen",
   "Calcium"
  ]
 },
 "q0181": {
  "q": "Wie lautet das chemische Symbol von Blei?",
  "a": [
   "Pb",
   "Cu",
   "Na",
   "C"
  ]
 },
 "q0182": {
  "q": "Welches Element hat das chemische Symbol Pb?",
  "a": [
   "Blei",
   "Chlor",
   "Zinn",
   "Kohlenstoff"
  ]
 },
 "q0183": {
  "q": "Wie lautet das chemische Symbol von Zinn?",
  "a": [
   "Sn",
   "H",
   "Pb",
   "Au"
  ]
 },
 "q0184": {
  "q": "Welches Element hat das chemische Symbol Sn?",
  "a": [
   "Zinn",
   "Silber",
   "Kupfer",
   "Helium"
  ]
 },
 "q0185": {
  "q": "Welcher Teil des menschlichen Körpers enthält das Herz?",
  "a": [
   "Brustkorb",
   "Magen",
   "Schädel",
   "Becken"
  ]
 },
 "q0186": {
  "q": "Welches Organ im menschlichen Körper produziert Galle?",
  "a": [
   "Leber",
   "Milz",
   "Schilddrüse",
   "Bauchspeicheldrüse"
  ]
 },
 "q0187": {
  "q": "Welches Protein in roten Blutkörperchen transportiert Sauerstoff von der Lunge ins Gewebe?",
  "a": [
   "Hämoglobin",
   "Insulin",
   "Keratin",
   "Kollagen"
  ]
 },
 "q0188": {
  "q": "Welcher schottische Bakteriologe entdeckte 1928 das Penicillin?",
  "a": [
   "Alexander Fleming",
   "Robert Koch",
   "Louis Pasteur",
   "Paul Ehrlich"
  ]
 },
 "q0189": {
  "q": "Welches von der Bauchspeicheldrüse gebildete Hormon senkt den Blutzuckerspiegel?",
  "a": [
   "Insulin",
   "Cortisol",
   "Adrenalin",
   "Melatonin"
  ]
 },
 "q0190": {
  "q": "Welcher Hirnnerv ist der wichtigste parasympathische Nerv für Herz und Verdauungstrakt?",
  "a": [
   "Vagusnerv",
   "Sehnerv",
   "Riechnerv",
   "Trigeminusnerv"
  ]
 },
 "q0191": {
  "q": "Welches Blutgefäß transportiert sauerstoffreiches Blut von der Lunge zum linken Herzvorhof?",
  "a": [
   "Lungenvene",
   "Lungenarterie",
   "Obere Hohlvene",
   "Aorta"
  ]
 },
 "q0192": {
  "q": "Welche Herzklappe liegt zwischen linkem Vorhof und linker Herzkammer des Menschen?",
  "a": [
   "Mitralklappe",
   "Trikuspidalklappe",
   "Pulmonalklappe",
   "Aortenklappe"
  ]
 },
 "q0193": {
  "q": "Welche Funktionseinheit der Niere filtert das Blut zur Harnbildung?",
  "a": [
   "Nephron",
   "Neuron",
   "Alveole",
   "Sarkomer"
  ]
 },
 "q0194": {
  "q": "Welche Zellen der Magenschleimhaut bilden den Intrinsic-Faktor für die Vitamin-B12-Aufnahme?",
  "a": [
   "Belegzellen",
   "Hauptzellen",
   "Becherzellen",
   "Paneth-Körnerzellen"
  ]
 },
 "q0195": {
  "q": "Welche Stadt ist die Hauptstadt von Bulgarien?",
  "a": [
   "Sofia",
   "Plowdiw",
   "Warna",
   "Burgas"
  ]
 },
 "q0196": {
  "q": "Welcher Herrscher führte die Bulgaren 681 über die Donau und gründete das Erste Bulgarische Reich?",
  "a": [
   "Asparuh",
   "Krum",
   "Boris I.",
   "Kalojan"
  ]
 },
 "q0197": {
  "q": "Welche Stadt war von 681 bis 893 die erste Hauptstadt des Ersten Bulgarischen Reiches?",
  "a": [
   "Pliska",
   "Weliko Tarnowo",
   "Ohrid",
   "Widin"
  ]
 },
 "q0198": {
  "q": "Welcher bulgarische Herrscher nahm in den 860er-Jahren das Christentum als Staatsreligion an?",
  "a": [
   "Boris I.",
   "Simeon I.",
   "Samuil",
   "Iwan Assen II."
  ]
 },
 "q0199": {
  "q": "Welche Stadt war von 1185 bis 1393 die Hauptstadt des Zweiten Bulgarischen Reiches?",
  "a": [
   "Weliko Tarnowo",
   "Sofia",
   "Preslaw",
   "Silistra"
  ]
 },
 "q0200": {
  "q": "Welches Felsrelief an einer Klippe bei Schumen zeigt einen Reiter, der über einen Löwen triumphiert?",
  "a": [
   "Reiter von Madara",
   "Felsenkirchen von Iwanowo",
   "Kirche von Bojana",
   "Thrakisches Grabmal von Kasanlak"
  ]
 },
 "q0201": {
  "q": "Welcher bulgarische Khan besiegte 811 den byzantinischen Kaiser Nikephoros I. in den Gebirgspässen?",
  "a": [
   "Krum",
   "Terwel",
   "Omurtag",
   "Kalojan"
  ]
 },
 "q0202": {
  "q": "In welchem Jahr fand die Vereinigung des Fürstentums Bulgarien mit Ostrumelien statt?",
  "a": [
   "1885",
   "1878",
   "1908",
   "1912"
  ]
 },
 "q0203": {
  "q": "In welchem Jahr erklärte Fürst Ferdinand in Weliko Tarnowo die volle Unabhängigkeit Bulgariens?",
  "a": [
   "1908",
   "1879",
   "1885",
   "1913"
  ]
 },
 "q0204": {
  "q": "Welcher mittelalterliche bulgarische Herrscher errang 917 in der Schlacht am Acheloos einen entscheidenden Sieg über Byzanz?",
  "a": [
   "Simeon I.",
   "Krum",
   "Terwel",
   "Peter I."
  ]
 },
 "q0205": {
  "q": "Welcher antiosmanische Aufstand brach im April 1876 in den bulgarischen Gebieten aus?",
  "a": [
   "Aprilaufstand",
   "Aufstand von Tschiprowzi",
   "Kresna-Raslog-Aufstand",
   "Aufstand von Assen und Peter"
  ]
 },
 "q0206": {
  "q": "Welcher Friedensvertrag beendete am 3. März 1878 den Russisch-Osmanischen Krieg von 1877–1878?",
  "a": [
   "Friede von San Stefano",
   "Vertrag von Neuilly",
   "Vertrag von Craiova",
   "Vertrag von Bukarest"
  ]
 },
 "q0207": {
  "q": "Welcher bulgarische Zar besiegte 1230 in der Schlacht von Klokotniza Theodoros Komnenos Dukas?",
  "a": [
   "Iwan Assen II.",
   "Kalojan",
   "Iwajlo",
   "Iwan Alexander"
  ]
 },
 "q0208": {
  "q": "In welcher Stadt wurde 1879 mit der Verfassung von Tarnowo die erste Verfassung Bulgariens verabschiedet?",
  "a": [
   "Weliko Tarnowo",
   "Sofia",
   "Plowdiw",
   "Russe"
  ]
 },
 "q0209": {
  "q": "Welcher bulgarische Zar besiegte 1205 in der Schlacht von Adrianopel den lateinischen Kaiser Balduin I.?",
  "a": [
   "Kalojan",
   "Iwan Assen II.",
   "Simeon I.",
   "Samuil"
  ]
 },
 "q0210": {
  "q": "Welcher am 7. September 1940 unterzeichnete Vertrag gab die Süddobrudscha an Bulgarien zurück?",
  "a": [
   "Vertrag von Craiova",
   "Vertrag von Neuilly",
   "Vertrag von Bukarest",
   "Vertrag von London"
  ]
 },
 "q0211": {
  "q": "Welcher am 27. November 1919 unterzeichnete Friedensvertrag verpflichtete Bulgarien zur Abtretung Westthrakiens?",
  "a": [
   "Vertrag von Neuilly",
   "Friede von San Stefano",
   "Vertrag von Craiova",
   "Vertrag von Bukarest"
  ]
 },
 "q0212": {
  "q": "Welcher bulgarische Staatsmann amtierte von 1887 bis 1894 unter Fürst Ferdinand als Ministerpräsident?",
  "a": [
   "Stefan Stambolow",
   "Aleksandar Malinow",
   "Aleksandar Stambolijski",
   "Konstantin Stoilow"
  ]
 },
 "q0213": {
  "q": "Welcher Bauernführer wurde nach Kämpfen gegen mongolische Einfälle von 1278 bis 1279 Zar von Bulgarien?",
  "a": [
   "Iwajlo",
   "Smilez",
   "Georgi Terter I.",
   "Michael Assen I."
  ]
 },
 "q0214": {
  "q": "Welcher bulgarische Khan schloss 815 mit dem byzantinischen Kaiser Leo V. einen 30-jährigen Friedensvertrag?",
  "a": [
   "Omurtag",
   "Krum",
   "Terwel",
   "Malamir"
  ]
 },
 "q0215": {
  "q": "In welchem Jahr stellte Usain Bolt in Berlin den 100-Meter-Weltrekord von 9,58 Sekunden auf?",
  "a": [
   "2009",
   "2008",
   "2012",
   "2016"
  ]
 },
 "q0216": {
  "q": "In welchem Jahr gewann der Schwimmer Michael Phelps bei den Olympischen Spielen in Peking rekordverdächtige acht Goldmedaillen?",
  "a": [
   "2008",
   "2004",
   "2012",
   "2016"
  ]
 },
 "q0217": {
  "q": "In welchem Jahr stellte Lionel Messi mit 91 offiziellen Toren einen Fußball-Weltrekord für ein Kalenderjahr auf?",
  "a": [
   "2012",
   "2010",
   "2015",
   "2019"
  ]
 },
 "q0218": {
  "q": "In welchem Jahr gewann Jesse Owens bei den Olympischen Spielen in Berlin rekordverdächtige vier Goldmedaillen in der Leichtathletik?",
  "a": [
   "1936",
   "1932",
   "1948",
   "1952"
  ]
 },
 "q0219": {
  "q": "In welchem Jahr erhielt die rumänische Turnerin Nadia Comăneci die erste perfekte 10 in der Geschichte des olympischen Turnens?",
  "a": [
   "1976",
   "1972",
   "1980",
   "1984"
  ]
 },
 "q0220": {
  "q": "In welchem Jahr lief der Kenianer Eliud Kipchoge in Wien als erster Mensch eine Marathondistanz unter zwei Stunden?",
  "a": [
   "2019",
   "2017",
   "2021",
   "2023"
  ]
 },
 "q0221": {
  "q": "In welchem Jahr erzielte Basketball-Legende Wilt Chamberlain seinen NBA-Rekord von 100 Punkten in einem einzigen Spiel?",
  "a": [
   "1962",
   "1959",
   "1968",
   "1971"
  ]
 },
 "q0222": {
  "q": "In welchem Jahr stellte die US-Sprinterin Florence Griffith-Joyner den 100-Meter-Weltrekord der Frauen von 10,49 Sekunden auf?",
  "a": [
   "1988",
   "1984",
   "1991",
   "1996"
  ]
 },
 "q0223": {
  "q": "In welchem Jahr durchbrach der britische Läufer Roger Bannister als erster Mensch die Vier-Minuten-Grenze über eine Meile?",
  "a": [
   "1954",
   "1948",
   "1958",
   "1960"
  ]
 },
 "q0224": {
  "q": "In welchem Jahr stellte Bob Beamon bei den Olympischen Spielen in Mexiko-Stadt seinen legendären Weitsprung-Weltrekord von 8,90 Metern auf?",
  "a": [
   "1968",
   "1964",
   "1972",
   "1976"
  ]
 },
 "q0225": {
  "q": "In welchem Jahr übersprang Stabhochspringer Sergej Bubka in Paris als erster Athlet die Marke von sechs Metern?",
  "a": [
   "1985",
   "1983",
   "1988",
   "1991"
  ]
 },
 "q0226": {
  "q": "In welchem Jahr stellte die bulgarische Hochspringerin Stefka Kostadinowa in Rom den Frauen-Weltrekord von 2,09 Metern auf?",
  "a": [
   "1987",
   "1985",
   "1988",
   "1992"
  ]
 },
 "q0227": {
  "q": "In welchem Jahr brach der US-Athlet Mike Powell mit 8,95 Metern in Tokio Bob Beamons Weitsprung-Weltrekord?",
  "a": [
   "1991",
   "1988",
   "1992",
   "1995"
  ]
 },
 "q0228": {
  "q": "In welchem Jahr erzielte Eishockey-Legende Wayne Gretzky seinen NHL-Rekord von 92 Toren in einer einzigen regulären Saison?",
  "a": [
   "1982",
   "1979",
   "1985",
   "1988"
  ]
 },
 "q0229": {
  "q": "In welchem Jahr stellte der kubanische Leichtathlet Javier Sotomayor in Salamanca den Hochsprung-Weltrekord der Männer von 2,45 Metern auf?",
  "a": [
   "1993",
   "1989",
   "1996",
   "2000"
  ]
 },
 "q0230": {
  "q": "In welchem Jahr stellte der britische Dreispringer Jonathan Edwards in Göteborg den Männer-Weltrekord von 18,29 Metern auf?",
  "a": [
   "1995",
   "1992",
   "1998",
   "2000"
  ]
 },
 "q0231": {
  "q": "In welchem Jahr brach die ukrainische Hochspringerin Jaroslawa Mahutschich in Paris mit 2,10 Metern Stefka Kostadinowas 37 Jahre alten Weltrekord?",
  "a": [
   "2024",
   "2021",
   "2022",
   "2025"
  ]
 },
 "q0232": {
  "q": "In welchem Jahr lief der kenianische Marathonläufer Kelvin Kiptum beim Chicago-Marathon den offiziellen Weltrekord von 2:00:35 Stunden?",
  "a": [
   "2023",
   "2021",
   "2022",
   "2024"
  ]
 },
 "q0233": {
  "q": "In welchem Jahr stellte die DDR-Sprinterin Marita Koch in Canberra den 400-Meter-Weltrekord der Frauen von 47,60 Sekunden auf?",
  "a": [
   "1985",
   "1980",
   "1982",
   "1988"
  ]
 },
 "q0234": {
  "q": "In welchem Jahr schlug New-York-Yankees-Outfielder Roger Maris 61 Home Runs und brach damit Babe Ruths MLB-Saisonrekord?",
  "a": [
   "1961",
   "1956",
   "1964",
   "1969"
  ]
 },
 "q0235": {
  "q": "Wie viele Seiten hat ein regelmäßiges Sechseck?",
  "a": [
   "6",
   "5",
   "8",
   "10"
  ]
 },
 "q0236": {
  "q": "Wie groß ist die Innenwinkelsumme eines Dreiecks in Grad?",
  "a": [
   "180",
   "90",
   "270",
   "360"
  ]
 },
 "q0237": {
  "q": "Wie groß ist 12 zum Quadrat?",
  "a": [
   "144",
   "124",
   "132",
   "164"
  ]
 },
 "q0238": {
  "q": "Was ist die kleinste Primzahl?",
  "a": [
   "2",
   "1",
   "0",
   "3"
  ]
 },
 "q0239": {
  "q": "Wie viele Flächen hat ein normaler Würfel?",
  "a": [
   "6",
   "8",
   "12",
   "4"
  ]
 },
 "q0240": {
  "q": "Was ist die Quadratwurzel aus 225?",
  "a": [
   "15",
   "12",
   "14",
   "16"
  ]
 },
 "q0241": {
  "q": "Was ist der Wert von 5 Fakultät (5!)?",
  "a": [
   "120",
   "25",
   "60",
   "720"
  ]
 },
 "q0242": {
  "q": "Welcher griechische Buchstabe bezeichnet üblicherweise den Goldenen Schnitt?",
  "a": [
   "Phi",
   "Pi",
   "Sigma",
   "Omega"
  ]
 },
 "q0243": {
  "q": "Wie heißt in einem rechtwinkligen Dreieck die Seite gegenüber dem rechten Winkel?",
  "a": [
   "Hypotenuse",
   "Ankathete",
   "Seitenhalbierende",
   "Höhe"
  ]
 },
 "q0244": {
  "q": "Wie viele Primzahlen sind kleiner als 20?",
  "a": [
   "8",
   "7",
   "9",
   "10"
  ]
 },
 "q0245": {
  "q": "Welcher Mathematiker veröffentlichte 1801 die \"Disquisitiones Arithmeticae\"?",
  "a": [
   "Carl Friedrich Gauß",
   "Leonhard Euler",
   "Pierre-Simon Laplace",
   "Joseph-Louis Lagrange"
  ]
 },
 "q0246": {
  "q": "Wie groß ist die Summe der ersten 10 positiven ganzen Zahlen?",
  "a": [
   "55",
   "45",
   "50",
   "65"
  ]
 },
 "q0247": {
  "q": "Wie viele platonische Körper gibt es im dreidimensionalen euklidischen Raum?",
  "a": [
   "5",
   "4",
   "6",
   "8"
  ]
 },
 "q0248": {
  "q": "Welcher Mathematiker formulierte 1931 die Unvollständigkeitssätze?",
  "a": [
   "Kurt Gödel",
   "Alan Turing",
   "Bertrand Russell",
   "John von Neumann"
  ]
 },
 "q0249": {
  "q": "Wie viele Kanten hat ein Dodekaeder?",
  "a": [
   "30",
   "20",
   "12",
   "24"
  ]
 },
 "q0250": {
  "q": "Welcher Mathematiker bewies 1995 den Großen Fermatschen Satz?",
  "a": [
   "Andrew Wiles",
   "Grigori Perelman",
   "Terence Tao",
   "Pierre Deligne"
  ]
 },
 "q0251": {
  "q": "Was ist die Euler-Charakteristik einer Sphäre?",
  "a": [
   "2",
   "0",
   "1",
   "-2"
  ]
 },
 "q0252": {
  "q": "Welcher Mathematiker begründete Ende des 19. Jahrhunderts die Mengenlehre?",
  "a": [
   "Georg Cantor",
   "Augustin-Louis Cauchy",
   "Évariste Galois",
   "Bernhard Riemann"
  ]
 },
 "q0253": {
  "q": "Welcher Satz besagt, dass jedes nichtkonstante Polynom in einer Variablen eine komplexe Nullstelle hat?",
  "a": [
   "Fundamentalsatz der Algebra",
   "Binomischer Lehrsatz",
   "Polynomdivisionssatz",
   "Satz von Green"
  ]
 },
 "q0254": {
  "q": "Welcher Mathematiker bewies 1963 die Unabhängigkeit der Kontinuumshypothese von ZFC?",
  "a": [
   "Paul Cohen",
   "Saharon Shelah",
   "Emil Post",
   "Alfred Tarski"
  ]
 },
 "q0255": {
  "q": "Wie viele Beine hat ein erwachsenes Insekt?",
  "a": [
   "6",
   "8",
   "4",
   "10"
  ]
 },
 "q0256": {
  "q": "In welches geflügelte Insekt verwandelt sich eine Raupe?",
  "a": [
   "Schmetterling",
   "Libelle",
   "Grashüpfer",
   "Marienkäfer"
  ]
 },
 "q0257": {
  "q": "Welches Insekt sammelt Nektar aus Blüten, um Honig herzustellen?",
  "a": [
   "Honigbiene",
   "Wespe",
   "Hornisse",
   "Hummel"
  ]
 },
 "q0258": {
  "q": "Was sind die drei Hauptkörperabschnitte eines erwachsenen Insekts?",
  "a": [
   "Kopf, Brust und Hinterleib",
   "Kopf, Hals und Schwanz",
   "Kopf, Panzer und Schwanz",
   "Kopf, Rücken und Beine"
  ]
 },
 "q0259": {
  "q": "Welches Insekt erzeugt durch Biolumineszenz Licht aus seinem Hinterleib?",
  "a": [
   "Glühwürmchen",
   "Zikade",
   "Grille",
   "Termite"
  ]
 },
 "q0260": {
  "q": "Die Raupe welches Nachtfalters spinnt Kokons zur Herstellung von Naturseide?",
  "a": [
   "Maulbeerspinner",
   "Atlasspinner",
   "Mondspinner",
   "Totenkopfschwärmer"
  ]
 },
 "q0261": {
  "q": "Welches blutsaugende Insekt überträgt die Parasiten, die Malaria verursachen?",
  "a": [
   "Stechmücke",
   "Floh",
   "Tsetsefliege",
   "Bettwanze"
  ]
 },
 "q0262": {
  "q": "Welches räuberische Insekt ist dafür bekannt, seine Vorderbeine wie zum Gebet gefaltet zu halten?",
  "a": [
   "Gottesanbeterin",
   "Gespenstschrecke",
   "Ohrwurm",
   "Kakerlake"
  ]
 },
 "q0263": {
  "q": "Welche Insektenordnung umfasst die größte Anzahl beschriebener Arten auf der Erde?",
  "a": [
   "Käfer",
   "Schmetterlinge",
   "Zweiflügler",
   "Hautflügler"
  ]
 },
 "q0264": {
  "q": "Welche sozialen Insekten ernähren sich hauptsächlich von Zellulose aus Holz und abgestorbenen Pflanzen?",
  "a": [
   "Termiten",
   "Libellen",
   "Marienkäfer",
   "Eintagsfliegen"
  ]
 },
 "q0265": {
  "q": "Wie heißen die spezialisierten Sinnesorgane am Kopf eines Insekts, die vorwiegend dem Riechen und Tasten dienen?",
  "a": [
   "Fühler",
   "Mandibeln",
   "Stigmen",
   "Tarsen"
  ]
 },
 "q0266": {
  "q": "Wie heißt das verhärtete Außenskelett, das den Körper eines Insekts stützt und schützt?",
  "a": [
   "Exoskelett",
   "Endoskelett",
   "Carapax",
   "Chorda dorsalis"
  ]
 },
 "q0267": {
  "q": "Wie heißt der vierstufige Lebenszyklus von Insekten aus Ei, Larve, Puppe und Imago?",
  "a": [
   "Vollständige Metamorphose",
   "Unvollständige Metamorphose",
   "Parthenogenese",
   "Häutung"
  ]
 },
 "q0268": {
  "q": "Welche räuberischen Käfer werden in der Landwirtschaft häufig zur Bekämpfung von Blattläusen eingesetzt?",
  "a": [
   "Marienkäfer",
   "Rüsselkäfer",
   "Schnellkäfer",
   "Maikäfer"
  ]
 },
 "q0269": {
  "q": "Wie heißt das widerstandsfähige stickstoffhaltige Polysaccharid, das den Hauptbestandteil des Exoskeletts von Insekten bildet?",
  "a": [
   "Chitin",
   "Keratin",
   "Zellulose",
   "Kollagen"
  ]
 },
 "q0270": {
  "q": "Wie teilen Honigbienen anderen Stockmitgliedern die Richtung und Entfernung von Nahrungsquellen mit?",
  "a": [
   "Schwänzeltanz",
   "Schwanzzucken",
   "Fühlerklopfen",
   "Flügeltrommeln"
  ]
 },
 "q0271": {
  "q": "Welche blutsaugende Fliege in Subsahara-Afrika überträgt die Parasiten, die die Schlafkrankheit verursachen?",
  "a": [
   "Tsetsefliege",
   "Bremse",
   "Dasselfliege",
   "Sandmücke"
  ]
 },
 "q0272": {
  "q": "Wie heißen die äußeren Öffnungen an Brust und Hinterleib eines Insekts, durch die Luft in das Atmungssystem gelangt?",
  "a": [
   "Stigmen",
   "Malpighische Gefäße",
   "Ocellen",
   "Tympanalorgane"
  ]
 },
 "q0273": {
  "q": "Welche umgebildeten Hinterflügel dienen bei Zweiflüglern der Ordnung Diptera als gyroskopische Gleichgewichtsorgane?",
  "a": [
   "Halteren",
   "Elytren",
   "Tegmina",
   "Cerci"
  ]
 },
 "q0274": {
  "q": "Welche Ausscheidungs- und Osmoregulationskanälchen zweigen vom Verdauungstrakt der Insekten ab?",
  "a": [
   "Malpighische Gefäße",
   "Nephridien",
   "Samenkanälchen",
   "Chylusgefäße"
  ]
 },
 "q0275": {
  "q": "Welcher pflanzenfressende Dinosaurier hatte drei Hörner im Gesicht und einen großen Nackenschild?",
  "a": [
   "Triceratops",
   "Velociraptor",
   "Allosaurus",
   "Spinosaurus"
  ]
 },
 "q0276": {
  "q": "Welcher Dinosaurier hatte eine Doppelreihe großer Knochenplatten auf dem Rücken und Stacheln am Schwanz?",
  "a": [
   "Stegosaurus",
   "Tyrannosaurus",
   "Brachiosaurus",
   "Diplodocus"
  ]
 },
 "q0277": {
  "q": "Wie pflanzten sich Nicht-Vogel-Dinosaurier fort?",
  "a": [
   "Durch das Legen von Eiern",
   "Durch Lebendgeburt",
   "Durch Knospung",
   "Durch Zweiteilung"
  ]
 },
 "q0278": {
  "q": "Welcher pflanzenfressende Dinosaurier besaß zur Verteidigung eine schwere knöcherne Keule am Ende seines Schwanzes?",
  "a": [
   "Ankylosaurus",
   "Iguanodon",
   "Compsognathus",
   "Deinonychus"
  ]
 },
 "q0279": {
  "q": "Welcher theropode Dinosaurier ist berühmt für sein hohes, segelartiges Gebilde auf dem Rücken?",
  "a": [
   "Spinosaurus",
   "Carnotaurus",
   "Giganotosaurus",
   "Ceratosaurus"
  ]
 },
 "q0280": {
  "q": "Was sind Gastrolithen, die in den versteinerten Skeletten vieler sauropoder Dinosaurier gefunden wurden?",
  "a": [
   "Verschluckte Steine zur Zerkleinerung von Pflanzennahrung",
   "Versteinerte Überreste ungeschlüpfter Eier",
   "Verkalkte Parasiten in der Lunge",
   "Knöcherne Panzerplatten unter der Haut"
  ]
 },
 "q0281": {
  "q": "Welcher zweibeinige pflanzenfressende Dinosaurier besaß an jeder Hand einen großen, spitzen Daumenstachel?",
  "a": [
   "Iguanodon",
   "Allosaurus",
   "Carnotaurus",
   "Corythosaurus"
  ]
 },
 "q0282": {
  "q": "Welcher Entenschnabelsaurier hatte einen langen, hohlen, nach hinten gebogenen Kopfkamm, der vermutlich Rufe verstärkte?",
  "a": [
   "Parasaurolophus",
   "Pachycephalosaurus",
   "Protoceratops",
   "Plateosaurus"
  ]
 },
 "q0283": {
  "q": "Welcher zweibeinige Dinosaurier hatte ein kuppelförmiges Schädeldach von bis zu 25 Zentimetern Dicke?",
  "a": [
   "Pachycephalosaurus",
   "Microraptor",
   "Therizinosaurus",
   "Oviraptor"
  ]
 },
 "q0284": {
  "q": "Welcher pflanzenfressende theropode Dinosaurier besaß die längsten bekannten Krallen aller Landtiere von bis zu einem Meter Länge?",
  "a": [
   "Therizinosaurus",
   "Baryonyx",
   "Megalosaurus",
   "Coelophysis"
  ]
 },
 "q0285": {
  "q": "Welche Schule für Hexerei und Zauberei besucht Harry Potter in J. K. Rowlings Romanen?",
  "a": [
   "Hogwarts",
   "Beauxbatons",
   "Durmstrang",
   "Ilvermorny"
  ]
 },
 "q0286": {
  "q": "In welchen Vulkan muss der Eine Ring in J. R. R. Tolkiens 'Der Herr der Ringe' geworfen werden, um zerstört zu werden?",
  "a": [
   "Schicksalsberg",
   "Einsamer Berg",
   "Gundabadberg",
   "Caradhras"
  ]
 },
 "q0287": {
  "q": "Von welchem Asteroiden stammt die Titelfigur in Antoine de Saint-Exupérys Erzählung 'Der kleine Prinz'?",
  "a": [
   "B 612",
   "A 113",
   "C 418",
   "D 904"
  ]
 },
 "q0288": {
  "q": "In welchem Museum findet Robert Langdon zu Beginn von Dan Browns 'Sakrileg' den ermordeten Kurator Jacques Saunière?",
  "a": [
   "Louvre",
   "Musée d'Orsay",
   "Britisches Museum",
   "Vatikanische Museen"
  ]
 },
 "q0289": {
  "q": "In der Nähe welches berühmten Bauwerks träumt Santiago in Paulo Coelhos Roman 'Der Alchimist', dass sein Schatz vergraben liegt?",
  "a": [
   "Die ägyptischen Pyramiden",
   "Die Hängenden Gärten von Babylon",
   "Das Kolosseum in Rom",
   "Der Leuchtturm von Alexandria"
  ]
 },
 "q0290": {
  "q": "Wie heißt der treue Knappe, der in Miguel de Cervantes' Roman auf einem Esel neben Don Quijote reitet?",
  "a": [
   "Sancho Pansa",
   "Rosinante",
   "Sansón Carrasco",
   "Ginés de Pasamonte"
  ]
 },
 "q0291": {
  "q": "Wie heißt der totalitäre Herrscher über Ozeanien in George Orwells Roman '1984'?",
  "a": [
   "Großer Bruder",
   "Emmanuel Goldstein",
   "O'Brien",
   "Napoleon"
  ]
 },
 "q0292": {
  "q": "Welches Abzeichen trägt Katniss Everdeen in Suzanne Collins' 'Die Tribute von Panem' als Symbol der Rebellion?",
  "a": [
   "Einen goldenen Spotttölpel",
   "Einen silbernen Wolf",
   "Eine bronzene Eule",
   "Einen kupfernen Falken"
  ]
 },
 "q0293": {
  "q": "Wie heißt der Kriminalroman von Agatha Christie, in dem zehn Fremde auf eine abgelegene Insel eingeladen werden?",
  "a": [
   "Und dann gabs keines mehr",
   "Mord im Orient-Express",
   "Der Tod auf dem Nil",
   "Alibi"
  ]
 },
 "q0294": {
  "q": "Wie heißt der Wüstenplanet, der in Frank Herberts Roman 'Der Wüstenplanet' die einzige Quelle des Gewürzes Melange ist?",
  "a": [
   "Arrakis",
   "Caladan",
   "Giedi Primus",
   "Salusa Secundus"
  ]
 },
 "q0295": {
  "q": "Wie heißt die fiktive Stadt, die José Arcadio Buendía in Gabriel García Márquez' Roman 'Hundert Jahre Einsamkeit' gründet?",
  "a": [
   "Macondo",
   "Comala",
   "Santa María",
   "Ollantaytambo"
  ]
 },
 "q0296": {
  "q": "Wie lautet der Vorname Raskolnikows, des verarmten ehemaligen Studenten in Fjodor Dostojewskis 'Schuld und Sühne'?",
  "a": [
   "Rodion",
   "Alexei",
   "Dmitri",
   "Iwan"
  ]
 },
 "q0297": {
  "q": "Wie heißt der Franziskanermönch, der in Umberto Ecos Roman 'Der Name der Rose' Morde in einer Abtei des 14. Jahrhunderts aufklärt?",
  "a": [
   "William von Baskerville",
   "Adson von Melk",
   "Jorge von Burgos",
   "Bernardo Gui"
  ]
 },
 "q0298": {
  "q": "Wie heißt die außerirdische Zivilisation aus einem Sternensystem mit drei Sonnen in Liu Cixins Roman 'Die drei Sonnen'?",
  "a": [
   "Trisolarier",
   "Sänger-Zivilisation",
   "Null-Heimkehrer",
   "Sophonen"
  ]
 },
 "q0299": {
  "q": "Wie heißt das Walfangschiff unter dem Kommando von Kapitän Ahab in Herman Melvilles Roman 'Moby-Dick'?",
  "a": [
   "Pequod",
   "Nautilus",
   "Hispaniola",
   "Beagle"
  ]
 },
 "q0300": {
  "q": "Wie heißt der riesige schwarze sprechende Kater aus Volands Gefolge in Michail Bulgakows 'Der Meister und Margarita'?",
  "a": [
   "Behemoth",
   "Asasello",
   "Korowjew",
   "Abadonna"
  ]
 },
 "q0301": {
  "q": "Welcher Song der Beatles gibt Haruki Murakamis Bestseller-Roman aus dem Jahr 1987 seinen Titel?",
  "a": [
   "Naokos Lächeln",
   "Strawberry Fields Forever",
   "Yesterday",
   "Across the Universe"
  ]
 },
 "q0302": {
  "q": "Wer schrieb den 1960 erschienenen und mit dem Pulitzer-Preis ausgezeichneten Roman 'Wer die Nachtigall stört'?",
  "a": [
   "Harper Lee",
   "Toni Morrison",
   "John Steinbeck",
   "Truman Capote"
  ]
 },
 "q0303": {
  "q": "Wie heißt die tätowierte Computerhackerin in Stieg Larssons 'Millennium'-Trilogie?",
  "a": [
   "Lisbeth Salander",
   "Erika Berger",
   "Harriet Vanger",
   "Saga Norén"
  ]
 },
 "q0304": {
  "q": "Wie heißt die totalitäre Republik in Margaret Atwoods dystopischem Roman 'Der Report der Magd'?",
  "a": [
   "Gilead",
   "Panem",
   "Ozeanien",
   "Luftstützpunkt Eins"
  ]
 },
 "q0305": {
  "q": "Wie heißt Amirs treuer Kindheitsfreund in Kabul in Khaled Hosseinis Roman 'Drachenläufer'?",
  "a": [
   "Hassan",
   "Sohrab",
   "Assef",
   "Rahim"
  ]
 },
 "q0306": {
  "q": "In welcher spanischen Stadt spielt Carlos Ruiz Zafóns Bestsellerroman 'Der Schatten des Windes' aus dem Jahr 2001?",
  "a": [
   "Barcelona",
   "Madrid",
   "Sevilla",
   "Valencia"
  ]
 },
 "q0307": {
  "q": "Ungefähr wie viele Monate dauert die Trächtigkeit eines Afrikanischen Elefanten?",
  "a": [
   "22 Monate",
   "9 Monate",
   "12 Monate",
   "36 Monate"
  ]
 },
 "q0308": {
  "q": "Ungefähr wie viele Tage dauert die Trächtigkeit eines Haushundes?",
  "a": [
   "63 Tage",
   "21 Tage",
   "120 Tage",
   "280 Tage"
  ]
 },
 "q0309": {
  "q": "Ungefähr wie viele Tage dauert die Trächtigkeit einer Hauskatze?",
  "a": [
   "65 Tage",
   "30 Tage",
   "150 Tage",
   "270 Tage"
  ]
 },
 "q0310": {
  "q": "Ungefähr wie viele Monate dauert die Trächtigkeit einer Giraffe?",
  "a": [
   "15 Monate",
   "6 Monate",
   "9 Monate",
   "24 Monate"
  ]
 },
 "q0311": {
  "q": "Ungefähr wie viele Tage dauert die Trächtigkeit eines Roten Riesenkängurus, bevor das Junge in den Beutel kriecht?",
  "a": [
   "33 Tage",
   "5 Tage",
   "120 Tage",
   "250 Tage"
  ]
 },
 "q0312": {
  "q": "Ungefähr wie viele Monate dauert die Trächtigkeit eines Hauspferdes?",
  "a": [
   "11 Monate",
   "5 Monate",
   "18 Monate",
   "24 Monate"
  ]
 },
 "q0313": {
  "q": "Wie viele Junge bringt ein Großer Panda normalerweise auf einmal zur Welt?",
  "a": [
   "1 oder 2",
   "5 oder 6",
   "8 bis 10",
   "12 bis 15"
  ]
 },
 "q0314": {
  "q": "Wie viele eineiige Junge bringt ein Neunbinden-Gürteltier typischerweise bei jedem Wurf zur Welt?",
  "a": [
   "4",
   "2",
   "6",
   "8"
  ]
 },
 "q0315": {
  "q": "Ungefähr wie viele Monate dauert die Trächtigkeit einer Hauskuh?",
  "a": [
   "9 Monate",
   "3 Monate",
   "15 Monate",
   "22 Monate"
  ]
 },
 "q0316": {
  "q": "Ungefähr wie viele Monate dauert die Trächtigkeit eines Blauwals?",
  "a": [
   "11 Monate",
   "4 Monate",
   "24 Monate",
   "36 Monate"
  ]
 },
 "q0317": {
  "q": "Ungefähr wie viele Tage dauert die Trächtigkeit eines Hauskaninchens?",
  "a": [
   "31 Tage",
   "7 Tage",
   "90 Tage",
   "180 Tage"
  ]
 },
 "q0318": {
  "q": "Ungefähr wie viele Tage dauert die Trächtigkeit einer Hausmaus?",
  "a": [
   "20 Tage",
   "5 Tage",
   "60 Tage",
   "120 Tage"
  ]
 },
 "q0319": {
  "q": "Ungefähr wie viele Monate dauert die Trächtigkeit eines Großen Tümmlers?",
  "a": [
   "12 Monate",
   "4 Monate",
   "22 Monate",
   "30 Monate"
  ]
 },
 "q0320": {
  "q": "Ungefähr wie viele Tage dauert die Trächtigkeit eines Nordopossums?",
  "a": [
   "12 Tage",
   "45 Tage",
   "90 Tage",
   "150 Tage"
  ]
 },
 "q0321": {
  "q": "Ungefähr wie viele Tage dauert die Trächtigkeit eines Hausschweins?",
  "a": [
   "114 Tage",
   "45 Tage",
   "210 Tage",
   "330 Tage"
  ]
 },
 "q0322": {
  "q": "Ungefähr wie viele Monate dauert die Trächtigkeit eines Spitzmaulnashorns?",
  "a": [
   "15 Monate",
   "6 Monate",
   "9 Monate",
   "28 Monate"
  ]
 },
 "q0323": {
  "q": "Ungefähr wie viele Tage dauert die Trächtigkeit eines Hausmeerschweinchens?",
  "a": [
   "65 Tage",
   "20 Tage",
   "120 Tage",
   "200 Tage"
  ]
 },
 "q0324": {
  "q": "Ungefähr wie viele Monate dauert die gesamte Tragzeit eines Walrosses einschließlich der Keimruhe?",
  "a": [
   "15 Monate",
   "6 Monate",
   "9 Monate",
   "28 Monate"
  ]
 },
 "q0325": {
  "q": "Ungefähr wie viele Tage dauert die Trächtigkeit eines Goldhamsters?",
  "a": [
   "16 Tage",
   "45 Tage",
   "90 Tage",
   "140 Tage"
  ]
 },
 "q0326": {
  "q": "Ungefähr wie viele Monate dauert die Tragzeit eines Kragenhais, eine der längsten unter den Wirbeltieren?",
  "a": [
   "42 Monate",
   "9 Monate",
   "18 Monate",
   "24 Monate"
  ]
 },
 "q0327": {
  "q": "Welcher Seefahrer leitete die Expedition von 1492 über den Atlantik, die Amerika erreichte?",
  "a": [
   "Christoph Kolumbus",
   "Vasco da Gama",
   "Ferdinand Magellan",
   "James Cook"
  ]
 },
 "q0328": {
  "q": "Welcher portugiesische Seefahrer leitete zwischen 1519 und 1522 die erste Weltumsegelung?",
  "a": [
   "Ferdinand Magellan",
   "Vasco da Gama",
   "Bartolomeu Dias",
   "Amerigo Vespucci"
  ]
 },
 "q0329": {
  "q": "Welcher portugiesische Seefahrer erreichte 1498 als erster Europäer Indien auf dem Seeweg?",
  "a": [
   "Vasco da Gama",
   "Pedro Álvares Cabral",
   "Heinrich der Seefahrer",
   "Diogo Cão"
  ]
 },
 "q0330": {
  "q": "Nach welchem italienischen Seefahrer wurden die Kontinente Nord- und Südamerika benannt?",
  "a": [
   "Amerigo Vespucci",
   "John Cabot",
   "Giovanni da Verrazzano",
   "Marco Polo"
  ]
 },
 "q0331": {
  "q": "Welcher britische Kapitän kartierte im 18. Jahrhundert die Ostküste Australiens und die Hawaii-Inseln?",
  "a": [
   "James Cook",
   "Francis Drake",
   "Henry Hudson",
   "William Bligh"
  ]
 },
 "q0332": {
  "q": "Welcher chinesische Admiral befehligte während der frühen Ming-Dynastie sieben Schatzfahrten durch den Indischen Ozean?",
  "a": [
   "Zheng He",
   "Kublai Khan",
   "Ban Chao",
   "Gan Ying"
  ]
 },
 "q0333": {
  "q": "Welchem altnordischen Seefahrer wird die erste europäische Expedition nach Nordamerika um das Jahr 1000 zugeschrieben?",
  "a": [
   "Leif Eriksson",
   "Erik der Rote",
   "Harald Hardråde",
   "Rollo"
  ]
 },
 "q0334": {
  "q": "Welcher portugiesische Seefahrer befehligte die Flotte, die im April 1500 an der Küste des heutigen Brasiliens landete?",
  "a": [
   "Pedro Álvares Cabral",
   "Bartolomeu Dias",
   "Afonso de Albuquerque",
   "Gil Eanes"
  ]
 },
 "q0335": {
  "q": "Welcher portugiesische Seefahrer umsegelte 1488 als erster Europäer die Südspitze Afrikas?",
  "a": [
   "Bartolomeu Dias",
   "Vasco da Gama",
   "Diogo Cão",
   "Nuno Tristão"
  ]
 },
 "q0336": {
  "q": "Welcher englische Kapitän vollendete zwischen 1577 und 1580 an Bord der Golden Hind die zweite Weltumsegelung?",
  "a": [
   "Francis Drake",
   "Walter Raleigh",
   "Martin Frobisher",
   "John Hawkins"
  ]
 },
 "q0337": {
  "q": "Welcher in Dänemark geborene Seefahrer leitete 1728 und 1741 russische Expeditionen zur Erforschung der Meerenge zwischen Asien und Nordamerika?",
  "a": [
   "Vitus Bering",
   "Alexei Tschirikow",
   "Semjon Deschnjow",
   "Iwan Krusenstern"
  ]
 },
 "q0338": {
  "q": "Welcher baskische Seefahrer übernahm nach Ferdinand Magellans Tod das Kommando und brachte das überlebende Schiff Victoria 1522 nach Spanien zurück?",
  "a": [
   "Juan Sebastián Elcano",
   "Andrés de Urdaneta",
   "Alonso de Salazar",
   "Miguel López de Legazpi"
  ]
 },
 "q0339": {
  "q": "Welcher niederländische Seefahrer erreichte 1642 als erster bekannter Europäer Tasmanien und Neuseeland?",
  "a": [
   "Abel Tasman",
   "Willem Barentsz",
   "Willem Janszoon",
   "Cornelis de Houtman"
  ]
 },
 "q0340": {
  "q": "Welcher französische Seefahrer leitete zwischen 1766 und 1769 die erste französische Weltumsegelung?",
  "a": [
   "Louis Antoine de Bougainville",
   "Jean-François de La Pérouse",
   "Jacques Cartier",
   "Samuel de Champlain"
  ]
 },
 "q0341": {
  "q": "Welcher englische Seefahrer erforschte auf Reisen in den Jahren 1609 und 1610 den Fluss und die Bucht in Nordamerika, die heute seinen Namen tragen?",
  "a": [
   "Henry Hudson",
   "John Cabot",
   "Martin Frobisher",
   "William Baffin"
  ]
 },
 "q0342": {
  "q": "Welcher französische Seefahrer beanspruchte 1534 die Region des Sankt-Lorenz-Stroms für Frankreich und nannte das Gebiet Kanada?",
  "a": [
   "Jacques Cartier",
   "Samuel de Champlain",
   "René-Robert Cavelier",
   "Jacques Marquette"
  ]
 },
 "q0343": {
  "q": "Welcher niederländische Seefahrer leitete in den 1590er-Jahren drei Expeditionen auf der Suche nach einer Nordostpassage und ist Namensgeber eines arktischen Meeres?",
  "a": [
   "Willem Barentsz",
   "Abel Tasman",
   "Jacob Roggeveen",
   "Dirk Hartog"
  ]
 },
 "q0344": {
  "q": "Welcher deutschbaltische Admiral befehligte zwischen 1803 und 1806 die erste russische Weltumsegelung?",
  "a": [
   "Adam Johann von Krusenstern",
   "Fabian Gottlieb von Bellingshausen",
   "Otto von Kotzebue",
   "Ferdinand von Wrangel"
  ]
 },
 "q0345": {
  "q": "Welcher niederländische Seefahrer leitete die Expedition von 1721–1722, der die erste dokumentierte europäische Sichtung der Osterinsel gelang?",
  "a": [
   "Jacob Roggeveen",
   "Willem Janszoon",
   "Dirk Hartog",
   "Frederick de Houtman"
  ]
 },
 "q0346": {
  "q": "Welcher spanische Seefahrer kartierte 1565 die Rückroute von West nach Ost über den Pazifik von den Philippinen nach Mexiko?",
  "a": [
   "Andrés de Urdaneta",
   "Ruy López de Villalobos",
   "Álvaro de Mendaña",
   "Pedro Fernández de Quirós"
  ]
 },
 "q0347": {
  "q": "Welcher Seefahrer leitete die Expedition, die 1492 Amerika erreichte?",
  "a": [
   "Christoph Kolumbus",
   "Marco Polo",
   "Vasco da Gama",
   "Ferdinand Magellan"
  ]
 },
 "q0348": {
  "q": "Welches medizinische Instrument legen Ärzte auf die Brust, um Herz und Lunge abzuhören?",
  "a": [
   "Stethoskop",
   "Thermometer",
   "Spritze",
   "Verband"
  ]
 },
 "q0349": {
  "q": "Wer erfand im Jahr 1816 das Stethoskop?",
  "a": [
   "René Laennec",
   "Louis Pasteur",
   "Alexander Fleming",
   "Edward Jenner"
  ]
 },
 "q0350": {
  "q": "Welches medizinische Gerät wird zur Messung der Körpertemperatur verwendet?",
  "a": [
   "Thermometer",
   "Barometer",
   "Hygrometer",
   "Anemometer"
  ]
 },
 "q0351": {
  "q": "Welches chirurgische Instrument hat eine scharfe Klinge zum Schneiden von Gewebe bei Operationen?",
  "a": [
   "Skalpell",
   "Pinzette",
   "Spekulum",
   "Kürette"
  ]
 },
 "q0352": {
  "q": "Welches medizinische Gerät gibt einen kontrollierten Stromschlag ab, um den Herzrhythmus wiederherzustellen?",
  "a": [
   "Defibrillator",
   "Herzschrittmacher",
   "Vernebler",
   "Dialysator"
  ]
 },
 "q0353": {
  "q": "Welches medizinische Instrument nutzen Ärzte, um Gehörgang und Trommelfell zu untersuchen?",
  "a": [
   "Otoskop",
   "Ophthalmoskop",
   "Laryngoskop",
   "Endoskop"
  ]
 },
 "q0354": {
  "q": "Welches medizinische Instrument dient zur Untersuchung des Augeninneren einschließlich der Netzhaut?",
  "a": [
   "Ophthalmoskop",
   "Otoskop",
   "Spirometer",
   "Tonometer"
  ]
 },
 "q0355": {
  "q": "Welches medizinische Gerät misst den arteriellen Blutdruck mithilfe einer aufblasbaren Manschette?",
  "a": [
   "Sphygmomanometer",
   "Pulsoximeter",
   "Blutzuckermessgerät",
   "Elektrokardiograf"
  ]
 },
 "q0356": {
  "q": "Welches medizinische Gerät misst das Atemvolumen, das ein Mensch ein- und ausatmet?",
  "a": [
   "Spirometer",
   "Audiometer",
   "Oxymeter",
   "Kapnograf"
  ]
 },
 "q0357": {
  "q": "Welches Instrument mit Hohlnadel und Kolben dient zum Spritzen oder Blutabnehmen?",
  "a": [
   "Spritze",
   "Katheter",
   "Kanüle",
   "Trokar"
  ]
 },
 "q0358": {
  "q": "Was ist die Sonne?",
  "a": [
   "Ein Stern",
   "Ein Planet",
   "Ein Mond",
   "Ein Komet"
  ]
 },
 "q0359": {
  "q": "Welcher Himmelskörper umkreist die Erde als ihr natürlicher Trabant?",
  "a": [
   "Der Mond",
   "Mars",
   "Venus",
   "Sirius"
  ]
 },
 "q0360": {
  "q": "In welchem Jahr landete Apollo 11 die ersten Menschen auf dem Mond?",
  "a": [
   "1969",
   "1957",
   "1975",
   "1986"
  ]
 },
 "q0361": {
  "q": "Wer flog 1961 als erster Mensch ins Weltall?",
  "a": [
   "Juri Gagarin",
   "Neil Armstrong",
   "Buzz Aldrin",
   "John Glenn"
  ]
 },
 "q0362": {
  "q": "Welche Galaxie enthält das Sonnensystem?",
  "a": [
   "Milchstraße",
   "Andromeda",
   "Dreiecksnebel",
   "Sombrero-Galaxie"
  ]
 },
 "q0363": {
  "q": "Welche Kraft hält Monde auf der Umlaufbahn um Planeten?",
  "a": [
   "Gravitation",
   "Magnetismus",
   "Reibung",
   "Trägheit"
  ]
 },
 "q0364": {
  "q": "Welcher Stern steht der Erde nach der Sonne am nächsten?",
  "a": [
   "Proxima Centauri",
   "Polarstern",
   "Beteigeuze",
   "Wega"
  ]
 },
 "q0365": {
  "q": "Welches Raumschiff brachte 1962 den ersten Amerikaner in die Erdumlaufbahn?",
  "a": [
   "Friendship 7",
   "Apollo 8",
   "Gemini 4",
   "Skylab"
  ]
 },
 "q0366": {
  "q": "Wie heißt das 1990 gestartete Weltraumteleskop?",
  "a": [
   "Hubble-Weltraumteleskop",
   "Spitzer-Weltraumteleskop",
   "Kepler-Weltraumteleskop",
   "Chandra-Röntgenobservatorium"
  ]
 },
 "q0367": {
  "q": "Welcher Mond des Saturn besitzt eine dichte Atmosphäre und Seen aus flüssigem Methan?",
  "a": [
   "Titan",
   "Europa",
   "Ganymed",
   "Io"
  ]
 },
 "q0368": {
  "q": "Wie heißt die eisige Region jenseits von Neptun, in der Pluto kreist?",
  "a": [
   "Kuipergürtel",
   "Asteroidengürtel",
   "Oortsche Wolke",
   "Van-Allen-Gürtel"
  ]
 },
 "q0369": {
  "q": "Welche Raumsonde war das erste von Menschen geschaffene Objekt im interstellaren Raum?",
  "a": [
   "Voyager 1",
   "Pioneer 10",
   "New Horizons",
   "Cassini"
  ]
 },
 "q0370": {
  "q": "Wie heißt die Grenze um ein Schwarzes Loch, jenseits derer nichts entweichen kann?",
  "a": [
   "Ereignishorizont",
   "Photosphäre",
   "Roche-Grenze",
   "Lagrange-Punkt"
  ]
 },
 "q0371": {
  "q": "Welcher Astronom formulierte Anfang des 17. Jahrhunderts die drei Gesetze der Planetenbewegung?",
  "a": [
   "Johannes Kepler",
   "Tycho Brahe",
   "Edmond Halley",
   "Christiaan Huygens"
  ]
 },
 "q0372": {
  "q": "Wie heißt die nächste große Spiralgalaxie zur Milchstraße?",
  "a": [
   "Andromedagalaxie",
   "Whirlpool-Galaxie",
   "Feuerradgalaxie",
   "Zigarrengalaxie"
  ]
 },
 "q0373": {
  "q": "Welche Raumsonde brachte 2020 Proben vom Asteroiden Ryugu zur Erde?",
  "a": [
   "Hayabusa2",
   "OSIRIS-REx",
   "Stardust",
   "Dawn"
  ]
 },
 "q0374": {
  "q": "Wie hoch ist das ungefähre Alter des Universums in der Standardkosmologie?",
  "a": [
   "13,8 Milliarden Jahre",
   "4,5 Milliarden Jahre",
   "9,2 Milliarden Jahre",
   "22,4 Milliarden Jahre"
  ]
 },
 "q0375": {
  "q": "Welcher rotierende Neutronenstern sendet elektromagnetische Strahlung als Impulse aus?",
  "a": [
   "Pulsar",
   "Magnetar",
   "Weißer Zwerg",
   "Brauner Zwerg"
  ]
 },
 "q0376": {
  "q": "Welche Grenze bestimmt den Abstand, in dem Gezeitenkräfte einen Körper zerreißen?",
  "a": [
   "Roche-Grenze",
   "Schwarzschild-Radius",
   "Chandrasekhar-Grenze",
   "Jeans-Masse"
  ]
 },
 "q0377": {
  "q": "Welche Raumsonde brachte 2010 als erste Proben von der Oberfläche eines Asteroiden zurück?",
  "a": [
   "Hayabusa",
   "Akatsuki",
   "Kaguya",
   "Hinode"
  ]
 },
 "q0378": {
  "q": "Was ist der Mond?",
  "a": [
   "Der natürliche Trabant der Erde",
   "Ein Stern",
   "Ein Planet",
   "Ein Komet"
  ]
 },
 "q0379": {
  "q": "Welcher Stern steht im Zentrum des Sonnensystems?",
  "a": [
   "Die Sonne",
   "Sirius",
   "Polarstern",
   "Aldebaran"
  ]
 },
 "q0380": {
  "q": "Welches Gas macht den größten Teil der Sonnenmasse aus?",
  "a": [
   "Wasserstoff",
   "Sauerstoff",
   "Stickstoff",
   "Kohlenstoffdioxid"
  ]
 },
 "q0381": {
  "q": "Welcher Jupitermond ist der größte Mond im Sonnensystem?",
  "a": [
   "Ganymed",
   "Europa",
   "Io",
   "Kallisto"
  ]
 },
 "q0382": {
  "q": "Zwischen welchen beiden Planeten liegt der Hauptasteroidengürtel?",
  "a": [
   "Mars und Jupiter",
   "Erde und Mars",
   "Jupiter und Saturn",
   "Saturn und Uranus"
  ]
 },
 "q0383": {
  "q": "Welches Raumfahrtunternehmen gründete Elon Musk im Jahr 2002?",
  "a": [
   "SpaceX",
   "Netflix",
   "IKEA",
   "McDonald's"
  ]
 },
 "q0384": {
  "q": "Welches Elektroauto-Unternehmen ist eng mit Elon Musk verbunden?",
  "a": [
   "Tesla",
   "Toyota",
   "Ferrari",
   "Volkswagen"
  ]
 },
 "q0385": {
  "q": "In welcher Stadt wurde Elon Musk im Jahr 1971 geboren?",
  "a": [
   "Pretoria",
   "Kapstadt",
   "Johannesburg",
   "Durban"
  ]
 },
 "q0386": {
  "q": "Welches Software-Startup gründete Elon Musk 1995 mit?",
  "a": [
   "Zip2",
   "Stripe",
   "Dropbox",
   "Airbnb"
  ]
 },
 "q0387": {
  "q": "Welches Unternehmen übernahm Zip2 im Jahr 1999?",
  "a": [
   "Compaq",
   "Oracle",
   "Cisco",
   "Dell"
  ]
 },
 "q0388": {
  "q": "Welcher Online-Bezahldienst ging 2000 aus der Fusion von Elon Musks X.com hervor?",
  "a": [
   "PayPal",
   "Venmo",
   "Square",
   "Alipay"
  ]
 },
 "q0389": {
  "q": "In welchem Jahr wurde Elon Musk CEO von Tesla?",
  "a": [
   "2008",
   "2004",
   "2006",
   "2012"
  ]
 },
 "q0390": {
  "q": "In welchem Jahr erreichte die Falcon 1 von SpaceX erstmals die Erdumlaufbahn?",
  "a": [
   "2008",
   "2006",
   "2010",
   "2012"
  ]
 },
 "q0391": {
  "q": "Welches Unternehmen für Gehirn-Computer-Schnittstellen gründete Elon Musk 2016 mit?",
  "a": [
   "Neuralink",
   "Cerebras",
   "Synchron",
   "Kernel"
  ]
 },
 "q0392": {
  "q": "Welches Tunnelbauunternehmen gründete Elon Musk im Jahr 2017?",
  "a": [
   "The Boring Company",
   "Bechtel",
   "Skanska",
   "Fluor"
  ]
 },
 "q0393": {
  "q": "Welches Unternehmen für künstliche Intelligenz gründete Elon Musk 2023?",
  "a": [
   "xAI",
   "Anthropic",
   "Mistral AI",
   "Cohere"
  ]
 },
 "q0394": {
  "q": "Welche Social-Media-Plattform übernahm Elon Musk im Jahr 2022?",
  "a": [
   "Twitter",
   "Reddit",
   "Snapchat",
   "Pinterest"
  ]
 },
 "q0395": {
  "q": "Welches Raumschiff von SpaceX ist für den Transport von Astronauten zur Internationalen Raumstation vorgesehen?",
  "a": [
   "Dragon",
   "Orion",
   "Shenzhou",
   "Dream Chaser"
  ]
 },
 "q0396": {
  "q": "Welche Satellitenkonstellation von SpaceX bietet weltweites Breitband-Internet?",
  "a": [
   "Starlink",
   "OneWeb",
   "Iridium",
   "Globalstar"
  ]
 },
 "q0397": {
  "q": "In welchem Jahr wurde Elon Musk eingebürgerter Staatsbürger der Vereinigten Staaten?",
  "a": [
   "2002",
   "1995",
   "1999",
   "2008"
  ]
 },
 "q0398": {
  "q": "Welcher KI-Chatbot wurde von Elon Musks Unternehmen xAI entwickelt?",
  "a": [
   "Grok",
   "Claude",
   "Gemini",
   "Llama"
  ]
 },
 "q0399": {
  "q": "Welche Universität verlieh Elon Musk 1997 seine Bachelorabschlüsse?",
  "a": [
   "University of Pennsylvania",
   "Stanford University",
   "Harvard University",
   "Cornell University"
  ]
 },
 "q0400": {
  "q": "Welche Triebwerksfamilie treibt die Rakete Falcon 9 von SpaceX an?",
  "a": [
   "Merlin",
   "Raptor",
   "Vulcain",
   "RD-180"
  ]
 },
 "q0401": {
  "q": "Welche Dummy-Nutzlast trug die Falcon 1 von SpaceX bei ihrem ersten Orbitalflug 2008?",
  "a": [
   "RatSat",
   "Starman",
   "Snoopy",
   "Redstone"
  ]
 },
 "q0402": {
  "q": "In welchem Jahr trat Elon Musk nach einem Führungsstreit als CEO von X.com zurück?",
  "a": [
   "2000",
   "1998",
   "2002",
   "2004"
  ]
 },
 "q0403": {
  "q": "Welche Art von Währung ist Bitcoin?",
  "a": [
   "Digitale Kryptowährung",
   "Papierbanknoten",
   "Metallmünzen",
   "Bankkarten aus Kunststoff"
  ]
 },
 "q0404": {
  "q": "Wie lautet das Pseudonym des Bitcoin-Erfinders?",
  "a": [
   "Satoshi Nakamoto",
   "Vitalik Buterin",
   "Elon Musk",
   "Charlie Lee"
  ]
 },
 "q0405": {
  "q": "Wie hoch ist die maximale Gesamtmenge an Bitcoins, die jemals geschürft werden kann?",
  "a": [
   "21 Millionen",
   "100 Millionen",
   "1 Milliarde",
   "50 Millionen"
  ]
 },
 "q0406": {
  "q": "Wie heißt die Technologie des verteilten Hauptbuchs, auf der Bitcoin basiert?",
  "a": [
   "Blockchain",
   "Cloud-Speicher",
   "Neuronales Netz",
   "Relationale Datenbank"
  ]
 },
 "q0407": {
  "q": "In welchem Jahr wurde das Bitcoin-Netzwerk gestartet?",
  "a": [
   "2009",
   "2005",
   "2013",
   "2017"
  ]
 },
 "q0408": {
  "q": "Welches Lebensmittel wurde 2010 bei der berühmten ersten kommerziellen Bitcoin-Transaktion für 10.000 BTC gekauft?",
  "a": [
   "Zwei Pizzen",
   "Eine Tasse Kaffee",
   "Ein Cheeseburger",
   "Ein Dutzend Donuts"
  ]
 },
 "q0409": {
  "q": "Welches Land führte Bitcoin im Jahr 2021 als erstes Land der Welt als gesetzliches Zahlungsmittel ein?",
  "a": [
   "El Salvador",
   "Schweiz",
   "Estland",
   "Malta"
  ]
 },
 "q0410": {
  "q": "Welcher Begriff beschreibt den Prozess der Bestätigung von Bitcoin-Transaktionen und der Schaffung neuer Bitcoins?",
  "a": [
   "Mining",
   "Schmelzen",
   "Schmieden",
   "Raffinieren"
  ]
 },
 "q0411": {
  "q": "Wie heißt die kleinste Einheit eines Bitcoins, die 0,00000001 BTC entspricht?",
  "a": [
   "Satoshi",
   "Finney",
   "Gwei",
   "Wei"
  ]
 },
 "q0412": {
  "q": "Wie oft wird die Bitcoin-Belohnung für das Schürfen eines neuen Blocks halbiert, ein Ereignis namens Halving?",
  "a": [
   "Alle 4 Jahre",
   "Jedes Jahr",
   "Alle 2 Jahre",
   "Alle 10 Jahre"
  ]
 },
 "q0413": {
  "q": "Welchen Konsensmechanismus verwendet das Bitcoin-Netzwerk zur Validierung von Transaktionen?",
  "a": [
   "Proof of Work",
   "Proof of Stake",
   "Proof of Authority",
   "Proof of Burn"
  ]
 },
 "q0414": {
  "q": "Wie lang ist die angestrebte durchschnittliche Zeit zwischen zwei aufeinanderfolgenden Blöcken in der Bitcoin-Blockchain?",
  "a": [
   "10 Minuten",
   "1 Minute",
   "1 Stunde",
   "15 Sekunden"
  ]
 },
 "q0415": {
  "q": "Welche kryptografische Hashfunktion wird im Proof-of-Work-Algorithmus von Bitcoin verwendet?",
  "a": [
   "SHA-256",
   "MD5",
   "SHA-1",
   "AES-128"
  ]
 },
 "q0416": {
  "q": "Wie heißt der allererste Block, der jemals in der Bitcoin-Blockchain geschürft wurde?",
  "a": [
   "Genesis-Block",
   "Alpha-Block",
   "Prime-Block",
   "Origin-Block"
  ]
 },
 "q0417": {
  "q": "Wer war der Empfänger der allerersten Bitcoin-Transaktion, die Satoshi Nakamoto im Januar 2009 sendete?",
  "a": [
   "Hal Finney",
   "Nick Szabo",
   "Gavin Andresen",
   "Adam Back"
  ]
 },
 "q0418": {
  "q": "Wie heißt das auf Bitcoin aufbauende Layer-2-Zahlungsprotokoll für schnelle Transaktionen mit niedrigen Gebühren?",
  "a": [
   "Lightning Network",
   "Polygon Network",
   "Optimism Network",
   "Avalanche Network"
  ]
 },
 "q0419": {
  "q": "In welchem Monat und Jahr veröffentlichte Satoshi Nakamoto das Bitcoin-Whitepaper?",
  "a": [
   "Oktober 2008",
   "Januar 2009",
   "Mai 2010",
   "August 2007"
  ]
 },
 "q0420": {
  "q": "Nach wie vielen geschürften Blöcken passt das Bitcoin-Netzwerk die Mining-Schwierigkeit automatisch an?",
  "a": [
   "2.016 Blöcke",
   "1.000 Blöcke",
   "210.000 Blöcke",
   "4.096 Blöcke"
  ]
 },
 "q0421": {
  "q": "Welche Schlagzeile vom 3. Januar 2009 bettete Satoshi Nakamoto in den Genesis-Block von Bitcoin ein?",
  "a": [
   "The Times: Chancellor on brink of second bailout for banks",
   "The Wall Street Journal: Global markets plunge to new lows",
   "Financial Times: Central banks cut interest rates to zero",
   "The New York Times: Banking crisis deepens worldwide"
  ]
 },
 "q0422": {
  "q": "Wie hoch war die genaue Blockbelohnung in Bitcoins beim ersten Start des Netzwerks im Jahr 2009?",
  "a": [
   "50 BTC",
   "25 BTC",
   "100 BTC",
   "10 BTC"
  ]
 },
 "q0423": {
  "q": "Was ist die Hauptstadt dieses Landes: Andorra?",
  "a": [
   "Andorra la Vella",
   "Nikosia",
   "Vatikanstadt",
   "Rom"
  ]
 },
 "q0424": {
  "q": "Was ist die Hauptstadt dieses Landes: Vereinigte Arabische Emirate?",
  "a": [
   "Abu Dhabi",
   "Manama",
   "Kuweit-Stadt",
   "Tiflis"
  ]
 },
 "q0425": {
  "q": "Was ist die Hauptstadt dieses Landes: Afghanistan?",
  "a": [
   "Kabul",
   "Malé",
   "Teheran",
   "Kathmandu"
  ]
 },
 "q0426": {
  "q": "Was ist die Hauptstadt dieses Landes: Antigua und Barbuda?",
  "a": [
   "Saint John's",
   "Port of Spain",
   "Nassau",
   "Kingstown"
  ]
 },
 "q0427": {
  "q": "Was ist die Hauptstadt dieses Landes: Albanien?",
  "a": [
   "Tirana",
   "Skopje",
   "Bukarest",
   "Podgorica"
  ]
 },
 "q0428": {
  "q": "Was ist die Hauptstadt dieses Landes: Armenien?",
  "a": [
   "Jerewan",
   "Damaskus",
   "Tiflis",
   "Manama"
  ]
 },
 "q0429": {
  "q": "Was ist die Hauptstadt dieses Landes: Angola?",
  "a": [
   "Luanda",
   "N’Djamena",
   "Juba",
   "Kinshasa"
  ]
 },
 "q0430": {
  "q": "Was ist die Hauptstadt dieses Landes: Argentinien?",
  "a": [
   "Buenos Aires",
   "Quito",
   "Georgetown",
   "Bogotá"
  ]
 },
 "q0431": {
  "q": "Was ist die Hauptstadt dieses Landes: Österreich?",
  "a": [
   "Wien",
   "Warschau",
   "Ljubljana",
   "Bratislava"
  ]
 },
 "q0432": {
  "q": "Was ist die Hauptstadt dieses Landes: Australien?",
  "a": [
   "Canberra",
   "Wellington",
   "Funafuti",
   "South Tarawa"
  ]
 },
 "q0433": {
  "q": "Was ist die Hauptstadt dieses Landes: Aserbaidschan?",
  "a": [
   "Baku",
   "Abu Dhabi",
   "Ramallah",
   "Jerusalem"
  ]
 },
 "q0434": {
  "q": "Was ist die Hauptstadt dieses Landes: Bosnien und Herzegowina?",
  "a": [
   "Sarajevo",
   "Sofia",
   "Belgrad",
   "Podgorica"
  ]
 },
 "q0435": {
  "q": "Was ist die Hauptstadt dieses Landes: Barbados?",
  "a": [
   "Bridgetown",
   "Port of Spain",
   "Castries",
   "Saint John's"
  ]
 },
 "q0436": {
  "q": "Was ist die Hauptstadt dieses Landes: Bangladesch?",
  "a": [
   "Dhaka",
   "Neu-Delhi",
   "Kabul",
   "Islamabad"
  ]
 },
 "q0437": {
  "q": "Was ist die Hauptstadt dieses Landes: Belgien?",
  "a": [
   "Brüssel",
   "Berlin",
   "Bern",
   "Monaco"
  ]
 },
 "q0438": {
  "q": "Was ist die Hauptstadt dieses Landes: Burkina Faso?",
  "a": [
   "Ouagadougou",
   "Accra",
   "Freetown",
   "Bamako"
  ]
 },
 "q0439": {
  "q": "Was ist die Hauptstadt dieses Landes: Bahrain?",
  "a": [
   "Manama",
   "Kuweit-Stadt",
   "Abu Dhabi",
   "Maskat"
  ]
 },
 "q0440": {
  "q": "Was ist die Hauptstadt dieses Landes: Burundi?",
  "a": [
   "Gitega",
   "Port Louis",
   "Dodoma",
   "Maputo"
  ]
 },
 "q0441": {
  "q": "Was ist die Hauptstadt dieses Landes: Benin?",
  "a": [
   "Porto-Novo",
   "Monrovia",
   "Banjul",
   "Accra"
  ]
 },
 "q0442": {
  "q": "Was ist die Hauptstadt dieses Landes: Brunei?",
  "a": [
   "Bandar Seri Begawan",
   "Phnom Penh",
   "Bangkok",
   "Vientiane"
  ]
 },
 "q0443": {
  "q": "Welche Stadt ist die verfassungsmäßige Hauptstadt Boliviens?",
  "a": [
   "Sucre",
   "Lima",
   "Buenos Aires",
   "Santiago de Chile"
  ]
 },
 "q0444": {
  "q": "Was ist die Hauptstadt dieses Landes: Brasilien?",
  "a": [
   "Brasília",
   "Paramaribo",
   "Buenos Aires",
   "Santiago de Chile"
  ]
 },
 "q0445": {
  "q": "Was ist die Hauptstadt dieses Landes: Bahamas?",
  "a": [
   "Nassau",
   "Port of Spain",
   "Kingston",
   "Santo Domingo"
  ]
 },
 "q0446": {
  "q": "Was ist die Hauptstadt dieses Landes: Bhutan?",
  "a": [
   "Thimphu",
   "Malé",
   "Teheran",
   "Dhaka"
  ]
 },
 "q0447": {
  "q": "Was ist die Hauptstadt dieses Landes: Botswana?",
  "a": [
   "Gaborone",
   "Pretoria",
   "Maseru",
   "Windhoek"
  ]
 },
 "q0448": {
  "q": "Was ist die Hauptstadt dieses Landes: Belarus?",
  "a": [
   "Minsk",
   "Kiew",
   "Kischinau",
   "Moskau"
  ]
 },
 "q0449": {
  "q": "Was ist die Hauptstadt dieses Landes: Belize?",
  "a": [
   "Belmopan",
   "Guatemala-Stadt",
   "Tegucigalpa",
   "San Salvador"
  ]
 },
 "q0450": {
  "q": "Was ist die Hauptstadt dieses Landes: Kanada?",
  "a": [
   "Ottawa",
   "Mexiko-Stadt",
   "Washington, D.C.",
   "Port-au-Prince"
  ]
 },
 "q0451": {
  "q": "Was ist die Hauptstadt dieses Landes: Demokratische Republik Kongo?",
  "a": [
   "Kinshasa",
   "Luanda",
   "N’Djamena",
   "Juba"
  ]
 },
 "q0452": {
  "q": "Was ist die Hauptstadt dieses Landes: Zentralafrikanische Republik?",
  "a": [
   "Bangui",
   "N’Djamena",
   "Yaoundé",
   "São Tomé"
  ]
 },
 "q0453": {
  "q": "Was ist die Hauptstadt dieses Landes: Republik Kongo?",
  "a": [
   "Brazzaville",
   "Juba",
   "N’Djamena",
   "Luanda"
  ]
 },
 "q0454": {
  "q": "Welche Stadt ist die Bundesstadt und der Regierungssitz der Schweiz?",
  "a": [
   "Bern",
   "Berlin",
   "Vaduz",
   "Monaco"
  ]
 },
 "q0455": {
  "q": "Was ist die Hauptstadt dieses Landes: Elfenbeinküste?",
  "a": [
   "Yamoussoukro",
   "Praia",
   "Abuja",
   "Porto-Novo"
  ]
 },
 "q0456": {
  "q": "Was ist die Hauptstadt dieses Landes: Chile?",
  "a": [
   "Santiago de Chile",
   "Paramaribo",
   "Montevideo",
   "Quito"
  ]
 },
 "q0457": {
  "q": "Was ist die Hauptstadt dieses Landes: Kamerun?",
  "a": [
   "Yaoundé",
   "São Tomé",
   "Bangui",
   "N’Djamena"
  ]
 },
 "q0458": {
  "q": "Was ist die Hauptstadt dieses Landes: Volksrepublik China?",
  "a": [
   "Peking",
   "Pjöngjang",
   "Seoul",
   "Tokio"
  ]
 },
 "q0459": {
  "q": "Was ist die Hauptstadt dieses Landes: Kolumbien?",
  "a": [
   "Bogotá",
   "Asunción",
   "Buenos Aires",
   "Sucre"
  ]
 },
 "q0460": {
  "q": "Was ist die Hauptstadt dieses Landes: Costa Rica?",
  "a": [
   "San José",
   "San Salvador",
   "Belmopan",
   "Managua"
  ]
 },
 "q0461": {
  "q": "Was ist die Hauptstadt dieses Landes: Kuba?",
  "a": [
   "Havanna",
   "Santo Domingo",
   "Roseau",
   "Port of Spain"
  ]
 },
 "q0462": {
  "q": "Was ist die Hauptstadt dieses Landes: Kap Verde?",
  "a": [
   "Praia",
   "Accra",
   "Ouagadougou",
   "Conakry"
  ]
 },
 "q0463": {
  "q": "Was ist die Hauptstadt dieses Landes: Zypern?",
  "a": [
   "Nikosia",
   "Andorra la Vella",
   "Madrid",
   "Valletta"
  ]
 },
 "q0464": {
  "q": "Was ist die Hauptstadt dieses Landes: Tschechien?",
  "a": [
   "Prag",
   "Budapest",
   "Ljubljana",
   "Warschau"
  ]
 },
 "q0465": {
  "q": "Was ist die Hauptstadt dieses Landes: Deutschland?",
  "a": [
   "Berlin",
   "Luxemburg",
   "Amsterdam",
   "Monaco"
  ]
 },
 "q0466": {
  "q": "Was ist die Hauptstadt dieses Landes: Dschibuti?",
  "a": [
   "Dschibuti",
   "Harare",
   "Port Louis",
   "Nairobi"
  ]
 },
 "q0467": {
  "q": "Was ist die Hauptstadt dieses Landes: Dänemark?",
  "a": [
   "Kopenhagen",
   "Reykjavík",
   "Oslo",
   "Helsinki"
  ]
 },
 "q0468": {
  "q": "Was ist die Hauptstadt dieses Landes: Dominica?",
  "a": [
   "Roseau",
   "Castries",
   "St. George’s",
   "Saint John's"
  ]
 },
 "q0469": {
  "q": "Was ist die Hauptstadt dieses Landes: Dominikanische Republik?",
  "a": [
   "Santo Domingo",
   "Port of Spain",
   "Kingston",
   "Nassau"
  ]
 },
 "q0470": {
  "q": "Was ist die Hauptstadt dieses Landes: Algerien?",
  "a": [
   "Algier",
   "Tripolis",
   "Rabat",
   "Tunis"
  ]
 },
 "q0471": {
  "q": "Was ist die Hauptstadt dieses Landes: Ecuador?",
  "a": [
   "Quito",
   "Paramaribo",
   "Brasília",
   "Caracas"
  ]
 },
 "q0472": {
  "q": "Was ist die Hauptstadt dieses Landes: Estland?",
  "a": [
   "Tallinn",
   "London",
   "Reykjavík",
   "Stockholm"
  ]
 },
 "q0473": {
  "q": "Was ist die Hauptstadt dieses Landes: Ägypten?",
  "a": [
   "Kairo",
   "Rabat",
   "Chartum",
   "Tunis"
  ]
 },
 "q0474": {
  "q": "Was ist die Hauptstadt dieses Landes: Eritrea?",
  "a": [
   "Asmara",
   "Lilongwe",
   "Addis Abeba",
   "Lusaka"
  ]
 },
 "q0475": {
  "q": "Was ist die Hauptstadt dieses Landes: Spanien?",
  "a": [
   "Madrid",
   "Rom",
   "Andorra la Vella",
   "San Marino"
  ]
 },
 "q0476": {
  "q": "Was ist die Hauptstadt dieses Landes: Äthiopien?",
  "a": [
   "Addis Abeba",
   "Moroni",
   "Maputo",
   "Mogadischu"
  ]
 },
 "q0477": {
  "q": "Was ist die Hauptstadt dieses Landes: Finnland?",
  "a": [
   "Helsinki",
   "Riga",
   "Reykjavík",
   "Stockholm"
  ]
 },
 "q0478": {
  "q": "Was ist die Hauptstadt dieses Landes: Fidschi?",
  "a": [
   "Suva",
   "Honiara",
   "Port Vila",
   "Port Moresby"
  ]
 },
 "q0479": {
  "q": "Was ist die Hauptstadt dieses Landes: Föderierte Staaten von Mikronesien?",
  "a": [
   "Palikir",
   "South Tarawa",
   "Majuro",
   "Yaren"
  ]
 },
 "q0480": {
  "q": "Was ist die Hauptstadt dieses Landes: Frankreich?",
  "a": [
   "Paris",
   "Brüssel",
   "Luxemburg",
   "Berlin"
  ]
 },
 "q0481": {
  "q": "Was ist die Hauptstadt dieses Landes: Gabun?",
  "a": [
   "Libreville",
   "Luanda",
   "São Tomé",
   "Juba"
  ]
 },
 "q0482": {
  "q": "Was ist die Hauptstadt dieses Landes: Vereinigtes Königreich?",
  "a": [
   "London",
   "Riga",
   "Kopenhagen",
   "Helsinki"
  ]
 },
 "q0483": {
  "q": "Was ist die Hauptstadt dieses Landes: Grenada?",
  "a": [
   "St. George’s",
   "Kingston",
   "Havanna",
   "Port of Spain"
  ]
 },
 "q0484": {
  "q": "Was ist die Hauptstadt dieses Landes: Georgien?",
  "a": [
   "Tiflis",
   "Damaskus",
   "Jerusalem",
   "Baku"
  ]
 },
 "q0485": {
  "q": "Was ist die Hauptstadt dieses Landes: Ghana?",
  "a": [
   "Accra",
   "Ouagadougou",
   "Freetown",
   "Monrovia"
  ]
 },
 "q0486": {
  "q": "Was ist die Hauptstadt dieses Landes: Gambia?",
  "a": [
   "Banjul",
   "Porto-Novo",
   "Praia",
   "Monrovia"
  ]
 },
 "q0487": {
  "q": "Was ist die Hauptstadt dieses Landes: Guinea?",
  "a": [
   "Conakry",
   "Nouakchott",
   "Yamoussoukro",
   "Freetown"
  ]
 },
 "q0488": {
  "q": "Was ist die Hauptstadt dieses Landes: Äquatorialguinea?",
  "a": [
   "Ciudad de la Paz",
   "São Tomé",
   "N’Djamena",
   "Yaoundé"
  ]
 },
 "q0489": {
  "q": "Was ist die Hauptstadt dieses Landes: Griechenland?",
  "a": [
   "Athen",
   "Rom",
   "Madrid",
   "Andorra la Vella"
  ]
 },
 "q0490": {
  "q": "Was ist die Hauptstadt dieses Landes: Guatemala?",
  "a": [
   "Guatemala-Stadt",
   "Managua",
   "Belmopan",
   "San Salvador"
  ]
 },
 "q0491": {
  "q": "Was ist die Hauptstadt dieses Landes: Guinea-Bissau?",
  "a": [
   "Bissau",
   "Lomé",
   "Niamey",
   "Dakar"
  ]
 },
 "q0492": {
  "q": "Was ist die Hauptstadt dieses Landes: Guyana?",
  "a": [
   "Georgetown",
   "Caracas",
   "Montevideo",
   "Brasília"
  ]
 },
 "q0493": {
  "q": "Was ist die Hauptstadt dieses Landes: Honduras?",
  "a": [
   "Tegucigalpa",
   "Managua",
   "Panama-Stadt",
   "San Salvador"
  ]
 },
 "q0494": {
  "q": "Was ist die Hauptstadt dieses Landes: Kroatien?",
  "a": [
   "Zagreb",
   "Belgrad",
   "Skopje",
   "Tirana"
  ]
 },
 "q0495": {
  "q": "Was ist die Hauptstadt dieses Landes: Haiti?",
  "a": [
   "Port-au-Prince",
   "Roseau",
   "Kingston",
   "Havanna"
  ]
 },
 "q0496": {
  "q": "Was ist die Hauptstadt dieses Landes: Ungarn?",
  "a": [
   "Budapest",
   "Ljubljana",
   "Wien",
   "Prag"
  ]
 },
 "q0497": {
  "q": "Was ist die Hauptstadt dieses Landes: Indonesien?",
  "a": [
   "Jakarta",
   "Naypyidaw",
   "Kuala Lumpur",
   "Manila"
  ]
 },
 "q0498": {
  "q": "Was ist die Hauptstadt dieses Landes: Irland?",
  "a": [
   "Dublin",
   "Vilnius",
   "Riga",
   "Reykjavík"
  ]
 },
 "q0499": {
  "q": "Was ist die Hauptstadt dieses Landes: Israel?",
  "a": [
   "Jerusalem",
   "Damaskus",
   "Riad",
   "Manama"
  ]
 },
 "q0500": {
  "q": "Was ist die Hauptstadt dieses Landes: Indien?",
  "a": [
   "Neu-Delhi",
   "Kabul",
   "Dhaka",
   "Teheran"
  ]
 },
 "q0501": {
  "q": "Was ist die Hauptstadt dieses Landes: Irak?",
  "a": [
   "Bagdad",
   "Tiflis",
   "Manama",
   "Riad"
  ]
 },
 "q0502": {
  "q": "Was ist die Hauptstadt dieses Landes: Iran?",
  "a": [
   "Teheran",
   "Neu-Delhi",
   "Islamabad",
   "Kabul"
  ]
 },
 "q0503": {
  "q": "Was ist die Hauptstadt dieses Landes: Island?",
  "a": [
   "Reykjavík",
   "Kopenhagen",
   "Vilnius",
   "London"
  ]
 },
 "q0504": {
  "q": "Was ist die Hauptstadt dieses Landes: Italien?",
  "a": [
   "Rom",
   "Madrid",
   "Nikosia",
   "Andorra la Vella"
  ]
 },
 "q0505": {
  "q": "Was ist die Hauptstadt dieses Landes: Jamaika?",
  "a": [
   "Kingston",
   "Nassau",
   "Santo Domingo",
   "Bridgetown"
  ]
 },
 "q0506": {
  "q": "Was ist die Hauptstadt dieses Landes: Jordanien?",
  "a": [
   "Amman",
   "Tiflis",
   "Maskat",
   "Beirut"
  ]
 },
 "q0507": {
  "q": "Was ist die Hauptstadt dieses Landes: Japan?",
  "a": [
   "Tokio",
   "Seoul",
   "Peking",
   "Pjöngjang"
  ]
 },
 "q0508": {
  "q": "Was ist die Hauptstadt dieses Landes: Kenia?",
  "a": [
   "Nairobi",
   "Dschibuti",
   "Maputo",
   "Asmara"
  ]
 },
 "q0509": {
  "q": "Was ist die Hauptstadt dieses Landes: Kirgisistan?",
  "a": [
   "Bischkek",
   "Duschanbe",
   "Astana",
   "Taschkent"
  ]
 },
 "q0510": {
  "q": "Was ist die Hauptstadt dieses Landes: Kambodscha?",
  "a": [
   "Phnom Penh",
   "Hanoi",
   "Bandar Seri Begawan",
   "Bangkok"
  ]
 },
 "q0511": {
  "q": "Was ist die Hauptstadt dieses Landes: Kiribati?",
  "a": [
   "South Tarawa",
   "Yaren",
   "Palikir",
   "Ngerulmud"
  ]
 },
 "q0512": {
  "q": "Was ist die Hauptstadt dieses Landes: Komoren?",
  "a": [
   "Moroni",
   "Asmara",
   "Addis Abeba",
   "Nairobi"
  ]
 },
 "q0513": {
  "q": "Was ist die Hauptstadt dieses Landes: St. Kitts und Nevis?",
  "a": [
   "Basseterre",
   "Saint John's",
   "Roseau",
   "Nassau"
  ]
 },
 "q0514": {
  "q": "Was ist die Hauptstadt dieses Landes: Nordkorea?",
  "a": [
   "Pjöngjang",
   "Tokio",
   "Seoul",
   "Ulaanbaatar"
  ]
 },
 "q0515": {
  "q": "Was ist die Hauptstadt dieses Landes: Südkorea?",
  "a": [
   "Seoul",
   "Tokio",
   "Pjöngjang",
   "Ulaanbaatar"
  ]
 },
 "q0516": {
  "q": "Was ist die Hauptstadt dieses Landes: Kuwait?",
  "a": [
   "Kuweit-Stadt",
   "Jerewan",
   "Bagdad",
   "Jerusalem"
  ]
 },
 "q0517": {
  "q": "Was ist die Hauptstadt dieses Landes: Kasachstan?",
  "a": [
   "Astana",
   "Bischkek",
   "Aşgabat",
   "Duschanbe"
  ]
 },
 "q0518": {
  "q": "Was ist die Hauptstadt dieses Landes: Laos?",
  "a": [
   "Vientiane",
   "Bangkok",
   "Kuala Lumpur",
   "Singapur"
  ]
 },
 "q0519": {
  "q": "Was ist die Hauptstadt dieses Landes: Libanon?",
  "a": [
   "Beirut",
   "Riad",
   "Ramallah",
   "Baku"
  ]
 },
 "q0520": {
  "q": "Was ist die Hauptstadt dieses Landes: St. Lucia?",
  "a": [
   "Castries",
   "Roseau",
   "Nassau",
   "Havanna"
  ]
 },
 "q0521": {
  "q": "Was ist die Hauptstadt dieses Landes: Liechtenstein?",
  "a": [
   "Vaduz",
   "Monaco",
   "Brüssel",
   "Berlin"
  ]
 },
 "q0522": {
  "q": "Welche Stadt ist die legislative Hauptstadt Sri Lankas?",
  "a": [
   "Sri Jayewardenepura Kotte",
   "Dhaka",
   "Kabul",
   "Islamabad"
  ]
 },
 "q0523": {
  "q": "Was ist die Hauptstadt dieses Landes: Liberia?",
  "a": [
   "Monrovia",
   "Freetown",
   "Yamoussoukro",
   "Abuja"
  ]
 },
 "q0524": {
  "q": "Was ist die Hauptstadt dieses Landes: Lesotho?",
  "a": [
   "Maseru",
   "Windhoek",
   "Mbabane",
   "Gaborone"
  ]
 },
 "q0525": {
  "q": "Was ist die Hauptstadt dieses Landes: Litauen?",
  "a": [
   "Vilnius",
   "Oslo",
   "Kopenhagen",
   "Reykjavík"
  ]
 },
 "q0526": {
  "q": "Was ist die Hauptstadt dieses Landes: Luxemburg?",
  "a": [
   "Luxemburg",
   "Paris",
   "Vaduz",
   "Bern"
  ]
 },
 "q0527": {
  "q": "Was ist die Hauptstadt dieses Landes: Lettland?",
  "a": [
   "Riga",
   "Stockholm",
   "Oslo",
   "Dublin"
  ]
 },
 "q0528": {
  "q": "Was ist die Hauptstadt dieses Landes: Libyen?",
  "a": [
   "Tripolis",
   "Chartum",
   "Kairo",
   "Algier"
  ]
 },
 "q0529": {
  "q": "Was ist die Hauptstadt dieses Landes: Marokko?",
  "a": [
   "Rabat",
   "Kairo",
   "Chartum",
   "Algier"
  ]
 },
 "q0530": {
  "q": "Was ist die Hauptstadt dieses Landes: Monaco?",
  "a": [
   "Monaco",
   "Brüssel",
   "Paris",
   "Bern"
  ]
 },
 "q0531": {
  "q": "Was ist die Hauptstadt dieses Landes: Moldau?",
  "a": [
   "Kischinau",
   "Kiew",
   "Minsk",
   "Moskau"
  ]
 },
 "q0532": {
  "q": "Was ist die Hauptstadt dieses Landes: Montenegro?",
  "a": [
   "Podgorica",
   "Belgrad",
   "Zagreb",
   "Bukarest"
  ]
 },
 "q0533": {
  "q": "Was ist die Hauptstadt dieses Landes: Madagaskar?",
  "a": [
   "Antananarivo",
   "Dschibuti",
   "Nairobi",
   "Lusaka"
  ]
 },
 "q0534": {
  "q": "Was ist die Hauptstadt dieses Landes: Marshallinseln?",
  "a": [
   "Majuro",
   "South Tarawa",
   "Ngerulmud",
   "Yaren"
  ]
 },
 "q0535": {
  "q": "Was ist die Hauptstadt dieses Landes: Nordmazedonien?",
  "a": [
   "Skopje",
   "Bukarest",
   "Zagreb",
   "Sarajevo"
  ]
 },
 "q0536": {
  "q": "Was ist die Hauptstadt dieses Landes: Mali?",
  "a": [
   "Bamako",
   "Abuja",
   "Nouakchott",
   "Bissau"
  ]
 },
 "q0537": {
  "q": "Was ist die Hauptstadt dieses Landes: Myanmar?",
  "a": [
   "Naypyidaw",
   "Kuala Lumpur",
   "Hanoi",
   "Singapur"
  ]
 },
 "q0538": {
  "q": "Was ist die Hauptstadt dieses Landes: Mongolei?",
  "a": [
   "Ulaanbaatar",
   "Tokio",
   "Pjöngjang",
   "Seoul"
  ]
 },
 "q0539": {
  "q": "Was ist die Hauptstadt dieses Landes: Mauretanien?",
  "a": [
   "Nouakchott",
   "Lomé",
   "Freetown",
   "Yamoussoukro"
  ]
 },
 "q0540": {
  "q": "Was ist die Hauptstadt dieses Landes: Malta?",
  "a": [
   "Valletta",
   "Madrid",
   "Rom",
   "Andorra la Vella"
  ]
 },
 "q0541": {
  "q": "Was ist die Hauptstadt dieses Landes: Mauritius?",
  "a": [
   "Port Louis",
   "Victoria",
   "Kampala",
   "Asmara"
  ]
 },
 "q0542": {
  "q": "Was ist die Hauptstadt dieses Landes: Malediven?",
  "a": [
   "Malé",
   "Kabul",
   "Teheran",
   "Kathmandu"
  ]
 },
 "q0543": {
  "q": "Was ist die Hauptstadt dieses Landes: Malawi?",
  "a": [
   "Lilongwe",
   "Kigali",
   "Nairobi",
   "Moroni"
  ]
 },
 "q0544": {
  "q": "Was ist die Hauptstadt dieses Landes: Mexiko?",
  "a": [
   "Mexiko-Stadt",
   "Ottawa",
   "Washington, D.C.",
   "Bridgetown"
  ]
 },
 "q0545": {
  "q": "Was ist die Hauptstadt dieses Landes: Malaysia?",
  "a": [
   "Kuala Lumpur",
   "Phnom Penh",
   "Naypyidaw",
   "Hanoi"
  ]
 },
 "q0546": {
  "q": "Was ist die Hauptstadt dieses Landes: Mosambik?",
  "a": [
   "Maputo",
   "Asmara",
   "Harare",
   "Addis Abeba"
  ]
 },
 "q0547": {
  "q": "Was ist die Hauptstadt dieses Landes: Namibia?",
  "a": [
   "Windhoek",
   "Pretoria",
   "Mbabane",
   "Gaborone"
  ]
 },
 "q0548": {
  "q": "Was ist die Hauptstadt dieses Landes: Niger?",
  "a": [
   "Niamey",
   "Monrovia",
   "Dakar",
   "Nouakchott"
  ]
 },
 "q0549": {
  "q": "Was ist die Hauptstadt dieses Landes: Nigeria?",
  "a": [
   "Abuja",
   "Yamoussoukro",
   "Porto-Novo",
   "Lomé"
  ]
 },
 "q0550": {
  "q": "Was ist die Hauptstadt dieses Landes: Nicaragua?",
  "a": [
   "Managua",
   "Belmopan",
   "Tegucigalpa",
   "San Salvador"
  ]
 },
 "q0551": {
  "q": "Was ist die Hauptstadt dieses Landes: Königreich der Niederlande?",
  "a": [
   "Amsterdam",
   "Brüssel",
   "Luxemburg",
   "Berlin"
  ]
 },
 "q0552": {
  "q": "Was ist die Hauptstadt dieses Landes: Norwegen?",
  "a": [
   "Oslo",
   "Reykjavík",
   "Stockholm",
   "Kopenhagen"
  ]
 },
 "q0553": {
  "q": "Was ist die Hauptstadt dieses Landes: Nepal?",
  "a": [
   "Kathmandu",
   "Kabul",
   "Dhaka",
   "Teheran"
  ]
 },
 "q0554": {
  "q": "In welchem Bezirk Naurus befinden sich die Regierungsbüros, da das Land keine offizielle Hauptstadt hat?",
  "a": [
   "Yaren",
   "Ngerulmud",
   "Palikir",
   "South Tarawa"
  ]
 },
 "q0555": {
  "q": "Was ist die Hauptstadt dieses Landes: Neuseeland?",
  "a": [
   "Wellington",
   "Canberra",
   "Suva",
   "Majuro"
  ]
 },
 "q0556": {
  "q": "Was ist die Hauptstadt dieses Landes: Oman?",
  "a": [
   "Maskat",
   "Bagdad",
   "Ankara",
   "Amman"
  ]
 },
 "q0557": {
  "q": "Was ist die Hauptstadt dieses Landes: Panama?",
  "a": [
   "Panama-Stadt",
   "Managua",
   "Tegucigalpa",
   "San Salvador"
  ]
 },
 "q0558": {
  "q": "Was ist die Hauptstadt dieses Landes: Peru?",
  "a": [
   "Lima",
   "Buenos Aires",
   "Paramaribo",
   "Georgetown"
  ]
 },
 "q0559": {
  "q": "Was ist die Hauptstadt dieses Landes: Papua-Neuguinea?",
  "a": [
   "Port Moresby",
   "Honiara",
   "Suva",
   "Port Vila"
  ]
 },
 "q0560": {
  "q": "Was ist die Hauptstadt dieses Landes: Philippinen?",
  "a": [
   "Manila",
   "Bandar Seri Begawan",
   "Singapur",
   "Vientiane"
  ]
 },
 "q0561": {
  "q": "Was ist die Hauptstadt dieses Landes: Pakistan?",
  "a": [
   "Islamabad",
   "Kabul",
   "Sri Jayewardenepura Kotte",
   "Dhaka"
  ]
 },
 "q0562": {
  "q": "Was ist die Hauptstadt dieses Landes: Polen?",
  "a": [
   "Warschau",
   "Prag",
   "Bratislava",
   "Budapest"
  ]
 },
 "q0563": {
  "q": "Welche Stadt ist das Verwaltungszentrum der Palästinensischen Autonomiebehörde?",
  "a": [
   "Ramallah",
   "Kuweit-Stadt",
   "Jerewan",
   "Bagdad"
  ]
 },
 "q0564": {
  "q": "Was ist die Hauptstadt dieses Landes: Portugal?",
  "a": [
   "Lissabon",
   "Nikosia",
   "Valletta",
   "Rom"
  ]
 },
 "q0565": {
  "q": "Was ist die Hauptstadt dieses Landes: Palau?",
  "a": [
   "Ngerulmud",
   "South Tarawa",
   "Majuro",
   "Yaren"
  ]
 },
 "q0566": {
  "q": "Was ist die Hauptstadt dieses Landes: Paraguay?",
  "a": [
   "Asunción",
   "Bogotá",
   "Brasília",
   "Quito"
  ]
 },
 "q0567": {
  "q": "Was ist die Hauptstadt dieses Landes: Katar?",
  "a": [
   "Doha",
   "Ramallah",
   "Baku",
   "Maskat"
  ]
 },
 "q0568": {
  "q": "Was ist die Hauptstadt dieses Landes: Rumänien?",
  "a": [
   "Bukarest",
   "Zagreb",
   "Sarajevo",
   "Podgorica"
  ]
 },
 "q0569": {
  "q": "Was ist die Hauptstadt dieses Landes: Serbien?",
  "a": [
   "Belgrad",
   "Tirana",
   "Zagreb",
   "Sofia"
  ]
 },
 "q0570": {
  "q": "Was ist die Hauptstadt dieses Landes: Russland?",
  "a": [
   "Moskau",
   "Kiew",
   "Kischinau",
   "Minsk"
  ]
 },
 "q0571": {
  "q": "Was ist die Hauptstadt dieses Landes: Ruanda?",
  "a": [
   "Kigali",
   "Moroni",
   "Gitega",
   "Maputo"
  ]
 },
 "q0572": {
  "q": "Was ist die Hauptstadt dieses Landes: Saudi-Arabien?",
  "a": [
   "Riad",
   "Bagdad",
   "Kuweit-Stadt",
   "Damaskus"
  ]
 },
 "q0573": {
  "q": "Was ist die Hauptstadt dieses Landes: Salomonen?",
  "a": [
   "Honiara",
   "Suva",
   "Port Vila",
   "Port Moresby"
  ]
 },
 "q0574": {
  "q": "Was ist die Hauptstadt dieses Landes: Seychellen?",
  "a": [
   "Victoria",
   "Asmara",
   "Lilongwe",
   "Dodoma"
  ]
 },
 "q0575": {
  "q": "Was ist die Hauptstadt dieses Landes: Sudan?",
  "a": [
   "Chartum",
   "Rabat",
   "Tunis",
   "Tripolis"
  ]
 },
 "q0576": {
  "q": "Was ist die Hauptstadt dieses Landes: Schweden?",
  "a": [
   "Stockholm",
   "Oslo",
   "Helsinki",
   "Dublin"
  ]
 },
 "q0577": {
  "q": "Was ist die Hauptstadt dieses Landes: Singapur?",
  "a": [
   "Singapur",
   "Vientiane",
   "Jakarta",
   "Bandar Seri Begawan"
  ]
 },
 "q0578": {
  "q": "Was ist die Hauptstadt dieses Landes: Slowenien?",
  "a": [
   "Ljubljana",
   "Bratislava",
   "Warschau",
   "Prag"
  ]
 },
 "q0579": {
  "q": "Was ist die Hauptstadt dieses Landes: Slowakei?",
  "a": [
   "Bratislava",
   "Prag",
   "Warschau",
   "Wien"
  ]
 },
 "q0580": {
  "q": "Was ist die Hauptstadt dieses Landes: Sierra Leone?",
  "a": [
   "Freetown",
   "Monrovia",
   "Yamoussoukro",
   "Porto-Novo"
  ]
 },
 "q0581": {
  "q": "Was ist die Hauptstadt dieses Landes: San Marino?",
  "a": [
   "San Marino",
   "Lissabon",
   "Madrid",
   "Nikosia"
  ]
 },
 "q0582": {
  "q": "Was ist die Hauptstadt dieses Landes: Senegal?",
  "a": [
   "Dakar",
   "Monrovia",
   "Banjul",
   "Bissau"
  ]
 },
 "q0583": {
  "q": "Was ist die Hauptstadt dieses Landes: Somalia?",
  "a": [
   "Mogadischu",
   "Lilongwe",
   "Addis Abeba",
   "Nairobi"
  ]
 },
 "q0584": {
  "q": "Was ist die Hauptstadt dieses Landes: Suriname?",
  "a": [
   "Paramaribo",
   "Lima",
   "Sucre",
   "Brasília"
  ]
 },
 "q0585": {
  "q": "Was ist die Hauptstadt dieses Landes: Südsudan?",
  "a": [
   "Juba",
   "Luanda",
   "Kinshasa",
   "Bangui"
  ]
 },
 "q0586": {
  "q": "Was ist die Hauptstadt dieses Landes: São Tomé und Príncipe?",
  "a": [
   "São Tomé",
   "Libreville",
   "Kinshasa",
   "Bangui"
  ]
 },
 "q0587": {
  "q": "Was ist die Hauptstadt dieses Landes: El Salvador?",
  "a": [
   "San Salvador",
   "San José",
   "Managua",
   "Guatemala-Stadt"
  ]
 },
 "q0588": {
  "q": "Was ist die Hauptstadt dieses Landes: Syrien?",
  "a": [
   "Damaskus",
   "Manama",
   "Doha",
   "Amman"
  ]
 },
 "q0589": {
  "q": "Welche Stadt ist die Verwaltungshauptstadt Eswatinis?",
  "a": [
   "Mbabane",
   "Windhoek",
   "Gaborone",
   "Pretoria"
  ]
 },
 "q0590": {
  "q": "Was ist die Hauptstadt dieses Landes: Tschad?",
  "a": [
   "N’Djamena",
   "Juba",
   "Brazzaville",
   "Kinshasa"
  ]
 },
 "q0591": {
  "q": "Was ist die Hauptstadt dieses Landes: Togo?",
  "a": [
   "Lomé",
   "Porto-Novo",
   "Abuja",
   "Bamako"
  ]
 },
 "q0592": {
  "q": "Was ist die Hauptstadt dieses Landes: Thailand?",
  "a": [
   "Bangkok",
   "Bandar Seri Begawan",
   "Naypyidaw",
   "Manila"
  ]
 },
 "q0593": {
  "q": "Was ist die Hauptstadt dieses Landes: Tadschikistan?",
  "a": [
   "Duschanbe",
   "Taschkent",
   "Astana",
   "Aşgabat"
  ]
 },
 "q0594": {
  "q": "Was ist die Hauptstadt dieses Landes: Osttimor?",
  "a": [
   "Dili",
   "Kuala Lumpur",
   "Vientiane",
   "Bandar Seri Begawan"
  ]
 },
 "q0595": {
  "q": "Was ist die Hauptstadt dieses Landes: Turkmenistan?",
  "a": [
   "Aşgabat",
   "Astana",
   "Bischkek",
   "Taschkent"
  ]
 },
 "q0596": {
  "q": "Was ist die Hauptstadt dieses Landes: Tunesien?",
  "a": [
   "Tunis",
   "Tripolis",
   "Chartum",
   "Algier"
  ]
 },
 "q0597": {
  "q": "Was ist die Hauptstadt dieses Landes: Tonga?",
  "a": [
   "Nukuʻalofa",
   "Apia",
   "Funafuti",
   "Port Moresby"
  ]
 },
 "q0598": {
  "q": "Was ist die Hauptstadt dieses Landes: Türkei?",
  "a": [
   "Ankara",
   "Jerewan",
   "Manama",
   "Kuweit-Stadt"
  ]
 },
 "q0599": {
  "q": "Was ist die Hauptstadt dieses Landes: Trinidad und Tobago?",
  "a": [
   "Port of Spain",
   "Basseterre",
   "Roseau",
   "Port-au-Prince"
  ]
 },
 "q0600": {
  "q": "Was ist die Hauptstadt dieses Landes: Tuvalu?",
  "a": [
   "Funafuti",
   "Nukuʻalofa",
   "Apia",
   "Yaren"
  ]
 },
 "q0601": {
  "q": "Was ist die Hauptstadt dieses Landes: Tansania?",
  "a": [
   "Dodoma",
   "Victoria",
   "Lilongwe",
   "Nairobi"
  ]
 },
 "q0602": {
  "q": "Was ist die Hauptstadt dieses Landes: Ukraine?",
  "a": [
   "Kiew",
   "Kischinau",
   "Minsk",
   "Moskau"
  ]
 },
 "q0603": {
  "q": "Was ist die Hauptstadt dieses Landes: Uganda?",
  "a": [
   "Kampala",
   "Gitega",
   "Victoria",
   "Dodoma"
  ]
 },
 "q0604": {
  "q": "Was ist die Hauptstadt dieses Landes: Vereinigte Staaten?",
  "a": [
   "Washington, D.C.",
   "Ottawa",
   "Mexiko-Stadt",
   "Belmopan"
  ]
 },
 "q0605": {
  "q": "Was ist die Hauptstadt dieses Landes: Uruguay?",
  "a": [
   "Montevideo",
   "Lima",
   "Sucre",
   "Caracas"
  ]
 },
 "q0606": {
  "q": "Was ist die Hauptstadt dieses Landes: Usbekistan?",
  "a": [
   "Taschkent",
   "Astana",
   "Bischkek",
   "Aşgabat"
  ]
 },
 "q0607": {
  "q": "Was ist die Hauptstadt dieses Landes: Vatikanstadt?",
  "a": [
   "Vatikanstadt",
   "Valletta",
   "Athen",
   "Nikosia"
  ]
 },
 "q0608": {
  "q": "Was ist die Hauptstadt dieses Landes: St. Vincent und die Grenadinen?",
  "a": [
   "Kingstown",
   "Castries",
   "Havanna",
   "Roseau"
  ]
 },
 "q0609": {
  "q": "Was ist die Hauptstadt dieses Landes: Venezuela?",
  "a": [
   "Caracas",
   "Bogotá",
   "Lima",
   "Sucre"
  ]
 },
 "q0610": {
  "q": "Was ist die Hauptstadt dieses Landes: Vietnam?",
  "a": [
   "Hanoi",
   "Bangkok",
   "Dili",
   "Manila"
  ]
 },
 "q0611": {
  "q": "Was ist die Hauptstadt dieses Landes: Vanuatu?",
  "a": [
   "Port Vila",
   "Suva",
   "Port Moresby",
   "Honiara"
  ]
 },
 "q0612": {
  "q": "Was ist die Hauptstadt dieses Landes: Samoa?",
  "a": [
   "Apia",
   "Funafuti",
   "Nukuʻalofa",
   "Ngerulmud"
  ]
 },
 "q0613": {
  "q": "Welche Stadt ist die verfassungsmäßige Hauptstadt Jemens?",
  "a": [
   "Sanaa",
   "Baku",
   "Ramallah",
   "Abu Dhabi"
  ]
 },
 "q0614": {
  "q": "Welche Stadt ist die Verwaltungshauptstadt Südafrikas?",
  "a": [
   "Pretoria",
   "Mbabane",
   "Windhoek",
   "Gaborone"
  ]
 },
 "q0615": {
  "q": "Was ist die Hauptstadt dieses Landes: Sambia?",
  "a": [
   "Lusaka",
   "Victoria",
   "Dschibuti",
   "Kigali"
  ]
 },
 "q0616": {
  "q": "Was ist die Hauptstadt dieses Landes: Simbabwe?",
  "a": [
   "Harare",
   "Kigali",
   "Mogadischu",
   "Dschibuti"
  ]
 },
 "q0617": {
  "q": "Welches chemische Element verbindet sich mit Wasserstoff zu Wasser?",
  "a": [
   "Sauerstoff",
   "Stickstoff",
   "Kohlenstoff",
   "Helium"
  ]
 },
 "q0618": {
  "q": "Welches chemische Element ist neben Natrium in gewöhnlichem Speisesalz enthalten?",
  "a": [
   "Chlor",
   "Neon",
   "Helium",
   "Silicium"
  ]
 },
 "q0619": {
  "q": "Welches leichte Gas wird häufig verwendet, um Luftballons steigen zu lassen, weil es leichter als Luft ist?",
  "a": [
   "Helium",
   "Sauerstoff",
   "Stickstoff",
   "Argon"
  ]
 },
 "q0620": {
  "q": "Welches chemische Element bildet die Grundlage von Diamanten und Graphit?",
  "a": [
   "Kohlenstoff",
   "Eisen",
   "Kupfer",
   "Schwefel"
  ]
 },
 "q0621": {
  "q": "Welches rotbraune Metall wird seit Jahrtausenden für elektrische Leitungen und Münzen verwendet?",
  "a": [
   "Kupfer",
   "Zink",
   "Blei",
   "Zinn"
  ]
 },
 "q0622": {
  "q": "Welches metallische chemische Element transportiert in menschlichen roten Blutkörperchen Sauerstoff?",
  "a": [
   "Eisen",
   "Silber",
   "Calcium",
   "Magnesium"
  ]
 },
 "q0623": {
  "q": "Welches chemische Element ist vor allem dafür bekannt, Knochen und Zähne zu stärken?",
  "a": [
   "Calcium",
   "Kalium",
   "Natrium",
   "Barium"
  ]
 },
 "q0624": {
  "q": "Welches chemische Element ist das Hauptmaterial für Computerchips und Solarzellen?",
  "a": [
   "Silicium",
   "Quecksilber",
   "Cobalt",
   "Nickel"
  ]
 },
 "q0625": {
  "q": "Welches Metall ist bei normaler Raumtemperatur flüssig und war früher in Fieberthermometern üblich?",
  "a": [
   "Quecksilber",
   "Gallium",
   "Bismut",
   "Indium"
  ]
 },
 "q0626": {
  "q": "Welches chemische Element macht rund 78 Prozent der trockenen Erdatmosphäre nach Volumen aus?",
  "a": [
   "Stickstoff",
   "Sauerstoff",
   "Argon",
   "Kohlenstoffdioxid"
  ]
 },
 "q0627": {
  "q": "Welches chemische Element ist im beobachtbaren Universum am häufigsten vorhanden?",
  "a": [
   "Wasserstoff",
   "Helium",
   "Sauerstoff",
   "Kohlenstoff"
  ]
 },
 "q0628": {
  "q": "Welches chemische Element hat im Periodensystem das Symbol Au?",
  "a": [
   "Gold",
   "Silber",
   "Aluminium",
   "Argon"
  ]
 },
 "q0629": {
  "q": "Welches leichte, silbrige Metall ist nach dem Erz Bauxit benannt, aus dem es gewonnen wird?",
  "a": [
   "Aluminium",
   "Titan",
   "Beryllium",
   "Magnesium"
  ]
 },
 "q0630": {
  "q": "Welches chemische Element hat im Periodensystem die Ordnungszahl 1?",
  "a": [
   "Wasserstoff",
   "Helium",
   "Lithium",
   "Kohlenstoff"
  ]
 },
 "q0631": {
  "q": "Welches chemische Element wird häufig in Akkus für Smartphones und Elektroautos verwendet?",
  "a": [
   "Lithium",
   "Wolfram",
   "Iod",
   "Phosphor"
  ]
 },
 "q0632": {
  "q": "Welches chemische Element hat im Periodensystem das Symbol Fe?",
  "a": [
   "Eisen",
   "Fluor",
   "Francium",
   "Fermium"
  ]
 },
 "q0633": {
  "q": "Welches chemische Element hat den höchsten Schmelzpunkt aller reinen Metalle?",
  "a": [
   "Wolfram",
   "Platin",
   "Osmium",
   "Chrom"
  ]
 },
 "q0634": {
  "q": "Welches Edelgas hat im Periodensystem das chemische Symbol Ne?",
  "a": [
   "Neon",
   "Nickel",
   "Niob",
   "Neodym"
  ]
 },
 "q0635": {
  "q": "Welches dichte Metall hat unter allen Elementen bei Normaldruck die höchste Dichte?",
  "a": [
   "Osmium",
   "Uran",
   "Thorium",
   "Rhenium"
  ]
 },
 "q0636": {
  "q": "Welches chemische Element hat im Periodensystem das Symbol W?",
  "a": [
   "Wolfram",
   "Bismut",
   "Vanadium",
   "Zirconium"
  ]
 },
 "q0637": {
  "q": "Was ist die Hauptstadt dieses Landes: Andorra?",
  "a": [
   "Andorra la Vella",
   "Nikosia",
   "Vatikanstadt",
   "Rom"
  ]
 },
 "q0638": {
  "q": "Was ist die Hauptstadt dieses Landes: Vereinigte Arabische Emirate?",
  "a": [
   "Abu Dhabi",
   "Manama",
   "Kuweit-Stadt",
   "Tiflis"
  ]
 },
 "q0639": {
  "q": "Was ist die Hauptstadt dieses Landes: Afghanistan?",
  "a": [
   "Kabul",
   "Malé",
   "Teheran",
   "Kathmandu"
  ]
 },
 "q0640": {
  "q": "Was ist die Hauptstadt dieses Landes: Antigua und Barbuda?",
  "a": [
   "Saint John's",
   "Port of Spain",
   "Nassau",
   "Kingstown"
  ]
 },
 "q0641": {
  "q": "Was ist die Hauptstadt dieses Landes: Albanien?",
  "a": [
   "Tirana",
   "Skopje",
   "Bukarest",
   "Podgorica"
  ]
 },
 "q0642": {
  "q": "Was ist die Hauptstadt dieses Landes: Armenien?",
  "a": [
   "Jerewan",
   "Damaskus",
   "Tiflis",
   "Manama"
  ]
 },
 "q0643": {
  "q": "Was ist die Hauptstadt dieses Landes: Angola?",
  "a": [
   "Luanda",
   "N’Djamena",
   "Juba",
   "Kinshasa"
  ]
 },
 "q0644": {
  "q": "Was ist die Hauptstadt dieses Landes: Argentinien?",
  "a": [
   "Buenos Aires",
   "Quito",
   "Georgetown",
   "Bogotá"
  ]
 },
 "q0645": {
  "q": "Was ist die Hauptstadt dieses Landes: Österreich?",
  "a": [
   "Wien",
   "Warschau",
   "Ljubljana",
   "Bratislava"
  ]
 },
 "q0646": {
  "q": "Was ist die Hauptstadt dieses Landes: Australien?",
  "a": [
   "Canberra",
   "Wellington",
   "Funafuti",
   "South Tarawa"
  ]
 },
 "q0647": {
  "q": "Was ist die Hauptstadt dieses Landes: Aserbaidschan?",
  "a": [
   "Baku",
   "Abu Dhabi",
   "Ramallah",
   "Jerusalem"
  ]
 },
 "q0648": {
  "q": "Was ist die Hauptstadt dieses Landes: Bosnien und Herzegowina?",
  "a": [
   "Sarajevo",
   "Sofia",
   "Belgrad",
   "Podgorica"
  ]
 },
 "q0649": {
  "q": "Was ist die Hauptstadt dieses Landes: Barbados?",
  "a": [
   "Bridgetown",
   "Port of Spain",
   "Castries",
   "Saint John's"
  ]
 },
 "q0650": {
  "q": "Was ist die Hauptstadt dieses Landes: Bangladesch?",
  "a": [
   "Dhaka",
   "Neu-Delhi",
   "Kabul",
   "Islamabad"
  ]
 },
 "q0651": {
  "q": "Was ist die Hauptstadt dieses Landes: Belgien?",
  "a": [
   "Brüssel",
   "Berlin",
   "Bern",
   "Monaco"
  ]
 },
 "q0652": {
  "q": "Was ist die Hauptstadt dieses Landes: Burkina Faso?",
  "a": [
   "Ouagadougou",
   "Accra",
   "Freetown",
   "Bamako"
  ]
 },
 "q0653": {
  "q": "Was ist die Hauptstadt dieses Landes: Bahrain?",
  "a": [
   "Manama",
   "Kuweit-Stadt",
   "Abu Dhabi",
   "Maskat"
  ]
 },
 "q0654": {
  "q": "Was ist die Hauptstadt dieses Landes: Burundi?",
  "a": [
   "Gitega",
   "Port Louis",
   "Dodoma",
   "Maputo"
  ]
 },
 "q0655": {
  "q": "Was ist die Hauptstadt dieses Landes: Benin?",
  "a": [
   "Porto-Novo",
   "Monrovia",
   "Banjul",
   "Accra"
  ]
 },
 "q0656": {
  "q": "Was ist die Hauptstadt dieses Landes: Brunei?",
  "a": [
   "Bandar Seri Begawan",
   "Phnom Penh",
   "Bangkok",
   "Vientiane"
  ]
 },
 "q0657": {
  "q": "Welche Stadt ist die verfassungsmäßige Hauptstadt Boliviens?",
  "a": [
   "Sucre",
   "Lima",
   "Buenos Aires",
   "Santiago de Chile"
  ]
 },
 "q0658": {
  "q": "Was ist die Hauptstadt dieses Landes: Brasilien?",
  "a": [
   "Brasília",
   "Paramaribo",
   "Buenos Aires",
   "Santiago de Chile"
  ]
 },
 "q0659": {
  "q": "Was ist die Hauptstadt dieses Landes: Bahamas?",
  "a": [
   "Nassau",
   "Port of Spain",
   "Kingston",
   "Santo Domingo"
  ]
 },
 "q0660": {
  "q": "Was ist die Hauptstadt dieses Landes: Bhutan?",
  "a": [
   "Thimphu",
   "Malé",
   "Teheran",
   "Dhaka"
  ]
 },
 "q0661": {
  "q": "Was ist die Hauptstadt dieses Landes: Botswana?",
  "a": [
   "Gaborone",
   "Pretoria",
   "Maseru",
   "Windhoek"
  ]
 },
 "q0662": {
  "q": "Was ist die Hauptstadt dieses Landes: Belarus?",
  "a": [
   "Minsk",
   "Kiew",
   "Kischinau",
   "Moskau"
  ]
 },
 "q0663": {
  "q": "Was ist die Hauptstadt dieses Landes: Belize?",
  "a": [
   "Belmopan",
   "Guatemala-Stadt",
   "Tegucigalpa",
   "San Salvador"
  ]
 },
 "q0664": {
  "q": "Was ist die Hauptstadt dieses Landes: Kanada?",
  "a": [
   "Ottawa",
   "Mexiko-Stadt",
   "Washington, D.C.",
   "Port-au-Prince"
  ]
 },
 "q0665": {
  "q": "Was ist die Hauptstadt dieses Landes: Demokratische Republik Kongo?",
  "a": [
   "Kinshasa",
   "Luanda",
   "N’Djamena",
   "Juba"
  ]
 },
 "q0666": {
  "q": "Was ist die Hauptstadt dieses Landes: Zentralafrikanische Republik?",
  "a": [
   "Bangui",
   "N’Djamena",
   "Yaoundé",
   "São Tomé"
  ]
 },
 "q0667": {
  "q": "Was ist die Hauptstadt dieses Landes: Republik Kongo?",
  "a": [
   "Brazzaville",
   "Juba",
   "N’Djamena",
   "Luanda"
  ]
 },
 "q0668": {
  "q": "Welche Stadt ist die Bundesstadt und der Regierungssitz der Schweiz?",
  "a": [
   "Bern",
   "Berlin",
   "Vaduz",
   "Monaco"
  ]
 },
 "q0669": {
  "q": "Was ist die Hauptstadt dieses Landes: Elfenbeinküste?",
  "a": [
   "Yamoussoukro",
   "Praia",
   "Abuja",
   "Porto-Novo"
  ]
 },
 "q0670": {
  "q": "Was ist die Hauptstadt dieses Landes: Chile?",
  "a": [
   "Santiago de Chile",
   "Paramaribo",
   "Montevideo",
   "Quito"
  ]
 },
 "q0671": {
  "q": "Was ist die Hauptstadt dieses Landes: Kamerun?",
  "a": [
   "Yaoundé",
   "São Tomé",
   "Bangui",
   "N’Djamena"
  ]
 },
 "q0672": {
  "q": "Was ist die Hauptstadt dieses Landes: Volksrepublik China?",
  "a": [
   "Peking",
   "Pjöngjang",
   "Seoul",
   "Tokio"
  ]
 },
 "q0673": {
  "q": "Was ist die Hauptstadt dieses Landes: Kolumbien?",
  "a": [
   "Bogotá",
   "Asunción",
   "Buenos Aires",
   "Sucre"
  ]
 },
 "q0674": {
  "q": "Was ist die Hauptstadt dieses Landes: Costa Rica?",
  "a": [
   "San José",
   "San Salvador",
   "Belmopan",
   "Managua"
  ]
 },
 "q0675": {
  "q": "Was ist die Hauptstadt dieses Landes: Kuba?",
  "a": [
   "Havanna",
   "Santo Domingo",
   "Roseau",
   "Port of Spain"
  ]
 },
 "q0676": {
  "q": "Was ist die Hauptstadt dieses Landes: Kap Verde?",
  "a": [
   "Praia",
   "Accra",
   "Ouagadougou",
   "Conakry"
  ]
 },
 "q0677": {
  "q": "Was ist die Hauptstadt dieses Landes: Zypern?",
  "a": [
   "Nikosia",
   "Andorra la Vella",
   "Madrid",
   "Valletta"
  ]
 },
 "q0678": {
  "q": "Was ist die Hauptstadt dieses Landes: Tschechien?",
  "a": [
   "Prag",
   "Budapest",
   "Ljubljana",
   "Warschau"
  ]
 },
 "q0679": {
  "q": "Was ist die Hauptstadt dieses Landes: Deutschland?",
  "a": [
   "Berlin",
   "Luxemburg",
   "Amsterdam",
   "Monaco"
  ]
 },
 "q0680": {
  "q": "Was ist die Hauptstadt dieses Landes: Dschibuti?",
  "a": [
   "Dschibuti",
   "Harare",
   "Port Louis",
   "Nairobi"
  ]
 },
 "q0681": {
  "q": "Was ist die Hauptstadt dieses Landes: Dänemark?",
  "a": [
   "Kopenhagen",
   "Reykjavík",
   "Oslo",
   "Helsinki"
  ]
 },
 "q0682": {
  "q": "Was ist die Hauptstadt dieses Landes: Dominica?",
  "a": [
   "Roseau",
   "Castries",
   "St. George’s",
   "Saint John's"
  ]
 },
 "q0683": {
  "q": "Was ist die Hauptstadt dieses Landes: Dominikanische Republik?",
  "a": [
   "Santo Domingo",
   "Port of Spain",
   "Kingston",
   "Nassau"
  ]
 },
 "q0684": {
  "q": "Was ist die Hauptstadt dieses Landes: Algerien?",
  "a": [
   "Algier",
   "Tripolis",
   "Rabat",
   "Tunis"
  ]
 },
 "q0685": {
  "q": "Was ist die Hauptstadt dieses Landes: Ecuador?",
  "a": [
   "Quito",
   "Paramaribo",
   "Brasília",
   "Caracas"
  ]
 },
 "q0686": {
  "q": "Was ist die Hauptstadt dieses Landes: Estland?",
  "a": [
   "Tallinn",
   "London",
   "Reykjavík",
   "Stockholm"
  ]
 },
 "q0687": {
  "q": "Was ist die Hauptstadt dieses Landes: Ägypten?",
  "a": [
   "Kairo",
   "Rabat",
   "Chartum",
   "Tunis"
  ]
 },
 "q0688": {
  "q": "Was ist die Hauptstadt dieses Landes: Eritrea?",
  "a": [
   "Asmara",
   "Lilongwe",
   "Addis Abeba",
   "Lusaka"
  ]
 },
 "q0689": {
  "q": "Was ist die Hauptstadt dieses Landes: Spanien?",
  "a": [
   "Madrid",
   "Rom",
   "Andorra la Vella",
   "San Marino"
  ]
 },
 "q0690": {
  "q": "Was ist die Hauptstadt dieses Landes: Äthiopien?",
  "a": [
   "Addis Abeba",
   "Moroni",
   "Maputo",
   "Mogadischu"
  ]
 },
 "q0691": {
  "q": "Was ist die Hauptstadt dieses Landes: Finnland?",
  "a": [
   "Helsinki",
   "Riga",
   "Reykjavík",
   "Stockholm"
  ]
 },
 "q0692": {
  "q": "Was ist die Hauptstadt dieses Landes: Fidschi?",
  "a": [
   "Suva",
   "Honiara",
   "Port Vila",
   "Port Moresby"
  ]
 },
 "q0693": {
  "q": "Was ist die Hauptstadt dieses Landes: Föderierte Staaten von Mikronesien?",
  "a": [
   "Palikir",
   "South Tarawa",
   "Majuro",
   "Yaren"
  ]
 },
 "q0694": {
  "q": "Was ist die Hauptstadt dieses Landes: Frankreich?",
  "a": [
   "Paris",
   "Brüssel",
   "Luxemburg",
   "Berlin"
  ]
 },
 "q0695": {
  "q": "Was ist die Hauptstadt dieses Landes: Gabun?",
  "a": [
   "Libreville",
   "Luanda",
   "São Tomé",
   "Juba"
  ]
 },
 "q0696": {
  "q": "Was ist die Hauptstadt dieses Landes: Vereinigtes Königreich?",
  "a": [
   "London",
   "Riga",
   "Kopenhagen",
   "Helsinki"
  ]
 },
 "q0697": {
  "q": "Was ist die Hauptstadt dieses Landes: Grenada?",
  "a": [
   "St. George’s",
   "Kingston",
   "Havanna",
   "Port of Spain"
  ]
 },
 "q0698": {
  "q": "Was ist die Hauptstadt dieses Landes: Georgien?",
  "a": [
   "Tiflis",
   "Damaskus",
   "Jerusalem",
   "Baku"
  ]
 },
 "q0699": {
  "q": "Was ist die Hauptstadt dieses Landes: Ghana?",
  "a": [
   "Accra",
   "Ouagadougou",
   "Freetown",
   "Monrovia"
  ]
 },
 "q0700": {
  "q": "Was ist die Hauptstadt dieses Landes: Gambia?",
  "a": [
   "Banjul",
   "Porto-Novo",
   "Praia",
   "Monrovia"
  ]
 },
 "q0701": {
  "q": "Was ist die Hauptstadt dieses Landes: Guinea?",
  "a": [
   "Conakry",
   "Nouakchott",
   "Yamoussoukro",
   "Freetown"
  ]
 },
 "q0702": {
  "q": "Was ist die Hauptstadt dieses Landes: Äquatorialguinea?",
  "a": [
   "Ciudad de la Paz",
   "São Tomé",
   "N’Djamena",
   "Yaoundé"
  ]
 },
 "q0703": {
  "q": "Was ist die Hauptstadt dieses Landes: Griechenland?",
  "a": [
   "Athen",
   "Rom",
   "Madrid",
   "Andorra la Vella"
  ]
 },
 "q0704": {
  "q": "Was ist die Hauptstadt dieses Landes: Guatemala?",
  "a": [
   "Guatemala-Stadt",
   "Managua",
   "Belmopan",
   "San Salvador"
  ]
 },
 "q0705": {
  "q": "Was ist die Hauptstadt dieses Landes: Guinea-Bissau?",
  "a": [
   "Bissau",
   "Lomé",
   "Niamey",
   "Dakar"
  ]
 },
 "q0706": {
  "q": "Was ist die Hauptstadt dieses Landes: Guyana?",
  "a": [
   "Georgetown",
   "Caracas",
   "Montevideo",
   "Brasília"
  ]
 },
 "q0707": {
  "q": "Was ist die Hauptstadt dieses Landes: Honduras?",
  "a": [
   "Tegucigalpa",
   "Managua",
   "Panama-Stadt",
   "San Salvador"
  ]
 },
 "q0708": {
  "q": "Was ist die Hauptstadt dieses Landes: Kroatien?",
  "a": [
   "Zagreb",
   "Belgrad",
   "Skopje",
   "Tirana"
  ]
 },
 "q0709": {
  "q": "Was ist die Hauptstadt dieses Landes: Haiti?",
  "a": [
   "Port-au-Prince",
   "Roseau",
   "Kingston",
   "Havanna"
  ]
 },
 "q0710": {
  "q": "Was ist die Hauptstadt dieses Landes: Ungarn?",
  "a": [
   "Budapest",
   "Ljubljana",
   "Wien",
   "Prag"
  ]
 },
 "q0711": {
  "q": "Was ist die Hauptstadt dieses Landes: Indonesien?",
  "a": [
   "Jakarta",
   "Naypyidaw",
   "Kuala Lumpur",
   "Manila"
  ]
 },
 "q0712": {
  "q": "Was ist die Hauptstadt dieses Landes: Irland?",
  "a": [
   "Dublin",
   "Vilnius",
   "Riga",
   "Reykjavík"
  ]
 },
 "q0713": {
  "q": "Was ist die Hauptstadt dieses Landes: Israel?",
  "a": [
   "Jerusalem",
   "Damaskus",
   "Riad",
   "Manama"
  ]
 },
 "q0714": {
  "q": "Was ist die Hauptstadt dieses Landes: Indien?",
  "a": [
   "Neu-Delhi",
   "Kabul",
   "Dhaka",
   "Teheran"
  ]
 },
 "q0715": {
  "q": "Was ist die Hauptstadt dieses Landes: Irak?",
  "a": [
   "Bagdad",
   "Tiflis",
   "Manama",
   "Riad"
  ]
 },
 "q0716": {
  "q": "Was ist die Hauptstadt dieses Landes: Iran?",
  "a": [
   "Teheran",
   "Neu-Delhi",
   "Islamabad",
   "Kabul"
  ]
 },
 "q0717": {
  "q": "Was ist die Hauptstadt dieses Landes: Island?",
  "a": [
   "Reykjavík",
   "Kopenhagen",
   "Vilnius",
   "London"
  ]
 },
 "q0718": {
  "q": "Was ist die Hauptstadt dieses Landes: Italien?",
  "a": [
   "Rom",
   "Madrid",
   "Nikosia",
   "Andorra la Vella"
  ]
 },
 "q0719": {
  "q": "Was ist die Hauptstadt dieses Landes: Jamaika?",
  "a": [
   "Kingston",
   "Nassau",
   "Santo Domingo",
   "Bridgetown"
  ]
 },
 "q0720": {
  "q": "Was ist die Hauptstadt dieses Landes: Jordanien?",
  "a": [
   "Amman",
   "Tiflis",
   "Maskat",
   "Beirut"
  ]
 },
 "q0721": {
  "q": "Was ist die Hauptstadt dieses Landes: Japan?",
  "a": [
   "Tokio",
   "Seoul",
   "Peking",
   "Pjöngjang"
  ]
 },
 "q0722": {
  "q": "Was ist die Hauptstadt dieses Landes: Kenia?",
  "a": [
   "Nairobi",
   "Dschibuti",
   "Maputo",
   "Asmara"
  ]
 },
 "q0723": {
  "q": "Was ist die Hauptstadt dieses Landes: Kirgisistan?",
  "a": [
   "Bischkek",
   "Duschanbe",
   "Astana",
   "Taschkent"
  ]
 },
 "q0724": {
  "q": "Was ist die Hauptstadt dieses Landes: Kambodscha?",
  "a": [
   "Phnom Penh",
   "Hanoi",
   "Bandar Seri Begawan",
   "Bangkok"
  ]
 },
 "q0725": {
  "q": "Was ist die Hauptstadt dieses Landes: Kiribati?",
  "a": [
   "South Tarawa",
   "Yaren",
   "Palikir",
   "Ngerulmud"
  ]
 },
 "q0726": {
  "q": "Was ist die Hauptstadt dieses Landes: Komoren?",
  "a": [
   "Moroni",
   "Asmara",
   "Addis Abeba",
   "Nairobi"
  ]
 },
 "q0727": {
  "q": "Was ist die Hauptstadt dieses Landes: St. Kitts und Nevis?",
  "a": [
   "Basseterre",
   "Saint John's",
   "Roseau",
   "Nassau"
  ]
 },
 "q0728": {
  "q": "Was ist die Hauptstadt dieses Landes: Nordkorea?",
  "a": [
   "Pjöngjang",
   "Tokio",
   "Seoul",
   "Ulaanbaatar"
  ]
 },
 "q0729": {
  "q": "Was ist die Hauptstadt dieses Landes: Südkorea?",
  "a": [
   "Seoul",
   "Tokio",
   "Pjöngjang",
   "Ulaanbaatar"
  ]
 },
 "q0730": {
  "q": "Was ist die Hauptstadt dieses Landes: Kuwait?",
  "a": [
   "Kuweit-Stadt",
   "Jerewan",
   "Bagdad",
   "Jerusalem"
  ]
 },
 "q0731": {
  "q": "Was ist die Hauptstadt dieses Landes: Kasachstan?",
  "a": [
   "Astana",
   "Bischkek",
   "Aşgabat",
   "Duschanbe"
  ]
 },
 "q0732": {
  "q": "Was ist die Hauptstadt dieses Landes: Laos?",
  "a": [
   "Vientiane",
   "Bangkok",
   "Kuala Lumpur",
   "Singapur"
  ]
 },
 "q0733": {
  "q": "Was ist die Hauptstadt dieses Landes: Libanon?",
  "a": [
   "Beirut",
   "Riad",
   "Ramallah",
   "Baku"
  ]
 },
 "q0734": {
  "q": "Was ist die Hauptstadt dieses Landes: St. Lucia?",
  "a": [
   "Castries",
   "Roseau",
   "Nassau",
   "Havanna"
  ]
 },
 "q0735": {
  "q": "Was ist die Hauptstadt dieses Landes: Liechtenstein?",
  "a": [
   "Vaduz",
   "Monaco",
   "Brüssel",
   "Berlin"
  ]
 },
 "q0736": {
  "q": "Welche Stadt ist die legislative Hauptstadt Sri Lankas?",
  "a": [
   "Sri Jayewardenepura Kotte",
   "Dhaka",
   "Kabul",
   "Islamabad"
  ]
 },
 "q0737": {
  "q": "Was ist die Hauptstadt dieses Landes: Liberia?",
  "a": [
   "Monrovia",
   "Freetown",
   "Yamoussoukro",
   "Abuja"
  ]
 },
 "q0738": {
  "q": "Was ist die Hauptstadt dieses Landes: Lesotho?",
  "a": [
   "Maseru",
   "Windhoek",
   "Mbabane",
   "Gaborone"
  ]
 },
 "q0739": {
  "q": "Was ist die Hauptstadt dieses Landes: Litauen?",
  "a": [
   "Vilnius",
   "Oslo",
   "Kopenhagen",
   "Reykjavík"
  ]
 },
 "q0740": {
  "q": "Was ist die Hauptstadt dieses Landes: Luxemburg?",
  "a": [
   "Luxemburg",
   "Paris",
   "Vaduz",
   "Bern"
  ]
 },
 "q0741": {
  "q": "Was ist die Hauptstadt dieses Landes: Lettland?",
  "a": [
   "Riga",
   "Stockholm",
   "Oslo",
   "Dublin"
  ]
 },
 "q0742": {
  "q": "Was ist die Hauptstadt dieses Landes: Libyen?",
  "a": [
   "Tripolis",
   "Chartum",
   "Kairo",
   "Algier"
  ]
 },
 "q0743": {
  "q": "Was ist die Hauptstadt dieses Landes: Marokko?",
  "a": [
   "Rabat",
   "Kairo",
   "Chartum",
   "Algier"
  ]
 },
 "q0744": {
  "q": "Was ist die Hauptstadt dieses Landes: Monaco?",
  "a": [
   "Monaco",
   "Brüssel",
   "Paris",
   "Bern"
  ]
 },
 "q0745": {
  "q": "Was ist die Hauptstadt dieses Landes: Moldau?",
  "a": [
   "Kischinau",
   "Kiew",
   "Minsk",
   "Moskau"
  ]
 },
 "q0746": {
  "q": "Was ist die Hauptstadt dieses Landes: Montenegro?",
  "a": [
   "Podgorica",
   "Belgrad",
   "Zagreb",
   "Bukarest"
  ]
 },
 "q0747": {
  "q": "Was ist die Hauptstadt dieses Landes: Madagaskar?",
  "a": [
   "Antananarivo",
   "Dschibuti",
   "Nairobi",
   "Lusaka"
  ]
 },
 "q0748": {
  "q": "Was ist die Hauptstadt dieses Landes: Marshallinseln?",
  "a": [
   "Majuro",
   "South Tarawa",
   "Ngerulmud",
   "Yaren"
  ]
 },
 "q0749": {
  "q": "Was ist die Hauptstadt dieses Landes: Nordmazedonien?",
  "a": [
   "Skopje",
   "Bukarest",
   "Zagreb",
   "Sarajevo"
  ]
 },
 "q0750": {
  "q": "Was ist die Hauptstadt dieses Landes: Mali?",
  "a": [
   "Bamako",
   "Abuja",
   "Nouakchott",
   "Bissau"
  ]
 },
 "q0751": {
  "q": "Was ist die Hauptstadt dieses Landes: Myanmar?",
  "a": [
   "Naypyidaw",
   "Kuala Lumpur",
   "Hanoi",
   "Singapur"
  ]
 },
 "q0752": {
  "q": "Was ist die Hauptstadt dieses Landes: Mongolei?",
  "a": [
   "Ulaanbaatar",
   "Tokio",
   "Pjöngjang",
   "Seoul"
  ]
 },
 "q0753": {
  "q": "Was ist die Hauptstadt dieses Landes: Mauretanien?",
  "a": [
   "Nouakchott",
   "Lomé",
   "Freetown",
   "Yamoussoukro"
  ]
 },
 "q0754": {
  "q": "Was ist die Hauptstadt dieses Landes: Malta?",
  "a": [
   "Valletta",
   "Madrid",
   "Rom",
   "Andorra la Vella"
  ]
 },
 "q0755": {
  "q": "Was ist die Hauptstadt dieses Landes: Mauritius?",
  "a": [
   "Port Louis",
   "Victoria",
   "Kampala",
   "Asmara"
  ]
 },
 "q0756": {
  "q": "Was ist die Hauptstadt dieses Landes: Malediven?",
  "a": [
   "Malé",
   "Kabul",
   "Teheran",
   "Kathmandu"
  ]
 },
 "q0757": {
  "q": "Was ist die Hauptstadt dieses Landes: Malawi?",
  "a": [
   "Lilongwe",
   "Kigali",
   "Nairobi",
   "Moroni"
  ]
 },
 "q0758": {
  "q": "Was ist die Hauptstadt dieses Landes: Mexiko?",
  "a": [
   "Mexiko-Stadt",
   "Ottawa",
   "Washington, D.C.",
   "Bridgetown"
  ]
 },
 "q0759": {
  "q": "Was ist die Hauptstadt dieses Landes: Malaysia?",
  "a": [
   "Kuala Lumpur",
   "Phnom Penh",
   "Naypyidaw",
   "Hanoi"
  ]
 },
 "q0760": {
  "q": "Was ist die Hauptstadt dieses Landes: Mosambik?",
  "a": [
   "Maputo",
   "Asmara",
   "Harare",
   "Addis Abeba"
  ]
 },
 "q0761": {
  "q": "Was ist die Hauptstadt dieses Landes: Namibia?",
  "a": [
   "Windhoek",
   "Pretoria",
   "Mbabane",
   "Gaborone"
  ]
 },
 "q0762": {
  "q": "Was ist die Hauptstadt dieses Landes: Niger?",
  "a": [
   "Niamey",
   "Monrovia",
   "Dakar",
   "Nouakchott"
  ]
 },
 "q0763": {
  "q": "Was ist die Hauptstadt dieses Landes: Nigeria?",
  "a": [
   "Abuja",
   "Yamoussoukro",
   "Porto-Novo",
   "Lomé"
  ]
 },
 "q0764": {
  "q": "Was ist die Hauptstadt dieses Landes: Nicaragua?",
  "a": [
   "Managua",
   "Belmopan",
   "Tegucigalpa",
   "San Salvador"
  ]
 },
 "q0765": {
  "q": "Was ist die Hauptstadt dieses Landes: Königreich der Niederlande?",
  "a": [
   "Amsterdam",
   "Brüssel",
   "Luxemburg",
   "Berlin"
  ]
 },
 "q0766": {
  "q": "Was ist die Hauptstadt dieses Landes: Norwegen?",
  "a": [
   "Oslo",
   "Reykjavík",
   "Stockholm",
   "Kopenhagen"
  ]
 },
 "q0767": {
  "q": "Was ist die Hauptstadt dieses Landes: Nepal?",
  "a": [
   "Kathmandu",
   "Kabul",
   "Dhaka",
   "Teheran"
  ]
 },
 "q0768": {
  "q": "In welchem Bezirk Naurus befinden sich die Regierungsbüros, da das Land keine offizielle Hauptstadt hat?",
  "a": [
   "Yaren",
   "Ngerulmud",
   "Palikir",
   "South Tarawa"
  ]
 },
 "q0769": {
  "q": "Was ist die Hauptstadt dieses Landes: Neuseeland?",
  "a": [
   "Wellington",
   "Canberra",
   "Suva",
   "Majuro"
  ]
 },
 "q0770": {
  "q": "Was ist die Hauptstadt dieses Landes: Oman?",
  "a": [
   "Maskat",
   "Bagdad",
   "Ankara",
   "Amman"
  ]
 },
 "q0771": {
  "q": "Was ist die Hauptstadt dieses Landes: Panama?",
  "a": [
   "Panama-Stadt",
   "Managua",
   "Tegucigalpa",
   "San Salvador"
  ]
 },
 "q0772": {
  "q": "Was ist die Hauptstadt dieses Landes: Peru?",
  "a": [
   "Lima",
   "Buenos Aires",
   "Paramaribo",
   "Georgetown"
  ]
 },
 "q0773": {
  "q": "Was ist die Hauptstadt dieses Landes: Papua-Neuguinea?",
  "a": [
   "Port Moresby",
   "Honiara",
   "Suva",
   "Port Vila"
  ]
 },
 "q0774": {
  "q": "Was ist die Hauptstadt dieses Landes: Philippinen?",
  "a": [
   "Manila",
   "Bandar Seri Begawan",
   "Singapur",
   "Vientiane"
  ]
 },
 "q0775": {
  "q": "Was ist die Hauptstadt dieses Landes: Pakistan?",
  "a": [
   "Islamabad",
   "Kabul",
   "Sri Jayewardenepura Kotte",
   "Dhaka"
  ]
 },
 "q0776": {
  "q": "Was ist die Hauptstadt dieses Landes: Polen?",
  "a": [
   "Warschau",
   "Prag",
   "Bratislava",
   "Budapest"
  ]
 },
 "q0777": {
  "q": "Welche Stadt ist das Verwaltungszentrum der Palästinensischen Autonomiebehörde?",
  "a": [
   "Ramallah",
   "Kuweit-Stadt",
   "Jerewan",
   "Bagdad"
  ]
 },
 "q0778": {
  "q": "Was ist die Hauptstadt dieses Landes: Portugal?",
  "a": [
   "Lissabon",
   "Nikosia",
   "Valletta",
   "Rom"
  ]
 },
 "q0779": {
  "q": "Was ist die Hauptstadt dieses Landes: Palau?",
  "a": [
   "Ngerulmud",
   "South Tarawa",
   "Majuro",
   "Yaren"
  ]
 },
 "q0780": {
  "q": "Was ist die Hauptstadt dieses Landes: Paraguay?",
  "a": [
   "Asunción",
   "Bogotá",
   "Brasília",
   "Quito"
  ]
 },
 "q0781": {
  "q": "Was ist die Hauptstadt dieses Landes: Katar?",
  "a": [
   "Doha",
   "Ramallah",
   "Baku",
   "Maskat"
  ]
 },
 "q0782": {
  "q": "Was ist die Hauptstadt dieses Landes: Rumänien?",
  "a": [
   "Bukarest",
   "Zagreb",
   "Sarajevo",
   "Podgorica"
  ]
 },
 "q0783": {
  "q": "Was ist die Hauptstadt dieses Landes: Serbien?",
  "a": [
   "Belgrad",
   "Tirana",
   "Zagreb",
   "Sofia"
  ]
 },
 "q0784": {
  "q": "Was ist die Hauptstadt dieses Landes: Russland?",
  "a": [
   "Moskau",
   "Kiew",
   "Kischinau",
   "Minsk"
  ]
 },
 "q0785": {
  "q": "Was ist die Hauptstadt dieses Landes: Ruanda?",
  "a": [
   "Kigali",
   "Moroni",
   "Gitega",
   "Maputo"
  ]
 },
 "q0786": {
  "q": "Was ist die Hauptstadt dieses Landes: Saudi-Arabien?",
  "a": [
   "Riad",
   "Bagdad",
   "Kuweit-Stadt",
   "Damaskus"
  ]
 },
 "q0787": {
  "q": "Was ist die Hauptstadt dieses Landes: Salomonen?",
  "a": [
   "Honiara",
   "Suva",
   "Port Vila",
   "Port Moresby"
  ]
 },
 "q0788": {
  "q": "Was ist die Hauptstadt dieses Landes: Seychellen?",
  "a": [
   "Victoria",
   "Asmara",
   "Lilongwe",
   "Dodoma"
  ]
 },
 "q0789": {
  "q": "Was ist die Hauptstadt dieses Landes: Sudan?",
  "a": [
   "Chartum",
   "Rabat",
   "Tunis",
   "Tripolis"
  ]
 },
 "q0790": {
  "q": "Was ist die Hauptstadt dieses Landes: Schweden?",
  "a": [
   "Stockholm",
   "Oslo",
   "Helsinki",
   "Dublin"
  ]
 },
 "q0791": {
  "q": "Was ist die Hauptstadt dieses Landes: Singapur?",
  "a": [
   "Singapur",
   "Vientiane",
   "Jakarta",
   "Bandar Seri Begawan"
  ]
 },
 "q0792": {
  "q": "Was ist die Hauptstadt dieses Landes: Slowenien?",
  "a": [
   "Ljubljana",
   "Bratislava",
   "Warschau",
   "Prag"
  ]
 },
 "q0793": {
  "q": "Was ist die Hauptstadt dieses Landes: Slowakei?",
  "a": [
   "Bratislava",
   "Prag",
   "Warschau",
   "Wien"
  ]
 },
 "q0794": {
  "q": "Was ist die Hauptstadt dieses Landes: Sierra Leone?",
  "a": [
   "Freetown",
   "Monrovia",
   "Yamoussoukro",
   "Porto-Novo"
  ]
 },
 "q0795": {
  "q": "Was ist die Hauptstadt dieses Landes: San Marino?",
  "a": [
   "San Marino",
   "Lissabon",
   "Madrid",
   "Nikosia"
  ]
 },
 "q0796": {
  "q": "Was ist die Hauptstadt dieses Landes: Senegal?",
  "a": [
   "Dakar",
   "Monrovia",
   "Banjul",
   "Bissau"
  ]
 },
 "q0797": {
  "q": "Was ist die Hauptstadt dieses Landes: Somalia?",
  "a": [
   "Mogadischu",
   "Lilongwe",
   "Addis Abeba",
   "Nairobi"
  ]
 },
 "q0798": {
  "q": "Was ist die Hauptstadt dieses Landes: Suriname?",
  "a": [
   "Paramaribo",
   "Lima",
   "Sucre",
   "Brasília"
  ]
 },
 "q0799": {
  "q": "Was ist die Hauptstadt dieses Landes: Südsudan?",
  "a": [
   "Juba",
   "Luanda",
   "Kinshasa",
   "Bangui"
  ]
 },
 "q0800": {
  "q": "Was ist die Hauptstadt dieses Landes: São Tomé und Príncipe?",
  "a": [
   "São Tomé",
   "Libreville",
   "Kinshasa",
   "Bangui"
  ]
 },
 "q0801": {
  "q": "Was ist die Hauptstadt dieses Landes: El Salvador?",
  "a": [
   "San Salvador",
   "San José",
   "Managua",
   "Guatemala-Stadt"
  ]
 },
 "q0802": {
  "q": "Was ist die Hauptstadt dieses Landes: Syrien?",
  "a": [
   "Damaskus",
   "Manama",
   "Doha",
   "Amman"
  ]
 },
 "q0803": {
  "q": "Welche Stadt ist die Verwaltungshauptstadt Eswatinis?",
  "a": [
   "Mbabane",
   "Windhoek",
   "Gaborone",
   "Pretoria"
  ]
 },
 "q0804": {
  "q": "Was ist die Hauptstadt dieses Landes: Tschad?",
  "a": [
   "N’Djamena",
   "Juba",
   "Brazzaville",
   "Kinshasa"
  ]
 },
 "q0805": {
  "q": "Was ist die Hauptstadt dieses Landes: Togo?",
  "a": [
   "Lomé",
   "Porto-Novo",
   "Abuja",
   "Bamako"
  ]
 },
 "q0806": {
  "q": "Was ist die Hauptstadt dieses Landes: Thailand?",
  "a": [
   "Bangkok",
   "Bandar Seri Begawan",
   "Naypyidaw",
   "Manila"
  ]
 },
 "q0807": {
  "q": "Was ist die Hauptstadt dieses Landes: Tadschikistan?",
  "a": [
   "Duschanbe",
   "Taschkent",
   "Astana",
   "Aşgabat"
  ]
 },
 "q0808": {
  "q": "Was ist die Hauptstadt dieses Landes: Osttimor?",
  "a": [
   "Dili",
   "Kuala Lumpur",
   "Vientiane",
   "Bandar Seri Begawan"
  ]
 },
 "q0809": {
  "q": "Was ist die Hauptstadt dieses Landes: Turkmenistan?",
  "a": [
   "Aşgabat",
   "Astana",
   "Bischkek",
   "Taschkent"
  ]
 },
 "q0810": {
  "q": "Was ist die Hauptstadt dieses Landes: Tunesien?",
  "a": [
   "Tunis",
   "Tripolis",
   "Chartum",
   "Algier"
  ]
 },
 "q0811": {
  "q": "Was ist die Hauptstadt dieses Landes: Tonga?",
  "a": [
   "Nukuʻalofa",
   "Apia",
   "Funafuti",
   "Port Moresby"
  ]
 },
 "q0812": {
  "q": "Was ist die Hauptstadt dieses Landes: Türkei?",
  "a": [
   "Ankara",
   "Jerewan",
   "Manama",
   "Kuweit-Stadt"
  ]
 },
 "q0813": {
  "q": "Was ist die Hauptstadt dieses Landes: Trinidad und Tobago?",
  "a": [
   "Port of Spain",
   "Basseterre",
   "Roseau",
   "Port-au-Prince"
  ]
 },
 "q0814": {
  "q": "Was ist die Hauptstadt dieses Landes: Tuvalu?",
  "a": [
   "Funafuti",
   "Nukuʻalofa",
   "Apia",
   "Yaren"
  ]
 },
 "q0815": {
  "q": "Was ist die Hauptstadt dieses Landes: Tansania?",
  "a": [
   "Dodoma",
   "Victoria",
   "Lilongwe",
   "Nairobi"
  ]
 },
 "q0816": {
  "q": "Was ist die Hauptstadt dieses Landes: Ukraine?",
  "a": [
   "Kiew",
   "Kischinau",
   "Minsk",
   "Moskau"
  ]
 },
 "q0817": {
  "q": "Was ist die Hauptstadt dieses Landes: Uganda?",
  "a": [
   "Kampala",
   "Gitega",
   "Victoria",
   "Dodoma"
  ]
 },
 "q0818": {
  "q": "Was ist die Hauptstadt dieses Landes: Vereinigte Staaten?",
  "a": [
   "Washington, D.C.",
   "Ottawa",
   "Mexiko-Stadt",
   "Belmopan"
  ]
 },
 "q0819": {
  "q": "Was ist die Hauptstadt dieses Landes: Uruguay?",
  "a": [
   "Montevideo",
   "Lima",
   "Sucre",
   "Caracas"
  ]
 },
 "q0820": {
  "q": "Was ist die Hauptstadt dieses Landes: Usbekistan?",
  "a": [
   "Taschkent",
   "Astana",
   "Bischkek",
   "Aşgabat"
  ]
 },
 "q0821": {
  "q": "Was ist die Hauptstadt dieses Landes: Vatikanstadt?",
  "a": [
   "Vatikanstadt",
   "Valletta",
   "Athen",
   "Nikosia"
  ]
 },
 "q0822": {
  "q": "Was ist die Hauptstadt dieses Landes: St. Vincent und die Grenadinen?",
  "a": [
   "Kingstown",
   "Castries",
   "Havanna",
   "Roseau"
  ]
 },
 "q0823": {
  "q": "Was ist die Hauptstadt dieses Landes: Venezuela?",
  "a": [
   "Caracas",
   "Bogotá",
   "Lima",
   "Sucre"
  ]
 },
 "q0824": {
  "q": "Was ist die Hauptstadt dieses Landes: Vietnam?",
  "a": [
   "Hanoi",
   "Bangkok",
   "Dili",
   "Manila"
  ]
 },
 "q0825": {
  "q": "Was ist die Hauptstadt dieses Landes: Vanuatu?",
  "a": [
   "Port Vila",
   "Suva",
   "Port Moresby",
   "Honiara"
  ]
 },
 "q0826": {
  "q": "Was ist die Hauptstadt dieses Landes: Samoa?",
  "a": [
   "Apia",
   "Funafuti",
   "Nukuʻalofa",
   "Ngerulmud"
  ]
 },
 "q0827": {
  "q": "Welche Stadt ist die verfassungsmäßige Hauptstadt Jemens?",
  "a": [
   "Sanaa",
   "Baku",
   "Ramallah",
   "Abu Dhabi"
  ]
 },
 "q0828": {
  "q": "Welche Stadt ist die Verwaltungshauptstadt Südafrikas?",
  "a": [
   "Pretoria",
   "Mbabane",
   "Windhoek",
   "Gaborone"
  ]
 },
 "q0829": {
  "q": "Was ist die Hauptstadt dieses Landes: Sambia?",
  "a": [
   "Lusaka",
   "Victoria",
   "Dschibuti",
   "Kigali"
  ]
 },
 "q0830": {
  "q": "Was ist die Hauptstadt dieses Landes: Simbabwe?",
  "a": [
   "Harare",
   "Kigali",
   "Mogadischu",
   "Dschibuti"
  ]
 },
 "q0831": {
  "q": "Welche Landesflagge zeigt weißes Feld und roter Kreis?",
  "a": [
   "Japan",
   "Marshallinseln",
   "Jordanien",
   "Botswana"
  ]
 },
 "q0832": {
  "q": "Welche Landesflagge zeigt rotes Ahornblatt?",
  "a": [
   "Kanada",
   "Südsudan",
   "Guinea",
   "Uganda"
  ]
 },
 "q0833": {
  "q": "Welche Landesflagge zeigt grünes Feld, gelbe Raute und blauer Kreis?",
  "a": [
   "Brasilien",
   "Eritrea",
   "Guyana",
   "Kirgisistan"
  ]
 },
 "q0834": {
  "q": "Welche Landesflagge zeigt weißes Kreuz auf rotem Feld?",
  "a": [
   "Schweiz",
   "Kasachstan",
   "Libyen",
   "Mauretanien"
  ]
 },
 "q0835": {
  "q": "Welche Landesflagge zeigt rote und weiße überlagerte Kreuze auf blauem Grund?",
  "a": [
   "Vereinigtes Königreich",
   "Usbekistan",
   "Kirgisistan",
   "Suriname"
  ]
 },
 "q0836": {
  "q": "Welche Landesflagge zeigt Sterne und rot-weiße Streifen?",
  "a": [
   "Vereinigte Staaten",
   "Gambia",
   "Osttimor",
   "Komoren"
  ]
 },
 "q0837": {
  "q": "Welche Landesflagge zeigt weißer Halbmond und Stern auf rotem Grund?",
  "a": [
   "Türkei",
   "Myanmar",
   "Nordmazedonien",
   "Naoero"
  ]
 },
 "q0838": {
  "q": "Welche Landesflagge zeigt fünf gelbe Sterne auf rotem Grund?",
  "a": [
   "Volksrepublik China",
   "Tuvalu",
   "Honduras",
   "Sri Lanka"
  ]
 },
 "q0839": {
  "q": "Welche Landesflagge zeigt orange, weiße und grüne Streifen und ein blaues Rad?",
  "a": [
   "Indien",
   "Trinidad und Tobago",
   "Malawi",
   "Nicaragua"
  ]
 },
 "q0840": {
  "q": "Welche Landesflagge zeigt rot-blauer Kreis und schwarze Trigramme auf weißem Grund?",
  "a": [
   "Südkorea",
   "Vanuatu",
   "Nicaragua",
   "Senegal"
  ]
 },
 "q0841": {
  "q": "Welche Landesflagge zeigt blauer sechszackiger Stern zwischen zwei blauen Streifen?",
  "a": [
   "Israel",
   "Papua-Neuguinea",
   "Malta",
   "São Tomé und Príncipe"
  ]
 },
 "q0842": {
  "q": "Welche Landesflagge zeigt blaue und weiße Streifen und weißes Kreuz in blauem Quadrat?",
  "a": [
   "Griechenland",
   "Malta",
   "Burundi",
   "Nigeria"
  ]
 },
 "q0843": {
  "q": "Welche Landesflagge zeigt ein großer gelber Stern auf rotem Grund?",
  "a": [
   "Vietnam",
   "Kap Verde",
   "Belize",
   "Saudi-Arabien"
  ]
 },
 "q0844": {
  "q": "Welche Landesflagge zeigt grüner fünfzackiger Stern auf rotem Grund?",
  "a": [
   "Marokko",
   "El Salvador",
   "Bahamas",
   "Tuvalu"
  ]
 },
 "q0845": {
  "q": "Welche Landesflagge zeigt zwei waagerechte Streifen: blau über gelb?",
  "a": [
   "Ukraine",
   "Kap Verde",
   "Naoero",
   "Sudan"
  ]
 },
 "q0846": {
  "q": "Welche Landesflagge zeigt drei senkrechte Streifen: blau, weiß und rot von links nach rechts?",
  "a": [
   "Frankreich",
   "Mauritius",
   "Costa Rica",
   "Föderierte Staaten von Mikronesien"
  ]
 },
 "q0847": {
  "q": "Welche Landesflagge zeigt drei senkrechte Streifen: grün, weiß und rot von links nach rechts?",
  "a": [
   "Italien",
   "Somalia",
   "Moldau",
   "Nigeria"
  ]
 },
 "q0848": {
  "q": "Welche Landesflagge zeigt drei waagerechte Streifen: weiß, grün und rot von oben nach unten?",
  "a": [
   "Bulgarien",
   "Demokratische Republik Kongo",
   "Libanon",
   "Dominica"
  ]
 },
 "q0849": {
  "q": "Welche Landesflagge zeigt drei waagerechte Streifen: schwarz, rot und gold von oben nach unten?",
  "a": [
   "Deutschland",
   "Nepal",
   "Österreich",
   "Bahamas"
  ]
 },
 "q0850": {
  "q": "Welche Landesflagge zeigt hellblaue und weiße waagerechte Streifen und eine Sonne?",
  "a": [
   "Argentinien",
   "Paraguay",
   "Costa Rica",
   "Nepal"
  ]
 },
 "q0851": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Kanada? (2024)",
  "a": [
   "41 000 000",
   "4 100 000",
   "12 000 000",
   "120 000 000"
  ]
 },
 "q0852": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Japan? (2024)",
  "a": [
   "120 000 000",
   "12 000 000",
   "37 000 000",
   "370 000 000"
  ]
 },
 "q0853": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Norwegen? (2024)",
  "a": [
   "5 600 000",
   "560 000",
   "1 700 000",
   "17 000 000"
  ]
 },
 "q0854": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Irland? (2024)",
  "a": [
   "5 400 000",
   "540 000",
   "1 600 000",
   "16 000 000"
  ]
 },
 "q0855": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Ungarn? (2024)",
  "a": [
   "9 600 000",
   "960 000",
   "2 900 000",
   "29 000 000"
  ]
 },
 "q0856": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Spanien? (2024)",
  "a": [
   "49 000 000",
   "4 900 000",
   "15 000 000",
   "150 000 000"
  ]
 },
 "q0857": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Vereinigte Staaten? (2024)",
  "a": [
   "340 000 000",
   "34 000 000",
   "100 000 000",
   "1 000 000 000"
  ]
 },
 "q0858": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Belgien? (2024)",
  "a": [
   "12 000 000",
   "1 200 000",
   "3 600 000",
   "36 000 000"
  ]
 },
 "q0859": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Luxemburg? (2024)",
  "a": [
   "680 000",
   "68 000",
   "200 000",
   "2 000 000"
  ]
 },
 "q0860": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Finnland? (2024)",
  "a": [
   "5 600 000",
   "560 000",
   "1 700 000",
   "17 000 000"
  ]
 },
 "q0861": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Schweden? (2024)",
  "a": [
   "11 000 000",
   "1 100 000",
   "3 200 000",
   "32 000 000"
  ]
 },
 "q0862": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Polen? (2024)",
  "a": [
   "37 000 000",
   "3 700 000",
   "11 000 000",
   "110 000 000"
  ]
 },
 "q0863": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Litauen? (2024)",
  "a": [
   "2 900 000",
   "290 000",
   "870 000",
   "8 700 000"
  ]
 },
 "q0864": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Italien? (2024)",
  "a": [
   "59 000 000",
   "5 900 000",
   "18 000 000",
   "180 000 000"
  ]
 },
 "q0865": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Schweiz? (2024)",
  "a": [
   "9 000 000",
   "900 000",
   "2 700 000",
   "27 000 000"
  ]
 },
 "q0866": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Österreich? (2024)",
  "a": [
   "9 200 000",
   "920 000",
   "2 800 000",
   "28 000 000"
  ]
 },
 "q0867": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Griechenland? (2024)",
  "a": [
   "10 000 000",
   "1 000 000",
   "3 100 000",
   "31 000 000"
  ]
 },
 "q0868": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Türkei? (2024)",
  "a": [
   "86 000 000",
   "8 600 000",
   "26 000 000",
   "260 000 000"
  ]
 },
 "q0869": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Portugal? (2024)",
  "a": [
   "11 000 000",
   "1 100 000",
   "3 200 000",
   "32 000 000"
  ]
 },
 "q0870": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Uruguay? (2024)",
  "a": [
   "3 400 000",
   "340 000",
   "1 000 000",
   "10 000 000"
  ]
 },
 "q0871": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Ägypten? (2024)",
  "a": [
   "120 000 000",
   "12 000 000",
   "35 000 000",
   "350 000 000"
  ]
 },
 "q0872": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Mexiko? (2024)",
  "a": [
   "130 000 000",
   "13 000 000",
   "39 000 000",
   "390 000 000"
  ]
 },
 "q0873": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Kenia? (2024)",
  "a": [
   "56 000 000",
   "5 600 000",
   "17 000 000",
   "170 000 000"
  ]
 },
 "q0874": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Äthiopien? (2024)",
  "a": [
   "130 000 000",
   "13 000 000",
   "40 000 000",
   "400 000 000"
  ]
 },
 "q0875": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Ghana? (2024)",
  "a": [
   "34 000 000",
   "3 400 000",
   "10 000 000",
   "100 000 000"
  ]
 },
 "q0876": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Frankreich? (2024)",
  "a": [
   "69 000 000",
   "6 900 000",
   "21 000 000",
   "210 000 000"
  ]
 },
 "q0877": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Vereinigtes Königreich? (2024)",
  "a": [
   "69 000 000",
   "6 900 000",
   "21 000 000",
   "210 000 000"
  ]
 },
 "q0878": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Volksrepublik China? (2024)",
  "a": [
   "1 400 000 000",
   "140 000 000",
   "420 000 000",
   "4 200 000 000"
  ]
 },
 "q0879": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Brasilien? (2024)",
  "a": [
   "210 000 000",
   "21 000 000",
   "64 000 000",
   "640 000 000"
  ]
 },
 "q0880": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Russland? (2024)",
  "a": [
   "140 000 000",
   "14 000 000",
   "43 000 000",
   "430 000 000"
  ]
 },
 "q0881": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Deutschland? (2024)",
  "a": [
   "84 000 000",
   "8 400 000",
   "25 000 000",
   "250 000 000"
  ]
 },
 "q0882": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Belarus? (2024)",
  "a": [
   "9 100 000",
   "910 000",
   "2 700 000",
   "27 000 000"
  ]
 },
 "q0883": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Island? (2024)",
  "a": [
   "390 000",
   "39 000",
   "120 000",
   "1 200 000"
  ]
 },
 "q0884": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Estland? (2024)",
  "a": [
   "1 400 000",
   "140 000",
   "410 000",
   "4 100 000"
  ]
 },
 "q0885": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Lettland? (2024)",
  "a": [
   "1 900 000",
   "190 000",
   "560 000",
   "5 600 000"
  ]
 },
 "q0886": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Ukraine? (2024)",
  "a": [
   "38 000 000",
   "3 800 000",
   "11 000 000",
   "110 000 000"
  ]
 },
 "q0887": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Tschechien? (2024)",
  "a": [
   "11 000 000",
   "1 100 000",
   "3 300 000",
   "33 000 000"
  ]
 },
 "q0888": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Slowakei? (2024)",
  "a": [
   "5 400 000",
   "540 000",
   "1 600 000",
   "16 000 000"
  ]
 },
 "q0889": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Slowenien? (2024)",
  "a": [
   "2 100 000",
   "210 000",
   "640 000",
   "6 400 000"
  ]
 },
 "q0890": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Moldau? (2024)",
  "a": [
   "2 400 000",
   "240 000",
   "720 000",
   "7 200 000"
  ]
 },
 "q0891": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Rumänien? (2024)",
  "a": [
   "19 000 000",
   "1 900 000",
   "5 700 000",
   "57 000 000"
  ]
 },
 "q0892": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Bulgarien? (2024)",
  "a": [
   "6 400 000",
   "640 000",
   "1 900 000",
   "19 000 000"
  ]
 },
 "q0893": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Nordmazedonien? (2024)",
  "a": [
   "1 800 000",
   "180 000",
   "550 000",
   "5 500 000"
  ]
 },
 "q0894": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Albanien? (2024)",
  "a": [
   "2 400 000",
   "240 000",
   "710 000",
   "7 100 000"
  ]
 },
 "q0895": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Kroatien? (2024)",
  "a": [
   "3 900 000",
   "390 000",
   "1 200 000",
   "12 000 000"
  ]
 },
 "q0896": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Bosnien und Herzegowina? (2024)",
  "a": [
   "3 200 000",
   "320 000",
   "950 000",
   "9 500 000"
  ]
 },
 "q0897": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Aserbaidschan? (2024)",
  "a": [
   "10 000 000",
   "1 000 000",
   "3 100 000",
   "31 000 000"
  ]
 },
 "q0898": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Andorra? (2024)",
  "a": [
   "82 000",
   "8 200",
   "25 000",
   "250 000"
  ]
 },
 "q0899": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Zypern? (2024)",
  "a": [
   "1 400 000",
   "140 000",
   "410 000",
   "4 100 000"
  ]
 },
 "q0900": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Georgien? (2024)",
  "a": [
   "3 800 000",
   "380 000",
   "1 100 000",
   "11 000 000"
  ]
 },
 "q0901": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Kasachstan? (2024)",
  "a": [
   "21 000 000",
   "2 100 000",
   "6 200 000",
   "62 000 000"
  ]
 },
 "q0902": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Malta? (2024)",
  "a": [
   "570 000",
   "57 000",
   "170 000",
   "1 700 000"
  ]
 },
 "q0903": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Monaco? (2024)",
  "a": [
   "39 000",
   "3 900",
   "12 000",
   "120 000"
  ]
 },
 "q0904": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Montenegro? (2024)",
  "a": [
   "620 000",
   "62 000",
   "190 000",
   "1 900 000"
  ]
 },
 "q0905": {
  "q": "Wie groß ist ungefähr die Bevölkerung von San Marino? (2024)",
  "a": [
   "34 000",
   "3 400",
   "10 000",
   "100 000"
  ]
 },
 "q0906": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Kuba? (2024)",
  "a": [
   "11 000 000",
   "1 100 000",
   "3 300 000",
   "33 000 000"
  ]
 },
 "q0907": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Belize? (2024)",
  "a": [
   "420 000",
   "42 000",
   "130 000",
   "1 300 000"
  ]
 },
 "q0908": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Barbados? (2024)",
  "a": [
   "280 000",
   "28 000",
   "85 000",
   "850 000"
  ]
 },
 "q0909": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Indonesien? (2024)",
  "a": [
   "280 000 000",
   "28 000 000",
   "85 000 000",
   "850 000 000"
  ]
 },
 "q0910": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Südafrika? (2024)",
  "a": [
   "64 000 000",
   "6 400 000",
   "19 000 000",
   "190 000 000"
  ]
 },
 "q0911": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Algerien? (2024)",
  "a": [
   "47 000 000",
   "4 700 000",
   "14 000 000",
   "140 000 000"
  ]
 },
 "q0912": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Usbekistan? (2024)",
  "a": [
   "36 000 000",
   "3 600 000",
   "11 000 000",
   "110 000 000"
  ]
 },
 "q0913": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Chile? (2024)",
  "a": [
   "20 000 000",
   "2 000 000",
   "5 900 000",
   "59 000 000"
  ]
 },
 "q0914": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Singapur? (2024)",
  "a": [
   "6 000 000",
   "600 000",
   "1 800 000",
   "18 000 000"
  ]
 },
 "q0915": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Liechtenstein? (2024)",
  "a": [
   "40 000",
   "4 000",
   "12 000",
   "120 000"
  ]
 },
 "q0916": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Bahrain? (2024)",
  "a": [
   "1 600 000",
   "160 000",
   "480 000",
   "4 800 000"
  ]
 },
 "q0917": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Armenien? (2024)",
  "a": [
   "3 000 000",
   "300 000",
   "910 000",
   "9 100 000"
  ]
 },
 "q0918": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Serbien? (2024)",
  "a": [
   "6 600 000",
   "660 000",
   "2 000 000",
   "20 000 000"
  ]
 },
 "q0919": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Australien? (2024)",
  "a": [
   "27 000 000",
   "2 700 000",
   "8 200 000",
   "82 000 000"
  ]
 },
 "q0920": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Argentinien? (2024)",
  "a": [
   "46 000 000",
   "4 600 000",
   "14 000 000",
   "140 000 000"
  ]
 },
 "q0921": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Peru? (2024)",
  "a": [
   "34 000 000",
   "3 400 000",
   "10 000 000",
   "100 000 000"
  ]
 },
 "q0922": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Nordkorea? (2024)",
  "a": [
   "26 000 000",
   "2 600 000",
   "7 900 000",
   "79 000 000"
  ]
 },
 "q0923": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Kambodscha? (2024)",
  "a": [
   "18 000 000",
   "1 800 000",
   "5 300 000",
   "53 000 000"
  ]
 },
 "q0924": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Osttimor? (2024)",
  "a": [
   "1 400 000",
   "140 000",
   "420 000",
   "4 200 000"
  ]
 },
 "q0925": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Tschad? (2024)",
  "a": [
   "20 000 000",
   "2 000 000",
   "6 100 000",
   "61 000 000"
  ]
 },
 "q0926": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Neuseeland? (2024)",
  "a": [
   "5 300 000",
   "530 000",
   "1 600 000",
   "16 000 000"
  ]
 },
 "q0927": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Indien? (2024)",
  "a": [
   "1 500 000 000",
   "150 000 000",
   "440 000 000",
   "4 400 000 000"
  ]
 },
 "q0928": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Tuvalu? (2024)",
  "a": [
   "9 600",
   "960",
   "2 900",
   "29 000"
  ]
 },
 "q0929": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Tonga? (2024)",
  "a": [
   "100 000",
   "10 000",
   "31 000",
   "310 000"
  ]
 },
 "q0930": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Samoa? (2024)",
  "a": [
   "220 000",
   "22 000",
   "65 000",
   "650 000"
  ]
 },
 "q0931": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Salomonen? (2024)",
  "a": [
   "820 000",
   "82 000",
   "250 000",
   "2 500 000"
  ]
 },
 "q0932": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Vanuatu? (2024)",
  "a": [
   "330 000",
   "33 000",
   "98 000",
   "980 000"
  ]
 },
 "q0933": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Papua-Neuguinea? (2024)",
  "a": [
   "11 000 000",
   "1 100 000",
   "3 200 000",
   "32 000 000"
  ]
 },
 "q0934": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Palau? (2024)",
  "a": [
   "18 000",
   "1 800",
   "5 300",
   "53 000"
  ]
 },
 "q0935": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Naoero? (2024)",
  "a": [
   "12 000",
   "1 200",
   "3 600",
   "36 000"
  ]
 },
 "q0936": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Föderierte Staaten von Mikronesien? (2024)",
  "a": [
   "110 000",
   "11 000",
   "34 000",
   "340 000"
  ]
 },
 "q0937": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Marshallinseln? (2024)",
  "a": [
   "38 000",
   "3 800",
   "11 000",
   "110 000"
  ]
 },
 "q0938": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Kiribati? (2024)",
  "a": [
   "130 000",
   "13 000",
   "40 000",
   "400 000"
  ]
 },
 "q0939": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Mongolei? (2024)",
  "a": [
   "3 500 000",
   "350 000",
   "1 100 000",
   "11 000 000"
  ]
 },
 "q0940": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Fidschi? (2024)",
  "a": [
   "930 000",
   "93 000",
   "280 000",
   "2 800 000"
  ]
 },
 "q0941": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Venezuela? (2024)",
  "a": [
   "28 000 000",
   "2 800 000",
   "8 500 000",
   "85 000 000"
  ]
 },
 "q0942": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Suriname? (2024)",
  "a": [
   "630 000",
   "63 000",
   "190 000",
   "1 900 000"
  ]
 },
 "q0943": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Paraguay? (2024)",
  "a": [
   "6 900 000",
   "690 000",
   "2 100 000",
   "21 000 000"
  ]
 },
 "q0944": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Guyana? (2024)",
  "a": [
   "830 000",
   "83 000",
   "250 000",
   "2 500 000"
  ]
 },
 "q0945": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Ecuador? (2024)",
  "a": [
   "18 000 000",
   "1 800 000",
   "5 400 000",
   "54 000 000"
  ]
 },
 "q0946": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Kolumbien? (2024)",
  "a": [
   "53 000 000",
   "5 300 000",
   "16 000 000",
   "160 000 000"
  ]
 },
 "q0947": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Bolivien? (2024)",
  "a": [
   "12 000 000",
   "1 200 000",
   "3 700 000",
   "37 000 000"
  ]
 },
 "q0948": {
  "q": "Wie groß ist ungefähr die Bevölkerung von St. Kitts und Nevis? (2024)",
  "a": [
   "47 000",
   "4 700",
   "14 000",
   "140 000"
  ]
 },
 "q0949": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Jamaika? (2024)",
  "a": [
   "2 800 000",
   "280 000",
   "850 000",
   "8 500 000"
  ]
 },
 "q0950": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Grenada? (2024)",
  "a": [
   "120 000",
   "12 000",
   "35 000",
   "350 000"
  ]
 },
 "q0951": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Guatemala? (2024)",
  "a": [
   "18 000 000",
   "1 800 000",
   "5 500 000",
   "55 000 000"
  ]
 },
 "q0952": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Bahamas? (2024)",
  "a": [
   "400 000",
   "40 000",
   "120 000",
   "1 200 000"
  ]
 },
 "q0953": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Antigua und Barbuda? (2024)",
  "a": [
   "94 000",
   "9 400",
   "28 000",
   "280 000"
  ]
 },
 "q0954": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Honduras? (2024)",
  "a": [
   "11 000 000",
   "1 100 000",
   "3 200 000",
   "32 000 000"
  ]
 },
 "q0955": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Dominica? (2024)",
  "a": [
   "66 000",
   "6 600",
   "20 000",
   "200 000"
  ]
 },
 "q0956": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Dominikanische Republik? (2024)",
  "a": [
   "11 000 000",
   "1 100 000",
   "3 400 000",
   "34 000 000"
  ]
 },
 "q0957": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Haiti? (2024)",
  "a": [
   "12 000 000",
   "1 200 000",
   "3 500 000",
   "35 000 000"
  ]
 },
 "q0958": {
  "q": "Wie groß ist ungefähr die Bevölkerung von El Salvador? (2024)",
  "a": [
   "6 300 000",
   "630 000",
   "1 900 000",
   "19 000 000"
  ]
 },
 "q0959": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Iran? (2024)",
  "a": [
   "92 000 000",
   "9 200 000",
   "27 000 000",
   "270 000 000"
  ]
 },
 "q0960": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Irak? (2024)",
  "a": [
   "46 000 000",
   "4 600 000",
   "14 000 000",
   "140 000 000"
  ]
 },
 "q0961": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Costa Rica? (2024)",
  "a": [
   "5 100 000",
   "510 000",
   "1 500 000",
   "15 000 000"
  ]
 },
 "q0962": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Israel? (2024)",
  "a": [
   "10 000 000",
   "1 000 000",
   "3 000 000",
   "30 000 000"
  ]
 },
 "q0963": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Panama? (2024)",
  "a": [
   "4 500 000",
   "450 000",
   "1 400 000",
   "14 000 000"
  ]
 },
 "q0964": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Jemen? (2024)",
  "a": [
   "41 000 000",
   "4 100 000",
   "12 000 000",
   "120 000 000"
  ]
 },
 "q0965": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Jordanien? (2024)",
  "a": [
   "12 000 000",
   "1 200 000",
   "3 500 000",
   "35 000 000"
  ]
 },
 "q0966": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Nicaragua? (2024)",
  "a": [
   "6 900 000",
   "690 000",
   "2 100 000",
   "21 000 000"
  ]
 },
 "q0967": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Kirgisistan? (2024)",
  "a": [
   "7 200 000",
   "720 000",
   "2 200 000",
   "22 000 000"
  ]
 },
 "q0968": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Kuwait? (2024)",
  "a": [
   "4 900 000",
   "490 000",
   "1 500 000",
   "15 000 000"
  ]
 },
 "q0969": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Laos? (2024)",
  "a": [
   "7 800 000",
   "780 000",
   "2 300 000",
   "23 000 000"
  ]
 },
 "q0970": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Libanon? (2024)",
  "a": [
   "5 800 000",
   "580 000",
   "1 700 000",
   "17 000 000"
  ]
 },
 "q0971": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Malediven? (2024)",
  "a": [
   "530 000",
   "53 000",
   "160 000",
   "1 600 000"
  ]
 },
 "q0972": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Malaysia? (2024)",
  "a": [
   "36 000 000",
   "3 600 000",
   "11 000 000",
   "110 000 000"
  ]
 },
 "q0973": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Myanmar? (2024)",
  "a": [
   "55 000 000",
   "5 500 000",
   "16 000 000",
   "160 000 000"
  ]
 },
 "q0974": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Nepal? (2024)",
  "a": [
   "30 000 000",
   "3 000 000",
   "8 900 000",
   "89 000 000"
  ]
 },
 "q0975": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Oman? (2024)",
  "a": [
   "5 300 000",
   "530 000",
   "1 600 000",
   "16 000 000"
  ]
 },
 "q0976": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Pakistan? (2024)",
  "a": [
   "250 000 000",
   "25 000 000",
   "75 000 000",
   "750 000 000"
  ]
 },
 "q0977": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Katar? (2024)",
  "a": [
   "2 900 000",
   "290 000",
   "860 000",
   "8 600 000"
  ]
 },
 "q0978": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Saudi-Arabien? (2024)",
  "a": [
   "35 000 000",
   "3 500 000",
   "11 000 000",
   "110 000 000"
  ]
 },
 "q0979": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Sri Lanka? (2024)",
  "a": [
   "22 000 000",
   "2 200 000",
   "6 600 000",
   "66 000 000"
  ]
 },
 "q0980": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Syrien? (2024)",
  "a": [
   "25 000 000",
   "2 500 000",
   "7 400 000",
   "74 000 000"
  ]
 },
 "q0981": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Tadschikistan? (2024)",
  "a": [
   "11 000 000",
   "1 100 000",
   "3 200 000",
   "32 000 000"
  ]
 },
 "q0982": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Thailand? (2024)",
  "a": [
   "72 000 000",
   "7 200 000",
   "22 000 000",
   "220 000 000"
  ]
 },
 "q0983": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Turkmenistan? (2024)",
  "a": [
   "7 500 000",
   "750 000",
   "2 200 000",
   "22 000 000"
  ]
 },
 "q0984": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Vereinigte Arabische Emirate? (2024)",
  "a": [
   "11 000 000",
   "1 100 000",
   "3 300 000",
   "33 000 000"
  ]
 },
 "q0985": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Vietnam? (2024)",
  "a": [
   "100 000 000",
   "10 000 000",
   "30 000 000",
   "300 000 000"
  ]
 },
 "q0986": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Südkorea? (2024)",
  "a": [
   "52 000 000",
   "5 200 000",
   "16 000 000",
   "160 000 000"
  ]
 },
 "q0987": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Afghanistan? (2024)",
  "a": [
   "43 000 000",
   "4 300 000",
   "13 000 000",
   "130 000 000"
  ]
 },
 "q0988": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Bangladesch? (2024)",
  "a": [
   "170 000 000",
   "17 000 000",
   "52 000 000",
   "520 000 000"
  ]
 },
 "q0989": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Mali? (2024)",
  "a": [
   "24 000 000",
   "2 400 000",
   "7 300 000",
   "73 000 000"
  ]
 },
 "q0990": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Angola? (2024)",
  "a": [
   "38 000 000",
   "3 800 000",
   "11 000 000",
   "110 000 000"
  ]
 },
 "q0991": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Bhutan? (2024)",
  "a": [
   "790 000",
   "79 000",
   "240 000",
   "2 400 000"
  ]
 },
 "q0992": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Brunei? (2024)",
  "a": [
   "460 000",
   "46 000",
   "140 000",
   "1 400 000"
  ]
 },
 "q0993": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Tansania? (2024)",
  "a": [
   "69 000 000",
   "6 900 000",
   "21 000 000",
   "210 000 000"
  ]
 },
 "q0994": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Philippinen? (2024)",
  "a": [
   "120 000 000",
   "12 000 000",
   "35 000 000",
   "350 000 000"
  ]
 },
 "q0995": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Zentralafrikanische Republik? (2024)",
  "a": [
   "5 300 000",
   "530 000",
   "1 600 000",
   "16 000 000"
  ]
 },
 "q0996": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Togo? (2024)",
  "a": [
   "8 400 000",
   "840 000",
   "2 500 000",
   "25 000 000"
  ]
 },
 "q0997": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Tunesien? (2024)",
  "a": [
   "12 000 000",
   "1 200 000",
   "3 700 000",
   "37 000 000"
  ]
 },
 "q0998": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Sambia? (2024)",
  "a": [
   "21 000 000",
   "2 100 000",
   "6 400 000",
   "64 000 000"
  ]
 },
 "q0999": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Simbabwe? (2024)",
  "a": [
   "17 000 000",
   "1 700 000",
   "5 000 000",
   "50 000 000"
  ]
 },
 "q1000": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Südsudan? (2024)",
  "a": [
   "12 000 000",
   "1 200 000",
   "3 600 000",
   "36 000 000"
  ]
 },
 "q1001": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Benin? (2024)",
  "a": [
   "14 000 000",
   "1 400 000",
   "4 300 000",
   "43 000 000"
  ]
 },
 "q1002": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Botswana? (2024)",
  "a": [
   "2 500 000",
   "250 000",
   "760 000",
   "7 600 000"
  ]
 },
 "q1003": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Burkina Faso? (2024)",
  "a": [
   "24 000 000",
   "2 400 000",
   "7 100 000",
   "71 000 000"
  ]
 },
 "q1004": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Burundi? (2024)",
  "a": [
   "14 000 000",
   "1 400 000",
   "4 200 000",
   "42 000 000"
  ]
 },
 "q1005": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Komoren? (2024)",
  "a": [
   "870 000",
   "87 000",
   "260 000",
   "2 600 000"
  ]
 },
 "q1006": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Republik Kongo? (2024)",
  "a": [
   "6 300 000",
   "630 000",
   "1 900 000",
   "19 000 000"
  ]
 },
 "q1007": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Demokratische Republik Kongo? (2024)",
  "a": [
   "110 000 000",
   "11 000 000",
   "33 000 000",
   "330 000 000"
  ]
 },
 "q1008": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Dschibuti? (2024)",
  "a": [
   "1 200 000",
   "120 000",
   "350 000",
   "3 500 000"
  ]
 },
 "q1009": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Äquatorialguinea? (2024)",
  "a": [
   "1 900 000",
   "190 000",
   "570 000",
   "5 700 000"
  ]
 },
 "q1010": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Eritrea? (2024)",
  "a": [
   "3 500 000",
   "350 000",
   "1 100 000",
   "11 000 000"
  ]
 },
 "q1011": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Gabun? (2024)",
  "a": [
   "2 500 000",
   "250 000",
   "760 000",
   "7 600 000"
  ]
 },
 "q1012": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Gambia? (2024)",
  "a": [
   "2 800 000",
   "280 000",
   "830 000",
   "8 300 000"
  ]
 },
 "q1013": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Guinea? (2024)",
  "a": [
   "15 000 000",
   "1 500 000",
   "4 400 000",
   "44 000 000"
  ]
 },
 "q1014": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Guinea-Bissau? (2024)",
  "a": [
   "2 200 000",
   "220 000",
   "660 000",
   "6 600 000"
  ]
 },
 "q1015": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Elfenbeinküste? (2024)",
  "a": [
   "32 000 000",
   "3 200 000",
   "9 600 000",
   "96 000 000"
  ]
 },
 "q1016": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Kamerun? (2024)",
  "a": [
   "29 000 000",
   "2 900 000",
   "8 700 000",
   "87 000 000"
  ]
 },
 "q1017": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Kap Verde? (2024)",
  "a": [
   "520 000",
   "52 000",
   "160 000",
   "1 600 000"
  ]
 },
 "q1018": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Lesotho? (2024)",
  "a": [
   "2 300 000",
   "230 000",
   "700 000",
   "7 000 000"
  ]
 },
 "q1019": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Liberia? (2024)",
  "a": [
   "5 600 000",
   "560 000",
   "1 700 000",
   "17 000 000"
  ]
 },
 "q1020": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Libyen? (2024)",
  "a": [
   "7 400 000",
   "740 000",
   "2 200 000",
   "22 000 000"
  ]
 },
 "q1021": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Madagaskar? (2024)",
  "a": [
   "32 000 000",
   "3 200 000",
   "9 600 000",
   "96 000 000"
  ]
 },
 "q1022": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Malawi? (2024)",
  "a": [
   "22 000 000",
   "2 200 000",
   "6 500 000",
   "65 000 000"
  ]
 },
 "q1023": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Mauretanien? (2024)",
  "a": [
   "5 200 000",
   "520 000",
   "1 600 000",
   "16 000 000"
  ]
 },
 "q1024": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Mauritius? (2024)",
  "a": [
   "1 200 000",
   "120 000",
   "370 000",
   "3 700 000"
  ]
 },
 "q1025": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Marokko? (2024)",
  "a": [
   "38 000 000",
   "3 800 000",
   "11 000 000",
   "110 000 000"
  ]
 },
 "q1026": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Mosambik? (2024)",
  "a": [
   "35 000 000",
   "3 500 000",
   "10 000 000",
   "100 000 000"
  ]
 },
 "q1027": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Namibia? (2024)",
  "a": [
   "3 000 000",
   "300 000",
   "910 000",
   "9 100 000"
  ]
 },
 "q1028": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Niger? (2024)",
  "a": [
   "27 000 000",
   "2 700 000",
   "8 100 000",
   "81 000 000"
  ]
 },
 "q1029": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Nigeria? (2024)",
  "a": [
   "230 000 000",
   "23 000 000",
   "70 000 000",
   "700 000 000"
  ]
 },
 "q1030": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Uganda? (2024)",
  "a": [
   "50 000 000",
   "5 000 000",
   "15 000 000",
   "150 000 000"
  ]
 },
 "q1031": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Ruanda? (2024)",
  "a": [
   "14 000 000",
   "1 400 000",
   "4 300 000",
   "43 000 000"
  ]
 },
 "q1032": {
  "q": "Wie groß ist ungefähr die Bevölkerung von São Tomé und Príncipe? (2024)",
  "a": [
   "240 000",
   "24 000",
   "71 000",
   "710 000"
  ]
 },
 "q1033": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Senegal? (2024)",
  "a": [
   "19 000 000",
   "1 900 000",
   "5 600 000",
   "56 000 000"
  ]
 },
 "q1034": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Seychellen? (2024)",
  "a": [
   "120 000",
   "12 000",
   "36 000",
   "360 000"
  ]
 },
 "q1035": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Sierra Leone? (2024)",
  "a": [
   "8 600 000",
   "860 000",
   "2 600 000",
   "26 000 000"
  ]
 },
 "q1036": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Somalia? (2024)",
  "a": [
   "19 000 000",
   "1 900 000",
   "5 700 000",
   "57 000 000"
  ]
 },
 "q1037": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Sudan? (2024)",
  "a": [
   "50 000 000",
   "5 000 000",
   "15 000 000",
   "150 000 000"
  ]
 },
 "q1038": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Eswatini? (2024)",
  "a": [
   "1 200 000",
   "120 000",
   "370 000",
   "3 700 000"
  ]
 },
 "q1039": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Königreich der Niederlande? (2024)",
  "a": [
   "18 000 000",
   "1 800 000",
   "5 400 000",
   "54 000 000"
  ]
 },
 "q1040": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Trinidad und Tobago? (2024)",
  "a": [
   "1 400 000",
   "140 000",
   "410 000",
   "4 100 000"
  ]
 },
 "q1041": {
  "q": "Wie groß ist ungefähr die Bevölkerung von St. Vincent und die Grenadinen? (2024)",
  "a": [
   "100 000",
   "10 000",
   "30 000",
   "300 000"
  ]
 },
 "q1042": {
  "q": "Wie groß ist ungefähr die Bevölkerung von St. Lucia? (2024)",
  "a": [
   "180 000",
   "18 000",
   "54 000",
   "540 000"
  ]
 },
 "q1043": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Dänemark? (2024)",
  "a": [
   "6 000 000",
   "600 000",
   "1 800 000",
   "18 000 000"
  ]
 },
 "q1044": {
  "q": "Wie groß ist ungefähr die Bevölkerung von Palästina? (2024)",
  "a": [
   "5 300 000",
   "530 000",
   "1 600 000",
   "16 000 000"
  ]
 },
 "q1045": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Kanada?",
  "a": [
   "10 000 000 km²",
   "1 000 000 km²",
   "3 000 000 km²",
   "30 000 000 km²"
  ]
 },
 "q1046": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Japan?",
  "a": [
   "380 000 km²",
   "38 000 km²",
   "110 000 km²",
   "1 100 000 km²"
  ]
 },
 "q1047": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Norwegen?",
  "a": [
   "320 000 km²",
   "32 000 km²",
   "97 000 km²",
   "970 000 km²"
  ]
 },
 "q1048": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Irland?",
  "a": [
   "70 000 km²",
   "7 000 km²",
   "21 000 km²",
   "210 000 km²"
  ]
 },
 "q1049": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Ungarn?",
  "a": [
   "93 000 km²",
   "9 300 km²",
   "28 000 km²",
   "280 000 km²"
  ]
 },
 "q1050": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Spanien?",
  "a": [
   "510 000 km²",
   "51 000 km²",
   "150 000 km²",
   "1 500 000 km²"
  ]
 },
 "q1051": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Vereinigte Staaten?",
  "a": [
   "9 400 000 km²",
   "940 000 km²",
   "2 800 000 km²",
   "28 000 000 km²"
  ]
 },
 "q1052": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Belgien?",
  "a": [
   "31 000 km²",
   "3 100 km²",
   "9 200 km²",
   "92 000 km²"
  ]
 },
 "q1053": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Luxemburg?",
  "a": [
   "2 600 km²",
   "260 km²",
   "780 km²",
   "7 800 km²"
  ]
 },
 "q1054": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Finnland?",
  "a": [
   "340 000 km²",
   "34 000 km²",
   "100 000 km²",
   "1 000 000 km²"
  ]
 },
 "q1055": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Schweden?",
  "a": [
   "450 000 km²",
   "45 000 km²",
   "140 000 km²",
   "1 400 000 km²"
  ]
 },
 "q1056": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Polen?",
  "a": [
   "310 000 km²",
   "31 000 km²",
   "94 000 km²",
   "940 000 km²"
  ]
 },
 "q1057": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Litauen?",
  "a": [
   "65 000 km²",
   "6 500 km²",
   "20 000 km²",
   "200 000 km²"
  ]
 },
 "q1058": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Italien?",
  "a": [
   "300 000 km²",
   "30 000 km²",
   "90 000 km²",
   "900 000 km²"
  ]
 },
 "q1059": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Schweiz?",
  "a": [
   "41 000 km²",
   "4 100 km²",
   "12 000 km²",
   "120 000 km²"
  ]
 },
 "q1060": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Österreich?",
  "a": [
   "84 000 km²",
   "8 400 km²",
   "25 000 km²",
   "250 000 km²"
  ]
 },
 "q1061": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Griechenland?",
  "a": [
   "130 000 km²",
   "13 000 km²",
   "40 000 km²",
   "400 000 km²"
  ]
 },
 "q1062": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Türkei?",
  "a": [
   "780 000 km²",
   "78 000 km²",
   "240 000 km²",
   "2 400 000 km²"
  ]
 },
 "q1063": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Portugal?",
  "a": [
   "92 000 km²",
   "9 200 km²",
   "28 000 km²",
   "280 000 km²"
  ]
 },
 "q1064": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Uruguay?",
  "a": [
   "180 000 km²",
   "18 000 km²",
   "54 000 km²",
   "540 000 km²"
  ]
 },
 "q1065": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Ägypten?",
  "a": [
   "1 000 000 km²",
   "100 000 km²",
   "300 000 km²",
   "3 000 000 km²"
  ]
 },
 "q1066": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Mexiko?",
  "a": [
   "2 000 000 km²",
   "200 000 km²",
   "590 000 km²",
   "5 900 000 km²"
  ]
 },
 "q1067": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Kenia?",
  "a": [
   "580 000 km²",
   "58 000 km²",
   "170 000 km²",
   "1 700 000 km²"
  ]
 },
 "q1068": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Äthiopien?",
  "a": [
   "1 100 000 km²",
   "110 000 km²",
   "330 000 km²",
   "3 300 000 km²"
  ]
 },
 "q1069": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Ghana?",
  "a": [
   "240 000 km²",
   "24 000 km²",
   "72 000 km²",
   "720 000 km²"
  ]
 },
 "q1070": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Frankreich?",
  "a": [
   "550 000 km²",
   "55 000 km²",
   "170 000 km²",
   "1 700 000 km²"
  ]
 },
 "q1071": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Vereinigtes Königreich?",
  "a": [
   "240 000 km²",
   "24 000 km²",
   "73 000 km²",
   "730 000 km²"
  ]
 },
 "q1072": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Volksrepublik China?",
  "a": [
   "9 700 000 km²",
   "970 000 km²",
   "2 900 000 km²",
   "29 000 000 km²"
  ]
 },
 "q1073": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Brasilien?",
  "a": [
   "8 500 000 km²",
   "850 000 km²",
   "2 600 000 km²",
   "26 000 000 km²"
  ]
 },
 "q1074": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Russland?",
  "a": [
   "17 000 000 km²",
   "1 700 000 km²",
   "5 100 000 km²",
   "51 000 000 km²"
  ]
 },
 "q1075": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Deutschland?",
  "a": [
   "360 000 km²",
   "36 000 km²",
   "110 000 km²",
   "1 100 000 km²"
  ]
 },
 "q1076": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Belarus?",
  "a": [
   "210 000 km²",
   "21 000 km²",
   "62 000 km²",
   "620 000 km²"
  ]
 },
 "q1077": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Island?",
  "a": [
   "100 000 km²",
   "10 000 km²",
   "31 000 km²",
   "310 000 km²"
  ]
 },
 "q1078": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Estland?",
  "a": [
   "45 000 km²",
   "4 500 km²",
   "14 000 km²",
   "140 000 km²"
  ]
 },
 "q1079": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Lettland?",
  "a": [
   "65 000 km²",
   "6 500 km²",
   "19 000 km²",
   "190 000 km²"
  ]
 },
 "q1080": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Ukraine?",
  "a": [
   "600 000 km²",
   "60 000 km²",
   "180 000 km²",
   "1 800 000 km²"
  ]
 },
 "q1081": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Tschechien?",
  "a": [
   "79 000 km²",
   "7 900 km²",
   "24 000 km²",
   "240 000 km²"
  ]
 },
 "q1082": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Slowakei?",
  "a": [
   "49 000 km²",
   "4 900 km²",
   "15 000 km²",
   "150 000 km²"
  ]
 },
 "q1083": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Slowenien?",
  "a": [
   "20 000 km²",
   "2 000 km²",
   "6 100 km²",
   "61 000 km²"
  ]
 },
 "q1084": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Moldau?",
  "a": [
   "34 000 km²",
   "3 400 km²",
   "10 000 km²",
   "100 000 km²"
  ]
 },
 "q1085": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Rumänien?",
  "a": [
   "240 000 km²",
   "24 000 km²",
   "72 000 km²",
   "720 000 km²"
  ]
 },
 "q1086": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Bulgarien?",
  "a": [
   "110 000 km²",
   "11 000 km²",
   "33 000 km²",
   "330 000 km²"
  ]
 },
 "q1087": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Nordmazedonien?",
  "a": [
   "26 000 km²",
   "2 600 km²",
   "7 700 km²",
   "77 000 km²"
  ]
 },
 "q1088": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Albanien?",
  "a": [
   "29 000 km²",
   "2 900 km²",
   "8 600 km²",
   "86 000 km²"
  ]
 },
 "q1089": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Kroatien?",
  "a": [
   "57 000 km²",
   "5 700 km²",
   "17 000 km²",
   "170 000 km²"
  ]
 },
 "q1090": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Bosnien und Herzegowina?",
  "a": [
   "51 000 km²",
   "5 100 km²",
   "15 000 km²",
   "150 000 km²"
  ]
 },
 "q1091": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Aserbaidschan?",
  "a": [
   "87 000 km²",
   "8 700 km²",
   "26 000 km²",
   "260 000 km²"
  ]
 },
 "q1092": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Andorra?",
  "a": [
   "470 km²",
   "47 km²",
   "140 km²",
   "1 400 km²"
  ]
 },
 "q1093": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Zypern?",
  "a": [
   "9 300 km²",
   "930 km²",
   "2 800 km²",
   "28 000 km²"
  ]
 },
 "q1094": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Georgien?",
  "a": [
   "70 000 km²",
   "7 000 km²",
   "21 000 km²",
   "210 000 km²"
  ]
 },
 "q1095": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Kasachstan?",
  "a": [
   "2 700 000 km²",
   "270 000 km²",
   "820 000 km²",
   "8 200 000 km²"
  ]
 },
 "q1096": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Malta?",
  "a": [
   "320 km²",
   "32 km²",
   "95 km²",
   "950 km²"
  ]
 },
 "q1097": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Montenegro?",
  "a": [
   "14 000 km²",
   "1 400 km²",
   "4 100 km²",
   "41 000 km²"
  ]
 },
 "q1098": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von San Marino?",
  "a": [
   "61 km²",
   "6 km²",
   "18 km²",
   "180 km²"
  ]
 },
 "q1099": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Kuba?",
  "a": [
   "110 000 km²",
   "11 000 km²",
   "33 000 km²",
   "330 000 km²"
  ]
 },
 "q1100": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Belize?",
  "a": [
   "23 000 km²",
   "2 300 km²",
   "6 900 km²",
   "69 000 km²"
  ]
 },
 "q1101": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Barbados?",
  "a": [
   "430 km²",
   "43 km²",
   "130 km²",
   "1 300 km²"
  ]
 },
 "q1102": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Indonesien?",
  "a": [
   "1 900 000 km²",
   "190 000 km²",
   "570 000 km²",
   "5 700 000 km²"
  ]
 },
 "q1103": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Südafrika?",
  "a": [
   "1 200 000 km²",
   "120 000 km²",
   "370 000 km²",
   "3 700 000 km²"
  ]
 },
 "q1104": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Algerien?",
  "a": [
   "2 400 000 km²",
   "240 000 km²",
   "710 000 km²",
   "7 100 000 km²"
  ]
 },
 "q1105": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Usbekistan?",
  "a": [
   "450 000 km²",
   "45 000 km²",
   "130 000 km²",
   "1 300 000 km²"
  ]
 },
 "q1106": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Chile?",
  "a": [
   "760 000 km²",
   "76 000 km²",
   "230 000 km²",
   "2 300 000 km²"
  ]
 },
 "q1107": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Singapur?",
  "a": [
   "710 km²",
   "71 km²",
   "210 km²",
   "2 100 km²"
  ]
 },
 "q1108": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Liechtenstein?",
  "a": [
   "160 km²",
   "16 km²",
   "48 km²",
   "480 km²"
  ]
 },
 "q1109": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Bahrain?",
  "a": [
   "760 km²",
   "76 km²",
   "230 km²",
   "2 300 km²"
  ]
 },
 "q1110": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Armenien?",
  "a": [
   "30 000 km²",
   "3 000 km²",
   "8 900 km²",
   "89 000 km²"
  ]
 },
 "q1111": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Serbien?",
  "a": [
   "88 000 km²",
   "8 800 km²",
   "27 000 km²",
   "270 000 km²"
  ]
 },
 "q1112": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Australien?",
  "a": [
   "7 700 000 km²",
   "770 000 km²",
   "2 300 000 km²",
   "23 000 000 km²"
  ]
 },
 "q1113": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Argentinien?",
  "a": [
   "2 800 000 km²",
   "280 000 km²",
   "830 000 km²",
   "8 300 000 km²"
  ]
 },
 "q1114": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Peru?",
  "a": [
   "1 300 000 km²",
   "130 000 km²",
   "390 000 km²",
   "3 900 000 km²"
  ]
 },
 "q1115": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Nordkorea?",
  "a": [
   "120 000 km²",
   "12 000 km²",
   "36 000 km²",
   "360 000 km²"
  ]
 },
 "q1116": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Kambodscha?",
  "a": [
   "180 000 km²",
   "18 000 km²",
   "54 000 km²",
   "540 000 km²"
  ]
 },
 "q1117": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Osttimor?",
  "a": [
   "15 000 km²",
   "1 500 km²",
   "4 500 km²",
   "45 000 km²"
  ]
 },
 "q1118": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Tschad?",
  "a": [
   "1 300 000 km²",
   "130 000 km²",
   "390 000 km²",
   "3 900 000 km²"
  ]
 },
 "q1119": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Neuseeland?",
  "a": [
   "270 000 km²",
   "27 000 km²",
   "81 000 km²",
   "810 000 km²"
  ]
 },
 "q1120": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Indien?",
  "a": [
   "3 300 000 km²",
   "330 000 km²",
   "990 000 km²",
   "9 900 000 km²"
  ]
 },
 "q1121": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Tuvalu?",
  "a": [
   "26 km²",
   "2 km²",
   "7 km²",
   "78 km²"
  ]
 },
 "q1122": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Tonga?",
  "a": [
   "750 km²",
   "75 km²",
   "220 km²",
   "2 200 km²"
  ]
 },
 "q1123": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Samoa?",
  "a": [
   "2 800 km²",
   "280 km²",
   "850 km²",
   "8 500 km²"
  ]
 },
 "q1124": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Salomonen?",
  "a": [
   "29 000 km²",
   "2 900 km²",
   "8 700 km²",
   "87 000 km²"
  ]
 },
 "q1125": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Vanuatu?",
  "a": [
   "12 000 km²",
   "1 200 km²",
   "3 700 km²",
   "37 000 km²"
  ]
 },
 "q1126": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Papua-Neuguinea?",
  "a": [
   "460 000 km²",
   "46 000 km²",
   "140 000 km²",
   "1 400 000 km²"
  ]
 },
 "q1127": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Palau?",
  "a": [
   "460 km²",
   "46 km²",
   "140 km²",
   "1 400 km²"
  ]
 },
 "q1128": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Naoero?",
  "a": [
   "21 km²",
   "2 km²",
   "6 km²",
   "63 km²"
  ]
 },
 "q1129": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Föderierte Staaten von Mikronesien?",
  "a": [
   "700 km²",
   "70 km²",
   "210 km²",
   "2 100 km²"
  ]
 },
 "q1130": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Marshallinseln?",
  "a": [
   "180 km²",
   "18 km²",
   "54 km²",
   "540 km²"
  ]
 },
 "q1131": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Kiribati?",
  "a": [
   "810 km²",
   "81 km²",
   "240 km²",
   "2 400 km²"
  ]
 },
 "q1132": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Mongolei?",
  "a": [
   "1 600 000 km²",
   "160 000 km²",
   "470 000 km²",
   "4 700 000 km²"
  ]
 },
 "q1133": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Fidschi?",
  "a": [
   "18 000 km²",
   "1 800 km²",
   "5 500 km²",
   "55 000 km²"
  ]
 },
 "q1134": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Venezuela?",
  "a": [
   "920 000 km²",
   "92 000 km²",
   "270 000 km²",
   "2 700 000 km²"
  ]
 },
 "q1135": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Suriname?",
  "a": [
   "160 000 km²",
   "16 000 km²",
   "49 000 km²",
   "490 000 km²"
  ]
 },
 "q1136": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Paraguay?",
  "a": [
   "410 000 km²",
   "41 000 km²",
   "120 000 km²",
   "1 200 000 km²"
  ]
 },
 "q1137": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Guyana?",
  "a": [
   "210 000 km²",
   "21 000 km²",
   "64 000 km²",
   "640 000 km²"
  ]
 },
 "q1138": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Ecuador?",
  "a": [
   "280 000 km²",
   "28 000 km²",
   "83 000 km²",
   "830 000 km²"
  ]
 },
 "q1139": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Kolumbien?",
  "a": [
   "1 100 000 km²",
   "110 000 km²",
   "340 000 km²",
   "3 400 000 km²"
  ]
 },
 "q1140": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Bolivien?",
  "a": [
   "1 100 000 km²",
   "110 000 km²",
   "330 000 km²",
   "3 300 000 km²"
  ]
 },
 "q1141": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von St. Kitts und Nevis?",
  "a": [
   "260 km²",
   "26 km²",
   "78 km²",
   "780 km²"
  ]
 },
 "q1142": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Jamaika?",
  "a": [
   "11 000 km²",
   "1 100 km²",
   "3 300 km²",
   "33 000 km²"
  ]
 },
 "q1143": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Grenada?",
  "a": [
   "340 km²",
   "34 km²",
   "100 km²",
   "1 000 km²"
  ]
 },
 "q1144": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Guatemala?",
  "a": [
   "110 000 km²",
   "11 000 km²",
   "33 000 km²",
   "330 000 km²"
  ]
 },
 "q1145": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Bahamas?",
  "a": [
   "14 000 km²",
   "1 400 km²",
   "4 200 km²",
   "42 000 km²"
  ]
 },
 "q1146": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Antigua und Barbuda?",
  "a": [
   "440 km²",
   "44 km²",
   "130 km²",
   "1 300 km²"
  ]
 },
 "q1147": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Honduras?",
  "a": [
   "110 000 km²",
   "11 000 km²",
   "34 000 km²",
   "340 000 km²"
  ]
 },
 "q1148": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Dominica?",
  "a": [
   "750 km²",
   "75 km²",
   "230 km²",
   "2 300 km²"
  ]
 },
 "q1149": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Dominikanische Republik?",
  "a": [
   "49 000 km²",
   "4 900 km²",
   "15 000 km²",
   "150 000 km²"
  ]
 },
 "q1150": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Haiti?",
  "a": [
   "28 000 km²",
   "2 800 km²",
   "8 300 km²",
   "83 000 km²"
  ]
 },
 "q1151": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von El Salvador?",
  "a": [
   "21 000 km²",
   "2 100 km²",
   "6 300 km²",
   "63 000 km²"
  ]
 },
 "q1152": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Iran?",
  "a": [
   "1 600 000 km²",
   "160 000 km²",
   "490 000 km²",
   "4 900 000 km²"
  ]
 },
 "q1153": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Irak?",
  "a": [
   "440 000 km²",
   "44 000 km²",
   "130 000 km²",
   "1 300 000 km²"
  ]
 },
 "q1154": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Costa Rica?",
  "a": [
   "51 000 km²",
   "5 100 km²",
   "15 000 km²",
   "150 000 km²"
  ]
 },
 "q1155": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Israel?",
  "a": [
   "21 000 km²",
   "2 100 km²",
   "6 200 km²",
   "62 000 km²"
  ]
 },
 "q1156": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Panama?",
  "a": [
   "75 000 km²",
   "7 500 km²",
   "23 000 km²",
   "230 000 km²"
  ]
 },
 "q1157": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Jemen?",
  "a": [
   "530 000 km²",
   "53 000 km²",
   "160 000 km²",
   "1 600 000 km²"
  ]
 },
 "q1158": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Jordanien?",
  "a": [
   "89 000 km²",
   "8 900 km²",
   "27 000 km²",
   "270 000 km²"
  ]
 },
 "q1159": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Nicaragua?",
  "a": [
   "130 000 km²",
   "13 000 km²",
   "39 000 km²",
   "390 000 km²"
  ]
 },
 "q1160": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Kirgisistan?",
  "a": [
   "200 000 km²",
   "20 000 km²",
   "60 000 km²",
   "600 000 km²"
  ]
 },
 "q1161": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Kuwait?",
  "a": [
   "18 000 km²",
   "1 800 km²",
   "5 300 km²",
   "53 000 km²"
  ]
 },
 "q1162": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Laos?",
  "a": [
   "240 000 km²",
   "24 000 km²",
   "71 000 km²",
   "710 000 km²"
  ]
 },
 "q1163": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Libanon?",
  "a": [
   "10 000 km²",
   "1 000 km²",
   "3 100 km²",
   "31 000 km²"
  ]
 },
 "q1164": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Malediven?",
  "a": [
   "300 km²",
   "30 km²",
   "90 km²",
   "900 km²"
  ]
 },
 "q1165": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Malaysia?",
  "a": [
   "330 000 km²",
   "33 000 km²",
   "99 000 km²",
   "990 000 km²"
  ]
 },
 "q1166": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Myanmar?",
  "a": [
   "680 000 km²",
   "68 000 km²",
   "200 000 km²",
   "2 000 000 km²"
  ]
 },
 "q1167": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Nepal?",
  "a": [
   "150 000 km²",
   "15 000 km²",
   "44 000 km²",
   "440 000 km²"
  ]
 },
 "q1168": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Oman?",
  "a": [
   "310 000 km²",
   "31 000 km²",
   "93 000 km²",
   "930 000 km²"
  ]
 },
 "q1169": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Pakistan?",
  "a": [
   "880 000 km²",
   "88 000 km²",
   "260 000 km²",
   "2 600 000 km²"
  ]
 },
 "q1170": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Katar?",
  "a": [
   "12 000 km²",
   "1 200 km²",
   "3 500 km²",
   "35 000 km²"
  ]
 },
 "q1171": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Saudi-Arabien?",
  "a": [
   "2 100 000 km²",
   "210 000 km²",
   "640 000 km²",
   "6 400 000 km²"
  ]
 },
 "q1172": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Sri Lanka?",
  "a": [
   "66 000 km²",
   "6 600 km²",
   "20 000 km²",
   "200 000 km²"
  ]
 },
 "q1173": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Syrien?",
  "a": [
   "190 000 km²",
   "19 000 km²",
   "56 000 km²",
   "560 000 km²"
  ]
 },
 "q1174": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Tadschikistan?",
  "a": [
   "140 000 km²",
   "14 000 km²",
   "43 000 km²",
   "430 000 km²"
  ]
 },
 "q1175": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Thailand?",
  "a": [
   "510 000 km²",
   "51 000 km²",
   "150 000 km²",
   "1 500 000 km²"
  ]
 },
 "q1176": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Turkmenistan?",
  "a": [
   "490 000 km²",
   "49 000 km²",
   "150 000 km²",
   "1 500 000 km²"
  ]
 },
 "q1177": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Vereinigte Arabische Emirate?",
  "a": [
   "84 000 km²",
   "8 400 km²",
   "25 000 km²",
   "250 000 km²"
  ]
 },
 "q1178": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Vietnam?",
  "a": [
   "330 000 km²",
   "33 000 km²",
   "99 000 km²",
   "990 000 km²"
  ]
 },
 "q1179": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Südkorea?",
  "a": [
   "100 000 km²",
   "10 000 km²",
   "30 000 km²",
   "300 000 km²"
  ]
 },
 "q1180": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Afghanistan?",
  "a": [
   "650 000 km²",
   "65 000 km²",
   "200 000 km²",
   "2 000 000 km²"
  ]
 },
 "q1181": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Bangladesch?",
  "a": [
   "150 000 km²",
   "15 000 km²",
   "44 000 km²",
   "440 000 km²"
  ]
 },
 "q1182": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Mali?",
  "a": [
   "1 200 000 km²",
   "120 000 km²",
   "370 000 km²",
   "3 700 000 km²"
  ]
 },
 "q1183": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Angola?",
  "a": [
   "1 200 000 km²",
   "120 000 km²",
   "370 000 km²",
   "3 700 000 km²"
  ]
 },
 "q1184": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Bhutan?",
  "a": [
   "38 000 km²",
   "3 800 km²",
   "12 000 km²",
   "120 000 km²"
  ]
 },
 "q1185": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Brunei?",
  "a": [
   "5 800 km²",
   "580 km²",
   "1 700 km²",
   "17 000 km²"
  ]
 },
 "q1186": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Tansania?",
  "a": [
   "950 000 km²",
   "95 000 km²",
   "280 000 km²",
   "2 800 000 km²"
  ]
 },
 "q1187": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Philippinen?",
  "a": [
   "340 000 km²",
   "34 000 km²",
   "100 000 km²",
   "1 000 000 km²"
  ]
 },
 "q1188": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Zentralafrikanische Republik?",
  "a": [
   "620 000 km²",
   "62 000 km²",
   "190 000 km²",
   "1 900 000 km²"
  ]
 },
 "q1189": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Togo?",
  "a": [
   "57 000 km²",
   "5 700 km²",
   "17 000 km²",
   "170 000 km²"
  ]
 },
 "q1190": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Tunesien?",
  "a": [
   "160 000 km²",
   "16 000 km²",
   "49 000 km²",
   "490 000 km²"
  ]
 },
 "q1191": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Sambia?",
  "a": [
   "750 000 km²",
   "75 000 km²",
   "230 000 km²",
   "2 300 000 km²"
  ]
 },
 "q1192": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Simbabwe?",
  "a": [
   "390 000 km²",
   "39 000 km²",
   "120 000 km²",
   "1 200 000 km²"
  ]
 },
 "q1193": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Südsudan?",
  "a": [
   "620 000 km²",
   "62 000 km²",
   "190 000 km²",
   "1 900 000 km²"
  ]
 },
 "q1194": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Benin?",
  "a": [
   "110 000 km²",
   "11 000 km²",
   "34 000 km²",
   "340 000 km²"
  ]
 },
 "q1195": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Botswana?",
  "a": [
   "580 000 km²",
   "58 000 km²",
   "170 000 km²",
   "1 700 000 km²"
  ]
 },
 "q1196": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Burkina Faso?",
  "a": [
   "270 000 km²",
   "27 000 km²",
   "82 000 km²",
   "820 000 km²"
  ]
 },
 "q1197": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Burundi?",
  "a": [
   "28 000 km²",
   "2 800 km²",
   "8 400 km²",
   "84 000 km²"
  ]
 },
 "q1198": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Komoren?",
  "a": [
   "1 900 km²",
   "190 km²",
   "560 km²",
   "5 600 km²"
  ]
 },
 "q1199": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Republik Kongo?",
  "a": [
   "340 000 km²",
   "34 000 km²",
   "100 000 km²",
   "1 000 000 km²"
  ]
 },
 "q1200": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Demokratische Republik Kongo?",
  "a": [
   "2 300 000 km²",
   "230 000 km²",
   "700 000 km²",
   "7 000 000 km²"
  ]
 },
 "q1201": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Dschibuti?",
  "a": [
   "23 000 km²",
   "2 300 km²",
   "7 000 km²",
   "70 000 km²"
  ]
 },
 "q1202": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Äquatorialguinea?",
  "a": [
   "28 000 km²",
   "2 800 km²",
   "8 400 km²",
   "84 000 km²"
  ]
 },
 "q1203": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Eritrea?",
  "a": [
   "120 000 km²",
   "12 000 km²",
   "35 000 km²",
   "350 000 km²"
  ]
 },
 "q1204": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Gabun?",
  "a": [
   "270 000 km²",
   "27 000 km²",
   "80 000 km²",
   "800 000 km²"
  ]
 },
 "q1205": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Gambia?",
  "a": [
   "11 000 km²",
   "1 100 km²",
   "3 200 km²",
   "32 000 km²"
  ]
 },
 "q1206": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Guinea?",
  "a": [
   "250 000 km²",
   "25 000 km²",
   "74 000 km²",
   "740 000 km²"
  ]
 },
 "q1207": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Guinea-Bissau?",
  "a": [
   "36 000 km²",
   "3 600 km²",
   "11 000 km²",
   "110 000 km²"
  ]
 },
 "q1208": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Elfenbeinküste?",
  "a": [
   "320 000 km²",
   "32 000 km²",
   "97 000 km²",
   "970 000 km²"
  ]
 },
 "q1209": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Kamerun?",
  "a": [
   "480 000 km²",
   "48 000 km²",
   "140 000 km²",
   "1 400 000 km²"
  ]
 },
 "q1210": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Kap Verde?",
  "a": [
   "4 000 km²",
   "400 km²",
   "1 200 km²",
   "12 000 km²"
  ]
 },
 "q1211": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Lesotho?",
  "a": [
   "30 000 km²",
   "3 000 km²",
   "9 100 km²",
   "91 000 km²"
  ]
 },
 "q1212": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Liberia?",
  "a": [
   "110 000 km²",
   "11 000 km²",
   "33 000 km²",
   "330 000 km²"
  ]
 },
 "q1213": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Libyen?",
  "a": [
   "1 800 000 km²",
   "180 000 km²",
   "530 000 km²",
   "5 300 000 km²"
  ]
 },
 "q1214": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Madagaskar?",
  "a": [
   "590 000 km²",
   "59 000 km²",
   "180 000 km²",
   "1 800 000 km²"
  ]
 },
 "q1215": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Malawi?",
  "a": [
   "120 000 km²",
   "12 000 km²",
   "36 000 km²",
   "360 000 km²"
  ]
 },
 "q1216": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Mauretanien?",
  "a": [
   "1 000 000 km²",
   "100 000 km²",
   "310 000 km²",
   "3 100 000 km²"
  ]
 },
 "q1217": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Mauritius?",
  "a": [
   "2 000 km²",
   "200 km²",
   "610 km²",
   "6 100 km²"
  ]
 },
 "q1218": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Marokko?",
  "a": [
   "450 000 km²",
   "45 000 km²",
   "130 000 km²",
   "1 300 000 km²"
  ]
 },
 "q1219": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Mosambik?",
  "a": [
   "800 000 km²",
   "80 000 km²",
   "240 000 km²",
   "2 400 000 km²"
  ]
 },
 "q1220": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Namibia?",
  "a": [
   "830 000 km²",
   "83 000 km²",
   "250 000 km²",
   "2 500 000 km²"
  ]
 },
 "q1221": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Niger?",
  "a": [
   "1 300 000 km²",
   "130 000 km²",
   "380 000 km²",
   "3 800 000 km²"
  ]
 },
 "q1222": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Nigeria?",
  "a": [
   "920 000 km²",
   "92 000 km²",
   "280 000 km²",
   "2 800 000 km²"
  ]
 },
 "q1223": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Uganda?",
  "a": [
   "240 000 km²",
   "24 000 km²",
   "72 000 km²",
   "720 000 km²"
  ]
 },
 "q1224": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Ruanda?",
  "a": [
   "26 000 km²",
   "2 600 km²",
   "7 900 km²",
   "79 000 km²"
  ]
 },
 "q1225": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von São Tomé und Príncipe?",
  "a": [
   "960 km²",
   "96 km²",
   "290 km²",
   "2 900 km²"
  ]
 },
 "q1226": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Senegal?",
  "a": [
   "200 000 km²",
   "20 000 km²",
   "59 000 km²",
   "590 000 km²"
  ]
 },
 "q1227": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Seychellen?",
  "a": [
   "450 km²",
   "45 km²",
   "140 km²",
   "1 400 km²"
  ]
 },
 "q1228": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Sierra Leone?",
  "a": [
   "72 000 km²",
   "7 200 km²",
   "22 000 km²",
   "220 000 km²"
  ]
 },
 "q1229": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Somalia?",
  "a": [
   "640 000 km²",
   "64 000 km²",
   "190 000 km²",
   "1 900 000 km²"
  ]
 },
 "q1230": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Sudan?",
  "a": [
   "1 900 000 km²",
   "190 000 km²",
   "570 000 km²",
   "5 700 000 km²"
  ]
 },
 "q1231": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Eswatini?",
  "a": [
   "17 000 km²",
   "1 700 km²",
   "5 200 km²",
   "52 000 km²"
  ]
 },
 "q1232": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Königreich der Niederlande?",
  "a": [
   "42 000 km²",
   "4 200 km²",
   "13 000 km²",
   "130 000 km²"
  ]
 },
 "q1233": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Trinidad und Tobago?",
  "a": [
   "5 100 km²",
   "510 km²",
   "1 500 km²",
   "15 000 km²"
  ]
 },
 "q1234": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von St. Vincent und die Grenadinen?",
  "a": [
   "390 km²",
   "39 km²",
   "120 km²",
   "1 200 km²"
  ]
 },
 "q1235": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von St. Lucia?",
  "a": [
   "620 km²",
   "62 km²",
   "180 km²",
   "1 800 km²"
  ]
 },
 "q1236": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Dänemark?",
  "a": [
   "43 000 km²",
   "4 300 km²",
   "13 000 km²",
   "130 000 km²"
  ]
 },
 "q1237": {
  "q": "Wie groß ist ungefähr die Gesamtfläche von Palästina?",
  "a": [
   "6 200 km²",
   "620 km²",
   "1 900 km²",
   "19 000 km²"
  ]
 },
 "q1238": {
  "q": "Welche gefrorene Substanz wird in Cocktails am häufigsten verwendet, um das Getränk zu kühlen?",
  "a": [
   "Eiswürfel",
   "Gefrorene Erbsen",
   "Gefrorener Fisch",
   "Gefrorenes Brot"
  ]
 },
 "q1239": {
  "q": "Welches frische Kraut ist eine wesentliche Zutat in einem klassischen Mojito-Cocktail?",
  "a": [
   "Minze",
   "Rosmarin",
   "Basilikum",
   "Thymian"
  ]
 },
 "q1240": {
  "q": "Welcher Gemüsesaft bildet die Basis eines klassischen Bloody-Mary-Cocktails?",
  "a": [
   "Tomatensaft",
   "Karottensaft",
   "Rote-Bete-Saft",
   "Selleriesaft"
  ]
 },
 "q1241": {
  "q": "Welcher tropische Fruchtgeschmack wird in einer klassischen Piña Colada mit Kokosnuss kombiniert?",
  "a": [
   "Ananas",
   "Mango",
   "Papaya",
   "Passionsfrucht"
  ]
 },
 "q1242": {
  "q": "Welche mexikanische Spirituose ist die Hauptalkoholzutat in einer Margarita?",
  "a": [
   "Tequila",
   "Rum",
   "Wodka",
   "Gin"
  ]
 },
 "q1243": {
  "q": "Welche Zutat wird traditionell verwendet, um den Rand eines klassischen Margarita-Glases zu verzieren?",
  "a": [
   "Salz",
   "Zimt",
   "Kakaopulver",
   "Gehackte Nüsse"
  ]
 },
 "q1244": {
  "q": "Welches Landes Nationalcocktail gilt die Caipirinha?",
  "a": [
   "Brasilien",
   "Argentinien",
   "Peru",
   "Kolumbien"
  ]
 },
 "q1245": {
  "q": "Welche zwei Hauptzutaten bilden einen klassischen Black-Russian-Cocktail?",
  "a": [
   "Wodka und Kaffeelikör",
   "Gin und trockener Wermut",
   "Rum und Cola",
   "Whiskey und süßer Wermut"
  ]
 },
 "q1246": {
  "q": "Wie bestellt der fiktive Geheimagent James Bond seinen Wodka-Martini bekanntermaßen?",
  "a": [
   "Geschüttelt, nicht gerührt",
   "Püriert, nicht gegossen",
   "Warm, nicht gekühlt",
   "Pur, ohne Eis"
  ]
 },
 "q1247": {
  "q": "Welcher Schaumwein wird mit Pfirsichpüree gemischt, um einen klassischen Bellini-Cocktail zuzubereiten?",
  "a": [
   "Prosecco",
   "Apfelwein",
   "Sherry",
   "Portwein"
  ]
 },
 "q1248": {
  "q": "Welche drei Zutaten werden zu gleichen Teilen für einen klassischen Negroni gemischt?",
  "a": [
   "Gin, Campari, süßer Wermut",
   "Wodka, Triple Sec, Limettensaft",
   "Rum, Amaretto, trockener Wermut",
   "Tequila, Aperol, Weißwein"
  ]
 },
 "q1249": {
  "q": "In welcher Art von Becher wird ein klassischer Moscow-Mule-Cocktail traditionell serviert?",
  "a": [
   "Kupferbecher",
   "Holzkrug",
   "Tonschale",
   "Pappbecher"
  ]
 },
 "q1250": {
  "q": "Welches Barwerkzeug wird verwendet, um Kräuter, Früchte oder Zuckerwürfel am Boden eines Glases zu zerdrücken?",
  "a": [
   "Stößel (Muddler)",
   "Barmaß (Jigger)",
   "Barsieb (Strainer)",
   "Barlöffel"
  ]
 },
 "q1251": {
  "q": "Welche Zutat verleiht einem klassischen Whiskey Sour seine charakteristische samtige Schaumkrone?",
  "a": [
   "Eiweiß",
   "Schlagsahne",
   "Aufgeschlagene Butter",
   "Kokosmilch"
  ]
 },
 "q1252": {
  "q": "In welcher berühmten Bar des Raffles Hotels wurde Anfang des 20. Jahrhunderts der Cocktail Singapore Sling kreiert?",
  "a": [
   "Long Bar",
   "Blue Bar",
   "Harry's Bar",
   "American Bar"
  ]
 },
 "q1253": {
  "q": "Welche Art von Cocktail-Shaker besteht aus einem großen Metallbecher und einem kleineren Metallbecher oder Mixglas?",
  "a": [
   "Boston-Shaker",
   "Cobbler-Shaker",
   "Pariser Shaker",
   "Wiener Shaker"
  ]
 },
 "q1254": {
  "q": "Welcher US-amerikanische Barkeeper des 19. Jahrhunderts veröffentlichte 1862 das erste bekannte Cocktail-Rezeptbuch?",
  "a": [
   "Jerry Thomas",
   "Harry Craddock",
   "Ada Coleman",
   "Dale DeGroff"
  ]
 },
 "q1255": {
  "q": "In welcher New Yorker Publikation von 1806 erschien die früheste bekannte gedruckte Definition des Wortes Cocktail?",
  "a": [
   "The Balance and Columbian Repository",
   "The New York Times",
   "Harper's Weekly",
   "The Saturday Evening Post"
  ]
 },
 "q1256": {
  "q": "Welche pflanzliche Verbindung verursacht den milchig-weißen Louche-Effekt, wenn Absinth oder Pastis kaltes Wasser zugesetzt wird?",
  "a": [
   "Anethol",
   "Capsaicin",
   "Chinin",
   "Tannin"
  ]
 },
 "q1257": {
  "q": "Wer schuf als legendäre Chef-Barkeeperin der Londoner Savoy American Bar Anfang des 20. Jahrhunderts den Cocktail Hanky Panky?",
  "a": [
   "Ada Coleman",
   "Harry Craddock",
   "Dick Bradsell",
   "Peter Dorelli"
  ]
 },
 "q1258": {
  "q": "In welcher Apotheke in New Orleans erfand Antoine Amédée Peychaud im 19. Jahrhundert seinen berühmten aromatischen Bitter?",
  "a": [
   "Pharmacie Peychaud",
   "Apothecary Lafitte",
   "Carondelet Dispensary",
   "Royal Street Chemist"
  ]
 },
 "q1259": {
  "q": "Welches Organ pumpt Blut durch den menschlichen Körper?",
  "a": [
   "Das Herz",
   "Die Leber",
   "Der Magen",
   "Das Gehirn"
  ]
 },
 "q1260": {
  "q": "Wie viele Finger und Daumen hat ein Mensch normalerweise an beiden Händen zusammen?",
  "a": [
   "10",
   "5",
   "8",
   "12"
  ]
 },
 "q1261": {
  "q": "Welche Organe ermöglichen es dem Menschen zu atmen und Sauerstoff aus der Luft aufzunehmen?",
  "a": [
   "Die Lunge",
   "Die Nieren",
   "Die Leber",
   "Der Magen"
  ]
 },
 "q1262": {
  "q": "Was ist das größte äußere Organ des menschlichen Körpers?",
  "a": [
   "Die Haut",
   "Die Leber",
   "Das Gehirn",
   "Das Herz"
  ]
 },
 "q1263": {
  "q": "Wie viele bleibende Zähne hat ein typischer erwachsener Mensch?",
  "a": [
   "32",
   "20",
   "24",
   "40"
  ]
 },
 "q1264": {
  "q": "Welcher Teil des menschlichen Auges gibt ihm seine Farbe und steuert die Größe der Pupille?",
  "a": [
   "Die Iris",
   "Die Netzhaut",
   "Die Hornhaut",
   "Der Sehnerv"
  ]
 },
 "q1265": {
  "q": "Welche Substanz verleiht den roten Blutkörperchen ihre Farbe und transportiert Sauerstoff?",
  "a": [
   "Hämoglobin",
   "Insulin",
   "Melanin",
   "Keratin"
  ]
 },
 "q1266": {
  "q": "Welcher Knochen ist der längste und stärkste im menschlichen Körper?",
  "a": [
   "Der Oberschenkelknochen",
   "Der Oberarmknochen",
   "Das Schienbein",
   "Das Schlüsselbein"
  ]
 },
 "q1267": {
  "q": "Wie heißt der Muskelschlauch, der die Nahrung vom Rachen in den Magen befördert?",
  "a": [
   "Die Speiseröhre",
   "Die Luftröhre",
   "Der Zwölffingerdarm",
   "Die Aorta"
  ]
 },
 "q1268": {
  "q": "Aus wie vielen Kammern besteht das menschliche Herz?",
  "a": [
   "4",
   "2",
   "3",
   "6"
  ]
 },
 "q1269": {
  "q": "Welches Organ im menschlichen Körper produziert Insulin zur Regulierung des Blutzuckers?",
  "a": [
   "Die Bauchspeicheldrüse",
   "Die Milz",
   "Die Gallenblase",
   "Die Schilddrüse"
  ]
 },
 "q1270": {
  "q": "Wie viele Knochen hat das Skelett eines typischen erwachsenen Menschen?",
  "a": [
   "206",
   "186",
   "226",
   "256"
  ]
 },
 "q1271": {
  "q": "Welches Pigment verleiht der menschlichen Haut, den Haaren und den Augen ihre Farbe?",
  "a": [
   "Melanin",
   "Keratin",
   "Kollagen",
   "Bilirubin"
  ]
 },
 "q1272": {
  "q": "Wo im menschlichen Körper befinden sich die kleinsten Knochen?",
  "a": [
   "Im Mittelohr",
   "In der Nasenspitze",
   "Im kleinen Zeh",
   "Im Handgelenk"
  ]
 },
 "q1273": {
  "q": "Welche Blutgruppe gilt als Universalspender für rote Blutkörperchen?",
  "a": [
   "0 negativ",
   "AB positiv",
   "A positiv",
   "B negativ"
  ]
 },
 "q1274": {
  "q": "Welcher Teil des menschlichen Gehirns ist hauptsächlich für Gleichgewicht und Bewegungskoordination zuständig?",
  "a": [
   "Das Kleinhirn",
   "Der Hypothalamus",
   "Die Amygdala",
   "Der Hippocampus"
  ]
 },
 "q1275": {
  "q": "Welcher kuppelförmige Muskel unterhalb der Lunge ist der Hauptatemmuskel?",
  "a": [
   "Das Zwerchfell",
   "Der Trapezmuskel",
   "Der Deltamuskel",
   "Der Schneidermuskel"
  ]
 },
 "q1276": {
  "q": "Welches Organ produziert Galle, um die Fettverdauung im Dünndarm zu unterstützen?",
  "a": [
   "Die Leber",
   "Die Bauchspeicheldrüse",
   "Der Magen",
   "Die Milz"
  ]
 },
 "q1277": {
  "q": "Wie viele Chromosomenpaare befinden sich normalerweise in einer menschlichen Körperzelle?",
  "a": [
   "23",
   "21",
   "24",
   "46"
  ]
 },
 "q1278": {
  "q": "Welches ist die größte Arterie im menschlichen Körper?",
  "a": [
   "Die Aorta",
   "Die Halsschlagader",
   "Die Lungenarterie",
   "Die Oberschenkelarterie"
  ]
 },
 "q1279": {
  "q": "Wie viele Rippenpaare hat ein typischer menschlicher Brustkorb?",
  "a": [
   "12",
   "10",
   "14",
   "16"
  ]
 },
 "q1280": {
  "q": "Welches feste Faserband verbindet einen Muskel mit einem Knochen?",
  "a": [
   "Eine Sehne",
   "Ein Band",
   "Knorpel",
   "Faszie"
  ]
 },
 "q1281": {
  "q": "Was ist die härteste Substanz im menschlichen Körper?",
  "a": [
   "Zahnschmelz",
   "Oberschenkelknochen",
   "Dentin",
   "Nagelkeratin"
  ]
 },
 "q1282": {
  "q": "Welches von der Zirbeldrüse produzierte Hormon hilft bei der Regulierung des Schlaf-Wach-Rhythmus?",
  "a": [
   "Melatonin",
   "Cortisol",
   "Adrenalin",
   "Oxytocin"
  ]
 },
 "q1283": {
  "q": "Wie heißen die winzigen Lungenbläschen, in denen Sauerstoff und Kohlendioxid ausgetauscht werden?",
  "a": [
   "Alveolen",
   "Nephrone",
   "Zotten",
   "Bronchiolen"
  ]
 },
 "q1284": {
  "q": "Welches der drei Gehörknöchelchen im menschlichen Mittelohr ist der kleinste Knochen im gesamten Körper?",
  "a": [
   "Der Steigbügel",
   "Der Hammer",
   "Der Amboss",
   "Das Zungenbein"
  ]
 },
 "q1285": {
  "q": "Welcher ist der einzige Knochen im menschlichen Körper, der nicht direkt mit einem anderen Knochen verbunden ist?",
  "a": [
   "Das Zungenbein",
   "Die Kniescheibe",
   "Das Steißbein",
   "Das Pflugscharbein"
  ]
 },
 "q1286": {
  "q": "Wie viele Halswirbel hat ein typischer menschlicher Hals?",
  "a": [
   "7",
   "5",
   "9",
   "12"
  ]
 },
 "q1287": {
  "q": "Welcher Bereich der menschlichen Großhirnrinde enthält den primären visuellen Kortex?",
  "a": [
   "Der Okzipitallappen",
   "Der Frontallappen",
   "Der Parietallappen",
   "Der Temporallappen"
  ]
 },
 "q1288": {
  "q": "Wie heißt die funktionelle Filtrationseinheit der menschlichen Niere?",
  "a": [
   "Das Nephron",
   "Der Hepatozyt",
   "Das Osteon",
   "Das Sarkomer"
  ]
 },
 "q1289": {
  "q": "In welcher europäischen Stadt steht der berühmte Eiffelturm?",
  "a": [
   "Paris",
   "Lyon",
   "Brüssel",
   "Madrid"
  ]
 },
 "q1290": {
  "q": "In welchem Land befinden sich die antiken Pyramiden von Gizeh?",
  "a": [
   "Ägypten",
   "Norwegen",
   "Kanada",
   "Japan"
  ]
 },
 "q1291": {
  "q": "Welches Land schenkte den Vereinigten Staaten im Jahr 1886 die Freiheitsstatue?",
  "a": [
   "Frankreich",
   "Vereinigtes Königreich",
   "Spanien",
   "Italien"
  ]
 },
 "q1292": {
  "q": "In welcher italienischen Stadt steht der berühmte Schiefe Turm?",
  "a": [
   "Pisa",
   "Venedig",
   "Mailand",
   "Neapel"
  ]
 },
 "q1293": {
  "q": "In welcher indischen Stadt befindet sich das Taj Mahal?",
  "a": [
   "Agra",
   "Mumbai",
   "Kalkutta",
   "Chennai"
  ]
 },
 "q1294": {
  "q": "In welchem südamerikanischen Land befindet sich die antike Inka-Ruinenstadt Machu Picchu?",
  "a": [
   "Peru",
   "Chile",
   "Kolumbien",
   "Argentinien"
  ]
 },
 "q1295": {
  "q": "Welches australische Wahrzeichen hat ein Dach aus markanten segelförmigen Schalen?",
  "a": [
   "Opernhaus von Sydney",
   "Melbourne Cricket Ground",
   "Parlamentsgebäude",
   "Royal Exhibition Building"
  ]
 },
 "q1296": {
  "q": "Wer war der Chefarchitekt der berühmten Basilika Sagrada Família in Barcelona?",
  "a": [
   "Antoni Gaudí",
   "Salvador Dalí",
   "Pablo Picasso",
   "Joan Miró"
  ]
 },
 "q1297": {
  "q": "Auf welchem Berg in Rio de Janeiro steht die Statue Christus der Erlöser?",
  "a": [
   "Corcovado",
   "Zuckerhut",
   "Monte Roraima",
   "Pico da Neblina"
  ]
 },
 "q1298": {
  "q": "In welchem Land liegt die antike Felsenstadt Petra?",
  "a": [
   "Jordanien",
   "Libanon",
   "Syrien",
   "Oman"
  ]
 },
 "q1299": {
  "q": "In welchem südostasiatischen Land befindet sich die Tempelanlage Angkor Wat?",
  "a": [
   "Kambodscha",
   "Thailand",
   "Laos",
   "Vietnam"
  ]
 },
 "q1300": {
  "q": "In welcher Stadt steht der Burj Khalifa, der höchste Wolkenkratzer der Welt?",
  "a": [
   "Dubai",
   "Abu Dhabi",
   "Doha",
   "Riad"
  ]
 },
 "q1301": {
  "q": "Zu welchem Land gehört die Osterinsel, die für ihre monumentalen Moai-Statuen berühmt ist?",
  "a": [
   "Chile",
   "Peru",
   "Ecuador",
   "Neuseeland"
  ]
 },
 "q1302": {
  "q": "Für welchen byzantinischen Kaiser des 6. Jahrhunderts wurde die Hagia Sophia in Istanbul erbaut?",
  "a": [
   "Justinian I.",
   "Konstantin der Große",
   "Theodosius I.",
   "Basileios II."
  ]
 },
 "q1303": {
  "q": "In welchem europäischen Gebirge liegt das bulgarische UNESCO-Welterbe Kloster Rila?",
  "a": [
   "Rila",
   "Pirin",
   "Rhodopen",
   "Witoscha"
  ]
 },
 "q1304": {
  "q": "In welchem deutschen Bundesland steht das Märchenschloss Neuschwanstein?",
  "a": [
   "Bayern",
   "Baden-Württemberg",
   "Hessen",
   "Sachsen"
  ]
 },
 "q1305": {
  "q": "In welchem US-Bundesstaat befindet sich das Mount Rushmore National Memorial?",
  "a": [
   "South Dakota",
   "North Dakota",
   "Montana",
   "Wyoming"
  ]
 },
 "q1306": {
  "q": "Zwischen welchen beiden afrikanischen Ländern liegen die Victoriafälle am Sambesi?",
  "a": [
   "Sambia und Simbabwe",
   "Kenia und Tansania",
   "Namibia und Botswana",
   "Mosambik und Malawi"
  ]
 },
 "q1307": {
  "q": "Welcher chinesische Kaiser gab die nahe Xi'an begrabene Terrakotta-Armee in Auftrag?",
  "a": [
   "Qin Shihuangdi",
   "Han Wudi",
   "Kublai Khan",
   "Tang Taizong"
  ]
 },
 "q1308": {
  "q": "Auf welcher indonesischen Insel befindet sich der buddhistische Tempel Borobudur aus dem 9. Jahrhundert?",
  "a": [
   "Java",
   "Bali",
   "Sumatra",
   "Sulawesi"
  ]
 },
 "q1309": {
  "q": "In welcher japanischen Stadt steht der berühmte mit Blattgold überzogene Pavillon Kinkaku-ji?",
  "a": [
   "Kyōto",
   "Nara",
   "Osaka",
   "Kamakura"
  ]
 },
 "q1310": {
  "q": "In welcher spanischen Stadt steht die maurische Palast- und Festungsanlage Alhambra?",
  "a": [
   "Granada",
   "Sevilla",
   "Córdoba",
   "Toledo"
  ]
 },
 "q1311": {
  "q": "Welcher russische Zar des 16. Jahrhunderts gab die Basilius-Kathedrale auf dem Moskauer Roten Platz in Auftrag?",
  "a": [
   "Iwan der Schreckliche",
   "Boris Godunow",
   "Peter der Große",
   "Wassili III."
  ]
 },
 "q1312": {
  "q": "In welcher türkischen Provinz liegt die jungsteinzeitliche Fundstätte Göbekli Tepe?",
  "a": [
   "Şanlıurfa",
   "Konya",
   "Nevşehir",
   "Antalya"
  ]
 },
 "q1313": {
  "q": "In welchem afrikanischen Land befinden sich die mittelalterlichen Felsenkirchen von Lalibela?",
  "a": [
   "Äthiopien",
   "Eritrea",
   "Sudan",
   "Kenia"
  ]
 },
 "q1314": {
  "q": "In welchem indischen Bundesstaat liegen die zum UNESCO-Welterbe gehörenden Höhlentempel von Ajanta und Ellora?",
  "a": [
   "Maharashtra",
   "Karnataka",
   "Madhya Pradesh",
   "Gujarat"
  ]
 },
 "q1315": {
  "q": "In der Nähe welches bulgarischen Dorfes ist das frühmittelalterliche Felsrelief Reiter von Madara eingemeißelt?",
  "a": [
   "Madara",
   "Pliska",
   "Preslaw",
   "Sweschtari"
  ]
 },
 "q1316": {
  "q": "Welcher sassanidische König des 6. Jahrhunderts gab den Bogen Taq Kasra in Ktesiphon im Irak in Auftrag?",
  "a": [
   "Chosrau I.",
   "Schapur I.",
   "Ardaschir I.",
   "Yazdegerd III."
  ]
 },
 "q1317": {
  "q": "Wer war der Chefarchitekt des Opernhauses von Sydney, der 1966 vor dessen Fertigstellung zurücktrat?",
  "a": [
   "Jørn Utzon",
   "Eero Saarinen",
   "Alvar Aalto",
   "Arne Jacobsen"
  ]
 },
 "q1318": {
  "q": "Welcher Khmer-König des 12. Jahrhunderts gab den Bau von Angkor Wat in Auftrag?",
  "a": [
   "Suryavarman II.",
   "Jayavarman VII.",
   "Indravarman I.",
   "Yasovarman I."
  ]
 },
 "q1319": {
  "q": "Wer war der Hofarchitekt des Mogulreichs, dem der Entwurf des Taj Mahal zugeschrieben wird?",
  "a": [
   "Ustad Ahmad Lahori",
   "Mirak Mirza Ghiyas",
   "Ustad Isa",
   "Mimar Sinan"
  ]
 },
 "q1320": {
  "q": "Welche prähistorische Erfindung revolutionierte den menschlichen Transport und die Töpferei?",
  "a": [
   "Das Rad",
   "Die Druckerpresse",
   "Der Kompass",
   "Die Dampfmaschine"
  ]
 },
 "q1321": {
  "q": "Wer erhielt 1876 das erste US-Patent für das Telefon?",
  "a": [
   "Alexander Graham Bell",
   "Thomas Edison",
   "Nikola Tesla",
   "Guglielmo Marconi"
  ]
 },
 "q1322": {
  "q": "In welchem antiken Land wurde um das 2. Jahrhundert v. Chr. die Papierherstellung erfunden?",
  "a": [
   "China",
   "Ägypten",
   "Griechenland",
   "Mesopotamien"
  ]
 },
 "q1323": {
  "q": "Wer erfand um 1440 die europäische Druckerpresse mit beweglichen Lettern?",
  "a": [
   "Johannes Gutenberg",
   "Leonardo da Vinci",
   "Galileo Galilei",
   "Martin Luther"
  ]
 },
 "q1324": {
  "q": "Welche Brüder vollbrachten 1903 den ersten gesteuerten, anhaltenden Motorflug?",
  "a": [
   "Orville und Wilbur Wright",
   "Auguste und Louis Lumière",
   "Joseph-Michel und Jacques-Étienne Montgolfier",
   "Jacob und Wilhelm Grimm"
  ]
 },
 "q1325": {
  "q": "Welcher englische Arzt entwickelte 1796 den ersten erfolgreichen Pockenimpfstoff?",
  "a": [
   "Edward Jenner",
   "Louis Pasteur",
   "Alexander Fleming",
   "Robert Koch"
  ]
 },
 "q1326": {
  "q": "Wer meldete 1886 den Benz Patent-Motorwagen zum Patent an, der als erstes modernes Automobil gilt?",
  "a": [
   "Carl Benz",
   "Henry Ford",
   "Gottlieb Daimler",
   "Rudolf Diesel"
  ]
 },
 "q1327": {
  "q": "Welcher italienische Physiker erfand im Jahr 1800 die Voltasche Säule, die erste echte elektrische Batterie?",
  "a": [
   "Alessandro Volta",
   "Luigi Galvani",
   "André-Marie Ampère",
   "Michael Faraday"
  ]
 },
 "q1328": {
  "q": "Welcher britische Informatiker erfand 1989 am CERN das World Wide Web?",
  "a": [
   "Tim Berners-Lee",
   "Vint Cerf",
   "Alan Turing",
   "Marc Andreessen"
  ]
 },
 "q1329": {
  "q": "Welcher französische Arzt erfand 1816 das Stethoskop?",
  "a": [
   "René Laennec",
   "Louis Pasteur",
   "Claude Bernard",
   "Ambroise Paré"
  ]
 },
 "q1330": {
  "q": "Wer schuf um 1826 mit „Blick aus dem Arbeitszimmer von Le Gras“ die älteste erhaltene Fotografie?",
  "a": [
   "Nicéphore Niépce",
   "Louis Daguerre",
   "William Henry Fox Talbot",
   "George Eastman"
  ]
 },
 "q1331": {
  "q": "Wer patentierte 1853 die Sicherheitsfangvorrichtung für Aufzüge und machte Wolkenkratzer erst praktikabel?",
  "a": [
   "Elisha Otis",
   "Gustave Eiffel",
   "George Westinghouse",
   "Werner von Siemens"
  ]
 },
 "q1332": {
  "q": "Welcher niederländische Brillenmacher reichte 1608 den frühesten bekannten Patentantrag für ein Linsenfernrohr ein?",
  "a": [
   "Hans Lipperhey",
   "Christiaan Huygens",
   "Antonie van Leeuwenhoek",
   "Willebrord van Roijen Snell"
  ]
 },
 "q1333": {
  "q": "Wer baute 1960 in den Hughes Research Laboratories den ersten funktionierenden Rubinlaser?",
  "a": [
   "Theodore Maiman",
   "Charles Townes",
   "Arthur Schawlow",
   "Gordon Gould"
  ]
 },
 "q1334": {
  "q": "Wer führte 1926 in London das erste funktionierende mechanische Fernsehsystem vor?",
  "a": [
   "John Logie Baird",
   "Philo Farnsworth",
   "Vladimir Zworykin",
   "Paul Nipkow"
  ]
 },
 "q1335": {
  "q": "Wer erfand 1964 am Stanford Research Institute die erste Computermaus aus Holz?",
  "a": [
   "Douglas Engelbart",
   "Alan Kay",
   "Ivan Sutherland",
   "Charles Thacker"
  ]
 },
 "q1336": {
  "q": "Welcher in Belgien geborene Chemiker erfand 1907 Bakelit, den ersten vollsynthetischen Kunststoff?",
  "a": [
   "Leo Baekeland",
   "Wallace Carothers",
   "Alexander Parkes",
   "Hermann Staudinger"
  ]
 },
 "q1337": {
  "q": "Wer baute im September 1958 bei Texas Instruments den ersten funktionierenden integrierten Schaltkreis?",
  "a": [
   "Jack Kilby",
   "Robert Noyce",
   "William Shockley",
   "Gordon Moore"
  ]
 },
 "q1338": {
  "q": "Wer patentierte 1917 den modernen Reißverschluss nach Weiterentwicklung früherer Verschlussmodelle?",
  "a": [
   "Gideon Sundbäck",
   "Whitcomb Judson",
   "Elias Howe",
   "Walter Hunt"
  ]
 },
 "q1339": {
  "q": "Welcher Universalgelehrte der Han-Dynastie erfand 132 n. Chr. das Houfeng Didong Yi, das erste bekannte Seismoskop?",
  "a": [
   "Zhang Heng",
   "Cai Lun",
   "Bi Sheng",
   "Zu Chongzhi"
  ]
 },
 "q1340": {
  "q": "Wer malte das berühmte Porträt Mona Lisa?",
  "a": [
   "Leonardo da Vinci",
   "Michelangelo",
   "Raffael",
   "Botticelli"
  ]
 },
 "q1341": {
  "q": "Welcher niederländische Künstler malte 1889 Die Sternennacht?",
  "a": [
   "Vincent van Gogh",
   "Rembrandt",
   "Jan Vermeer",
   "Piet Mondrian"
  ]
 },
 "q1342": {
  "q": "In welchem Museum ist Leonardo da Vincis Mona Lisa dauerhaft ausgestellt?",
  "a": [
   "Im Louvre",
   "Im Prado",
   "In den Uffizien",
   "Im British Museum"
  ]
 },
 "q1343": {
  "q": "Wer malte 1893 das berühmte expressionistische Werk Der Schrei?",
  "a": [
   "Edvard Munch",
   "Gustav Klimt",
   "Egon Schiele",
   "Wassily Kandinsky"
  ]
 },
 "q1344": {
  "q": "Welches Gemälde von Pablo Picasso zeigt die Bombardierung einer baskischen Stadt im Jahr 1937?",
  "a": [
   "Guernica",
   "Les Demoiselles d'Avignon",
   "Der alte Gitarrenspieler",
   "Die weinende Frau"
  ]
 },
 "q1345": {
  "q": "Welche Gegenstände scheinen in Salvador Dalís Gemälde Die Beständigkeit der Erinnerung von 1931 zu schmelzen?",
  "a": [
   "Taschenuhren",
   "Kerzen",
   "Geigen",
   "Weingläser"
  ]
 },
 "q1346": {
  "q": "Welcher Meister des Goldenen Zeitalters der Niederlande malte um 1665 Das Mädchen mit dem Perlenohrgehänge?",
  "a": [
   "Jan Vermeer",
   "Frans Hals",
   "Jan Steen",
   "Hieronymus Bosch"
  ]
 },
 "q1347": {
  "q": "Worauf steht Venus in Sandro Botticellis Gemälde Die Geburt der Venus?",
  "a": [
   "Auf einer riesigen Jakobsmuschel",
   "Auf einem Marmorsockel",
   "Auf einem weißen Schwan",
   "Auf einem Holzfloß"
  ]
 },
 "q1348": {
  "q": "Welcher französische Maler schuf die berühmte Serie von rund 250 Ölgemälden mit dem Titel Seerosen?",
  "a": [
   "Claude Monet",
   "Pierre-Auguste Renoir",
   "Edgar Degas",
   "Paul Cézanne"
  ]
 },
 "q1349": {
  "q": "Welcher Berg ist im Hintergrund von Hokusais Farbholzschnitt Die große Welle vor Kanagawa zu sehen?",
  "a": [
   "Der Fuji",
   "Der Aso",
   "Der Kita",
   "Der Ontake"
  ]
 },
 "q1350": {
  "q": "Welches landwirtschaftliche Werkzeug hält der Mann in Grant Woods Gemälde American Gothic von 1930?",
  "a": [
   "Eine Mistgabel",
   "Eine Sense",
   "Eine Schaufel",
   "Einen Holzrechen"
  ]
 },
 "q1351": {
  "q": "In welchem Museum ist Gustav Klimts Gemälde Der Kuss dauerhaft ausgestellt?",
  "a": [
   "Im Schloss Belvedere in Wien",
   "Im Kunsthistorischen Museum in Wien",
   "In der Alten Nationalgalerie in Berlin",
   "In der Pinakothek der Moderne in München"
  ]
 },
 "q1352": {
  "q": "Welcher spanische Barockmaler schuf 1656 das Meisterwerk Las Meninas?",
  "a": [
   "Diego Velázquez",
   "Francisco de Goya",
   "El Greco",
   "Bartolomé Esteban Murillo"
  ]
 },
 "q1353": {
  "q": "Welcher Gegenstand verdeckt das Gesicht des Mannes in René Magrittes Gemälde Der Sohn des Mannes von 1964?",
  "a": [
   "Ein grüner Apfel",
   "Eine weiße Taube",
   "Eine Melone",
   "Eine rote Rose"
  ]
 },
 "q1354": {
  "q": "Wer ist der schwarz gekleidete Hauptmann mit roter Schärpe in Rembrandts Gemälde Die Nachtwache von 1642?",
  "a": [
   "Frans Banninck Cocq",
   "Willem van Ruytenburch",
   "Jan Six",
   "Nicolaes Tulp"
  ]
 },
 "q1355": {
  "q": "Welcher Aufstand inspirierte Eugène Delacroix' Gemälde Die Freiheit führt das Volk von 1830?",
  "a": [
   "Die Julirevolution von 1830",
   "Der Sturm auf die Bastille 1789",
   "Die Pariser Kommune von 1871",
   "Die Februarrevolution von 1848"
  ]
 },
 "q1356": {
  "q": "Welche Maltechnik verwendete Georges Seurat in Ein Sonntagnachmittag auf der Insel La Grande Jatte?",
  "a": [
   "Pointillismus",
   "Chiaroscuro",
   "Sfumato",
   "Impasto"
  ]
 },
 "q1357": {
  "q": "Welcher in Bulgarien tätige Künstler malte 1892 das berühmte Werk Ratscheniza?",
  "a": [
   "Ivan Mrkvička",
   "Wladimir Dimitrow-Maistora",
   "Slatju Bojadschiew",
   "Zanko Lawrenow"
  ]
 },
 "q1358": {
  "q": "Welcher verborgene Gegenstand erscheint verzerrt im Vordergrund von Hans Holbeins des Jüngeren Gemälde Die Gesandten von 1533?",
  "a": [
   "Ein menschlicher Schädel",
   "Eine goldene Krone",
   "Ein Schiffsanker",
   "Eine zusammengerollte Schlange"
  ]
 },
 "q1359": {
  "q": "Welche lateinische Inschrift steht über dem Spiegel in Jan van Eycks Gemälde Arnolfini-Hochzeit von 1434?",
  "a": [
   "Johannes de Eyck fuit hic",
   "Memento mori",
   "Ars longa vita brevis",
   "Vanitas vanitatum"
  ]
 },
 "q1360": {
  "q": "In welcher alten Sprache ist die berühmte Phrase 'Carpe diem' verfasst?",
  "a": [
   "Latein",
   "Altägyptisch",
   "Altnordisch",
   "Sumerisch"
  ]
 },
 "q1361": {
  "q": "Welcher römische Feldherr verkündete nach einem schnellen Sieg berühmt 'Veni, vidi, vici'?",
  "a": [
   "Julius Cäsar",
   "Augustus",
   "Nero",
   "Mark Aurel"
  ]
 },
 "q1362": {
  "q": "Welcher Philosoph formulierte den berühmten lateinischen Satz 'Cogito, ergo sum'?",
  "a": [
   "René Descartes",
   "Immanuel Kant",
   "Francis Bacon",
   "Baruch Spinoza"
  ]
 },
 "q1363": {
  "q": "Welche internationale Veranstaltung verwendet das lateinische Motto 'Citius, Altius, Fortius'?",
  "a": [
   "Olympische Spiele",
   "Fußball-Weltmeisterschaft",
   "Tour de France",
   "Wimbledon"
  ]
 },
 "q1364": {
  "q": "Welcher römische Dichter schrieb die berühmte lateinische Wendung 'Carpe diem' in seinen Oden?",
  "a": [
   "Horaz",
   "Vergil",
   "Ovid",
   "Catull"
  ]
 },
 "q1365": {
  "q": "Welcher Beruf ist am engsten mit dem lateinischen Grundsatz 'Primum non nocere' verbunden?",
  "a": [
   "Medizin",
   "Architektur",
   "Astronomie",
   "Navigation"
  ]
 },
 "q1366": {
  "q": "In welchem Bereich wird der lateinische Begriff 'Habeas corpus' hauptsächlich verwendet?",
  "a": [
   "Rechtswissenschaft",
   "Botanik",
   "Musiktheorie",
   "Metallurgie"
  ]
 },
 "q1367": {
  "q": "Welchen Fluss überquerte Julius Cäsar 49 v. Chr., als er 'Alea iacta est' sagte?",
  "a": [
   "Rubikon",
   "Tiber",
   "Po",
   "Arno"
  ]
 },
 "q1368": {
  "q": "Was wurde nach altrömischer Tradition einem siegreichen Feldherrn während eines Triumphzugs zugeflüstert?",
  "a": [
   "Memento mori",
   "Carpe diem",
   "In vino veritas",
   "Tabula rasa"
  ]
 },
 "q1369": {
  "q": "Welcher römische Autor hielt das lateinische Sprichwort 'In vino veritas' in seiner Naturalis historia fest?",
  "a": [
   "Plinius der Ältere",
   "Seneca",
   "Cicero",
   "Tacitus"
  ]
 },
 "q1370": {
  "q": "Welcher Kontinent wurde auf frühen Karten historisch mit dem lateinischen Namen 'Terra Australis' bezeichnet?",
  "a": [
   "Australien",
   "Südamerika",
   "Afrika",
   "Nordamerika"
  ]
 },
 "q1371": {
  "q": "Welcher Philosoph machte das lateinische Konzept 'Tabula rasa' 1689 in seinem Werk über den menschlichen Verstand bekannt?",
  "a": [
   "John Locke",
   "Thomas Hobbes",
   "David Hume",
   "George Berkeley"
  ]
 },
 "q1372": {
  "q": "Welcher lateinische Ausdruck beschreibt im antiken Theater ein Stilmittel, bei dem ein unlösbares Problem plötzlich durch ein unerwartetes Eingreifen gelöst wird?",
  "a": [
   "Deus ex machina",
   "In medias res",
   "Alter ego",
   "Magnum opus"
  ]
 },
 "q1373": {
  "q": "Welche römische Militärschrift von Vegetius enthält die ursprüngliche Quelle der lateinischen Maxime 'Si vis pacem, para bellum'?",
  "a": [
   "De re militari",
   "De bello Gallico",
   "Ab urbe condita",
   "Res gestae"
  ]
 },
 "q1374": {
  "q": "Die philosophische Schrift 'De finibus bonorum et malorum' welches römischen Redners ist die Quelle des Blindtextes 'Lorem ipsum'?",
  "a": [
   "Cicero",
   "Quintilian",
   "Lukrez",
   "Varro"
  ]
 },
 "q1375": {
  "q": "Welcher Wissenschaftler prägte 'Eppur si muove' und nannte die vier größten Jupitermonde zuvor lateinisch 'Sidera Medicea'?",
  "a": [
   "Galileo Galilei",
   "Johannes Kepler",
   "Nikolaus Kopernikus",
   "Tycho Brahe"
  ]
 },
 "q1376": {
  "q": "Welcher römische Satiriker prägte die berühmte lateinische Frage 'Quis custodiet ipsos custodes?' in seinen Satiren?",
  "a": [
   "Juvenal",
   "Martial",
   "Persius",
   "Petronius"
  ]
 },
 "q1377": {
  "q": "Welcher trojanische Priester warnt in Vergils Aeneis mit dem lateinischen Vers 'Timeo Danaos et dona ferentes' vor dem hölzernen Pferd?",
  "a": [
   "Laokoon",
   "Priamos",
   "Anchises",
   "Hektor"
  ]
 },
 "q1378": {
  "q": "Welcher römische Senator beendete laut Plutarch seine Reden im Senat wiederholt mit 'Ceterum censeo Carthaginem esse delendam'?",
  "a": [
   "Cato der Ältere",
   "Scipio Africanus",
   "Fabius Maximus",
   "Tiberius Gracchus"
  ]
 },
 "q1379": {
  "q": "Welcher römische Dichter schrieb die lateinische Wendung 'Tempus fugit' in seinem Lehrgedicht Georgica?",
  "a": [
   "Vergil",
   "Horaz",
   "Ovid",
   "Lukan"
  ]
 },
 "q1380": {
  "q": "Welches Geräusch macht eine glückliche Hauskatze gewöhnlich?",
  "a": [
   "Schnurren",
   "Bellen",
   "Quaken",
   "Heulen"
  ]
 },
 "q1381": {
  "q": "Wie viele Zehen hat eine typische Hauskatze an beiden Vorderpfoten zusammen?",
  "a": [
   "10",
   "8",
   "12",
   "6"
  ]
 },
 "q1382": {
  "q": "Wie viele Zehen hat eine typische Hauskatze an beiden Hinterpfoten zusammen?",
  "a": [
   "8",
   "10",
   "6",
   "12"
  ]
 },
 "q1383": {
  "q": "Welchen Grundgeschmack können Hauskatzen aufgrund eines fehlenden Rezeptorgens nicht wahrnehmen?",
  "a": [
   "Süß",
   "Salzig",
   "Sauer",
   "Bitter"
  ]
 },
 "q1384": {
  "q": "Wie viele Stunden pro Tag verbringt eine erwachsene Hauskatze ungefähr mit Schlafen?",
  "a": [
   "12 bis 16 Stunden",
   "4 bis 6 Stunden",
   "7 bis 9 Stunden",
   "21 bis 23 Stunden"
  ]
 },
 "q1385": {
  "q": "Wo befindet sich der Großteil der Schweißdrüsen einer Hauskatze?",
  "a": [
   "In den Pfotenballen",
   "Entlang der Wirbelsäule",
   "Im Inneren der Ohren",
   "Am Bauch"
  ]
 },
 "q1386": {
  "q": "Wie heißt die reflektierende Gewebeschicht hinter der Netzhaut einer Katze, die ihre Augen im Dunkeln leuchten lässt?",
  "a": [
   "Tapetum lucidum",
   "Corpus callosum",
   "Stratum corneum",
   "Fovea centralis"
  ]
 },
 "q1387": {
  "q": "Welcher Knochen in der Schulter einer Katze ist frei beweglich und nicht mit anderen Knochen verbunden, sodass sie durch enge Spalten passt?",
  "a": [
   "Schlüsselbein",
   "Schulterblatt",
   "Brustbein",
   "Kniescheibe"
  ]
 },
 "q1388": {
  "q": "Wie viele bleibende Zähne hat eine typische erwachsene Hauskatze?",
  "a": [
   "30",
   "20",
   "42",
   "16"
  ]
 },
 "q1389": {
  "q": "Wie viele Muskeln steuern jedes der äußeren Ohren einer Hauskatze?",
  "a": [
   "32",
   "6",
   "12",
   "64"
  ]
 },
 "q1390": {
  "q": "Welches Organ im Maul einer Katze hilft ihr, Gerüche zu analysieren, wenn sie das Maul leicht geöffnet hält?",
  "a": [
   "Jacobson-Organ",
   "Schilddrüse",
   "Zirbeldrüse",
   "Hypophyse"
  ]
 },
 "q1391": {
  "q": "Welche Wildkatze ist der direkte Vorfahre der modernen Hauskatze?",
  "a": [
   "Afrikanische Wildkatze",
   "Eurasischer Luchs",
   "Rohrkatze",
   "Manul"
  ]
 },
 "q1392": {
  "q": "Warum sind fast alle dreifarbigen Glückskatzen weiblich?",
  "a": [
   "Fellfarbgene liegen auf dem X-Chromosom",
   "Männchen fehlen Pigmentzellen",
   "Testosteron unterdrückt rotes Fell",
   "Das Y-Chromosom blockiert weiße Flecken"
  ]
 },
 "q1393": {
  "q": "Welche chemische Verbindung in Katzenminze löst bei vielen Hauskatzen eine euphorische Reaktion aus?",
  "a": [
   "Nepetalacton",
   "Capsaicin",
   "Theobromin",
   "Menthol"
  ]
 },
 "q1394": {
  "q": "Welche katzenköpfige Göttin im alten Ägypten symbolisierte Schutz, Fruchtbarkeit und Mutterschaft?",
  "a": [
   "Bastet",
   "Sachmet",
   "Isis",
   "Hathor"
  ]
 },
 "q1395": {
  "q": "Wie hieß die erste Katze, die 1963 von Frankreich ins All geschossen wurde?",
  "a": [
   "Félicette",
   "Laika",
   "Belka",
   "Strelka"
  ]
 },
 "q1396": {
  "q": "Auf welcher Insel in der Irischen See entstand die von Natur aus schwanzlose Manx-Katze?",
  "a": [
   "Isle of Man",
   "Isle of Wight",
   "Isle of Skye",
   "Anglesey"
  ]
 },
 "q1397": {
  "q": "Welcher frühere Name Thailands gab der Siamkatze ihren Namen?",
  "a": [
   "Siam",
   "Birma",
   "Ceylon",
   "Formosa"
  ]
 },
 "q1398": {
  "q": "Welche Katzenrasse ist vor allem dafür bekannt, fast haarlos zu sein und faltige Haut zu haben?",
  "a": [
   "Sphynx",
   "Maine Coon",
   "Ragdoll",
   "Perserkatze"
  ]
 },
 "q1399": {
  "q": "Welche Genmutation bewirkt, dass sich die Ohren von Schottischen Faltohrkatzen nach vorne und unten falten?",
  "a": [
   "Knorpelmutation",
   "Keratinmangel",
   "Melaninüberschuss",
   "Kollagenduplikation"
  ]
 },
 "q1400": {
  "q": "Wie lautet der Fachbegriff für eine Katze, die mit mehr als der üblichen Anzahl an Zehen geboren wird?",
  "a": [
   "Polydaktyl",
   "Syndaktyl",
   "Brachydaktyl",
   "Ektrodaktyl"
  ]
 },
 "q1401": {
  "q": "Welcher amerikanische Schriftsteller hielt Dutzende sechszehiger Katzen in seinem Haus in Key West, Florida?",
  "a": [
   "Ernest Hemingway",
   "Mark Twain",
   "F. Scott Fitzgerald",
   "William Faulkner"
  ]
 },
 "q1402": {
  "q": "Welches Protein im Speichel und in den Hautdrüsen einer Katze ist die Hauptursache für Katzenallergien beim Menschen?",
  "a": [
   "Fel d 1",
   "Keratin",
   "Kasein",
   "Kollagen"
  ]
 },
 "q1403": {
  "q": "Welche essenzielle Aminosäure müssen Katzen direkt über Fleisch aufnehmen, da ihr Körper nicht genug davon selbst bilden kann?",
  "a": [
   "Taurin",
   "Glycin",
   "Alanin",
   "Glutamin"
  ]
 },
 "q1404": {
  "q": "Wie hoch ist die normale Ruhe-Körpertemperatur einer gesunden erwachsenen Hauskatze?",
  "a": [
   "38,1 bis 39,2 °C",
   "35,0 bis 36,0 °C",
   "36,5 bis 37,0 °C",
   "41,0 bis 42,0 °C"
  ]
 },
 "q1405": {
  "q": "Welches Blutgruppensystem ist bei Hauskatzen klinisch am wichtigsten?",
  "a": [
   "AB-System",
   "Kell-System",
   "Duffy-System",
   "Kidd-System"
  ]
 },
 "q1406": {
  "q": "Wie lange dauert die typische Trächtigkeit einer Hauskatze?",
  "a": [
   "Etwa 63 bis 65 Tage",
   "Etwa 30 bis 32 Tage",
   "Etwa 95 bis 100 Tage",
   "Etwa 120 bis 125 Tage"
  ]
 },
 "q1407": {
  "q": "Wie lautet der wissenschaftliche Name für das dritte Augenlid einer Katze, das das Auge schützt und befeuchtet?",
  "a": [
   "Nickhaut",
   "Trommelfell",
   "Basilarmembran",
   "Synovialmembran"
  ]
 },
 "q1408": {
  "q": "Welcher Dichter schrieb die Sammlung von Katzengedichten, die Andrew Lloyd Webbers Musical „Cats“ inspirierte?",
  "a": [
   "T. S. Eliot",
   "W. B. Yeats",
   "Dylan Thomas",
   "W. H. Auden"
  ]
 },
 "q1409": {
  "q": "Wie heißen die winzigen, nach hinten gerichteten Keratinstacheln auf der Zunge einer Hauskatze?",
  "a": [
   "Fadenpapillen",
   "Pilzpapillen",
   "Wallpapillen",
   "Blattpapillen"
  ]
 },
 "q1410": {
  "q": "Wie lautet der offizielle wissenschaftliche Begriff für die Schnurrhaare einer Katze?",
  "a": [
   "Vibrissen",
   "Zilien",
   "Flagellen",
   "Villi"
  ]
 },
 "q1411": {
  "q": "Auf welcher Mittelmeerinsel fanden Archäologen die älteste bekannte absichtliche Katzenbestattung vor etwa 9.500 Jahren?",
  "a": [
   "Zypern",
   "Kreta",
   "Sizilien",
   "Sardinien"
  ]
 },
 "q1412": {
  "q": "In welchem typischen Grundfrequenzbereich liegt das Schnurren einer Hauskatze?",
  "a": [
   "25 bis 150 Hz",
   "500 bis 1.000 Hz",
   "2.000 bis 4.000 Hz",
   "10.000 bis 15.000 Hz"
  ]
 },
 "q1413": {
  "q": "Welches physikalische Gesetz ermöglicht es einer fallenden Katze, Ober- und Unterkörper entgegengesetzt zu drehen, um auf den Pfoten zu landen?",
  "a": [
   "Drehimpulserhaltung",
   "Bernoulli-Prinzip",
   "Hookesches Gesetz",
   "Archimedisches Prinzip"
  ]
 },
 "q1414": {
  "q": "Welches temperaturempfindliche Enzym verursacht die dunklen Abzeichen an Gesicht, Ohren, Pfoten und Schwanz bei Siamkatzen?",
  "a": [
   "Tyrosinase",
   "Amylase",
   "Katalase",
   "Pepsin"
  ]
 },
 "q1415": {
  "q": "Was war die Amtssprache des Römischen Reiches?",
  "a": [
   "Latein",
   "Arabisch",
   "Hebräisch",
   "Sanskrit"
  ]
 },
 "q1416": {
  "q": "In welchem großen Amphitheater in Rom fanden Gladiatorenkämpfe statt?",
  "a": [
   "Im Kolosseum",
   "Im Parthenon",
   "Im Pantheon",
   "In der Hagia Sophia"
  ]
 },
 "q1417": {
  "q": "Wer war der erste römische Kaiser?",
  "a": [
   "Augustus",
   "Julius Caesar",
   "Nero",
   "Konstantin"
  ]
 },
 "q1418": {
  "q": "Welcher Vulkan zerstörte 79 n. Chr. Pompeji und Herculaneum?",
  "a": [
   "Vesuv",
   "Ätna",
   "Stromboli",
   "Olymp"
  ]
 },
 "q1419": {
  "q": "An welchem Datum im Jahr 44 v. Chr. wurde Julius Caesar ermordet?",
  "a": [
   "15. März",
   "1. April",
   "4. Juli",
   "31. Oktober"
  ]
 },
 "q1420": {
  "q": "Wofür wurden römische Aquädukte gebaut?",
  "a": [
   "Frischwasser",
   "Olivenöl",
   "Silbermünzen",
   "Getreide"
  ]
 },
 "q1421": {
  "q": "Welcher römische Kaiser ordnete den Bau einer Schutzmauer in Nordbritannien an?",
  "a": [
   "Hadrian",
   "Trajan",
   "Mark Aurel",
   "Caligula"
  ]
 },
 "q1422": {
  "q": "Welche Stadt machte Konstantin der Große 330 n. Chr. zur neuen Hauptstadt des Römischen Reiches?",
  "a": [
   "Konstantinopel",
   "Alexandria",
   "Antiochia",
   "Ravenna"
  ]
 },
 "q1423": {
  "q": "Welcher thrakische Gladiator führte 73 v. Chr. einen großen Sklavenaufstand gegen Rom an?",
  "a": [
   "Spartacus",
   "Vercingetorix",
   "Hannibal",
   "Arminius"
  ]
 },
 "q1424": {
  "q": "Welcher römische Kaiser verfasste das stoische Werk „Selbstbetrachtungen“?",
  "a": [
   "Mark Aurel",
   "Nero",
   "Commodus",
   "Tiberius"
  ]
 },
 "q1425": {
  "q": "Welchen Fluss überquerte Julius Caesar 49 v. Chr. und löste damit den Bürgerkrieg gegen Pompeius aus?",
  "a": [
   "Den Rubikon",
   "Den Tiber",
   "Den Rhein",
   "Den Donau"
  ]
 },
 "q1426": {
  "q": "Welcher römische Kaiser ernannte sein Lieblingspferd Incitatus zum Priester?",
  "a": [
   "Caligula",
   "Claudius",
   "Vespasian",
   "Antoninus Pius"
  ]
 },
 "q1427": {
  "q": "Unter welchem Kaiser erreichte das Römische Reich 117 n. Chr. seine größte Ausdehnung?",
  "a": [
   "Trajan",
   "Augustus",
   "Diokletian",
   "Septimius Severus"
  ]
 },
 "q1428": {
  "q": "Wer war der letzte Kaiser des Weströmischen Reiches, der 476 n. Chr. abgesetzt wurde?",
  "a": [
   "Romulus Augustulus",
   "Julius Nepos",
   "Honorius",
   "Valentinian III."
  ]
 },
 "q1429": {
  "q": "Was war Garum, eine beliebte Würzsauce der antiken römischen Küche?",
  "a": [
   "Fermentierte Fischsauce",
   "Gewürzter Honigwein",
   "Eingelegte Olivenpaste",
   "Geräucherter Schafskäse"
  ]
 },
 "q1430": {
  "q": "Wie heißt die kreisrunde Öffnung in der Mitte der Kuppel des Pantheons in Rom?",
  "a": [
   "Oculus",
   "Atrium",
   "Portikus",
   "Apsis"
  ]
 },
 "q1431": {
  "q": "Welcher römische Kaiser führte 293 n. Chr. die Tetrarchie mit vier Mitherrschern ein?",
  "a": [
   "Diokletian",
   "Konstantin",
   "Gallienus",
   "Aurelian"
  ]
 },
 "q1432": {
  "q": "Wie hieß das größte Stadion für Wagenrennen im antiken Rom?",
  "a": [
   "Circus Maximus",
   "Campus Martius",
   "Theater des Pompeius",
   "Caracalla-Thermen"
  ]
 },
 "q1433": {
  "q": "Welcher römische Kaiser verlieh 212 n. Chr. fast allen freien Männern im Reich das römische Bürgerrecht?",
  "a": [
   "Caracalla",
   "Hadrian",
   "Claudius",
   "Nerva"
  ]
 },
 "q1434": {
  "q": "Welche Vulkanasche aus dem Golf von Neapel verlieh dem römischen Beton seine enorme Haltbarkeit unter Wasser?",
  "a": [
   "Puzzolan",
   "Obsidian",
   "Bimsstein",
   "Basalt"
  ]
 },
 "q1435": {
  "q": "In welcher Schlacht im Jahr 9 n. Chr. vernichteten germanische Stämme unter Arminius drei römische Legionen?",
  "a": [
   "Varusschlacht im Teutoburger Wald",
   "Schlacht von Cannae",
   "Schlacht von Zama",
   "Schlacht von Adrianopel"
  ]
 },
 "q1436": {
  "q": "Welches Jahr ging als das „Vierkaiserjahr“ in die römische Geschichte ein?",
  "a": [
   "69 n. Chr.",
   "14 n. Chr.",
   "193 n. Chr.",
   "306 n. Chr."
  ]
 },
 "q1437": {
  "q": "Welcher römische Schriftsteller starb 79 n. Chr. bei der Beobachtung des Vesuvausbruchs?",
  "a": [
   "Plinius der Ältere",
   "Seneca der Jüngere",
   "Tacitus",
   "Sueton"
  ]
 },
 "q1438": {
  "q": "Welches Edikt aus dem Jahr 313 n. Chr. gewährte den Christen im Römischen Reich Religionsfreiheit?",
  "a": [
   "Mailänder Vereinbarung",
   "Edikt von Thessaloniki",
   "Edikt von Nantes",
   "Wormser Edikt"
  ]
 },
 "q1439": {
  "q": "Welcher römische Kaiser wurde 260 n. Chr. in der Schlacht von Edessa vom Perserkönig Schapur I. gefangen genommen?",
  "a": [
   "Valerian",
   "Gallienus",
   "Decius",
   "Gordian III."
  ]
 },
 "q1440": {
  "q": "Welche Königin von Palmyra errichtete im 3. Jahrhundert n. Chr. ein abtrünniges Reich im römischen Osten?",
  "a": [
   "Zenobia",
   "Boudicca",
   "Kleopatra",
   "Agrippina"
  ]
 },
 "q1441": {
  "q": "Wie hieß die unter Julius Caesar eingeführte und von Augustus reformierte römische Standard-Goldmünze?",
  "a": [
   "Aureus",
   "Denar",
   "Sesterz",
   "Solidus"
  ]
 },
 "q1442": {
  "q": "Welcher Prätorianerpräfekt regierte faktisch Rom, während Kaiser Tiberius zurückgezogen auf Capri lebte?",
  "a": [
   "Sejanus",
   "Macro",
   "Tigellinus",
   "Burrus"
  ]
 },
 "q1443": {
  "q": "Welcher römische Kaiser zerschlug 274 n. Chr. das Gallische Sonderreich und erhielt den Titel „Restitutor Orbis“?",
  "a": [
   "Aurelian",
   "Probus",
   "Claudius Gothicus",
   "Carus"
  ]
 },
 "q1444": {
  "q": "Welcher römische Kaiser erließ 301 n. Chr. das Höchstpreisedikt zur Bekämpfung der Inflation?",
  "a": [
   "Diokletian",
   "Konstantin",
   "Gallienus",
   "Maxentius"
  ]
 },
 "q1445": {
  "q": "Welcher römische Kaiser wurde am 31. Dezember 192 n. Chr. vom Ringer Narcissus im Bad erwürgt?",
  "a": [
   "Commodus",
   "Caracalla",
   "Elagabal",
   "Domitian"
  ]
 },
 "q1446": {
  "q": "Welches riesige Wasserfahrzeug baute Noah laut dem Buch Genesis vor der Sintflut?",
  "a": [
   "Eine Arche",
   "Einen Tempel",
   "Eine Brücke",
   "Eine Burg"
  ]
 },
 "q1447": {
  "q": "Welches Tier verführte Eva laut Genesis im Garten Eden?",
  "a": [
   "Eine Schlange",
   "Ein Löwe",
   "Ein Wolf",
   "Ein Adler"
  ]
 },
 "q1448": {
  "q": "Welcher junge Hirte besiegte den Riesen Goliat mit einer Schleuder und einem Stein?",
  "a": [
   "David",
   "Salomo",
   "Simson",
   "Samuel"
  ]
 },
 "q1449": {
  "q": "Worin lag Simsons übermenschliche Kraft laut dem Buch der Richter?",
  "a": [
   "In seinem ungeschnittenen Haar",
   "In seinem Bronzegürtel",
   "In seinem Eisenstab",
   "In seinem Goldring"
  ]
 },
 "q1450": {
  "q": "Im Bauch welchen Tieres verbrachte der Prophet Jona drei Tage und drei Nächte?",
  "a": [
   "Eines großen Fisches",
   "Einer Riesenschildkröte",
   "Eines Nilkrokodils",
   "Einer Seeschlange"
  ]
 },
 "q1451": {
  "q": "Was geschah mit Lots Frau, als sie auf das brennende Sodom zurückblickte?",
  "a": [
   "Sie erstarrte zur Salzsäule",
   "Sie wurde zu Stein",
   "Sie erblindete",
   "Sie zerfiel zu Asche"
  ]
 },
 "q1452": {
  "q": "Welches Meer teilte Mose laut dem Buch Exodus, damit die Israeliten aus Ägypten fliehen konnten?",
  "a": [
   "Das Rote Meer",
   "Das Tote Meer",
   "Das Mittelmeer",
   "Das Schwarze Meer"
  ]
 },
 "q1453": {
  "q": "Welches Kleidungsstück schenkte Jakob seinem Sohn Josef, was den Neid seiner Brüder weckte?",
  "a": [
   "Einen bunten Rock",
   "Einen silbernen Brustpanzer",
   "Einen purpurnen Königsmantel",
   "Eine goldene Krone"
  ]
 },
 "q1454": {
  "q": "Wie schlug König Salomo vor, den Streit zweier Frauen um dasselbe Baby zu lösen?",
  "a": [
   "Das Kind entzweizuschneiden",
   "Das Los zu werfen",
   "Nach dem Alter zu fragen",
   "Ihre Handschrift zu prüfen"
  ]
 },
 "q1455": {
  "q": "Welches Tier sprach zum Propheten Bileam, nachdem ein Engel ihren Weg versperrt hatte?",
  "a": [
   "Eine Eselin",
   "Ein Kamel",
   "Ein Rabe",
   "Ein Löwe"
  ]
 },
 "q1456": {
  "q": "Wie fielen die Mauern von Jericho laut dem Buch Josua?",
  "a": [
   "Nach Posaunenstößen und Kriegsgeschrei",
   "Durch Rammböcke und Katapulte",
   "Bei einem Vulkanausbruch",
   "Durch Untergraben der Fundamente"
  ]
 },
 "q1457": {
  "q": "Welche Speise fiel jeden Morgen vom Himmel, um die Israeliten in der Wüste zu ernähren?",
  "a": [
   "Manna",
   "Ambrosia",
   "Ungesäuerte Gerste",
   "Wilde Feigen"
  ]
 },
 "q1458": {
  "q": "Welchen Vogel ließ Noah zuerst aus der Arche fliegen, um zu prüfen, ob das Wasser gefallen war?",
  "a": [
   "Einen Raben",
   "Eine Taube",
   "Eine Schwalbe",
   "Einen Adler"
  ]
 },
 "q1459": {
  "q": "Wie viele Jahre soll Metuschelach laut dem Buch Genesis gelebt haben?",
  "a": [
   "969",
   "777",
   "850",
   "912"
  ]
 },
 "q1460": {
  "q": "Welcher Prophet fuhr in einem Sturmwind mit feurigem Wagen und feurigen Rossen gen Himmel?",
  "a": [
   "Elija",
   "Elischa",
   "Jesaja",
   "Ezechiel"
  ]
 },
 "q1461": {
  "q": "Wie hießen die drei Männer, die in König Nebukadnezars Feuerofen geworfen wurden?",
  "a": [
   "Schadrach, Meschach und Abed-Nego",
   "Sem, Ham und Jafet",
   "Gerschon, Kehat und Merari",
   "Elifas, Bildad und Zofar"
  ]
 },
 "q1462": {
  "q": "Welche Königin besuchte König Salomo mit Gold und Gewürzen, um ihn mit Rätseln zu prüfen?",
  "a": [
   "Die Königin von Saba",
   "Königin Ester",
   "Königin Isebel",
   "Königin Waschti"
  ]
 },
 "q1463": {
  "q": "Welcher babylonische König lebte laut dem Buch Daniel wie ein wildes Tier und fraß Gras wie ein Rind?",
  "a": [
   "Nebukadnezar",
   "Belschazzar",
   "Hammurapi",
   "Nabonid"
  ]
 },
 "q1464": {
  "q": "Was geschah mit Usa, als er die Hand ausstreckte, um die Bundeslade festzuhalten?",
  "a": [
   "Er starb auf der Stelle",
   "Seine Hand wurde aussätzig",
   "Er wurde stumm",
   "Er wurde vom Licht geblendet"
  ]
 },
 "q1465": {
  "q": "Welcher Stamm Israels erhielt keinen Landbesitz in Kanaan, weil er für den Priesterdienst bestimmt war?",
  "a": [
   "Levi",
   "Juda",
   "Benjamin",
   "Efraim"
  ]
 },
 "q1466": {
  "q": "Welche drei Gegenstände wurden laut dem Alten Testament in der Bundeslade aufbewahrt?",
  "a": [
   "Steintafeln, Manna und Aarons Stab",
   "Steintafeln, Weihrauch und eine Goldkrone",
   "Aarons Stab, Salböl und Silbermünzen",
   "Eine Torarolle, Manna und Salz"
  ]
 },
 "q1467": {
  "q": "Welcher linkshändige Richter tötete König Eglon von Moab mit einem zweischneidigen Dolch?",
  "a": [
   "Ehud",
   "Gideon",
   "Jeftah",
   "Otniël"
  ]
 },
 "q1468": {
  "q": "Welche Worte schrieb eine Hand an die Wand bei König Belschazzars Gastmahl?",
  "a": [
   "Mene, Mene, Tekel, Upharsin",
   "Kadosch, Kadosch, Kadosch",
   "Schma, Jisrael, Adonai",
   "Elohim, Zebaoth, Schalom"
  ]
 },
 "q1469": {
  "q": "Womit tötete Jaël den kanaanäischen Feldherrn Sisera, während er in ihrem Zelt schlief?",
  "a": [
   "Mit einem Zeltpflock und einem Hammer",
   "Mit einem vergifteten Becher Milch",
   "Mit seinem eigenen Bronzespeer",
   "Mit einer seidenen Bogensehne"
  ]
 },
 "q1470": {
  "q": "In welchem Buch des Alten Testaments wird Gott kein einziges Mal erwähnt?",
  "a": [
   "Ester",
   "Rut",
   "Ijob",
   "Kohelet"
  ]
 },
 "q1471": {
  "q": "Welchem König von Juda wurde das Leben um 15 Jahre verlängert, nachdem er in schwerer Krankheit gebetet hatte?",
  "a": [
   "Hiskija",
   "Joschija",
   "Joschafat",
   "Usija"
  ]
 },
 "q1472": {
  "q": "Wer war der erste namentlich genannte Kunsthandwerker der Bibel, der die Stiftshütte fertigte?",
  "a": [
   "Bezalel",
   "Hiram",
   "Tubal-Kain",
   "Oholiab"
  ]
 },
 "q1473": {
  "q": "Welcher Prophet wurde in Jerusalem in eine schlammige Zisterne hinabgelassen und mit Seilen und Lumpen gerettet?",
  "a": [
   "Jeremia",
   "Ezechiel",
   "Amos",
   "Hosea"
  ]
 },
 "q1474": {
  "q": "Wie wird König Eglon von Moab im Buch der Richter körperlich beschrieben?",
  "a": [
   "Er war ein sehr fetter Mann",
   "Er hatte sechs Finger an jeder Hand",
   "Er war auf einem Auge blind",
   "Er war über drei Meter groß"
  ]
 },
 "q1475": {
  "q": "Welcher Richter Israels besiegte die Philister mit einem Ochsenstecken?",
  "a": [
   "Schamgar",
   "Tola",
   "Jaïr",
   "Ibzan"
  ]
 },
 "q1476": {
  "q": "Wie hießen Hiobs drei Töchter, die geboren wurden, nachdem sein Wohlstand wiederhergestellt war?",
  "a": [
   "Jemima, Kezia und Keren-Happuch",
   "Lea, Rahel und Dina",
   "Machla, Noa und Hogla",
   "Orpa, Rut und Noomi"
  ]
 },
 "q1477": {
  "q": "Welcher Riese aus Gat hatte im 2. Buch Samuel je sechs Finger an den Händen und sechs Zehen an den Füßen?",
  "a": [
   "Ein namenloser Nachkomme Rafas",
   "Lachmi",
   "Jischbi-Benob",
   "Saf"
  ]
 },
 "q1478": {
  "q": "Welcher König von Israel verbrannte in Tirza nach nur sieben Tagen Herrschaft die Königsburg über sich selbst?",
  "a": [
   "Simri",
   "Ela",
   "Schallum",
   "Tibni"
  ]
 },
 "q1479": {
  "q": "Worin verwandelte Jesus laut dem Neuen Testament Wasser auf einer Hochzeit in Kana?",
  "a": [
   "Wein",
   "Milch",
   "Olivenöl",
   "Honig"
  ]
 },
 "q1480": {
  "q": "Wie viele Apostel wählte Jesus laut den Evangelien ursprünglich aus?",
  "a": [
   "12",
   "7",
   "10",
   "15"
  ]
 },
 "q1481": {
  "q": "In welchem Fluss wurde Jesus von Johannes dem Täufer getauft?",
  "a": [
   "Jordan",
   "Nil",
   "Euphrat",
   "Tigris"
  ]
 },
 "q1482": {
  "q": "Aus wie vielen Büchern besteht das christliche Neue Testament?",
  "a": [
   "27",
   "24",
   "33",
   "39"
  ]
 },
 "q1483": {
  "q": "Mit wie vielen Broten speiste Jesus laut den Evangelien 5.000 Männer?",
  "a": [
   "5",
   "3",
   "7",
   "12"
  ]
 },
 "q1484": {
  "q": "In welcher Originalsprache wurden die Bücher des Neuen Testaments verfasst?",
  "a": [
   "Griechisch",
   "Hebräisch",
   "Latein",
   "Aramäisch"
  ]
 },
 "q1485": {
  "q": "Welchen Freund erweckte Jesus in Betanien nach vier Tagen im Grab von den Toten?",
  "a": [
   "Lazarus",
   "Nikodemus",
   "Barnabas",
   "Zachäus"
  ]
 },
 "q1486": {
  "q": "Welchen Beruf übte der Apostel Petrus aus, bevor er ein Jünger Jesu wurde?",
  "a": [
   "Fischer",
   "Zöllner",
   "Zimmermann",
   "Zeltmacher"
  ]
 },
 "q1487": {
  "q": "Wie viele Reiter erscheinen laut der Offenbarung beim Öffnen der ersten vier Siegel?",
  "a": [
   "4",
   "3",
   "7",
   "12"
  ]
 },
 "q1488": {
  "q": "Welcher Verfasser eines Evangeliums und der Apostelgeschichte wird von Paulus als Arzt bezeichnet?",
  "a": [
   "Lukas",
   "Markus",
   "Matthäus",
   "Johannes"
  ]
 },
 "q1489": {
  "q": "Auf was für einen Baum kletterte der kleinwüchsige Zöllner Zachäus in Jericho, um Jesus zu sehen?",
  "a": [
   "Maulbeerfeigenbaum",
   "Olivenbaum",
   "Feigenbaum",
   "Zeder"
  ]
 },
 "q1490": {
  "q": "Wie viele Silberstücke erhielt Judas Iskariot laut den Evangelien für den Verrat an Jesus?",
  "a": [
   "30",
   "20",
   "40",
   "50"
  ]
 },
 "q1491": {
  "q": "Auf welcher Insel erlitt der Apostel Paulus laut der Apostelgeschichte auf dem Weg nach Rom Schiffbruch?",
  "a": [
   "Malta",
   "Zypern",
   "Kreta",
   "Sizilien"
  ]
 },
 "q1492": {
  "q": "In welcher Stadt wurden die Nachfolger Jesu laut der Apostelgeschichte erstmals Christen genannt?",
  "a": [
   "Antiochia",
   "Jerusalem",
   "Ephesus",
   "Korinth"
  ]
 },
 "q1493": {
  "q": "Auf welcher griechischen Insel schrieb Johannes während seines Exils die Offenbarung?",
  "a": [
   "Patmos",
   "Rhodos",
   "Lesbos",
   "Korfu"
  ]
 },
 "q1494": {
  "q": "Wer wurde durch das Los ausgewählt, um Judas Iskariot unter den zwölf Aposteln zu ersetzen?",
  "a": [
   "Matthias",
   "Barnabas",
   "Silas",
   "Timotheus"
  ]
 },
 "q1495": {
  "q": "Wer sah laut dem Johannesevangelium den auferstandenen Jesus als Erste am Grab?",
  "a": [
   "Maria Magdalena",
   "Simon Petrus",
   "Apostel Johannes",
   "Thomas"
  ]
 },
 "q1496": {
  "q": "Welches Handwerk übte der Apostel Paulus zusammen mit Aquila und Priszilla in Korinth aus?",
  "a": [
   "Zeltmacherei",
   "Zimmerei",
   "Töpferei",
   "Maurerei"
  ]
 },
 "q1497": {
  "q": "Welches ist nach Wortanzahl das kürzeste Buch im Neuen Testament?",
  "a": [
   "Dritter Brief des Johannes",
   "Zweiter Brief des Johannes",
   "Brief an Philemon",
   "Brief des Judas"
  ]
 },
 "q1498": {
  "q": "Wer trug laut den synoptischen Evangelien ein Stück weit das Kreuz Jesu nach Golgatha?",
  "a": [
   "Simon von Cyrene",
   "Josef von Arimathäa",
   "Nikodemus",
   "Barabbas"
  ]
 },
 "q1499": {
  "q": "Wie viele Menschen wurden laut der Apostelgeschichte beim Schiffbruch mit Paulus vor Malta gerettet?",
  "a": [
   "276",
   "144",
   "153",
   "312"
  ]
 },
 "q1500": {
  "q": "Wie viele große Fische fingen die Jünger im Johannesevangelium nach der Auferstehung?",
  "a": [
   "153",
   "120",
   "144",
   "200"
  ]
 },
 "q1501": {
  "q": "Welcher junge Mann schlief während der Predigt des Paulus in Troas ein und stürzte aus dem dritten Stock?",
  "a": [
   "Eutychus",
   "Onesimus",
   "Tychikus",
   "Epaphras"
  ]
 },
 "q1502": {
  "q": "An wen schrieb Paulus einen kurzen neutestamentlichen Brief zugunsten des entlaufenen Sklaven Onesimus?",
  "a": [
   "Philemon",
   "Titus",
   "Gajus",
   "Archippus"
  ]
 },
 "q1503": {
  "q": "In welcher Stadt predigte Paulus über einen Altar mit der Inschrift Dem unbekannten Gott?",
  "a": [
   "Athen",
   "Rom",
   "Korinth",
   "Thessaloniki"
  ]
 },
 "q1504": {
  "q": "Welcher Schreiber wird am Ende des Römerbriefs als Verfasser der Niederschrift des Paulus genannt?",
  "a": [
   "Tertius",
   "Quartus",
   "Sosthenes",
   "Silvanus"
  ]
 },
 "q1505": {
  "q": "Wie hieß der Diener des Hohepriesters, dem Petrus laut Johannes in Getsemani das rechte Ohr abschlug?",
  "a": [
   "Malchus",
   "Hannas",
   "Kajaphas",
   "Alexander"
  ]
 },
 "q1506": {
  "q": "Welche Gestalt wird im Brief des Judas erwähnt, wie sie mit dem Teufel um den Leichnam des Mose streitet?",
  "a": [
   "Erzengel Michael",
   "Prophet Elija",
   "Erzengel Gabriel",
   "Hohepriester Aaron"
  ]
 },
 "q1507": {
  "q": "Wie viele Münzen besaß die Frau laut dem Lukasevangelium, bevor sie in Jesu Gleichnis eine verlor?",
  "a": [
   "10",
   "7",
   "12",
   "20"
  ]
 },
 "q1508": {
  "q": "Welcher römische Prokonsul von Achaia wies in Korinth die Anklagen gegen Paulus ab?",
  "a": [
   "Gallio",
   "Felix",
   "Festus",
   "Sergius Paulus"
  ]
 },
 "q1509": {
  "q": "Welches Mitglied des Athener Areopags wurde gläubig, nachdem es dort die Rede des Paulus gehört hatte?",
  "a": [
   "Dionysius",
   "Aristarchus",
   "Apollos",
   "Epaphroditus"
  ]
 },
 "q1510": {
  "q": "Mit welchem Himmelskörper war Ra, der altägyptische Sonnengott, verbunden?",
  "a": [
   "Mit der Sonne",
   "Dem Mond",
   "Dem Mars",
   "Dem Jupiter"
  ]
 },
 "q1511": {
  "q": "Welcher ägyptische Gott war der Gemahl der Isis und der Vater des Horus?",
  "a": [
   "Osiris",
   "Seth",
   "Thot",
   "Anubis"
  ]
 },
 "q1512": {
  "q": "Welche ägyptische Göttin ist im Osirismythos die Mutter des Horus?",
  "a": [
   "Isis",
   "Nephthys",
   "Nut",
   "Bastet"
  ]
 },
 "q1513": {
  "q": "Welcher Gott tötet Osiris im ägyptischen Mythos?",
  "a": [
   "Seth",
   "Horus",
   "Thot",
   "Ptah"
  ]
 },
 "q1514": {
  "q": "Welcher ägyptische Gott streitet nach Osiris’ Tod mit Seth um den Thron?",
  "a": [
   "Horus",
   "Anubis",
   "Thot",
   "Chnum"
  ]
 },
 "q1515": {
  "q": "Welches Tier stellt häufig den ägyptischen Gott Horus dar?",
  "a": [
   "Falke",
   "Krokodil",
   "Nilpferd",
   "Skarabäus"
  ]
 },
 "q1516": {
  "q": "Welcher ägyptische Gott ist eng mit der Einbalsamierung verbunden und wird oft mit Schakalkopf dargestellt?",
  "a": [
   "Anubis",
   "Horus",
   "Thot",
   "Sobek"
  ]
 },
 "q1517": {
  "q": "Welcher ägyptische Gott der Schrift wird oft mit einem Ibiskopf dargestellt?",
  "a": [
   "Thot",
   "Horus",
   "Anubis",
   "Seth"
  ]
 },
 "q1518": {
  "q": "Welche ägyptische Göttin wurde häufig als Katze dargestellt?",
  "a": [
   "Bastet",
   "Nut",
   "Maat",
   "Nephthys"
  ]
 },
 "q1519": {
  "q": "Welche ägyptische Göttin ist für ihre Darstellung mit Löwenkopf und ihre zerstörerische Kraft bekannt?",
  "a": [
   "Sachmet",
   "Isis",
   "Nut",
   "Nephthys"
  ]
 },
 "q1520": {
  "q": "Welche ägyptische Göttin wurde oft als Frau dargestellt, die sich als Himmel über die Erde wölbt?",
  "a": [
   "Nut",
   "Isis",
   "Bastet",
   "Maat"
  ]
 },
 "q1521": {
  "q": "Welcher ägyptische Gott verkörperte die Erde und war der Gemahl der Himmelsgöttin Nut?",
  "a": [
   "Geb",
   "Schu",
   "Thot",
   "Anubis"
  ]
 },
 "q1522": {
  "q": "Welcher ägyptische Luftgott trennt die Himmelsgöttin Nut vom Erdgott Geb?",
  "a": [
   "Schu",
   "Seth",
   "Thot",
   "Anubis"
  ]
 },
 "q1523": {
  "q": "Welche ägyptische Göttin verkörperte Wahrheit, Gerechtigkeit und kosmische Ordnung?",
  "a": [
   "Maat",
   "Bastet",
   "Nut",
   "Taweret"
  ]
 },
 "q1524": {
  "q": "Welches Organ wurde nach ägyptischem Totenglauben gegen die Feder der Maat gewogen?",
  "a": [
   "Das Herz",
   "Das Gehirn",
   "Die Leber",
   "Die Lunge"
  ]
 },
 "q1525": {
  "q": "Wie heißt das Wesen, das nach ägyptischem Totenglauben die unwürdigen Toten verschlingt?",
  "a": [
   "Ammit",
   "Apophis",
   "Sobek",
   "Chepri"
  ]
 },
 "q1526": {
  "q": "Was für ein Wesen ist Apophis, ein Feind des ägyptischen Sonnengottes Ra?",
  "a": [
   "Eine Schlange",
   "Ein Krokodil",
   "Ein Falke",
   "Ein Löwe"
  ]
 },
 "q1527": {
  "q": "Mit welchem Fahrzeug durchquert der Sonnengott in der ägyptischen Mythologie den Himmel?",
  "a": [
   "Mit einem Boot",
   "Mit einem Streitwagen",
   "Mit einem Schlitten",
   "Mit einer Kutsche"
  ]
 },
 "q1528": {
  "q": "Welcher ägyptische Gott ist mit Krokodilen und dem Nil verbunden?",
  "a": [
   "Sobek",
   "Thot",
   "Horus",
   "Anubis"
  ]
 },
 "q1529": {
  "q": "Welche ägyptische Geburtsgöttin wurde häufig mit dem Körper eines trächtigen Nilpferds dargestellt?",
  "a": [
   "Taweret",
   "Maat",
   "Isis",
   "Nut"
  ]
 },
 "q1530": {
  "q": "Welcher ägyptische Gott, der oft als Zwerg dargestellt wurde, schützte Haushalte und Kinder?",
  "a": [
   "Bes",
   "Seth",
   "Geb",
   "Thot"
  ]
 },
 "q1531": {
  "q": "Welche ägyptische Göttin der Musik und Freude wurde oft mit Kuhhörnern um eine Sonnenscheibe dargestellt?",
  "a": [
   "Hathor",
   "Nephthys",
   "Maat",
   "Taweret"
  ]
 },
 "q1532": {
  "q": "Welches rasselähnliche Musikinstrument war eng mit der ägyptischen Göttin Hathor verbunden?",
  "a": [
   "Sistrum",
   "Harfe",
   "Flöte",
   "Trompete"
  ]
 },
 "q1533": {
  "q": "Welcher ägyptische Gott verkörperte die aufgehende Sonne und war mit dem Skarabäus verbunden?",
  "a": [
   "Chepri",
   "Sobek",
   "Anubis",
   "Thot"
  ]
 },
 "q1534": {
  "q": "Welcher ägyptische Schöpfergott wurde besonders in Memphis verehrt und mit Handwerkern verbunden?",
  "a": [
   "Ptah",
   "Sobek",
   "Horus",
   "Anubis"
  ]
 },
 "q1535": {
  "q": "Welcher ägyptische Gott soll Menschen auf einer Töpferscheibe geformt haben?",
  "a": [
   "Chnum",
   "Seth",
   "Thot",
   "Horus"
  ]
 },
 "q1536": {
  "q": "Welche ägyptische Göttin hilft Isis im Mythos von Osiris’ Tod, ihn zu betrauern und zu schützen?",
  "a": [
   "Nephthys",
   "Bastet",
   "Sachmet",
   "Taweret"
  ]
 },
 "q1537": {
  "q": "Was stellt das altägyptische Ankh-Zeichen dar?",
  "a": [
   "Leben",
   "Krieg",
   "Nacht",
   "Hungersnot"
  ]
 },
 "q1538": {
  "q": "Als was wurde das ägyptische Schutzzeichen namens Horusauge häufig verwendet?",
  "a": [
   "Als Amulett",
   "Als Musikinstrument",
   "Als Ackergerät",
   "Als Kochtopf"
  ]
 },
 "q1539": {
  "q": "Welches Tier säugte der römischen Sage nach die Zwillinge Romulus und Remus?",
  "a": [
   "Eine Wölfin",
   "Eine Bärin",
   "Eine Löwin",
   "Eine Kuh"
  ]
 },
 "q1540": {
  "q": "Wer war der oberste Gott des römischen Pantheons?",
  "a": [
   "Jupiter",
   "Neptun",
   "Mars",
   "Merkur"
  ]
 },
 "q1541": {
  "q": "Welcher römische Gott war mit dem Meer verbunden?",
  "a": [
   "Neptun",
   "Mars",
   "Merkur",
   "Vulkan"
  ]
 },
 "q1542": {
  "q": "Welcher römische Gott war mit dem Krieg verbunden?",
  "a": [
   "Mars",
   "Neptun",
   "Merkur",
   "Saturn"
  ]
 },
 "q1543": {
  "q": "Welche römische Göttin war mit Liebe und Schönheit verbunden?",
  "a": [
   "Venus",
   "Diana",
   "Vesta",
   "Ceres"
  ]
 },
 "q1544": {
  "q": "Welche römische Göttin war mit der Jagd verbunden?",
  "a": [
   "Diana",
   "Juno",
   "Vesta",
   "Ceres"
  ]
 },
 "q1545": {
  "q": "Welche römische Göttin war mit Weisheit und Handwerk verbunden?",
  "a": [
   "Minerva",
   "Venus",
   "Diana",
   "Vesta"
  ]
 },
 "q1546": {
  "q": "Welche römische Göttin war mit dem Herdfeuer verbunden?",
  "a": [
   "Vesta",
   "Diana",
   "Venus",
   "Minerva"
  ]
 },
 "q1547": {
  "q": "Welcher römische Gott war ein Bote der Götter?",
  "a": [
   "Merkur",
   "Neptun",
   "Saturn",
   "Vulkan"
  ]
 },
 "q1548": {
  "q": "Welcher römische Gott war mit Feuer und Metallverarbeitung verbunden?",
  "a": [
   "Vulkan",
   "Merkur",
   "Neptun",
   "Mars"
  ]
 },
 "q1549": {
  "q": "Wer war in der römischen Mythologie Jupiters Gemahlin?",
  "a": [
   "Juno",
   "Diana",
   "Vesta",
   "Ceres"
  ]
 },
 "q1550": {
  "q": "Welcher römische Gott wurde gewöhnlich mit zwei in entgegengesetzte Richtungen blickenden Gesichtern dargestellt?",
  "a": [
   "Janus",
   "Mars",
   "Merkur",
   "Neptun"
  ]
 },
 "q1551": {
  "q": "Welche römische Göttin war mit Getreide und Ackerbau verbunden?",
  "a": [
   "Ceres",
   "Diana",
   "Venus",
   "Juno"
  ]
 },
 "q1552": {
  "q": "In der römischen Mythologie: Wie hieß die Tochter der Ceres, die Pluto in die Unterwelt entführte?",
  "a": [
   "Proserpina",
   "Minerva",
   "Diana",
   "Vesta"
  ]
 },
 "q1553": {
  "q": "Welcher römische Gott herrschte als Entsprechung des griechischen Hades über die Unterwelt?",
  "a": [
   "Pluto",
   "Merkur",
   "Mars",
   "Neptun"
  ]
 },
 "q1554": {
  "q": "Welcher Gegenstand ist ein bekanntes Attribut Neptuns in der römischen Kunst?",
  "a": [
   "Ein Dreizack",
   "Ein Blitz",
   "Eine Sichel",
   "Ein Bogen"
  ]
 },
 "q1555": {
  "q": "Welcher Vogel war in der römischen Religion besonders mit Jupiter verbunden?",
  "a": [
   "Adler",
   "Eule",
   "Pfau",
   "Taube"
  ]
 },
 "q1556": {
  "q": "Welcher Vogel war in der römischen Kunst besonders mit Minerva verbunden?",
  "a": [
   "Eule",
   "Adler",
   "Pfau",
   "Taube"
  ]
 },
 "q1557": {
  "q": "Wer war der römischen Sage nach der Zwillingsbruder des Romulus?",
  "a": [
   "Remus",
   "Aeneas",
   "Numitor",
   "Faustulus"
  ]
 },
 "q1558": {
  "q": "Welcher Gott war in der römischen Sage der Vater von Romulus und Remus?",
  "a": [
   "Mars",
   "Jupiter",
   "Neptun",
   "Merkur"
  ]
 },
 "q1559": {
  "q": "Wer war in der römischen Sage die Mutter von Romulus und Remus?",
  "a": [
   "Rhea Silvia",
   "Lavinium",
   "Dido",
   "Lavinia"
  ]
 },
 "q1560": {
  "q": "Auf welchem Fluss wurden Romulus und Remus der römischen Sage nach ausgesetzt?",
  "a": [
   "Tiber",
   "Po",
   "Arno",
   "Rhone"
  ]
 },
 "q1561": {
  "q": "Welcher Hirte fand Romulus und Remus in der römischen Sage?",
  "a": [
   "Faustulus",
   "Numitor",
   "Amulius",
   "Anchises"
  ]
 },
 "q1562": {
  "q": "Welcher trojanische Held steht im Mittelpunkt von Vergils Aeneis?",
  "a": [
   "Aeneas",
   "Hektor",
   "Paris",
   "Priamos"
  ]
 },
 "q1563": {
  "q": "Welche Göttin ist in Vergils Aeneis die Mutter des Aeneas?",
  "a": [
   "Venus",
   "Juno",
   "Diana",
   "Vesta"
  ]
 },
 "q1564": {
  "q": "Welche Königin verliebt sich in Vergils Aeneis in Aeneas?",
  "a": [
   "Dido",
   "Lavinia",
   "Rhea Silvia",
   "Amata"
  ]
 },
 "q1565": {
  "q": "Welche Stadt regiert Dido in Vergils Aeneis?",
  "a": [
   "Karthago",
   "Troja",
   "Athen",
   "Sparta"
  ]
 },
 "q1566": {
  "q": "Wen trägt Aeneas in Vergils Aeneis aus dem brennenden Troja?",
  "a": [
   "Seinen Vater Anchises",
   "Seinen Sohn Ascanius",
   "Seine Frau Creusa",
   "Seinen Freund Achates"
  ]
 },
 "q1567": {
  "q": "Welches römische Fest wurde zu Ehren Saturns gefeiert?",
  "a": [
   "Saturnalien",
   "Lupercalien",
   "Floralia",
   "Vestalia"
  ]
 },
 "q1568": {
  "q": "Welche römische Göttin wurde beim Fest der Floralia geehrt?",
  "a": [
   "Flora",
   "Pomona",
   "Vesta",
   "Juno"
  ]
 },
 "q1569": {
  "q": "Für welches Naturphänomen ist Thor in der nordischen Mythologie ein Gott?",
  "a": [
   "Donner",
   "Regen",
   "Schnee",
   "Wind"
  ]
 },
 "q1570": {
  "q": "Für welche Waffe ist Thor in der nordischen Mythologie bekannt?",
  "a": [
   "Einen Hammer",
   "Einen Bogen",
   "Einen Dreizack",
   "Eine Sense"
  ]
 },
 "q1571": {
  "q": "Wie heißt Thors Hammer in der nordischen Mythologie?",
  "a": [
   "Mjölnir",
   "Gungnir",
   "Gleipnir",
   "Gram"
  ]
 },
 "q1572": {
  "q": "Wer ist Thors Vater in der nordischen Mythologie?",
  "a": [
   "Odin",
   "Loki",
   "Tyr",
   "Heimdall"
  ]
 },
 "q1573": {
  "q": "Wie heißt Odins Halle für einen Teil der gefallenen Krieger in der nordischen Mythologie?",
  "a": [
   "Walhall",
   "Midgard",
   "Jötunheim",
   "Niflheim"
  ]
 },
 "q1574": {
  "q": "Welche Wesen wählen in der nordischen Mythologie gefallene Krieger für Odin aus?",
  "a": [
   "Walküren",
   "Nornen",
   "Zwerge",
   "Riesen"
  ]
 },
 "q1575": {
  "q": "Wie heißt der Weltenbaum in der nordischen Mythologie?",
  "a": [
   "Yggdrasil",
   "Bifröst",
   "Walhall",
   "Gungnir"
  ]
 },
 "q1576": {
  "q": "Als welche Baumart wird Yggdrasil in der nordischen Mythologie beschrieben?",
  "a": [
   "Esche",
   "Eiche",
   "Kiefer",
   "Birke"
  ]
 },
 "q1577": {
  "q": "Wie heißt die Welt der Menschen in der nordischen Mythologie?",
  "a": [
   "Midgard",
   "Asgard",
   "Jötunheim",
   "Niflheim"
  ]
 },
 "q1578": {
  "q": "Wie heißt die Heimat der Asen in der nordischen Mythologie?",
  "a": [
   "Asgard",
   "Midgard",
   "Jötunheim",
   "Niflheim"
  ]
 },
 "q1579": {
  "q": "Wie heißt die Regenbogenbrücke nach Asgard in der nordischen Mythologie?",
  "a": [
   "Bifröst",
   "Gleipnir",
   "Mjölnir",
   "Gungnir"
  ]
 },
 "q1580": {
  "q": "Welcher Gott bewacht in der nordischen Mythologie die Brücke Bifröst?",
  "a": [
   "Heimdall",
   "Tyr",
   "Freyr",
   "Balder"
  ]
 },
 "q1581": {
  "q": "In der nordischen Mythologie: Wie heißt der große Wolf, der Odin bei Ragnarök tötet?",
  "a": [
   "Fenrir",
   "Sleipnir",
   "Ratatoskr",
   "Nidhöggr"
  ]
 },
 "q1582": {
  "q": "In der nordischen Mythologie: Welcher Gott verliert eine Hand, als die Götter Fenrir fesseln?",
  "a": [
   "Tyr",
   "Thor",
   "Balder",
   "Heimdall"
  ]
 },
 "q1583": {
  "q": "In der nordischen Mythologie: Wie heißt die magische Fessel, mit der Fenrir gebunden wird?",
  "a": [
   "Gleipnir",
   "Gungnir",
   "Mjölnir",
   "Gram"
  ]
 },
 "q1584": {
  "q": "Welcher Gott ist in der nordischen Mythologie Fenrirs Vater?",
  "a": [
   "Loki",
   "Odin",
   "Thor",
   "Tyr"
  ]
 },
 "q1585": {
  "q": "In der nordischen Mythologie: Welcher Sohn Odins rächt ihn bei Ragnarök, indem er Fenrir tötet?",
  "a": [
   "Vidar",
   "Balder",
   "Hödur",
   "Hermod"
  ]
 },
 "q1586": {
  "q": "Was für ein Wesen ist Jörmungandr in der nordischen Mythologie?",
  "a": [
   "Eine Schlange",
   "Ein Wolf",
   "Ein Pferd",
   "Ein Adler"
  ]
 },
 "q1587": {
  "q": "In der nordischen Mythologie: Welcher Gott kämpft bei Ragnarök gegen die Weltschlange Jörmungandr?",
  "a": [
   "Thor",
   "Odin",
   "Tyr",
   "Freyr"
  ]
 },
 "q1588": {
  "q": "Was für ein Tier ist Odins Reittier Sleipnir in der nordischen Mythologie?",
  "a": [
   "Ein Pferd",
   "Ein Wolf",
   "Ein Bär",
   "Ein Eber"
  ]
 },
 "q1589": {
  "q": "In der nordischen Mythologie: Wie viele Beine hat Odins Pferd Sleipnir?",
  "a": [
   "8",
   "4",
   "6",
   "10"
  ]
 },
 "q1590": {
  "q": "In der nordischen Mythologie: Was für Vögel sind Odins Begleiter Hugin und Munin?",
  "a": [
   "Raben",
   "Adler",
   "Schwäne",
   "Habichte"
  ]
 },
 "q1591": {
  "q": "In der nordischen Mythologie: Was opferte Odin an Mimirs Brunnen im Austausch für Weisheit?",
  "a": [
   "Ein Auge",
   "Eine Hand",
   "Ein Ohr",
   "Einen Fuß"
  ]
 },
 "q1592": {
  "q": "Wie heißt Odins Speer in der nordischen Mythologie?",
  "a": [
   "Gungnir",
   "Mjölnir",
   "Gleipnir",
   "Gram"
  ]
 },
 "q1593": {
  "q": "Welche Göttin ist in der nordischen Mythologie Freyrs Schwester?",
  "a": [
   "Freyja",
   "Frigg",
   "Sif",
   "Idun"
  ]
 },
 "q1594": {
  "q": "Welche Göttin fährt in der nordischen Mythologie in einem von Katzen gezogenen Wagen?",
  "a": [
   "Freyja",
   "Frigg",
   "Sif",
   "Idun"
  ]
 },
 "q1595": {
  "q": "Welche Göttin ist in der nordischen Mythologie Thors Frau?",
  "a": [
   "Sif",
   "Freyja",
   "Idun",
   "Hel"
  ]
 },
 "q1596": {
  "q": "In der nordischen Mythologie: Welche Göttin bewahrt in der Prosa-Edda die Äpfel auf, die den Göttern Jugend bewahren?",
  "a": [
   "Idun",
   "Sif",
   "Frigg",
   "Hel"
  ]
 },
 "q1597": {
  "q": "In der nordischen Mythologie: Welche Pflanze wird in der Prosa-Edda benutzt, um Balder zu töten?",
  "a": [
   "Mistel",
   "Efeu",
   "Stechpalme",
   "Eibe"
  ]
 },
 "q1598": {
  "q": "Was ist Ragnarök in der nordischen Mythologie?",
  "a": [
   "Die letzte Schlacht der Götter",
   "Die Erschaffung der Sonne",
   "Eine Hochzeit der Riesen",
   "Ein Fest in Walhall"
  ]
 },
 "q1599": {
  "q": "Wer war der König der Götter in der griechischen Mythologie?",
  "a": [
   "Zeus",
   "Achilles",
   "Odysseus",
   "Perseus"
  ]
 },
 "q1600": {
  "q": "In der griechischen Mythologie: Wie viele Arbeiten musste Herakles für König Eurystheus vollbringen?",
  "a": [
   "12",
   "7",
   "10",
   "24"
  ]
 },
 "q1601": {
  "q": "In der griechischen Mythologie: Was hatte Medusa anstelle von Haaren auf dem Kopf?",
  "a": [
   "Giftschlangen",
   "Brennende Federn",
   "Bronzehörner",
   "Stachelige Kristalle"
  ]
 },
 "q1602": {
  "q": "In der griechischen Mythologie: Welcher Körperteil von Achilles blieb verwundbar, nachdem seine Mutter ihn in den Fluss Styx getaucht hatte?",
  "a": [
   "Seine Ferse",
   "Seine linke Schulter",
   "Seine Kehle",
   "Sein rechtes Handgelenk"
  ]
 },
 "q1603": {
  "q": "In der griechischen Mythologie: Wer öffnete das Gefäß, aus dem alle Übel in die Welt entwichen und nur die Hoffnung zurückblieb?",
  "a": [
   "Pandora",
   "Kassandra",
   "Penelope",
   "Andromeda"
  ]
 },
 "q1604": {
  "q": "In der griechischen Mythologie: Wie gelangten die Griechen schließlich in die ummauerte Stadt Troja?",
  "a": [
   "In einem riesigen Holzpferd",
   "Durch ein geflutetes Aquädukt",
   "Als Handelsseeleute verkleidet",
   "Über eine Brücke aus vertäuten Schiffen"
  ]
 },
 "q1605": {
  "q": "Wie hieß der dreiköpfige Hund, der den Eingang zur griechischen Unterwelt bewachte?",
  "a": [
   "Zerberus",
   "Orthos",
   "Chimära",
   "Typhon"
  ]
 },
 "q1606": {
  "q": "In der griechischen Mythologie: Welcher mythische König verwandelte alles, was er berührte, in Gold?",
  "a": [
   "Midas",
   "Krösus",
   "Tantalos",
   "Sisyphos"
  ]
 },
 "q1607": {
  "q": "In der griechischen Mythologie: Wer flog mit Flügeln aus Federn und Wachs zu nah an die Sonne?",
  "a": [
   "Ikarus",
   "Phaethon",
   "Bellerophon",
   "Perseus"
  ]
 },
 "q1608": {
  "q": "In der griechischen Mythologie: Worin bestand die ewige Strafe des Sisyphos in der Unterwelt?",
  "a": [
   "Einen Felsbrocken endlos bergauf rollen",
   "Im Wasser stehen, ohne trinken zu können",
   "An ein feuriges Rad gebunden sein",
   "Ein Adler frisst seine Leber"
  ]
 },
 "q1609": {
  "q": "In der griechischen Mythologie: Wie half Ariadne Theseus, nach dem Sieg über den Minotaurus aus dem Labyrinth zu entkommen?",
  "a": [
   "Sie gab ihm ein Garnknäuel",
   "Sie zeichnete eine Karte auf Papyrus",
   "Sie lieh ihm eine leuchtende Laterne",
   "Sie markierte die Wände mit Kreide"
  ]
 },
 "q1610": {
  "q": "Welcher Fluss der griechischen Unterwelt ließ die Seelen ihr irdisches Leben vergessen, wenn sie daraus tranken?",
  "a": [
   "Lethe",
   "Acheron",
   "Kokytos",
   "Phlegethon"
  ]
 },
 "q1611": {
  "q": "In der griechischen Mythologie: Warum verlor Orpheus Eurydike für immer, als er sie aus der Unterwelt führte?",
  "a": [
   "Er sah sich zu früh nach ihr um",
   "Er hörte auf, Lyra zu spielen",
   "Er sprach ihren Namen laut aus",
   "Er ließ den goldenen Zweig fallen"
  ]
 },
 "q1612": {
  "q": "In der griechischen Mythologie: Wie vermied Perseus im Kampf gegen Medusa, zu Stein zu erstarren?",
  "a": [
   "Er blickte auf ihr Spiegelbild in seinem Schild",
   "Er kämpfte mit verbundenen Augen",
   "Er trug einen Helm der Unsichtbarkeit",
   "Er schloss die Augen und nutzte einen Spiegelzauber"
  ]
 },
 "q1613": {
  "q": "In der griechischen Mythologie: Wie schützte Odysseus seine Mannschaft vor dem tödlichen Gesang der Sirenen?",
  "a": [
   "Er verstopfte ihre Ohren mit Bienenwachs",
   "Er befahl ihnen, lauter zu singen",
   "Er ankerte das Schiff weit vor der Insel",
   "Er spielte Flöte, um ihre Stimmen zu übertönen"
  ]
 },
 "q1614": {
  "q": "In der griechischen Mythologie: Welche Göttin entsprang voll ausgewachsen und gerüstet dem Haupt des Zeus?",
  "a": [
   "Athene",
   "Artemis",
   "Aphrodite",
   "Hera"
  ]
 },
 "q1615": {
  "q": "In der griechischen Mythologie: Wie hieß das geflügelte Pferd, das aus dem Blut der Medusa entsprang?",
  "a": [
   "Pegasus",
   "Areion",
   "Xanthos",
   "Sleipnir"
  ]
 },
 "q1616": {
  "q": "In der griechischen Mythologie: Welcher vielköpfigen Schlange wuchsen für jeden abgeschlagenen Kopf zwei neue nach?",
  "a": [
   "Die Lernäische Hydra",
   "Python",
   "Echidna",
   "Typhon"
  ]
 },
 "q1617": {
  "q": "In der griechischen Mythologie: Welche Inschrift trug der goldene Apfel, der den Streit zwischen Hera, Athene und Aphrodite auslöste?",
  "a": [
   "Der Schönsten",
   "Der Weisesten",
   "Der Stärksten",
   "Der Himmelskönigin"
  ]
 },
 "q1618": {
  "q": "In der griechischen Mythologie: Wie hieß der Fährmann, der die Toten über den Fluss Acheron oder Styx ruderte?",
  "a": [
   "Charon",
   "Thanatos",
   "Hypnos",
   "Morpheus"
  ]
 },
 "q1619": {
  "q": "In der griechischen Mythologie: Wie zögerte Penelope die Wahl eines neuen Ehemanns hinaus, während sie auf Odysseus wartete?",
  "a": [
   "Sie trennte ihr Webstück jede Nacht wieder auf",
   "Sie täuschte ein Schweigegelübde vor",
   "Sie veranstaltete täglich einen Bogenwettkampf",
   "Sie behauptete, der Webstuhl sei verflucht"
  ]
 },
 "q1620": {
  "q": "In der griechischen Mythologie: Welcher Titan stahl den Göttern das Feuer und brachte es den Menschen?",
  "a": [
   "Prometheus",
   "Epimetheus",
   "Atlas",
   "Hyperion"
  ]
 },
 "q1621": {
  "q": "In der griechischen Mythologie: Wer wurde damit verflucht, dass ihren wahren Prophezeiungen niemand Glauben schenkte?",
  "a": [
   "Kassandra",
   "Kirke",
   "Medea",
   "Semele"
  ]
 },
 "q1622": {
  "q": "In der griechischen Mythologie: Wie reinigte Herakles die schmutzigen Ställe des Königs Augias an einem einzigen Tag?",
  "a": [
   "Er leitete zwei Flüsse hindurch",
   "Er rief einen Orkan des Zeus herbei",
   "Er brannte sie nieder und baute sie neu",
   "Er heuerte tausend Satyrn zum Schaufeln an"
  ]
 },
 "q1623": {
  "q": "In der griechischen Mythologie: Welcher Jäger wurde in einen Hirsch verwandelt und von seinen eigenen Hunden zerrissen, nachdem er Artemis beim Baden sah?",
  "a": [
   "Aktaion",
   "Orion",
   "Adonis",
   "Endymion"
  ]
 },
 "q1624": {
  "q": "In der griechischen Mythologie: Welchen Namen nannte Odysseus dem Kyklopen Polyphem, bevor er ihn blendete?",
  "a": [
   "Niemand",
   "Fremder",
   "Achäer",
   "Reisender"
  ]
 },
 "q1625": {
  "q": "In der griechischen Mythologie: Wie löste Dädalus König Minos' Rätsel, einen Faden durch ein Schneckenhaus zu ziehen?",
  "a": [
   "Er band den Faden an eine mit Honig gelockte Ameise",
   "Er blies Seide durch ein Schilfrohr hindurch",
   "Er schmolz Wachs hinein als Führungsspur",
   "Er ließ eine Korkfaser auf warmem Öl treiben"
  ]
 },
 "q1626": {
  "q": "In der griechischen Mythologie: Welche Weberin wurde in eine Spinne verwandelt, nachdem sie Athene zum Wettweben herausgefordert hatte?",
  "a": [
   "Arachne",
   "Niobe",
   "Daphne",
   "Kallisto"
  ]
 },
 "q1627": {
  "q": "In der griechischen Mythologie: Warum musste Persephone jedes Jahr einen Teil der Zeit bei Hades in der Unterwelt verbringen?",
  "a": [
   "Sie aß dort Granatapfelkerne",
   "Sie trank aus einem goldenen Kelch",
   "Sie unterzeichnete eine Bronzetafel",
   "Sie trug eine Krone aus dunklem Silber"
  ]
 },
 "q1628": {
  "q": "In der griechischen Mythologie: Wie besiegte Zeus das Ungeheuer Typhon, nachdem dieses ihm die Sehnen durchtrennt hatte?",
  "a": [
   "Hermes und Pan stahlen die Sehnen zurück",
   "Athene schmiedete neue Sehnen aus Bronze",
   "Hephaistos fing Typhon in eisernen Netzen",
   "Apollon blendete Typhon mit Sonnenpfeilen"
  ]
 },
 "q1629": {
  "q": "In der griechischen Mythologie: Welche Tochter von König Pelias weigerte sich, ihren Vater zusammen mit ihren Schwestern zur Verjüngung lebendig zu kochen?",
  "a": [
   "Alkestis",
   "Euadne",
   "Asteropeia",
   "Antinoe"
  ]
 },
 "q1630": {
  "q": "Welchen Gegenstand schießen Spieler im Fußball ins Tor, um ein Tor zu erzielen?",
  "a": [
   "Einen Ball",
   "Einen Puck",
   "Eine Frisbee",
   "Einen Federball"
  ]
 },
 "q1631": {
  "q": "In welcher Sportart treten Athleten im Wasser in Stilen wie Freistil und Schmetterling gegeneinander an?",
  "a": [
   "Schwimmen",
   "Eishockey",
   "Bogenschießen",
   "Schach"
  ]
 },
 "q1632": {
  "q": "Wie viele ineinander verschlungene Ringe sind auf der offiziellen olympischen Flagge abgebildet?",
  "a": [
   "5",
   "4",
   "6",
   "7"
  ]
 },
 "q1633": {
  "q": "Wie viele Spieler einer Mannschaft dürfen in einem regulären Basketballspiel gleichzeitig auf dem Spielfeld stehen?",
  "a": [
   "5",
   "6",
   "7",
   "11"
  ]
 },
 "q1634": {
  "q": "In welcher Sportart wird das prestigeträchtige Wimbledon-Turnier ausgetragen?",
  "a": [
   "Tennis",
   "Golf",
   "Badminton",
   "Cricket"
  ]
 },
 "q1635": {
  "q": "Welche drei Disziplinen bilden einen klassischen Triathlon?",
  "a": [
   "Schwimmen, Radfahren und Laufen",
   "Laufen, Rudern und Radfahren",
   "Schwimmen, Skilanglauf und Schießen",
   "Radfahren, Turnen und Schwimmen"
  ]
 },
 "q1636": {
  "q": "Welche Farbe hat das Trikot des Gesamtführenden beim Radrennen Tour de France?",
  "a": [
   "Gelb",
   "Rosa",
   "Grün",
   "Rot"
  ]
 },
 "q1637": {
  "q": "Wie lang ist die offizielle Distanz eines modernen Marathonlaufs?",
  "a": [
   "42,195 km",
   "40,000 km",
   "45,500 km",
   "50,000 km"
  ]
 },
 "q1638": {
  "q": "In welchem Land entstand die Kampfsportart Judo?",
  "a": [
   "Japan",
   "Südkorea",
   "China",
   "Thailand"
  ]
 },
 "q1639": {
  "q": "Wie nennt man das gefiederte Spielgerät, das beim Badminton über das Netz geschlagen wird?",
  "a": [
   "Federball",
   "Puck",
   "Quaffel",
   "Wicket"
  ]
 },
 "q1640": {
  "q": "Welche zwei Sportarten werden in der olympischen Winterdisziplin Biathlon kombiniert?",
  "a": [
   "Skilanglauf und Gewehrschießen",
   "Skispringen und Skilanglauf",
   "Ski Alpin und Eiskunstlauf",
   "Eisschnelllauf und Bogenschießen"
  ]
 },
 "q1641": {
  "q": "Welche drei Waffen werden im modernen olympischen Fechten verwendet?",
  "a": [
   "Florett, Degen und Säbel",
   "Rapier, Breitschwert und Dolch",
   "Katana, Florett und Lanze",
   "Säbel, Claymore und Degen"
  ]
 },
 "q1642": {
  "q": "Wie viele Punkte muss ein Spieler seit der Regeländerung von 2001 erreichen, um einen regulären Satz im Tischtennis zu gewinnen?",
  "a": [
   "11",
   "21",
   "15",
   "25"
  ]
 },
 "q1643": {
  "q": "Wie hoch ist die maximal mögliche Punktzahl in einem einzelnen regulären Ten-Pin-Bowlingspiel?",
  "a": [
   "300",
   "200",
   "250",
   "360"
  ]
 },
 "q1644": {
  "q": "Wie heißt im Hallenvolleyball der Spieler mit andersfarbigem Trikot, der auf Abwehr spezialisiert ist?",
  "a": [
   "Libero",
   "Zuspieler",
   "Diagonalangreifer",
   "Ausputzer"
  ]
 },
 "q1645": {
  "q": "Welcher Begriff bezeichnet im Golf das Beenden eines Lochs mit zwei Schlägen unter Par?",
  "a": [
   "Eagle",
   "Birdie",
   "Albatros",
   "Bogey"
  ]
 },
 "q1646": {
  "q": "Was bedeutet das Schwenken der schwarz-weiß karierten Flagge in der Formel 1?",
  "a": [
   "Das Ende des Rennens oder der Sitzung",
   "Eine sofortige Unterbrechung des Rennens",
   "Die Disqualifikation eines Fahrers",
   "Rutschige Fahrbahn voraus"
  ]
 },
 "q1647": {
  "q": "Aus welcher Gesteinsart werden olympische Curlingsteine traditionell gefertigt?",
  "a": [
   "Granit",
   "Marmor",
   "Basalt",
   "Sandstein"
  ]
 },
 "q1648": {
  "q": "Wie viele Spieler stehen beim Polo in einem regulären Freiluftspiel pro Mannschaft auf dem Feld?",
  "a": [
   "4",
   "5",
   "6",
   "7"
  ]
 },
 "q1649": {
  "q": "Wie viele Punkte bringt im Wettkampf-Bogenschießen ein Treffer im innersten Zentrum einer olympischen Zielscheibe?",
  "a": [
   "10",
   "9",
   "12",
   "50"
  ]
 },
 "q1650": {
  "q": "Wie viele rote Bälle liegen zu Beginn eines regulären Frames im Snooker auf dem Tisch?",
  "a": [
   "15",
   "10",
   "21",
   "12"
  ]
 },
 "q1651": {
  "q": "Welches Gerät wird im olympischen Gerätturnen von Frauen, aber nicht von Männern geturnt?",
  "a": [
   "Schwebebalken",
   "Sprung",
   "Boden",
   "Pauschenpferd"
  ]
 },
 "q1652": {
  "q": "Wie viele Spieler jeder Mannschaft befinden sich während eines regulären Wasserballspiels gleichzeitig im Becken?",
  "a": [
   "7",
   "6",
   "8",
   "5"
  ]
 },
 "q1653": {
  "q": "Welche fünf Disziplinen bilden den Modernen Fünfkampf bei den Olympischen Spielen?",
  "a": [
   "Fechten, Schwimmen, Hindernisparcours, Pistolenschießen und Laufen",
   "Fechten, Rudern, Radfahren, Pistolenschießen und Laufen",
   "Bogenschießen, Schwimmen, Springreiten, Radfahren und Laufen",
   "Fechten, Schwimmen, Gewichtheben, Gewehrschießen und Laufen"
  ]
 },
 "q1654": {
  "q": "Wie viele Schläger darf ein Spieler laut Golfregeln während einer regulären Runde maximal in seiner Tasche mitführen?",
  "a": [
   "14",
   "12",
   "16",
   "18"
  ]
 },
 "q1655": {
  "q": "Wie viele Punkte werden im Rugby Union für einen Versuch vergeben?",
  "a": [
   "5",
   "4",
   "6",
   "7"
  ]
 },
 "q1656": {
  "q": "Wie nennt man im olympischen Rudern das leichte Besatzungsmitglied, das am Heck sitzt, das Boot steuert und die Mannschaft anleitet?",
  "a": [
   "Steuermann",
   "Bugmann",
   "Schlagmann",
   "Bootsmann"
  ]
 },
 "q1657": {
  "q": "Wie hoch sind in der Leichtathletik die Hürden im 110-Meter-Hürdenlauf der Männer?",
  "a": [
   "1,067 m",
   "0,914 m",
   "0,840 m",
   "1,200 m"
  ]
 },
 "q1658": {
  "q": "Wie schwer ist die offizielle Kugel beim Kugelstoßen der Männer in der Leichtathletik?",
  "a": [
   "7,26 kg",
   "6,00 kg",
   "8,00 kg",
   "5,45 kg"
  ]
 },
 "q1659": {
  "q": "Wie viele Wände des geschlossenen Courts sind beim regulären Racquetball als Spielfläche zugelassen?",
  "a": [
   "4",
   "3",
   "2",
   "1"
  ]
 },
 "q1660": {
  "q": "Wie viele Millimeter über dem Boden liegt laut Regeln der World Squash Federation die Oberkante des Blechs an der Stirnwand eines Einzel-Courts?",
  "a": [
   "480 mm",
   "430 mm",
   "530 mm",
   "380 mm"
  ]
 },
 "q1661": {
  "q": "In welchem antiken griechischen Heiligtum fanden die Olympischen Spiele der Antike statt?",
  "a": [
   "Olympia",
   "Delphi",
   "Sparta",
   "Korinth"
  ]
 },
 "q1662": {
  "q": "Aus wie vielen Einzeldisziplinen besteht der reguläre Zehnkampf der Männer in der Leichtathletik?",
  "a": [
   "10",
   "7",
   "8",
   "12"
  ]
 },
 "q1663": {
  "q": "Wie lang ist ein Schwimmbecken mit olympischen Maßen offiziell?",
  "a": [
   "50 m",
   "25 m",
   "100 m",
   "40 m"
  ]
 },
 "q1664": {
  "q": "Wie hoch ist im Turnier-Dressurreiten die maximal erreichbare Wertung in Prozent?",
  "a": [
   "100%",
   "10%",
   "50%",
   "200%"
  ]
 },
 "q1665": {
  "q": "Welche zwei Disziplinen bilden im olympischen Gewichtheben die Gesamtwertung des Zweikampfs?",
  "a": [
   "Reißen und Stoßen",
   "Kreuzheben und Bankdrücken",
   "Kniebeuge und Reißen",
   "Stoßen und Drücken"
  ]
 },
 "q1666": {
  "q": "Welches Naturphänomen bei einem Gewitter erzeugt einen hellen Lichtblitz am Himmel?",
  "a": [
   "Blitz",
   "Ein Regenbogen",
   "Nebel",
   "Schnee"
  ]
 },
 "q1667": {
  "q": "Welches Geräusch entsteht durch die schnelle Ausdehnung und Erhitzung von Luft entlang eines Blitzkanals?",
  "a": [
   "Donner",
   "Regentropfen",
   "Hagelkörner",
   "Windböen"
  ]
 },
 "q1668": {
  "q": "Welche Sicherheitsregel hilft, den Abstand zu einem sichtbaren Blitz in Kilometern über die Sekunden bis zum Donner zu schätzen?",
  "a": [
   "Sekunden durch 3 teilen",
   "Sekunden mit 3 malnehmen",
   "Sekunden durch 10 teilen",
   "Sekunden mit 10 malnehmen"
  ]
 },
 "q1669": {
  "q": "Welche Erfindung von Benjamin Franklin aus dem Jahr 1752 zeigte die elektrische Natur von Blitzen?",
  "a": [
   "Blitzableiter",
   "Voltaische Säule",
   "Leydener Flasche",
   "Elektroskop"
  ]
 },
 "q1670": {
  "q": "Welcher Aggregatzustand bildet den heißen, ionisierten Kanal einer typischen Blitzentladung?",
  "a": [
   "Plasma",
   "Suprafluidität",
   "Bose-Einstein-Kondensat",
   "Amorpher Feststoff"
  ]
 },
 "q1671": {
  "q": "Welche Wolkenart erzeugt fast alle natürlichen Blitze auf der Erde?",
  "a": [
   "Cumulonimbus",
   "Cirrus",
   "Altostratus",
   "Stratus"
  ]
 },
 "q1672": {
  "q": "Wie heißt bei einem Wolke-Erde-Blitz der schwache, schrittweise Ladungskanal, der zuerst abwärts läuft?",
  "a": [
   "Vorentladung",
   "Hauptentladung",
   "Folgeentladung",
   "Fangentladung"
  ]
 },
 "q1673": {
  "q": "Welcher helle Aufwärtsstrom fließt bei einem Blitz entlang des ionisierten Kanals, nachdem sich Vorentladung und Fangentladung verbunden haben?",
  "a": [
   "Hauptentladung",
   "Vorentladung",
   "Koronaentladung",
   "Schrittspannung"
  ]
 },
 "q1674": {
  "q": "Welches Seebecken in Südamerika ist für häufige, lang anhaltende nächtliche Gewitter bekannt, die Catatumbo-Blitze genannt werden?",
  "a": [
   "Maracaibo-See",
   "Titicacasee",
   "Poopó-See",
   "Valenciasee"
  ]
 },
 "q1675": {
  "q": "Welcher Begriff bezeichnet die Spannungsdifferenz am Boden zwischen beiden Füßen bei einem Blitzeinschlag in der Nähe?",
  "a": [
   "Schrittspannung",
   "Berührungsspannung",
   "Hall-Spannung",
   "Durchschlagspannung"
  ]
 },
 "q1676": {
  "q": "Welche Art von Blitz in der oberen Atmosphäre erscheint als kurzer rötlich-oranger Lichtstrahl über Gewitterwolken?",
  "a": [
   "Rotes Koboldphänomen",
   "Blauer Strahl",
   "Elf",
   "Elmsfeuer"
  ]
 },
 "q1677": {
  "q": "Welches Leuchtphänomen tritt bei Gewittern an spitzen Gegenständen durch stille Koronaentladung auf?",
  "a": [
   "Elmsfeuer",
   "Rotes Koboldphänomen",
   "Kugelblitz",
   "Grüner Blitz"
  ]
 },
 "q1678": {
  "q": "Welcher Vorgang trennt elektrische Ladungen in einer Gewitterwolke, wenn Graupel und Eiskristalle im Aufwind kollidieren?",
  "a": [
   "Nicht-induktive Aufladung",
   "Photoionisation",
   "Glühemission",
   "Piezoelektrizität"
  ]
 },
 "q1679": {
  "q": "Welche glasige, verschmolzene Mineralröhre entsteht, wenn ein Blitz sandigen Boden entlang des Entladungskanals schmilzt?",
  "a": [
   "Blitzröhre",
   "Obsidian",
   "Bimsstein",
   "Schlacke"
  ]
 },
 "q1680": {
  "q": "Welcher kurze, sich ausdehnende Ring aus Ultraviolett- und optischem Licht entsteht hoch über Gewitterwolken bei Elfen?",
  "a": [
   "Elfen-Emissionsring",
   "Blauer Starter",
   "Riesenstrahl",
   "Troll"
  ]
 },
 "q1681": {
  "q": "Welche kurzen Ausbrüche hochenergetischer Photonen entstehen durch starke elektrische Felder in Gewitterwolken?",
  "a": [
   "Terrestrische Gammablitze",
   "Synchrotron-Pulse",
   "Tscherenkow-Blitze",
   "Aurorale Kilowellenstrahlung"
  ]
 },
 "q1682": {
  "q": "Welcher Mechanismus beschleunigt Elektronen in Gewitterwolken auf relativistische Geschwindigkeiten für Blitze und Gammablitze?",
  "a": [
   "Runaway-Breakdown",
   "Joulesche Erwärmung",
   "Thomson-Streuung",
   "Zeeman-Effekt"
  ]
 },
 "q1683": {
  "q": "Welche schnelle, dünne Ionisationswelle läuft vor der Spitze eines Blitzleiters, um den Kanal zu verlängern?",
  "a": [
   "Streamer",
   "Whistler",
   "Sprite-Halo",
   "Sprite-Perle"
  ]
 },
 "q1684": {
  "q": "Welche Niederfrequenz-Radiowelle läuft nach einem Blitz entlang der Magnetfeldlinien der Erde?",
  "a": [
   "Whistler-Welle",
   "Schumann-Resonanz",
   "Alfvén-Welle",
   "Langmuir-Welle"
  ]
 },
 "q1685": {
  "q": "Welcher kurzlebige, aufwärts gerichtete Stromimpuls geht einem blauen Strahl über einer Gewitterwolke voraus?",
  "a": [
   "Blauer Starter",
   "Rotes Koboldphänomen",
   "Sprite-Halo",
   "Korona"
  ]
 },
 "q1686": {
  "q": "Welche Hochfrequenzentladung in Gewitterwolken erzeugt Mikrowellen- und UKW-Pulse ohne hellen Lichtblitz?",
  "a": [
   "Schmales bipolares Ereignis",
   "Vorentladung",
   "Hauptentladung",
   "Blauer Strahl"
  ]
 },
 "q1687": {
  "q": "Welches schwache Leuchten, das zu den mit Blitzen verbundenen Erscheinungen der oberen Atmosphäre über Gewittern gehört, geht einem roten Sprite voraus und erstreckt sich in etwa 75 bis 85 km Höhe über Dutzende Kilometer?",
  "a": [
   "Sprite-Halo",
   "Blauer Starter",
   "Elf",
   "Streamer"
  ]
 },
 "q1688": {
  "q": "Welches Tier ist dafür bekannt, im Stehen zu schlafen und schwarz-weiße Streifen zu haben?",
  "a": [
   "Zebra",
   "Tiger",
   "Großer Panda",
   "Pferd"
  ]
 },
 "q1689": {
  "q": "Welches ist das einzige Säugetier, das zu echtem, anhaltendem Flug fähig ist?",
  "a": [
   "Fledermaus",
   "Gleithörnchen",
   "Kurzkopfgleitbeutler",
   "Riesengleiter"
  ]
 },
 "q1690": {
  "q": "Wie viele Herzen hat ein Oktopus?",
  "a": [
   "3",
   "1",
   "2",
   "5"
  ]
 },
 "q1691": {
  "q": "Welches natürliche Lebensmittel verdirbt in verschlossenen Gefäßen selbst nach Jahrtausenden nicht?",
  "a": [
   "Honig",
   "Olivenöl",
   "Ahornsirup",
   "Erdnussbutter"
  ]
 },
 "q1692": {
  "q": "Welches Element lässt das Blut von Hummern im sauerstoffreichen Zustand blau erscheinen?",
  "a": [
   "Kupfer",
   "Eisen",
   "Kobalt",
   "Magnesium"
  ]
 },
 "q1693": {
  "q": "Auf welchem Planeten des Sonnensystems ist ein einzelner Tag länger als sein gesamtes Jahr?",
  "a": [
   "Venus",
   "Merkur",
   "Mars",
   "Uranus"
  ]
 },
 "q1694": {
  "q": "Welche altägyptische Königin lebte zeitlich näher an der Mondlandung von 1969 als am Bau der Großen Pyramide von Gizeh?",
  "a": [
   "Kleopatra VII.",
   "Nofretete",
   "Hatschepsut",
   "Nefertari"
  ]
 },
 "q1695": {
  "q": "Welches Tier scheidet würfelförmigen Kot aus, damit dieser nicht wegrollt?",
  "a": [
   "Wombat",
   "Schnabeltier",
   "Koala",
   "Beutelteufel"
  ]
 },
 "q1696": {
  "q": "In welchem Land liegt der Lake Hillier, der für sein natürlich leuchtend pinkes Wasser bekannt ist?",
  "a": [
   "Australien",
   "Chile",
   "Senegal",
   "Kasachstan"
  ]
 },
 "q1697": {
  "q": "Welches Küchengerät wurde erfunden, nachdem Percy Spencer 1945 bemerkte, dass ein Schokoriegel in seiner Tasche neben einem Radarmagnetron schmolz?",
  "a": [
   "Mikrowellenherd",
   "Toaster",
   "Wasserkocher",
   "Induktionskochfeld"
  ]
 },
 "q1698": {
  "q": "Wie heißt der eindeutige Temperatur- und Druckpunkt, an dem ein Stoff gleichzeitig als Gas, Flüssigkeit und Feststoff vorliegt?",
  "a": [
   "Tripelpunkt",
   "Kritischer Punkt",
   "Curie-Punkt",
   "Taupunkt"
  ]
 },
 "q1699": {
  "q": "Auf welchem berühmten Gemälde von Leonardo da Vinci hat die dargestellte Person keine sichtbaren Augenbrauen oder Wimpern?",
  "a": [
   "Mona Lisa",
   "Dame mit dem Hermelin",
   "La Belle Ferronnière",
   "Ginevra de’ Benci"
  ]
 },
 "q1700": {
  "q": "Gegen welche großen flugunfähigen Vögel führte das australische Militär 1932 eine erfolglose Bekämpfungsaktion durch?",
  "a": [
   "Emus",
   "Kasuare",
   "Strauße",
   "Nandus"
  ]
 },
 "q1701": {
  "q": "Welches Meer auf der Erde hat überhaupt keine Küstenlinie und wird ausschließlich von Meeresströmungen begrenzt?",
  "a": [
   "Sargassosee",
   "Weißes Meer",
   "Beringmeer",
   "Aralsee"
  ]
 },
 "q1702": {
  "q": "In welchem Land wurde im Jahr 705 n. Chr. das älteste durchgehend betriebene Hotel der Welt, das Nishiyama Onsen Keiunkan, gegründet?",
  "a": [
   "Japan",
   "China",
   "Südkorea",
   "Schweiz"
  ]
 },
 "q1703": {
  "q": "Welche ist die einzige bekannte Vogelart, die rückwärts fliegen kann?",
  "a": [
   "Kolibri",
   "Eisvogel",
   "Schwalbe",
   "Mauersegler"
  ]
 },
 "q1704": {
  "q": "Welche Sportart übte der Astronaut Alan Shepard 1971 während der Mission Apollo 14 auf dem Mond aus?",
  "a": [
   "Golf",
   "Baseball",
   "Tennis",
   "Dart"
  ]
 },
 "q1705": {
  "q": "Welcher Roman von Ernest Vincent Wright aus dem Jahr 1939 wurde vollständig ohne den Buchstaben E geschrieben?",
  "a": [
   "Gadsby",
   "Finnegans Wake",
   "Wenn ein Reisender in einer Winternacht",
   "Fahles Feuer"
  ]
 },
 "q1706": {
  "q": "Welche Frucht enthält das Enzym Bromelain, das Proteine abbaut und ein Kribbeln auf der Zunge verursachen kann?",
  "a": [
   "Ananas",
   "Kiwi",
   "Papaya",
   "Mango"
  ]
 },
 "q1707": {
  "q": "Welcher französische Herrscher des 19. Jahrhunderts wurde 1807 bei einer Jagd von einer Schar zahmer Kaninchen angegriffen?",
  "a": [
   "Napoleon Bonaparte",
   "Ludwig XVIII.",
   "Karl X.",
   "Napoleon III."
  ]
 },
 "q1708": {
  "q": "In welchen Farben wurden Karotten überwiegend angebaut, bevor niederländische Züchter im 17. Jahrhundert orangefarbene Sorten populär machten?",
  "a": [
   "Violett und Gelb",
   "Blau und Grün",
   "Reinweiß",
   "Leuchtend Pink"
  ]
 },
 "q1709": {
  "q": "Welche Art der „unsterblichen“ Qualle kann ihre ausgewachsenen Zellen wieder in ein jugendliches Polypenstadium zurückverwandeln?",
  "a": [
   "Turritopsis dohrnii",
   "Chironex fleckeri",
   "Physalia physalis",
   "Aurelia aurita"
  ]
 },
 "q1710": {
  "q": "Um welchen Planeten kreist der Mond Titan, der eine dichte stickstoffreiche Atmosphäre und Seen aus flüssigem Methan besitzt?",
  "a": [
   "Saturn",
   "Jupiter",
   "Uranus",
   "Neptun"
  ]
 },
 "q1711": {
  "q": "Welches Insekt wurde 1947 in einem Relais des Computers Harvard Mark II gefunden und führte zu dem berühmten Logbucheintrag eines echten Computer-„Bugs“?",
  "a": [
   "Motte",
   "Kakerlake",
   "Käfer",
   "Ameise"
  ]
 },
 "q1712": {
  "q": "Zwischen welchen beiden Ländern liegt die Fasaneninsel, eine Flussinsel, deren Souveränität gemäß dem Pyrenäenfrieden von 1659 alle sechs Monate wechselt?",
  "a": [
   "Frankreich und Spanien",
   "Deutschland und Polen",
   "Österreich und Schweiz",
   "Italien und Slowenien"
  ]
 },
 "q1713": {
  "q": "Welches Phänomen beschreibt, dass heißes Wasser unter bestimmten Versuchsbedingungen schneller gefriert als kaltes Wasser?",
  "a": [
   "Mpemba-Effekt",
   "Leidenfrost-Effekt",
   "Marangoni-Effekt",
   "Magnus-Effekt"
  ]
 },
 "q1714": {
  "q": "Wie lange dauert die vollständige Aufführung von John Cages Avantgarde-Komposition „As Slow as Possible“ in Halberstadt?",
  "a": [
   "639 Jahre",
   "100 Jahre",
   "250 Jahre",
   "1.000 Jahre"
  ]
 },
 "q1715": {
  "q": "In welchem Jahr fand der Britisch-Sansibarische Krieg statt, der mit rund 38 Minuten als kürzester Krieg der Geschichte gilt?",
  "a": [
   "1896",
   "1879",
   "1902",
   "1914"
  ]
 },
 "q1716": {
  "q": "Wie lange dauerte es, bis beim berühmten Pechtropfenexperiment der University of Queensland von 1927 der erste Tropfen fiel?",
  "a": [
   "8 Jahre",
   "2 Jahre",
   "15 Jahre",
   "24 Jahre"
  ]
 },
 "q1717": {
  "q": "Welcher exzentrische Kaufmann des 18. Jahrhunderts veröffentlichte 1802 das Buch „A Pickle for the Knowing Ones“ völlig ohne Satzzeichen und fügte später eine Seite mit Satzzeichen zum Selbsteinfügen hinzu?",
  "a": [
   "Timothy Dexter",
   "William Beckford",
   "John Mytton",
   "Beau Brummell"
  ]
 },
 "q1718": {
  "q": "Welche Meeresschneckenart stiehlt funktionsfähige Chloroplasten aus gefressenen Algen und kann dadurch monatelang durch Fotosynthese überleben?",
  "a": [
   "Elysia chlorotica",
   "Glaucus atlanticus",
   "Chromodoris willani",
   "Aplysia californica"
  ]
 },
 "q1719": {
  "q": "Welches große Säugetier trägt sein Junges in einem Beutel und hüpft auf zwei Beinen?",
  "a": [
   "Känguru",
   "Koala",
   "Wombat",
   "Tasmanischer Teufel"
  ]
 },
 "q1720": {
  "q": "Welches berühmte Wahrzeichen in Paris ist ein hoher Eisengitterturm, der für die Weltausstellung 1889 gebaut wurde?",
  "a": [
   "Eiffelturm",
   "Arc de Triomphe",
   "Kathedrale Notre-Dame",
   "Louvre-Pyramide"
  ]
 },
 "q1721": {
  "q": "Welcher flugunfähige Vogel aus der Antarktis kann über 30 km/h schnell schwimmen und trägt ein schwarz-weißes Gefieder?",
  "a": [
   "Kaiserpinguin",
   "Strauß",
   "Kiwi",
   "Dodo"
  ]
 },
 "q1722": {
  "q": "Welches große Meerestier hat eine Zunge, die so viel wiegen kann wie ein ausgewachsener Elefant?",
  "a": [
   "Blauwal",
   "Weißer Hai",
   "Riesenkalmar",
   "Walross"
  ]
 },
 "q1723": {
  "q": "Welche Farbe hat die Haut eines Eisbären unter seinem lichtdurchlässigen weißen Fell?",
  "a": [
   "Schwarz",
   "Rosa",
   "Blassgelb",
   "Hellblau"
  ]
 },
 "q1724": {
  "q": "Welcher Planet unseres Sonnensystems dreht sich, von oberhalb seines Nordpols betrachtet, im Uhrzeigersinn um seine Achse?",
  "a": [
   "Venus",
   "Mars",
   "Jupiter",
   "Merkur"
  ]
 },
 "q1725": {
  "q": "Welche tropische Frucht wird botanisch als einsamige Beere und nicht als Steinfrucht eingestuft?",
  "a": [
   "Avocado",
   "Pfirsich",
   "Kirsche",
   "Pflaume"
  ]
 },
 "q1726": {
  "q": "Welcher von Italien umschlossene europäische Zwergstaat gilt als die älteste noch bestehende Republik der Welt, gegründet im Jahr 301 n. Chr.?",
  "a": [
   "San Marino",
   "Monaco",
   "Liechtenstein",
   "Andorra"
  ]
 },
 "q1727": {
  "q": "Welches australische Beuteltier produziert charakteristische würfelförmige Kotstücke, die nicht wegrollen?",
  "a": [
   "Wombat",
   "Koala",
   "Tasmanischer Teufel",
   "Schnabeltier"
  ]
 },
 "q1728": {
  "q": "Mit welchem südamerikanischen Land teilt Frankreich über Französisch-Guayana seine längste Landgrenze?",
  "a": [
   "Brasilien",
   "Suriname",
   "Venezuela",
   "Kolumbien"
  ]
 },
 "q1729": {
  "q": "Warum glaubten wohlhabende Aristokraten im Europa des 18. Jahrhunderts fälschlicherweise, Tomaten seien giftig, nachdem sie von Zinntellern gegessen hatten?",
  "a": [
   "Tomatensäure löste Blei aus den Tellern",
   "Tomatenschalen enthielten Zyanid",
   "Rohe Tomaten lösten allergische Schocks aus",
   "Auf ungewaschenen Tellern wuchsen Bakterien"
  ]
 },
 "q1730": {
  "q": "Welches chemische Element macht rund 90 Prozent der Atome im beobachtbaren Universum aus?",
  "a": [
   "Wasserstoff",
   "Helium",
   "Sauerstoff",
   "Kohlenstoff"
  ]
 },
 "q1731": {
  "q": "In welchem afrikanischen Land stehen mehr antike Pyramiden als in Ägypten – über 200 vom Königreich Kusch erbaute Bauwerke?",
  "a": [
   "Sudan",
   "Libyen",
   "Äthiopien",
   "Marokko"
  ]
 },
 "q1732": {
  "q": "Welches große semi-aquatische afrikanische Säugetier sondert eine rötlich-rosa ölige Flüssigkeit ab, die als Sonnenschutz und Antibiotikum wirkt?",
  "a": [
   "Flusspferd",
   "Afrikanischer Elefant",
   "Nilkrokodil",
   "Breitmaulnashorn"
  ]
 },
 "q1733": {
  "q": "Welches Metall befindet sich zu fast 99 Prozent seines gesamten irdischen Vorkommens im Erdkern, genug für eine 45 cm dicke Schicht auf der Oberfläche?",
  "a": [
   "Gold",
   "Silber",
   "Platin",
   "Kupfer"
  ]
 },
 "q1734": {
  "q": "Welches berühmte Brettspiel wurde 1904 ursprünglich von Elizabeth Magie als „The Landlord's Game“ patentiert, um die Gefahren von Bodenmonopolen zu zeigen?",
  "a": [
   "Monopoly",
   "Risiko",
   "Scrabble",
   "Cluedo"
  ]
 },
 "q1735": {
  "q": "Welchen beigefarbenen Weißton benannten Astronomen im Jahr 2002 als Durchschnittsfarbe des gesamten Lichts der Galaxien im Universum?",
  "a": [
   "Cosmic Latte",
   "Galaktische Creme",
   "Sternen-Elfenbein",
   "Nebelperlweiß"
  ]
 },
 "q1736": {
  "q": "Welches sich langsam bewegende baumbewohnende Säugetier hat acht oder neun Halswirbel – mehr als die sieben einer Giraffe?",
  "a": [
   "Dreifinger-Faultier",
   "Koala",
   "Kleiner Panda",
   "Chamäleon"
  ]
 },
 "q1737": {
  "q": "Welcher natürliche Mechanismus lässt im kalifornischen Death Valley schwere Felsbrocken über die Ebene Racetrack Playa gleiten?",
  "a": [
   "Dünne Eisplatten, die von leichtem Wind geschoben werden",
   "Erdbeben, die den trockenen Lehm erschüttern",
   "Unterirdische magnetische Mineralströme",
   "Sturzfluten, die die Steine anheben"
  ]
 },
 "q1738": {
  "q": "Welcher US-amerikanische Leichtathlet brach 1991 Bob Beamons 23 Jahre alten Weitsprung-Weltrekord mit einer Weite von 8,95 Metern?",
  "a": [
   "Mike Powell",
   "Carl Lewis",
   "Jesse Owens",
   "Iván Pedroso"
  ]
 },
 "q1739": {
  "q": "Auf welcher arktischen Insel überlebte eine kleine isolierte Population von Wollhaarmammuts bis etwa 2000 v. Chr., nach dem Bau der ägyptischen Pyramiden?",
  "a": [
   "Wrangelinsel",
   "Spitzbergen",
   "Baffininsel",
   "Nowaja Semlja"
  ]
 },
 "q1740": {
  "q": "Wodurch erhält der Blutfall in der Antarktis seine leuchtend rote Farbe, wenn Salzwasser unter dem Taylor-Gletscher hervortritt?",
  "a": [
   "Oxidierte eisenreiche Sole",
   "Blüte roter Schneealgen",
   "Vulkanische Zinnoberablagerungen",
   "Hohe Bromkonzentrationen"
  ]
 },
 "q1741": {
  "q": "Welche spanische Stadt in den Pyrenäen bildet seit dem Pyrenäenfrieden von 1659 eine vollständig von Frankreich umschlossene Exklave?",
  "a": [
   "Llívia",
   "Puigcerdà",
   "Olivenza",
   "Ceuta"
  ]
 },
 "q1742": {
  "q": "Welches mit Kalk gemischte Vulkangestein ermöglichte es dem antiken römischen Meeresbeton, in Meerwasser Risse selbstständig zu heilen?",
  "a": [
   "Puzzolan",
   "Obsidian",
   "Basalt",
   "Granit"
  ]
 },
 "q1743": {
  "q": "Über welcher Inselgruppe im australischen Northern Territory bildet sich in der Regenzeit fast jeden Nachmittag das Gewitter Hector the Convector?",
  "a": [
   "Tiwi-Inseln",
   "Whitsunday-Inseln",
   "Torres-Strait-Inseln",
   "Furneaux-Gruppe"
  ]
 },
 "q1744": {
  "q": "Welche neolithische Ausgrabungsstätte im Südosten der Türkei besitzt T-förmige Steinpfeiler aus der Zeit um 9500 v. Chr., noch vor Ackerbau und Keramik?",
  "a": [
   "Göbekli Tepe",
   "Çatalhöyük",
   "Hattuša",
   "Troja"
  ]
 },
 "q1745": {
  "q": "In welcher arktischen norwegischen Siedlung auf Spitzbergen sind Bestattungen verboten, weil der Permafrostboden die Verwesung verhindert?",
  "a": [
   "Longyearbyen",
   "Tromsø",
   "Hammerfest",
   "Narvik"
  ]
 },
 "q1746": {
  "q": "Welcher Gesteinsplanet unseres Sonnensystems ist dreiachsig, besitzt also drei unterschiedliche Radien entlang seiner Achsen statt eines abgeplatteten Sphäroids?",
  "a": [
   "Mars",
   "Venus",
   "Merkur",
   "Erde"
  ]
 },
 "q1747": {
  "q": "In welchem ostafrikanischen Land brach 1962 in einem Mädcheninternat eine ansteckende Lachepidemie aus, die vorübergehend 14 Schulen schloss?",
  "a": [
   "Tanganjika (Tansania)",
   "Kenia",
   "Uganda",
   "Malawi"
  ]
 },
 "q1748": {
  "q": "Welche Hochdruck-Kristallform von Wasser, bekannt als brennendes Eis, bleibt im Inneren großer Exoplaneten selbst über 400 °C fest?",
  "a": [
   "Eis VII",
   "Eis Ih",
   "Eis III",
   "Eis V"
  ]
 },
 "q1749": {
  "q": "Bei der Mumie welches ägyptischen Pharaos der 20. Dynastie entdeckte man im 19. Jahrhundert kleine Zwiebeln in den Augenhöhlen als Symbol ewigen Lebens?",
  "a": [
   "Ramses IV.",
   "Tutanchamun",
   "Ramses II.",
   "Sethos I."
  ]
 },
 "q1750": {
  "q": "Welcher nachtaktive Greifvogel kann seinen Kopf um bis zu 270 Grad drehen, um nach hinten zu blicken, ohne den Körper zu bewegen?",
  "a": [
   "Eule",
   "Adler",
   "Flamingo",
   "Pelikan"
  ]
 },
 "q1751": {
  "q": "Welcher achtarmige Meeresweichtier-Bewohner besitzt drei Herzen und blaues, kupferbasiertes Blut?",
  "a": [
   "Krake",
   "Meeresschildkröte",
   "Muräne",
   "Seepferdchen"
  ]
 },
 "q1752": {
  "q": "Welche bekannte Hülsenfrucht reift unter der Erde in Hülsen statt an Bäumen, obwohl sie oft als Nuss bezeichnet wird?",
  "a": [
   "Erdnuss",
   "Mandel",
   "Walnuss",
   "Haselnuss"
  ]
 },
 "q1753": {
  "q": "Wie viele Zeitzonen durchquert ein Reisender auf der gesamten 9.289 Kilometer langen Strecke der russischen Transsibirischen Eisenbahn?",
  "a": [
   "8",
   "3",
   "15",
   "24"
  ]
 },
 "q1754": {
  "q": "Warum haben eineiige Zwillinge unterschiedliche Fingerabdrücke, obwohl sie nahezu identische DNA besitzen?",
  "a": [
   "Zufällige Einflüsse im Mutterleib",
   "Unterschiedliche Ernährung in der Kindheit",
   "Sonneneinstrahlung nach der Geburt",
   "Zufällige Mutationen der Hautzellen"
  ]
 },
 "q1755": {
  "q": "Welche Geschmacksrichtung können Hauskatzen und andere Katzenartige aufgrund einer genetischen Besonderheit überhaupt nicht schmecken?",
  "a": [
   "Süß",
   "Salzig",
   "Bitter",
   "Sauer"
  ]
 },
 "q1756": {
  "q": "Wie viele Steinstufen führen an jeder der vier Seiten der Hauptpyramide El Castillo in Chichén Itzá hinauf, was mit der Plattform 365 ergibt?",
  "a": [
   "91",
   "73",
   "100",
   "120"
  ]
 },
 "q1757": {
  "q": "Um wie viele Sekunden pro Jahrhundert nimmt die durchschnittliche Länge eines Erdentages durch die Gezeitenreibung des Mondes ungefähr zu?",
  "a": [
   "1,8 Sekunden",
   "15 Sekunden",
   "45 Sekunden",
   "2 Minuten"
  ]
 },
 "q1758": {
  "q": "Welcher Tiefsee-Kopffüßer besitzt mit bis zu 27 Zentimetern Durchmesser die größten Augen im Tierreich, um schwaches Licht in der Tiefe zu erkennen?",
  "a": [
   "Koloss-Kalmar",
   "Vampirtintenfisch",
   "Pazifischer Riesenkrake",
   "Perlboot"
  ]
 },
 "q1759": {
  "q": "Welche Art von Wasser füllt die Ozeane der Erde?",
  "a": [
   "Salzwasser",
   "Süßwasser",
   "Sprudelwasser",
   "Regenwasser"
  ]
 },
 "q1760": {
  "q": "Welcher ist der größte und tiefste Ozean der Erde?",
  "a": [
   "Pazifischer Ozean",
   "Atlantischer Ozean",
   "Indischer Ozean",
   "Arktischer Ozean"
  ]
 },
 "q1761": {
  "q": "In welchem Ozean liegt der Marianengraben, der tiefste bekannte Tiefseegraben der Erde?",
  "a": [
   "Pazifischer Ozean",
   "Atlantischer Ozean",
   "Indischer Ozean",
   "Südlicher Ozean"
  ]
 },
 "q1762": {
  "q": "Welcher stark salzhaltige See an der Grenze zwischen Jordanien und Israel ist dafür bekannt, dass Schwimmer mühelos an seiner Oberfläche treiben?",
  "a": [
   "Totes Meer",
   "Kaspisches Meer",
   "Aralsee",
   "Rotes Meer"
  ]
 },
 "q1763": {
  "q": "Vor der Küste welches Landes liegt das Great Barrier Reef, das größte Korallenriffsystem der Welt?",
  "a": [
   "Australien",
   "Brasilien",
   "Indonesien",
   "Mexiko"
  ]
 },
 "q1764": {
  "q": "Welche warme Meeresströmung im Atlantik fließt vom Golf von Mexiko Richtung Westeuropa und mildert dessen Klima?",
  "a": [
   "Golfstrom",
   "Humboldtstrom",
   "Kuroshio",
   "Benguelastrom"
  ]
 },
 "q1765": {
  "q": "Die Anziehungskraft welches Himmelskörpers ist die Hauptursache für die Gezeiten der Ozeane auf der Erde?",
  "a": [
   "Des Mondes",
   "Des Mars",
   "Der Venus",
   "Des Jupiter"
  ]
 },
 "q1766": {
  "q": "Welche schmale Meerenge trennt Europa und Afrika am westlichen Eingang zum Mittelmeer?",
  "a": [
   "Straße von Gibraltar",
   "Straße von Hormus",
   "Beringstraße",
   "Straße von Malakka"
  ]
 },
 "q1767": {
  "q": "Welches Meer trennt die Arabische Halbinsel von Nordostafrika und ist über den Suezkanal mit dem Mittelmeer verbunden?",
  "a": [
   "Rotes Meer",
   "Schwarzes Meer",
   "Arabisches Meer",
   "Ägäisches Meer"
  ]
 },
 "q1768": {
  "q": "Welches abflusslose Gewässer zwischen Europa und Asien ist flächenmäßig das größte Binnenmeer der Welt?",
  "a": [
   "Kaspisches Meer",
   "Aralsee",
   "Totes Meer",
   "Asowsches Meer"
  ]
 },
 "q1769": {
  "q": "Ungefähr wie viele Gramm gelöstes Salz sind in 1 Kilogramm durchschnittlichem Meerwasser enthalten?",
  "a": [
   "35 Gramm",
   "5 Gramm",
   "120 Gramm",
   "250 Gramm"
  ]
 },
 "q1770": {
  "q": "Welche Region im Nordatlantik ist das einzige Meer der Erde, das ausschließlich durch Meeresströmungen und nicht durch Küsten begrenzt wird?",
  "a": [
   "Sargassosee",
   "Beringmeer",
   "Barentssee",
   "Korallenmeer"
  ]
 },
 "q1771": {
  "q": "In welchem Meer ist das Wasser unterhalb einer Tiefe von etwa 200 Metern völlig sauerstofffrei und reich an giftigem Schwefelwasserstoff?",
  "a": [
   "Schwarzes Meer",
   "Ostsee",
   "Nordsee",
   "Adriatisches Meer"
  ]
 },
 "q1772": {
  "q": "Wie groß ist die ungefähre maximale Tiefe des Challengertiefs im Marianengraben?",
  "a": [
   "11.000 Meter",
   "4.500 Meter",
   "7.200 Meter",
   "18.500 Meter"
  ]
 },
 "q1773": {
  "q": "Welcher Ozean bedeckt rund 46 Prozent der Wasseroberfläche der Erde und ist größer als alle Landmassen der Erde zusammen?",
  "a": [
   "Pazifischer Ozean",
   "Atlantischer Ozean",
   "Indischer Ozean",
   "Südlicher Ozean"
  ]
 },
 "q1774": {
  "q": "Welche Ozeanschicht unterhalb von etwa 200 Metern erhält zu wenig Sonnenlicht für Photosynthese und wird oft Dämmerungszone genannt?",
  "a": [
   "Mesopelagial",
   "Epipelagial",
   "Abyssopelagial",
   "Hadopelagial"
  ]
 },
 "q1775": {
  "q": "Wie heißt der abgelegene Punkt im Südpazifik, der am weitesten von jeder Landmasse der Erde entfernt liegt?",
  "a": [
   "Point Nemo",
   "Kap Hoorn",
   "Tristan da Cunha",
   "Bouvetinsel"
  ]
 },
 "q1776": {
  "q": "In welcher Bucht zwischen den kanadischen Provinzen New Brunswick und Nova Scotia tritt der weltweit höchste Tidenhub auf?",
  "a": [
   "Bay of Fundy",
   "Hudson Bay",
   "Chesapeake Bay",
   "Golf von Biskaya"
  ]
 },
 "q1777": {
  "q": "Welcher ist der längste zusammenhängende Gebirgszug der Erde, der sich rund 65.000 Kilometer unter den Weltmeeren erstreckt?",
  "a": [
   "Mittelozeanischer Rücken",
   "Anden",
   "Himalaya",
   "Great Dividing Range"
  ]
 },
 "q1778": {
  "q": "Welche 1977 nahe dem Galápagos-Graben entdeckten hydrothermalen Tiefseequellen stoßen überhitztes, mineralreiches Wasser aus, das wie dunkler Rauch aussieht?",
  "a": [
   "Schwarze Raucher",
   "Blue Holes",
   "Salzsoleseen",
   "Schlammvulkane"
  ]
 },
 "q1779": {
  "q": "Welcher Ozean ist der einzige auf der Erde, der den Globus vollständig umfließt, ohne von einem Kontinent blockiert zu werden?",
  "a": [
   "Südlicher Ozean",
   "Arktischer Ozean",
   "Indischer Ozean",
   "Atlantischer Ozean"
  ]
 },
 "q1780": {
  "q": "Welcher Ozean ist sowohl der kleinste als auch der flachste der fünf Ozeane der Erde?",
  "a": [
   "Arktischer Ozean",
   "Südlicher Ozean",
   "Indischer Ozean",
   "Atlantischer Ozean"
  ]
 },
 "q1781": {
  "q": "Wie heißt die Grenzschicht im Ozean, unterhalb derer die Temperatur im Vergleich zur warmen Oberflächenschicht mit der Tiefe rasch abnimmt?",
  "a": [
   "Thermokline",
   "Halokline",
   "Pyknokline",
   "Chemokline"
  ]
 },
 "q1782": {
  "q": "Welche beiden Forscher unternahmen 1960 an Bord des Bathyskaphs Trieste den ersten bemannten Tauchgang zum Grund des Marianengrabens?",
  "a": [
   "Jacques Piccard und Don Walsh",
   "Jacques Cousteau und Sylvia Earle",
   "James Cameron und Victor Vescovo",
   "Robert Ballard und Auguste Piccard"
  ]
 },
 "q1783": {
  "q": "Wie heißt die horizontale Tiefseeschicht im Ozean, in der sich Schallwellen mit minimaler Geschwindigkeit ausbreiten und über Tausende Kilometer tragen können?",
  "a": [
   "SOFAR-Kanal",
   "Ekman-Schicht",
   "Benthal",
   "Litoral"
  ]
 },
 "q1784": {
  "q": "Welche große Meeresströmung, die von starken Westwinden rund um die Antarktis angetrieben wird, ist nach transportiertem Wasservolumen die stärkste der Erde?",
  "a": [
   "Antarktischer Zirkumpolarstrom",
   "Agulhasstrom",
   "Labradorstrom",
   "Kanarenstrom"
  ]
 },
 "q1785": {
  "q": "Welcher Tiefseegraben im Südatlantik ist der tiefste Punkt des Atlantischen Ozeans und erreicht im Meteortief rund 8.264 Meter?",
  "a": [
   "Süd-Sandwich-Graben",
   "Puerto-Rico-Graben",
   "Sundagraben",
   "Kermadecgraben"
  ]
 },
 "q1786": {
  "q": "Welcher ozeanografische Effekt bewirkt, dass oberflächennahe Meeresströmungen auf der Nordhalbkugel um etwa 45 Grad nach rechts von der Windrichtung abgelenkt werden?",
  "a": [
   "Ekman-Spirale",
   "Venturi-Effekt",
   "Magnus-Effekt",
   "Marangoni-Effekt"
  ]
 },
 "q1787": {
  "q": "Welcher Unterwasservulkan vor der Südostküste der Insel Hawaii ist der jüngste Vulkan der Hawaii-Emperor-Vulkankette?",
  "a": [
   "Kamaʻehuakanaloa",
   "Mauna Loa",
   "Kīlauea",
   "Hualālai"
  ]
 },
 "q1788": {
  "q": "Welche Einheit wird in der Ozeanografie zur Messung des Volumentransports von Meeresströmungen verwendet und entspricht einer Million Kubikmeter pro Sekunde?",
  "a": [
   "Sverdrup",
   "Nansen",
   "Beaufort",
   "Fathom"
  ]
 },
 "q1789": {
  "q": "Welches im Jahr 2000 im Atlantik entdeckte hydrothermale Tiefseefeld besitzt bis zu 60 Meter hohe Karbonatschlote, die durch Serpentinisierung statt Magma gespeist werden?",
  "a": [
   "Hydrothermalfeld Lost City",
   "TAG-Hydrothermalfeld",
   "Rainbow-Hydrothermalfeld",
   "Endeavour-Hydrothermalfeld"
  ]
 },
 "q1790": {
  "q": "Wie heißt die Tiefengrenze im Ozean, unterhalb derer sich Kalziumkarbonat schneller auflöst als es abgelagert wird, sodass kalkhaltige Schalen am Meeresboden nicht erhalten bleiben?",
  "a": [
   "Karbonat-Kompensationstiefe",
   "Aragonit-Sättigungshorizont",
   "Euphotische Kompensationstiefe",
   "Isopyknische Grenze"
  ]
 },
 "q1791": {
  "q": "Welches Meerestier hat acht Arme und kann dunkle Tinte ausstoßen, um Feinden zu entkommen?",
  "a": [
   "Krake",
   "Seestern",
   "Seegurke",
   "Seepferdchen"
  ]
 },
 "q1792": {
  "q": "Welches Reptil kann seine Hautfarbe wechseln und seine beiden Augen unabhängig voneinander bewegen?",
  "a": [
   "Chamäleon",
   "Krokodil",
   "Komodowaran",
   "Landschildkröte"
  ]
 },
 "q1793": {
  "q": "Welches australische eierlegende Säugetier hat einen entenähnlichen Schnabel und Schwimmhäute?",
  "a": [
   "Schnabeltier",
   "Wombat",
   "Koala",
   "Beutelteufel"
  ]
 },
 "q1794": {
  "q": "Bei welchem Meeresfisch tragen die Männchen die befruchteten Eier bis zum Schlüpfen in einer Bruttasche?",
  "a": [
   "Seepferdchen",
   "Clownfisch",
   "Kugelfisch",
   "Schwertfisch"
  ]
 },
 "q1795": {
  "q": "Welcher mexikanische Schwanzlurch behält seine äußeren Kiemen ein Leben lang und kann ganze Gliedmaßen nachwachsen lassen?",
  "a": [
   "Axolotl",
   "Schlammteufel",
   "Grottenolm",
   "Feuersalamander"
  ]
 },
 "q1796": {
  "q": "Welches mikroskopisch kleine achtbeinige Tier überlebt in einem Ruhezustand extreme Temperaturen, Vakuum und Strahlung?",
  "a": [
   "Bärtierchen",
   "Rädertierchen",
   "Wasserfloh",
   "Süßwasserpolyp"
  ]
 },
 "q1797": {
  "q": "Welches nahezu haarlose ostafrikanische Nagetier lebt unterirdisch in insektenähnlichen Kolonien mit einer einzigen Königin?",
  "a": [
   "Nacktmull",
   "Sternmull",
   "Taschenratte",
   "Murmeltier"
  ]
 },
 "q1798": {
  "q": "Welcher Meereskrebs schlägt Beute mit Fangbeinen, die wie eine Gewehrkugel beschleunigen und Kavitationsblasen erzeugen?",
  "a": [
   "Fangschreckenkrebs",
   "Knallkrebs",
   "Winkerkrabbe",
   "Pfeilschwanzkrebs"
  ]
 },
 "q1799": {
  "q": "Woraus besteht der lange spiralförmige Stoßzahn eines männlichen Narwals tatsächlich?",
  "a": [
   "Aus einem verlängerten Zahn",
   "Aus einem Nasenhorn",
   "Aus einer umgebildeten Rippe",
   "Aus verhärtetem Knorpel"
  ]
 },
 "q1800": {
  "q": "Welche Nesseltierart (Turritopsis dohrnii) kann sich vom erwachsenen Medusenstadium wieder in einen jungen Polypen zurückverwandeln?",
  "a": [
   "Unsterbliche Qualle",
   "Portugiesische Galeere",
   "Seewespe",
   "Gelbe Haarqualle"
  ]
 },
 "q1801": {
  "q": "Welcher Quastenflosser, der 66 Millionen Jahre als ausgestorben galt, wurde 1938 vor Südafrika lebend wiederentdeckt?",
  "a": [
   "Latimeria",
   "Lungenfisch",
   "Stör",
   "Flösselhecht"
  ]
 },
 "q1802": {
  "q": "Welches nordamerikanische Reptil kann zur Abschreckung von Feinden Blut aus seinen Augenwinkeln spritzen?",
  "a": [
   "Krötenechse",
   "Gila-Krustenechse",
   "Chuckwalla",
   "Schleiche"
  ]
 },
 "q1803": {
  "q": "Bei welchem südamerikanischen Froschlurch sinken die befruchteten Eier in Hauttaschen auf dem Rücken der Mutter ein?",
  "a": [
   "Wabenkröte",
   "Geburtshelferkröte",
   "Glasfrosch",
   "Hornfrosch"
  ]
 },
 "q1804": {
  "q": "Bei welchem großen südamerikanischen Vogel besitzen die Küken an jedem Flügel zwei Krallen zum Klettern im Geäst?",
  "a": [
   "Hoatzin",
   "Kasuar",
   "Schuhschnabel",
   "Sekretär"
  ]
 },
 "q1805": {
  "q": "Welcher Tiefseehai ist das langlebigste bekannte Wirbeltier und kann ein Alter von rund 400 Jahren erreichen?",
  "a": [
   "Grönlandhai",
   "Koboldhai",
   "Kragenhai",
   "Riesenmaulhai"
  ]
 },
 "q1806": {
  "q": "Welches ostafrikanische Nagetier kaut giftige Acokanthera-Rinde und reibt das Toxin zur Abwehr ins eigene Fell?",
  "a": [
   "Mähnenratte",
   "Riesenhamsterratte",
   "Springhase",
   "Rohrratte"
  ]
 },
 "q1807": {
  "q": "Welche Tiefseeschnecke bildet an ihrem Fuß mit Eisensulfiden verstärkte Panzerschuppen nahe hydrothermalen Quellen?",
  "a": [
   "Schuppenfuß-Schnecke",
   "Kegelschnecke",
   "Perlboot",
   "Seeengel"
  ]
 },
 "q1808": {
  "q": "Welches Insekt schmeckt Nahrung mithilfe von Chemorezeptoren an seinen Füßen?",
  "a": [
   "Schmetterling",
   "Gottesanbeterin",
   "Libelle",
   "Stabschrecke"
  ]
 },
 "q1809": {
  "q": "Welches australische Beuteltier hat Fingerabdrücke, die von menschlichen kaum zu unterscheiden sind?",
  "a": [
   "Koala",
   "Schnabeltier",
   "Ameisenigel",
   "Quokka"
  ]
 },
 "q1810": {
  "q": "Welcher südamerikanische Süßwasserfisch kann Stromstöße von über 600 Volt erzeugen, um Beute zu betäuben?",
  "a": [
   "Zitteraal",
   "Piranha",
   "Arapaima",
   "Pacu"
  ]
 },
 "q1811": {
  "q": "Welcher große flugunfähige australische Vogel besitzt an der inneren Zehe eine dolchartige Kralle für tödliche Tritte?",
  "a": [
   "Kasuar",
   "Emu",
   "Jägerliest",
   "Leierschwanz"
  ]
 },
 "q1812": {
  "q": "Welche Kopffüßerart (Thaumoctopus mimicus) ahmt Seeschlangen, Rotfeuerfische und Plattfische nach, um Feinde abzuschrecken?",
  "a": [
   "Mimik-Oktopus",
   "Blaugeringelter Krake",
   "Dumbo-Oktopus",
   "Vampirtintenfisch"
  ]
 },
 "q1813": {
  "q": "Welcher nachtaktive Primat aus Madagaskar nutzt einen stark verlängerten Mittelfinger, um Holz abzuklopfen und Larven herauszuziehen?",
  "a": [
   "Fingertier",
   "Koboldmaki",
   "Plumplori",
   "Galago"
  ]
 },
 "q1814": {
  "q": "Welches in Afrika und Asien heimische Schuppentier rollt sich bei Gefahr zu einer festen Kugel mit Keratinschuppen zusammen?",
  "a": [
   "Pangolin",
   "Gürteltier",
   "Ameisenigel",
   "Erdferkel"
  ]
 },
 "q1815": {
  "q": "Welcher große Stelzvogel ostafrikanischer Sümpfe besitzt einen massiven schuhförmigen Schnabel und steht stundenlang regungslos?",
  "a": [
   "Schuhschnabel",
   "Marabu",
   "Kanadareiher",
   "Löffler"
  ]
 },
 "q1816": {
  "q": "Welche nordamerikanische Maulwurfsart besitzt 22 fleischige rosa Tentakel an der Schnauze als hochempfindliches Tastorgan?",
  "a": [
   "Sternmull",
   "Goldmull",
   "Desman",
   "Spitzmausmaulwurf"
  ]
 },
 "q1817": {
  "q": "Welcher Tiefsee-Kopffüßer hat einen gallertartigen Körper, riesige Augen und stülpt sich bei Gefahr mit Stacheln nach außen?",
  "a": [
   "Vampirtintenfisch",
   "Koloss-Kalmar",
   "Sepia",
   "Papierboot"
  ]
 },
 "q1818": {
  "q": "Welches arktische Nagetier kann seine Körperkerntemperatur im Winterschlaf unter den Gefrierpunkt auf etwa -2,9 °C absenken?",
  "a": [
   "Arktischer Ziesel",
   "Halsbandlemming",
   "Schneehase",
   "Murmeltier"
  ]
 },
 "q1819": {
  "q": "Welcher Tiefseefisch besitzt eine durchsichtige, flüssigkeitsgefüllte Kopfkuppel, durch die seine Röhrenaugen nach oben blicken?",
  "a": [
   "Gespensterfisch",
   "Anglerfisch",
   "Vipernfisch",
   "Riemenfisch"
  ]
 },
 "q1820": {
  "q": "Welches große Landtier hat so gebaute Beine, dass es nicht mit allen vier Füßen gleichzeitig vom Boden abspringen kann?",
  "a": [
   "Elefant",
   "Nashorn",
   "Flusspferd",
   "Giraffe"
  ]
 },
 "q1821": {
  "q": "Welches große Meeressäugetier schläft senkrecht treibend dicht unter der Meeresoberfläche?",
  "a": [
   "Pottwal",
   "Seeotter",
   "Seekuh",
   "Walross"
  ]
 },
 "q1822": {
  "q": "Welches große arktische Säugetier hat keine oberen Schneidezähne und drückt Nahrung gegen eine Kauplatte am Oberkiefer?",
  "a": [
   "Moschusochse",
   "Eisbär",
   "Walross",
   "Narwal"
  ]
 },
 "q1823": {
  "q": "Welcher gleitfähige Froschlurch Südostasiens nutzt riesige Schwimmhäute und Hautlappen zum Steuern durch das Blätterdach?",
  "a": [
   "Wallace-Flugfrosch",
   "Pfeilgiftfrosch",
   "Goliathfrosch",
   "Axolotl"
  ]
 },
 "q1824": {
  "q": "Bei welchem indonesischen Wildschwein wachsen die oberen Eckzähne durch die Schnauzenhaut nach oben Richtung Stirn?",
  "a": [
   "Hirscheber",
   "Warzenschwein",
   "Pekari",
   "Pinselohrschwein"
  ]
 },
 "q1825": {
  "q": "Welches Instrument ist traditionell das Leitinstrument von Roma-Kapellen in Ungarn und Rumänien?",
  "a": [
   "Geige",
   "Harfe",
   "Banjo",
   "Kirchenorgel"
  ]
 },
 "q1826": {
  "q": "Sprachwissenschaftliche Erkenntnisse zeigen, dass die ursprüngliche Heimat der Roma in welcher Region liegt?",
  "a": [
   "Nordindien",
   "Zentralasien",
   "Der Balkan",
   "Anatolien"
  ]
 },
 "q1827": {
  "q": "Welcher Begriff bezeichnet im traditionellen sozialen Gesetz und Brauchtum der Roma das System moralischer Regeln und Reinheitsvorstellungen?",
  "a": [
   "Romaniya",
   "Banya",
   "Kumpanya",
   "Chavale"
  ]
 },
 "q1828": {
  "q": "Welcher Begriff bezeichnet in den traditionellen Bräuchen der Roma das Konzept ritueller Unreinheit oder Entweihung?",
  "a": [
   "Marime",
   "Phral",
   "Gadjo",
   "Kalo"
  ]
 },
 "q1829": {
  "q": "Welche andalusische Musik- und Tanzkunstform in Spanien wurde maßgeblich von den Gitanos (spanischen Roma) geprägt?",
  "a": [
   "Flamenco",
   "Sardana",
   "Jota",
   "Fado"
  ]
 },
 "q1830": {
  "q": "Wie nennt man in der spanischen Flamenco-Tradition ein lebhaftes, festliches Beisammensein mit Gesang, Händeklatschen und Tanz?",
  "a": [
   "Juerga",
   "Corrida",
   "Romería",
   "Tertulia"
  ]
 },
 "q1831": {
  "q": "Welcher Begriff bezeichnet in traditionellen Roma-Gemeinschaften einen Ältesten oder Rat von Ältesten, der Streitigkeiten schlichtet und Bräuche wahrt?",
  "a": [
   "Kris",
   "Voivode",
   "Kaftan",
   "Saraf"
  ]
 },
 "q1832": {
  "q": "Welchem Rechtsstatus waren die meisten Roma in den mittelalterlichen Fürstentümern Walachei und Moldau über Jahrhunderte bis zur Befreiung im 19. Jahrhundert unterworfen?",
  "a": [
   "Sklaverei",
   "Feudales Rittertum",
   "Zunftbürgerschaft",
   "Klösterliche Befreiung"
  ]
 },
 "q1833": {
  "q": "Welches traditionelle Handwerk, das eng mit Roma-Handwerkern verbunden ist, umfasst das Formen von heißem Eisen und Metall zu Werkzeugen, Hufeisen und Zierarbeiten?",
  "a": [
   "Schmiedekunst",
   "Glasbläserei",
   "Porzellanmalerei",
   "Uhrmacherei"
  ]
 },
 "q1834": {
  "q": "Welche von Jarko Jovanović komponierte Roma-Hymne ist weithin als internationale Hymne der Roma anerkannt?",
  "a": [
   "Gelem, Gelem",
   "O Sole Mio",
   "Bella Ciao",
   "Greensleeves"
  ]
 },
 "q1835": {
  "q": "Welches Symbol erscheint auf der 1971 angenommenen internationalen Roma-Flagge in der Mitte über den blauen und grünen Streifen?",
  "a": [
   "Ein rotes Chakra-Rad",
   "Ein goldener Halbmond",
   "Eine weiße Taube",
   "Ein silberner Anker"
  ]
 },
 "q1836": {
  "q": "Was symbolisieren die grüne und die blaue Hälfte auf der 1971 angenommenen internationalen Roma-Flagge?",
  "a": [
   "Erde und Himmel",
   "Wälder und Flüsse",
   "Frühling und Winter",
   "Land und Meer"
  ]
 },
 "q1837": {
  "q": "In welcher britischen Stadt fand 1971 der erste Welt-Roma-Kongress statt?",
  "a": [
   "London",
   "Manchester",
   "Edinburgh",
   "Bristol"
  ]
 },
 "q1838": {
  "q": "Welche historische Tragödie während des Zweiten Weltkriegs wird mit dem Roma-Begriff Porajmos (auch Samudaripen genannt) erinnert?",
  "a": [
   "Der nationalsozialistische Völkermord an den Roma",
   "Die Teilung Bengalens",
   "Die Belagerung von Wien",
   "Die Hungersnot auf dem Balkan"
  ]
 },
 "q1839": {
  "q": "Welcher ungarische Komponist und Pianist schrieb die neunzehn Ungarischen Rhapsodien, die stark von der Musik der Roma inspiriert sind?",
  "a": [
   "Franz Liszt",
   "Béla Bartók",
   "Zoltán Kodály",
   "György Ligeti"
  ]
 },
 "q1840": {
  "q": "Wie heißt das 1931 in Moskau gegründete erste und älteste ständige professionelle Roma-Theater der Welt?",
  "a": [
   "Romen-Theater",
   "Teatro Gitano",
   "Kalo-Bühne",
   "Balkan-Vorhang"
  ]
 },
 "q1841": {
  "q": "Welcher Roma-Dichter und Bürgerrechtler aus der Slowakei schrieb das bekannte Gedicht „Opre Roma“?",
  "a": [
   "Jozef Ravasz",
   "Matei Vișniec",
   "Bronisława Wajs",
   "Rajko Đurić"
  ]
 },
 "q1842": {
  "q": "Unter welchem Roma-Dichternamen war die polnische Roma-Dichterin Bronisława Wajs weithin bekannt?",
  "a": [
   "Papusza",
   "Nadia",
   "Zaira",
   "Esmeralda"
  ]
 },
 "q1843": {
  "q": "Welcher französische Jazzgitarrist mit Manouche-Herkunft (Roma) gründete zusammen mit dem Geiger Stéphane Grappelli das Quintette du Hot Club de France?",
  "a": [
   "Django Reinhardt",
   "Bireli Lagrène",
   "Angelo Debarre",
   "Stochelo Rosenberg"
  ]
 },
 "q1844": {
  "q": "Welcher Begriff bezeichnet in der traditionellen Folklore und im Glauben der Roma eine Person, der übernatürliche Einsicht, Wahrsagekunst oder spirituelle Kraft zugeschrieben wird?",
  "a": [
   "Drabarni",
   "Khar",
   "Vesh",
   "Kher"
  ]
 },
 "q1845": {
  "q": "In welchem Monat wird jedes Jahr weltweit der Internationale Roma-Tag begangen?",
  "a": [
   "April",
   "Januar",
   "Juli",
   "November"
  ]
 },
 "q1846": {
  "q": "Welcher symbolische Gegenstand wird bei traditionellen Roma-Hochzeiten in vielen Gemeinschaften zerbrochen, um Bund und Glück des Paares zu markieren?",
  "a": [
   "Ein Tongefäß oder Teller",
   "Ein silberner Kompass",
   "Eine Messingglocke",
   "Ein Holzruder"
  ]
 },
 "q1847": {
  "q": "Welcher deutsche Erfinder meldete 1886 das erste praxistaugliche Automobil mit Benzinmotor zum Patent an?",
  "a": [
   "Carl Benz",
   "Gottlieb Daimler",
   "Rudolf Diesel",
   "Ferdinand Porsche"
  ]
 },
 "q1848": {
  "q": "Wer unternahm im August 1888 die erste Überlandfahrt der Welt mit einem Automobil über rund 106 km von Mannheim nach Pforzheim?",
  "a": [
   "Bertha Benz",
   "Marie Curie",
   "Amelia Earhart",
   "Clara Ford"
  ]
 },
 "q1849": {
  "q": "Welche Art von Fahrzeugen stellte das italienische Unternehmen Lamborghini ursprünglich her, bevor es 1963 in den Sportwagenmarkt eintrat?",
  "a": [
   "Traktoren",
   "Motorräder",
   "Flugzeuge",
   "Fahrräder"
  ]
 },
 "q1850": {
  "q": "Welcher Automobilhersteller führte 1959 den modernen Dreipunkt-Sicherheitsgurt ein und gab das Patent kostenlos für alle Hersteller frei?",
  "a": [
   "Volvo",
   "Mercedes-Benz",
   "Saab",
   "Ford"
  ]
 },
 "q1851": {
  "q": "Wem wurde 1903 das erste US-Patent für einen praxistauglichen, vom Fahrzeuginnenraum aus bedienbaren Scheibenwischer erteilt?",
  "a": [
   "Mary Anderson",
   "Hedy Lamarr",
   "Stephanie Kwolek",
   "Margaret Knight"
  ]
 },
 "q1852": {
  "q": "Welcher amerikanische Erfinder, der im Alter von fünf Jahren vollständig erblindete, erfand in den 1940er-Jahren den modernen Tempomaten für Autos?",
  "a": [
   "Ralph Teetor",
   "Charles Kettering",
   "Henry Leland",
   "Ransom Olds"
  ]
 },
 "q1853": {
  "q": "Mit welcher Geschwindigkeit in Meilen pro Stunde wurde Walter Arnold im Januar 1896 in Kent, England, erwischt, als er den ersten Strafzettel der Welt wegen Geschwindigkeitsüberschreitung erhielt?",
  "a": [
   "8 mph",
   "25 mph",
   "40 mph",
   "55 mph"
  ]
 },
 "q1854": {
  "q": "Welches 1966 eingeführte Automodell hält mit über 50 Millionen verkauften Exemplaren den Rekord als meistverkaufte Modellreihe der Automobilgeschichte?",
  "a": [
   "Toyota Corolla",
   "Volkswagen Beetle",
   "Ford Model T",
   "Honda Civic"
  ]
 },
 "q1855": {
  "q": "Welcher französische Autohersteller zwang Porsche 1963 dazu, seinen Sportwagen von 901 in 911 umzubenennen, weil er Markenrechte an dreistelligen Zahlen mit einer Null in der Mitte hielt?",
  "a": [
   "Peugeot",
   "Renault",
   "Citroën",
   "Bugatti"
  ]
 },
 "q1856": {
  "q": "Das Emblem mit dem sich aufbäumenden Pferd von Ferrari war ursprünglich auf das Jagdflugzeug aus dem Ersten Weltkrieg welches italienischen Fliegerasses gemalt?",
  "a": [
   "Francesco Baracca",
   "Gabriele D'Annunzio",
   "Italo Balbo",
   "Umberto Nobile"
  ]
 },
 "q1857": {
  "q": "Welcher englische Bildhauer schuf die Kühlerfigur Spirit of Ecstasy, die auf Fahrzeugen von Rolls-Royce verwendet wird?",
  "a": [
   "Charles Robinson Sykes",
   "Henry Moore",
   "Jacob Epstein",
   "Eric Gill"
  ]
 },
 "q1858": {
  "q": "Welcher Verbrennungsmotortyp, der unter anderem in Mazda-Sportwagen wie dem RX-7 bekannt wurde, verwendet einen dreieckigen Kreiskolben anstelle von Hubkolben?",
  "a": [
   "Wankelmotor",
   "Stirlingmotor",
   "Atkinson-Motor",
   "Dieselmotor"
  ]
 },
 "q1859": {
  "q": "Welcher japanische Autohersteller gewann 1991 die 24 Stunden von Le Mans mit dem 787B, dem einzigen Fahrzeug mit Kreiskolbenmotor, das je den Gesamtsieg holte?",
  "a": [
   "Mazda",
   "Toyota",
   "Nissan",
   "Honda"
  ]
 },
 "q1860": {
  "q": "Welcher südostasiatische Monarch besitzt die größte private Autosammlung der Welt, die auf rund 7.000 Fahrzeuge geschätzt wird?",
  "a": [
   "Sultan von Brunei",
   "König von Thailand",
   "Sultan von Oman",
   "König von Malaysia"
  ]
 },
 "q1861": {
  "q": "Welche schwedische Automarke stellte das Coupé 1800S von 1966 her, mit dem Irv Gordon als Erstbesitzer rekordverdächtige 3,26 Millionen Meilen zurücklegte?",
  "a": [
   "Volvo",
   "Saab",
   "Koenigsegg",
   "Polestar"
  ]
 },
 "q1862": {
  "q": "Welcher Automobilingenieur entwarf in den 1930er-Jahren in Deutschland den ursprünglichen Volkswagen Käfer?",
  "a": [
   "Ferdinand Porsche",
   "Carl Benz",
   "Gottlieb Daimler",
   "Adam Opel"
  ]
 },
 "q1863": {
  "q": "Laut Henry Fords berühmtem Ausspruch über das Model T konnten Kunden ein Auto in jeder beliebigen Farbe haben, solange es welche Farbe war?",
  "a": [
   "Schwarz",
   "Weiß",
   "Dunkelblau",
   "Silber"
  ]
 },
 "q1864": {
  "q": "Welcher italienische Automobildesigner entwarf bei Bertone sowohl den Mittelmotor-Sportwagen Lamborghini Miura als auch den keilförmigen Lamborghini Countach?",
  "a": [
   "Marcello Gandini",
   "Giorgetto Giugiaro",
   "Battista Farina",
   "Sergio Scaglietti"
  ]
 },
 "q1865": {
  "q": "Welcher amerikanische Ingenieur entwickelte den elektrischen Anlasser für Automobile, der 1912 erstmals in Cadillac-Fahrzeugen eingeführt wurde?",
  "a": [
   "Charles Kettering",
   "Lee De Forest",
   "Nikola Tesla",
   "George Westinghouse"
  ]
 },
 "q1866": {
  "q": "Der italienische Supersportwagenhersteller Pagani benennt seine Modelle wie den Zonda und den Huayra nach welchem Naturphänomen?",
  "a": [
   "Winde",
   "Vulkane",
   "Sternbilder",
   "Meeresströmungen"
  ]
 },
 "q1867": {
  "q": "Auf welchen musikalischen Ton sind die meisten herkömmlichen Autohupen gestimmt?",
  "a": [
   "F",
   "C",
   "A",
   "G"
  ]
 },
 "q1868": {
  "q": "Welche Lackfarbe wurde laut der Rennlegende von Mercedes-Benz 1934 von den W25-Rennwagen abgekratzt, um ein Gewichtslimit einzuhalten, wodurch die Silberpfeile entstanden?",
  "a": [
   "Weiß",
   "Rot",
   "Blau",
   "Grün"
  ]
 },
 "q1869": {
  "q": "Welche amerikanische Automarke stellte 1938 mit dem von Harley Earl entworfenen Y-Job das erste praxistaugliche Konzeptfahrzeug vor?",
  "a": [
   "Buick",
   "Cadillac",
   "Lincoln",
   "Packard"
  ]
 },
 "q1870": {
  "q": "Welcher in Ungarn geborene Daimler-Benz-Ingenieur leistete in den 1950er-Jahren Pionierarbeit bei Knautschzonen und der gestaltfesten Fahrgastzelle?",
  "a": [
   "Béla Barényi",
   "János Csonka",
   "Donát Bánki",
   "Ottó Bláthy"
  ]
 },
 "q1871": {
  "q": "Welcher amerikanische Automobilpionier führte 1901 ein stationäres Fließband zur Massenproduktion des Curved Dash ein, noch vor Henry Fords laufendem Band?",
  "a": [
   "Ransom E. Olds",
   "Walter Chrysler",
   "David Dunbar Buick",
   "William C. Durant"
  ]
 },
 "q1872": {
  "q": "In welchem Jahr baute der französische Erfinder Nicolas-Joseph Cugnot seinen dampfbetriebenen Artillerieschlepper, der als erstes vollwertiges selbstfahrendes mechanisches Fahrzeug der Welt gilt?",
  "a": [
   "1769",
   "1804",
   "1825",
   "1852"
  ]
 },
 "q1873": {
  "q": "Welcher amerikanische Erfinder ließ 1967 den Intervall-Scheibenwischer patentieren und erstritt später hohe Schadensersatzzahlungen wegen Patentverletzung gegen Ford und Chrysler?",
  "a": [
   "Robert Kearns",
   "Mary Anderson",
   "William Folberth",
   "Ralph Teetor"
  ]
 },
 "q1874": {
  "q": "Wie viele Exemplare des ultraluxuriösen Bugatti Royale (Type 41) wurden zwischen 1927 und 1933 gebaut?",
  "a": [
   "7",
   "3",
   "15",
   "25"
  ]
 },
 "q1875": {
  "q": "Welcher britische Ingenieur ließ 1902 die Scheibenbremse für Automobile patentieren, Jahrzehnte bevor sie zur Serienausstattung von Pkw wurde?",
  "a": [
   "Frederick Lanchester",
   "Herbert Austin",
   "William Morris",
   "Henry Royce"
  ]
 },
 "q1876": {
  "q": "In welcher deutschen Apotheke hielt Bertha Benz auf ihrer Fahrt 1888 an, um Ligroin als Kraftstoff zu kaufen, wodurch sie zur ersten Tankstelle der Welt wurde?",
  "a": [
   "Stadt-Apotheke Wiesloch",
   "Löwen-Apotheke Heidelberg",
   "Hof-Apotheke Mannheim",
   "Alte Apotheke Pforzheim"
  ]
 },
 "q1877": {
  "q": "Welcher tschechoslowakische Autohersteller verklagte Volkswagen wegen Designähnlichkeiten zwischen seinen Heckmotorwagen der 1930er-Jahre und dem Käfer und erhielt 1965 eine Abfindung von 1 Million D-Mark?",
  "a": [
   "Tatra",
   "Škoda",
   "Praga",
   "Aero"
  ]
 },
 "q1878": {
  "q": "Welcher deutsche Autohersteller baute 1964 den Wankel-Spider, das weltweit erste Serienauto mit einem Wankel-Kreiskolbenmotor?",
  "a": [
   "NSU",
   "Mazda",
   "Audi",
   "Borgward"
  ]
 },
 "q1879": {
  "q": "In welchem Jahr überschritt das belgische Elektroauto La Jamais Contente als erstes Automobil die Marke von 100 km/h?",
  "a": [
   "1899",
   "1908",
   "1921",
   "1875"
  ]
 },
 "q1880": {
  "q": "Welches System in einem Elektroauto wandelt beim Verzögern kinetische Energie wieder in Strom zum Laden der Batterie um?",
  "a": [
   "Rekuperationsbremse",
   "Turboaufladung",
   "Kraftstoffeinspritzung",
   "Katalytische Umwandlung"
  ]
 },
 "q1881": {
  "q": "Welches europäische Land ist weltweit führend bei der Verbreitung von Elektroautos, mit über 95 Prozent rein elektrischen Neuwagen?",
  "a": [
   "Norwegen",
   "Spanien",
   "Polen",
   "Griechenland"
  ]
 },
 "q1882": {
  "q": "Welche Antriebsart nutzte der 1898 gebaute Egger-Lohner C.2 Phaeton, das erste von Ferdinand Porsche konstruierte Fahrzeug?",
  "a": [
   "Einen Elektromotor",
   "Einen Dieselmotor",
   "Einen Dampfkessel",
   "Eine Gasturbine"
  ]
 },
 "q1883": {
  "q": "Welche Standard-Energieeinheit wird verwendet, um die Speicherkapazität der Batterie eines Elektroautos anzugeben?",
  "a": [
   "Kilowattstunde",
   "Newtonmeter",
   "Hertz",
   "Lumen"
  ]
 },
 "q1884": {
  "q": "Welche beiden teuren Metalle fehlen in Lithium-Eisenphosphat-Batterien (LFP) für Elektroautos vollständig?",
  "a": [
   "Nickel und Kobalt",
   "Eisen und Phosphor",
   "Lithium und Kohlenstoff",
   "Kupfer und Aluminium"
  ]
 },
 "q1885": {
  "q": "Welches Elektro-Sportwagenmodell wurde im Februar 2018 an Bord einer SpaceX-Falcon-Heavy-Rakete in eine Sonnenumlaufbahn geschossen?",
  "a": [
   "Tesla Roadster",
   "Nissan Leaf",
   "Porsche Taycan",
   "Rimac Nevera"
  ]
 },
 "q1886": {
  "q": "Welcher japanische Autohersteller brachte 2010 den Leaf als weltweit ersten vollelektrischen Kompaktwagen für den Massenmarkt heraus?",
  "a": [
   "Nissan",
   "Subaru",
   "Mazda",
   "Suzuki"
  ]
 },
 "q1887": {
  "q": "Das Aluminium-Chassis welches britischen Sportwagens diente als strukturelle Basis für den ersten Tesla Roadster von 2008?",
  "a": [
   "Lotus Elise",
   "Aston Martin DB9",
   "Jaguar XK8",
   "Mini Cooper"
  ]
 },
 "q1888": {
  "q": "Was war das Hauptgeschäft des chinesischen Elektroauto-Riesen BYD, als Wang Chuanfu das Unternehmen 1995 in Shenzhen gründete?",
  "a": [
   "Herstellung wiederaufladbarer Batterien",
   "Bau von Hochgeschwindigkeitszügen",
   "Produktion von Solarmodulen",
   "Montage von Smartphones"
  ]
 },
 "q1889": {
  "q": "Welche Stadt richtete im September 2014 das allererste Meisterschaftsrennen der FIA-Formel-E für vollelektrische Monoposti aus?",
  "a": [
   "Peking",
   "Monaco",
   "London",
   "Tokio"
  ]
 },
 "q1890": {
  "q": "In welchem europäischen Land hat der Elektro-Supersportwagenhersteller Rimac Automobili, Schöpfer des Nevera, seinen Hauptsitz?",
  "a": [
   "Kroatien",
   "Schweden",
   "Italien",
   "Belgien"
  ]
 },
 "q1891": {
  "q": "Wofür steht die Abkürzung V2G bei Elektrofahrzeugen, die gespeicherten Strom wieder in das Stromnetz einspeisen können?",
  "a": [
   "Vehicle-to-grid",
   "Volt-to-generator",
   "Valve-to-gearbox",
   "Vector-to-ground"
  ]
 },
 "q1892": {
  "q": "Welche Komponente ersetzt in einer Festkörperbatterie den flüssigen oder gelförmigen Elektrolyten herkömmlicher Lithium-Ionen-Akkus?",
  "a": [
   "Ein festes Elektrolytmaterial",
   "Komprimiertes Wasserstoffgas",
   "Flüssiger Stickstoff",
   "Destilliertes Wasser"
  ]
 },
 "q1893": {
  "q": "Warum sind moderne Elektroautos in vielen Regionen gesetzlich verpflichtet, bei niedrigen Geschwindigkeiten ein künstliches Geräusch zu erzeugen?",
  "a": [
   "Um Fußgänger und Sehbehinderte zu warnen",
   "Um den Elektromotor zu kühlen",
   "Um statische Elektrizität abzuleiten",
   "Um das Navigations-GPS zu kalibrieren"
  ]
 },
 "q1894": {
  "q": "Welche Art von elektrischem Strom speichern Batterien und liefern Ultraschnellladestationen direkt an den Akku eines Elektroautos?",
  "a": [
   "Gleichstrom",
   "Wechselstrom",
   "Drehstrom",
   "Wirbelstrom"
  ]
 },
 "q1895": {
  "q": "Wie viele Vorwärtsgänge hat das Getriebe fast jedes modernen batterieelektrischen Pkw?",
  "a": [
   "Einen",
   "Fünf",
   "Sechs",
   "Acht"
  ]
 },
 "q1896": {
  "q": "Welcher französische Physiker erfand 1859 den wiederaufladbaren Bleiakkumulator und ermöglichte damit frühe Elektrofahrzeuge?",
  "a": [
   "Gaston Planté",
   "André-Marie Ampère",
   "Charles-Augustin de Coulomb",
   "Henri Becquerel"
  ]
 },
 "q1897": {
  "q": "Wofür steht die Abkürzung CCS beim in Europa und Nordamerika weit verbreiteten Schnellladestecker-Standard für Elektroautos?",
  "a": [
   "Combined Charging System",
   "Current Control Socket",
   "Central Cable Station",
   "Capacitor Cell Supply"
  ]
 },
 "q1898": {
  "q": "Welcher US-Autohersteller verleaste von 1996 bis 1999 das aerodynamische Elektro-Coupé EV1 an Fahrer in Kalifornien und Arizona?",
  "a": [
   "General Motors",
   "Chrysler",
   "American Motors",
   "Studebaker"
  ]
 },
 "q1899": {
  "q": "Welches elektronische Bauteil wandelt in einem Elektroauto den Gleichstrom der Batterie in Wechselstrom für den Antriebsmotor um?",
  "a": [
   "Wechselrichter",
   "Vergaser",
   "Lichtmaschine",
   "Zündverteiler"
  ]
 },
 "q1900": {
  "q": "Wie hoch war die ungefähre Höchstgeschwindigkeit des batteriebetriebenen Lunar Roving Vehicle, das Apollo-Astronauten auf dem Mond fuhren?",
  "a": [
   "13 km/h",
   "65 km/h",
   "110 km/h",
   "180 km/h"
  ]
 },
 "q1901": {
  "q": "Wie lautet der aus dem Englischen stammende Begriff für den vorderen Kofferraum vieler Elektroautos anstelle des Verbrennungsmotors?",
  "a": [
   "Frunk",
   "Crankcase",
   "Sump",
   "Manifold"
  ]
 },
 "q1902": {
  "q": "Welche Erfindung von Charles Kettering aus dem Jahr 1912 ersetzte die Handkurbel bei Benzinautos und trug zum Niedergang früher Elektroautos bei?",
  "a": [
   "Der elektrische Anlasser",
   "Der Scheibenwischer",
   "Der Luftreifen",
   "Der Rückspiegel"
  ]
 },
 "q1903": {
  "q": "Welches effiziente Heizsystem überträgt Umgebungswärme in den Innenraum eines Elektroautos und verbraucht dabei deutlich weniger Batteriestrom?",
  "a": [
   "Wärmepumpe",
   "Kühlerkern",
   "Nachbrenner",
   "Glühkerze"
  ]
 },
 "q1904": {
  "q": "In welchem Land wurde der Gleichstrom-Schnellladestandard CHAdeMO für Elektrofahrzeuge ursprünglich entwickelt?",
  "a": [
   "Japan",
   "Deutschland",
   "Südkorea",
   "Vereinigtes Königreich"
  ]
 },
 "q1905": {
  "q": "Welches leichte Alkalimetall gibt der vorherrschenden wiederaufladbaren Batterietechnologie in modernen Elektroautos seinen Namen?",
  "a": [
   "Lithium",
   "Natrium",
   "Kalium",
   "Cäsium"
  ]
 },
 "q1906": {
  "q": "Welcher deutsche Luxus-Sportwagen führte 2019 als erstes Serien-Elektroauto eine 800-Volt-Systemarchitektur ein?",
  "a": [
   "Porsche Taycan",
   "BMW i3",
   "Volkswagen e-Golf",
   "Smart Fortwo EQ"
  ]
 },
 "q1907": {
  "q": "Warum liefern Elektromotoren im Gegensatz zu Verbrennungsmotoren schon ab null Umdrehungen pro Minute ihr maximales Drehmoment?",
  "a": [
   "Elektromagnetische Kraft wirkt sofort ohne Drehzahlaufbau",
   "Sie nutzen hydraulische Drehmomentwandler",
   "Sie verbrennen im Stand schneller Kraftstoff",
   "Ihre Kolben haben kürzere Hübe"
  ]
 },
 "q1908": {
  "q": "Wofür steht die Abkürzung NACS beim ursprünglich von Tesla entwickelten Ladestecker-Standard für Elektrofahrzeuge?",
  "a": [
   "North American Charging Standard",
   "National Alternating Current System",
   "New Automotive Cable Socket",
   "Neutral Anode Cell Supply"
  ]
 },
 "q1909": {
  "q": "Wo wird das schwere Batteriepaket in einem speziell entwickelten modernen Elektroauto meist eingebaut, um den Schwerpunkt zu senken?",
  "a": [
   "Flach unter dem Kabinenboden",
   "Auf dem Dachblech",
   "In der vorderen Stoßstange",
   "Hinter der Heckscheibe"
  ]
 },
 "q1910": {
  "q": "Welche Fahrfunktion vieler Elektroautos ermöglicht das Beschleunigen und Abbremsen bis zum Stillstand allein mit dem Fahrpedal?",
  "a": [
   "One-Pedal-Driving",
   "Launch Control",
   "Kriechtempomat",
   "Bergabfahrhilfe"
  ]
 },
 "q1911": {
  "q": "Warum sinkt die Reichweite eines Elektroautos bei eisigem Winterwetter spürbar?",
  "a": [
   "Kälte verlangsamt die Zellchemie und die Heizung verbraucht Strom",
   "Elektromotoren frieren unter null Grad fest",
   "Reifen dehnen sich aus und verdoppeln ihr Gewicht",
   "Kalte Luft erhöht die Batteriespannung"
  ]
 },
 "q1912": {
  "q": "Wofür steht die Abkürzung WLTP beim in Europa verwendeten Prüfverfahren zur Ermittlung der Reichweite von Elektroautos?",
  "a": [
   "Worldwide Harmonised Light Vehicles Test Procedure",
   "Western Lithium Traction Protocol",
   "Wireless Low-Tension Power",
   "Wheel Load Torque Performance"
  ]
 },
 "q1913": {
  "q": "Wofür steht der englische Name des chinesischen Elektroautoherstellers BYD?",
  "a": [
   "Build Your Dreams",
   "Beyond Your Drive",
   "Battery Yield Design",
   "Bright Youth Dynamics"
  ]
 },
 "q1914": {
  "q": "Welche standardmäßige 12-Volt-Komponente, die noch in fast jedem Elektroauto steckt, versorgt Türschlösser, Bildschirme und Sicherheitsrechner?",
  "a": [
   "Eine Niedervolt-Hilfsbatterie",
   "Ein Wasserstoff-Brennstoffzellenstapel",
   "Ein mechanisches Schwungrad",
   "Ein Solardachmodul"
  ]
 },
 "q1915": {
  "q": "Welche Standard-Einheit der elektrischen Leistung gibt die maximale Ladegeschwindigkeit einer Schnellladestation an?",
  "a": [
   "Kilowatt",
   "Kilovoltamperestunde",
   "Ohm",
   "Tesla"
  ]
 },
 "q1916": {
  "q": "Welche elektrische Luxuslimousine stellte im Juli 2025 mit 1.205 Kilometern mit einer einzigen Akkuladung einen Guinness-Weltrekord auf?",
  "a": [
   "Lucid Air Grand Touring",
   "Mini Cooper SE",
   "Fiat 500e",
   "Renault Zoe"
  ]
 },
 "q1917": {
  "q": "Warum haben batterieelektrische Autos keinen Auspuff?",
  "a": [
   "Ihre Elektromotoren verbrennen keinen Kraftstoff und erzeugen keine Abgase",
   "Abgase werden in den Reifen gespeichert",
   "Das Auspuffrohr ist in der Lenksäule versteckt",
   "Sie stoßen Gase nur beim Laden aus"
  ]
 },
 "q1918": {
  "q": "Warum nutzen Elektrofahrzeuge ihre mechanischen Bremsbeläge deutlich langsamer ab als vergleichbare Benzinautos?",
  "a": [
   "Die Rekuperation übernimmt den Großteil der normalen Verzögerung",
   "Ihre Bremsbeläge bestehen aus massivem Diamant",
   "Sie können oberhalb von 50 km/h nicht bremsen",
   "Airbags verlangsamen das Auto vor den Bremsen"
  ]
 },
 "q1919": {
  "q": "In der Geschichte der Formel 1: In welchem Jahr fand die erste Saison der Weltmeisterschaft statt?",
  "a": [
   "1950",
   "1946",
   "1954",
   "1960"
  ]
 },
 "q1920": {
  "q": "Welcher Fahrer gewann in der Formel-1-Weltmeisterschaft 1950 den ersten Fahrertitel?",
  "a": [
   "Giuseppe Farina",
   "Juan Manuel Fangio",
   "Alberto Ascari",
   "Stirling Moss"
  ]
 },
 "q1921": {
  "q": "Wie viele Fahrerweltmeisterschaften in der Formel 1 gewann Juan Manuel Fangio in den 1950er-Jahren?",
  "a": [
   "5",
   "4",
   "6",
   "3"
  ]
 },
 "q1922": {
  "q": "Welche Rennstrecke war im Mai 1950 Gastgeber des ersten Rennens der Formel-1-Weltmeisterschaft?",
  "a": [
   "Silverstone",
   "Monza",
   "Spa-Francorchamps",
   "Monaco"
  ]
 },
 "q1923": {
  "q": "Welches Formel-1-Team führte 1977 mit dem Lotus 78 die Bodeneffekt-Aerodynamik ein?",
  "a": [
   "Team Lotus",
   "Brabham",
   "Tyrrell",
   "McLaren"
  ]
 },
 "q1924": {
  "q": "Welcher Grand Prix richtete 2008 das erste Nachtrennen der Formel 1 unter Flutlicht aus?",
  "a": [
   "Großer Preis von Singapur",
   "Großer Preis von Bahrain",
   "Großer Preis von Abu Dhabi",
   "Großer Preis von Las Vegas"
  ]
 },
 "q1925": {
  "q": "Welcher Fahrer gewann 2009 mit dem Team Brawn GP den Fahrer- und Konstrukteurstitel?",
  "a": [
   "Jenson Button",
   "Lewis Hamilton",
   "Sebastian Vettel",
   "Kimi Räikkönen"
  ]
 },
 "q1926": {
  "q": "In welcher Formel-1-Saison wurde der Halo-Cockpitschutz verpflichtend?",
  "a": [
   "2018",
   "2016",
   "2020",
   "2021"
  ]
 },
 "q1927": {
  "q": "Welcher Fahrer gewann 1976 den Großen Preis von Monaco für Ferrari von der Pole-Position?",
  "a": [
   "Niki Lauda",
   "James Hunt",
   "Jody Scheckter",
   "Clay Regazzoni"
  ]
 },
 "q1928": {
  "q": "In der Formel-1-Geschichte: Welcher Fahrer sicherte sich 1988 beim Großen Preis von Monaco die Pole-Position vor Alain Prost?",
  "a": [
   "Ayrton Senna",
   "Nigel Mansell",
   "Gerhard Berger",
   "Nelson Piquet"
  ]
 },
 "q1929": {
  "q": "Welcher bulgarisch-amerikanische Physiker baute zwischen 1937 und 1942 am Iowa State College den ersten elektronischen Digitalcomputer?",
  "a": [
   "John Atanasoff",
   "Assen Jordanoff",
   "Peter Petroff",
   "Georgi Nadjakov"
  ]
 },
 "q1930": {
  "q": "Welcher Doktorand unterstützte John Atanasoff am Iowa State College beim Bau des Atanasoff-Berry-Computers?",
  "a": [
   "Clifford Berry",
   "John Mauchly",
   "Presper Eckert",
   "Konrad Zuse"
  ]
 },
 "q1931": {
  "q": "Welcher bulgarische Arzt entdeckte 1905 bei Untersuchungen von Sauermilch in Genf das Bakterium Lactobacillus bulgaricus?",
  "a": [
   "Stamen Grigorow",
   "Iwan Mitew",
   "Dimitar Paskow",
   "Georgi Nadschakow"
  ]
 },
 "q1932": {
  "q": "Welcher in Bulgarien geborene Luftfahrtpionier baute 1915 Bulgariens erstes Motorflugzeug und entwarf später frühe Flugzeug-Airbags?",
  "a": [
   "Assen Jordanoff",
   "Simeon Petrow",
   "Peter Petroff",
   "Rumen Antonow"
  ]
 },
 "q1933": {
  "q": "Welcher in Bulgarien geborene Ingenieur war in den USA an der Entwicklung der ersten digitalen LED-Armbanduhr Pulsar beteiligt?",
  "a": [
   "Peter Petroff",
   "John Atanasoff",
   "Assen Jordanoff",
   "Georgi Nadjakov"
  ]
 },
 "q1934": {
  "q": "Welcher bulgarische Physiker entdeckte 1937 den Photoelektret-Zustand der Materie, eine Grundlage des modernen Fotokopierens?",
  "a": [
   "Georgi Nadschakow",
   "Iwan Stranski",
   "Stamen Grigorow",
   "Dimitar Sasselow"
  ]
 },
 "q1935": {
  "q": "Welcher bulgarische Pharmakologe entwickelte das Medikament Nivalin aus dem Galantamin von Schneeglöckchenzwiebeln?",
  "a": [
   "Dimitar Paskow",
   "Stamen Grigorow",
   "Iwan Mitew",
   "Carl Djerassi"
  ]
 },
 "q1936": {
  "q": "Welcher in Wien und Sofia aufgewachsene Chemiker bulgarisch-österreichischer Herkunft war Miterfinder der ersten Antibabypille?",
  "a": [
   "Carl Djerassi",
   "Dimitar Paskow",
   "Stamen Grigorow",
   "Iwan Stranski"
  ]
 },
 "q1937": {
  "q": "Welcher in Bulgarien geborene Ingenieur wirkte an den Triebwerken der Apollo-Mondlandefähre Eagle mit, die 1969 auf dem Mond landete?",
  "a": [
   "John Nochev",
   "Assen Jordanoff",
   "Peter Petroff",
   "Roumen Antonov"
  ]
 },
 "q1938": {
  "q": "Welcher bulgarische Softwareentwickler war Miterfinder der 3D-Rendering-Software V-Ray und gewann 2017 einen Technik-Oscar?",
  "a": [
   "Wladimir Kojlasow",
   "George Borshukov",
   "John Atanasoff",
   "Blagowest Sendow"
  ]
 },
 "q1939": {
  "q": "Welcher bulgarische Spezialeffekt-Pionier gewann Technik-Oscars für Verfahren, die in den Fortsetzungen von Matrix eingesetzt wurden?",
  "a": [
   "George Borshukov",
   "Wladimir Kojlasow",
   "Peter Petroff",
   "Christo Javacheff"
  ]
 },
 "q1940": {
  "q": "Welcher bulgarische Kinderkardiologe entdeckte Anfang der 1970er-Jahre den sechsten Herzton?",
  "a": [
   "Iwan Mitew",
   "Stamen Grigorow",
   "Dimitar Paskow",
   "Samuel Refetoff"
  ]
 },
 "q1941": {
  "q": "Welcher bulgarische Automobilingenieur erfand ein kompaktes Automatikgetriebe ohne Drehmomentwandler für Kleinwagen?",
  "a": [
   "Rumen Antonow",
   "Assen Jordanoff",
   "Peter Petroff",
   "Simeon Petrow"
  ]
 },
 "q1942": {
  "q": "Welcher bulgarische Physikochemiker begründete die molekular-kinetische Theorie des Kristallwachstums und prägte ein Wachstumsmodell?",
  "a": [
   "Iwan Stranski",
   "Georgi Nadschakow",
   "Dimitar Iwanow",
   "Nikola Obreschkow"
  ]
 },
 "q1943": {
  "q": "Welcher bulgarische Militärflieger konstruierte 1912 die erste speziell entwickelte Fliegerbombe mit Leitwerk und Aufschlagzünder?",
  "a": [
   "Simeon Petrow",
   "Assen Jordanoff",
   "Radul Milkow",
   "Prodan Tarakschiew"
  ]
 },
 "q1944": {
  "q": "Welcher bulgarische Kryobiologe leitete das Team, das in den 1970er-Jahren gefriergetrocknete Weltraumnahrung für Interkosmos entwickelte?",
  "a": [
   "Zwetan Zwetkow",
   "Stamen Grigorow",
   "Georgi Iwanow",
   "Iwan Mitew"
  ]
 },
 "q1945": {
  "q": "Welche bulgarischen Metallurgen erfanden das Gegendruck-Gießverfahren, das weltweit zur Herstellung hochfester Leichtmetallräder dient?",
  "a": [
   "Angel Balewski und Iwan Dimow",
   "Iwan Stranski und Rostislaw Kaischew",
   "John Atanasoff und Clifford Berry",
   "Georgi Nadschakow und Dimitar Paskow"
  ]
 },
 "q1946": {
  "q": "Wie nannte der bulgarisch-amerikanische Erfinder Assen Jordanoff seinen in den 1950er-Jahren entwickelten Anrufbeantworter?",
  "a": [
   "Jordaphone",
   "Bulgarophone",
   "Aviaphone",
   "Petroffone"
  ]
 },
 "q1947": {
  "q": "In welcher Schweizer Stadt studierte der bulgarische Arzt Stamen Grigorow, als er 1905 Lactobacillus bulgaricus identifizierte?",
  "a": [
   "Genf",
   "Zürich",
   "Bern",
   "Basel"
  ]
 },
 "q1948": {
  "q": "Aus welcher Frühlingsblume isolierte der bulgarische Pharmakologe Dimitar Paskow Galantamin für das Medikament Nivalin?",
  "a": [
   "Schneeglöckchen",
   "Krokus",
   "Narzisse",
   "Maiglöckchen"
  ]
 },
 "q1949": {
  "q": "Welches Zahlensystem verwendete John Atanasoff für interne Berechnungen in seinem bahnbrechenden elektronischen Digitalcomputer?",
  "a": [
   "Binärsystem",
   "Dezimalsystem",
   "Oktalsystem",
   "Hexadezimalsystem"
  ]
 },
 "q1950": {
  "q": "Welcher in Bulgarien geborene Harvard-Astronom leitete das Team, das 2002 den fernen Exoplaneten OGLE-TR-56b entdeckte?",
  "a": [
   "Dimitar Sasselow",
   "Nikola Bonew",
   "Georgi Nadschakow",
   "Iwan Stranski"
  ]
 },
 "q1951": {
  "q": "An der Entwicklung welches berühmten zweimotorigen Verkehrsflugzeugs der 1930er-Jahre wirkte Assen Jordanoff bei Douglas mit?",
  "a": [
   "Douglas DC-3",
   "Boeing 707",
   "Lockheed Constellation",
   "Concorde"
  ]
 },
 "q1952": {
  "q": "Für welche frühe NASA-Wettersatellitenserie entwickelte der in Bulgarien geborene Erfinder Peter Petroff Telemetrie-Komponenten?",
  "a": [
   "Nimbus",
   "Voyager",
   "Hubble",
   "Cassini"
  ]
 },
 "q1953": {
  "q": "Welcher bulgarische Psychotherapeut entwickelte die Suggestopädie, eine 1978 der UNESCO vorgestellte Methode zum schnellen Lernen?",
  "a": [
   "Georgi Losanow",
   "Iwan Mitew",
   "Dimitar Paskow",
   "Stamen Grigorow"
  ]
 },
 "q1954": {
  "q": "Welcher bulgarische Organiker entdeckte eine nach ihm benannte Synthesereaktion mit Magnesiumenolaten, die Iwanow-Reaktion?",
  "a": [
   "Dimitar Iwanow",
   "Iwan Stranski",
   "Georgi Nadschakow",
   "Carl Djerassi"
  ]
 },
 "q1955": {
  "q": "Welcher in Bulgarien geborene Endokrinologe entdeckte das nach ihm benannte genetische Syndrom der Schilddrüsenhormonresistenz?",
  "a": [
   "Samuel Refetoff",
   "Iwan Mitew",
   "Stamen Grigorow",
   "Dimitar Paskow"
  ]
 },
 "q1956": {
  "q": "Welches tragbare medizinische Gerät erfand der in Bulgarien geborene Ingenieur Peter Petroff neben der digitalen Armbanduhr?",
  "a": [
   "Kabelloser Herzmonitor",
   "Künstlicher Herzschrittmacher",
   "Insulinpumpe",
   "Cochlea-Implantat"
  ]
 },
 "q1957": {
  "q": "In welchem Jahr entschied ein US-Bundesgericht, dass das ENIAC-Patent auf John Atanasoffs Computererfindung zurückging?",
  "a": [
   "1973",
   "1955",
   "1962",
   "1984"
  ]
 },
 "q1958": {
  "q": "Welche neurodegenerative Erkrankung wird heute weltweit mit Galantamin behandelt, dem von Dimitar Paskow in Nivalin genutzten Wirkstoff?",
  "a": [
   "Alzheimer-Krankheit",
   "Parkinson-Krankheit",
   "Multiple Sklerose",
   "Chorea Huntington"
  ]
 },
 "q1959": {
  "q": "Über welcher Festungsstadt warfen bulgarische Flieger im Oktober 1912 die von Simeon Petrow neu entwickelten Fliegerbomben ab?",
  "a": [
   "Edirne (Odrin)",
   "Thessaloniki",
   "Belgrad",
   "Bukarest"
  ]
 },
 "q1960": {
  "q": "Im Pariser Labor welches französischen Physikers forschte der bulgarische Physiker Georgi Nadschakow 1925–1926 zur Photoelektrizität?",
  "a": [
   "Paul Langevin",
   "Louis de Broglie",
   "Henri Becquerel",
   "Jean Perrin"
  ]
 },
 "q1961": {
  "q": "Welches synthetische Gestagen synthetisierte Carl Djerassi 1951 mit, um die erste Antibabypille zu entwickeln?",
  "a": [
   "Norethisteron",
   "Estradiol",
   "Testosteron",
   "Cortison"
  ]
 },
 "q1962": {
  "q": "Welches Uhrenunternehmen brachte die Pulsar auf den Markt, die erste digitale LED-Armbanduhr von Miterfinder Peter Petroff?",
  "a": [
   "Hamilton Watch Company",
   "Rolex",
   "Omega",
   "Casio"
  ]
 },
 "q1963": {
  "q": "Welches Konservierungsverfahren nutzte der bulgarische Wissenschaftler Zwetan Zwetkow in den 1970er-Jahren für leichte Weltraumnahrung?",
  "a": [
   "Gefriertrocknung (Lyophilisierung)",
   "Einkochen in Dosen",
   "Einsalzen",
   "Einlegen in Essig"
  ]
 },
 "q1964": {
  "q": "Mit welcher Methode entdeckte das Team des bulgarischstämmigen Astronomen Dimitar Sasselow 2002 den Exoplaneten OGLE-TR-56b?",
  "a": [
   "Transitmethode",
   "Direkte Abbildung",
   "Gravitationsmikrolinseneffekt",
   "Pulsar-Timing"
  ]
 },
 "q1965": {
  "q": "Wie hieß die Mondlandefähre von Apollo 11, an deren Triebwerken der in Bulgarien geborene Ingenieur John Nochev mitwirkte?",
  "a": [
   "Eagle",
   "Columbia",
   "Intrepid",
   "Aquarius"
  ]
 },
 "q1966": {
  "q": "Gegen welche lähmende Viruserkrankung wurde Dimitar Paskows Medikament Nivalin Ende der 1950er-Jahre hauptsächlich eingesetzt?",
  "a": [
   "Poliomyelitis (Kinderlähmung)",
   "Tuberkulose",
   "Malaria",
   "Cholera"
  ]
 },
 "q1967": {
  "q": "Welches bulgarische Softwareunternehmen gründeten Wladimir Kojlasow und Peter Mitew zur Entwicklung des Oscar-prämierten Renderers V-Ray?",
  "a": [
   "Chaos Group",
   "Pixar",
   "Autodesk",
   "Epic Games"
  ]
 },
 "q1968": {
  "q": "Welcher Schauspieler lieh Darth Vader in den Filmen der ursprünglichen Star-Wars-Trilogie seine markante tiefe Stimme?",
  "a": [
   "James Earl Jones",
   "David Prowse",
   "Harrison Ford",
   "Alec Guinness"
  ]
 },
 "q1969": {
  "q": "Sagt der Detektiv in Sir Arthur Conan Doyles Sherlock-Holmes-Geschichten jemals genau den Satz „Elementar, mein lieber Watson“?",
  "a": [
   "Nein, nie in den Geschichten",
   "Ja, im ersten Roman",
   "Ja, in der letzten Geschichte",
   "Nur in Briefen an Watson"
  ]
 },
 "q1970": {
  "q": "Welchen Beruf übt der Archäologe und Abenteurer Indiana Jones in der Filmreihe aus, wenn er nicht nach Relikten sucht?",
  "a": [
   "Hochschulprofessor",
   "Museumskurator",
   "Marineoffizier",
   "Zeitungsreporter"
  ]
 },
 "q1971": {
  "q": "Wer wird neben Zeichner Bob Kane offiziell als Mitschöpfer des DC-Comics-Superhelden Batman geführt?",
  "a": [
   "Bill Finger",
   "Jack Kirby",
   "Stan Lee",
   "Jerry Siegel"
  ]
 },
 "q1972": {
  "q": "In welcher Comicheft-Ausgabe hatte der Marvel-Superheld Spider-Man 1962 seinen ersten Auftritt?",
  "a": [
   "Amazing Fantasy #15",
   "Action Comics #1",
   "Detective Comics #27",
   "Fantastic Four #1"
  ]
 },
 "q1973": {
  "q": "In J. R. R. Tolkiens Der Herr der Ringe reist welcher andere Hobbit mit Frodo Beutlin bis zum Schicksalsberg?",
  "a": [
   "Samweis Gamdschie",
   "Peregrin Tuk",
   "Meriadoc Brandybock",
   "Bilbo Beutlin"
  ]
 },
 "q1974": {
  "q": "Welchen regulären Beruf hat Walter White in der Fernsehserie Breaking Bad, bevor er Methamphetamin herstellt?",
  "a": [
   "Chemielehrer an einer Highschool",
   "Besitzer einer Waschanlage",
   "Apotheker",
   "Chemieingenieur"
  ]
 },
 "q1975": {
  "q": "Was für ein Wesen ist Totoro in Hayao Miyazakis Animationsfilm Mein Nachbar Totoro von 1988?",
  "a": [
   "Waldgeist",
   "Riesenmarderhund",
   "Bergtroll",
   "Fliegender Drache"
  ]
 },
 "q1976": {
  "q": "Welches Geschäft baut Forrest im Film Forrest Gump von 1994 mit dem Geld seines verstorbenen Armeefreundes Bubba auf?",
  "a": [
   "Garnelenkutter-Flotte",
   "Schokoladenfabrik",
   "Tischtennis-Akademie",
   "Baumwollplantage"
  ]
 },
 "q1977": {
  "q": "Welchen Beruf übt Dr. Hannibal Lecter in den Romanen von Thomas Harris und deren Verfilmungen vor seiner Inhaftierung aus?",
  "a": [
   "Rechtspsychiater",
   "Neurochirurg",
   "Strafverteidiger",
   "Pathologe"
  ]
 },
 "q1978": {
  "q": "Wer ist in Disneys Animationsfilm Der König der Löwen von 1994 der heimtückische Onkel des jungen Löwen Simba?",
  "a": [
   "Scar",
   "Mufasa",
   "Rafiki",
   "Shenzi"
  ]
 },
 "q1979": {
  "q": "Welche Schauspielerin spielt die Hauptfigur Ellen Ripley im Science-Fiction-Horrorfilm Alien von 1979?",
  "a": [
   "Sigourney Weaver",
   "Jamie Lee Curtis",
   "Linda Hamilton",
   "Carrie Fisher"
  ]
 },
 "q1980": {
  "q": "Wie lautet im Science-Fiction-Film Matrix von 1999 Neos bürgerlicher Name, bevor er aus der Simulation befreit wird?",
  "a": [
   "Thomas Anderson",
   "John Connor",
   "Arthur Pendelton",
   "David Bowman"
  ]
 },
 "q1981": {
  "q": "Unter welchem Namen trat die Nintendo-Figur Mario 1981 erstmals im Arcade-Spiel Donkey Kong auf?",
  "a": [
   "Jumpman",
   "Klempner",
   "Luigi",
   "Wario"
  ]
 },
 "q1982": {
  "q": "In der Zeichentrickserie Die Simpsons arbeitet Homer Simpson als Sicherheitsinspektor an welchem Arbeitsplatz?",
  "a": [
   "Kernkraftwerk Springfield",
   "Kwik-E-Mart",
   "Moes Taverne",
   "Grundschule Springfield"
  ]
 },
 "q1983": {
  "q": "Welche britische Automarke ist in Ian Flemings Romanen und den James-Bond-Filmen am berühmtesten mit Bonds Gadget-Sportwagen verbunden?",
  "a": [
   "Aston Martin",
   "Jaguar",
   "Rolls-Royce",
   "Bentley"
  ]
 },
 "q1984": {
  "q": "Was für ein Wesen ist Shrek im Animationsfilm Shrek von 2001?",
  "a": [
   "Oger",
   "Kobold",
   "Ork",
   "Zentaur"
  ]
 },
 "q1985": {
  "q": "Was für ein Tier ist Harrys Haustier Hedwig in J. K. Rowlings Harry-Potter-Reihe?",
  "a": [
   "Schneeeule",
   "Schwarze Katze",
   "Schleiereule",
   "Wanderfalke"
  ]
 },
 "q1986": {
  "q": "In welcher US-Stadt trainiert und läuft Boxer Rocky Balboa in der Rocky-Filmreihe die Museumstreppe hinauf?",
  "a": [
   "Philadelphia",
   "Boston",
   "Chicago",
   "Baltimore"
  ]
 },
 "q1987": {
  "q": "In der Zeichentrickserie SpongeBob Schwammkopf wohnt SpongeBob unter Wasser in was für einem Haus?",
  "a": [
   "Ananas",
   "Korallenschloss",
   "Gesunkenes Schiff",
   "Riesenmuschel"
  ]
 },
 "q1988": {
  "q": "Welcher Schauspieler spielt im Film Der Pate von 1972 das Mafia-Oberhaupt Vito Corleone?",
  "a": [
   "Marlon Brando",
   "Al Pacino",
   "Robert De Niro",
   "James Caan"
  ]
 },
 "q1989": {
  "q": "Auf welchem Wüstenplaneten wächst Luke Skywalker im Film Krieg der Sterne von 1977 auf?",
  "a": [
   "Tatooine",
   "Hoth",
   "Endor",
   "Dagobah"
  ]
 },
 "q1990": {
  "q": "Wer ist in den Geschichten und Verfilmungen von Die Addams Family der Bruder von Wednesday Addams?",
  "a": [
   "Pugsley",
   "Gomez",
   "Lurch",
   "Fester"
  ]
 },
 "q1991": {
  "q": "Welcher Schauspieler spielt im Science-Fiction-Film Terminator von 1984 den Cyborg-Killer T-800?",
  "a": [
   "Arnold Schwarzenegger",
   "Michael Biehn",
   "Sylvester Stallone",
   "Kurt Russell"
  ]
 },
 "q1992": {
  "q": "Wie lautet in Segas Sonic-the-Hedgehog-Reihe der vollständige Name des zweischwänzigen Fuchses Tails?",
  "a": [
   "Miles Prower",
   "Knuckles Echidna",
   "Shadow Hedgehog",
   "Silver Prower"
  ]
 },
 "q1993": {
  "q": "Welcher Schauspieler spielt im Marvel-Film Iron Man von 2008 den Erfinder und Superhelden Tony Stark?",
  "a": [
   "Robert Downey Jr.",
   "Chris Evans",
   "Mark Ruffalo",
   "Chris Hemsworth"
  ]
 },
 "q1994": {
  "q": "Welcher Synchronsprecher lieh Bugs Bunny über Jahrzehnte hinweg ab den Looney-Tunes-Kurzfilmen von Warner Bros. seine Stimme?",
  "a": [
   "Mel Blanc",
   "Frank Welker",
   "Billy West",
   "Daws Butler"
  ]
 },
 "q1995": {
  "q": "Welchen elbischen Namen geben die Elben dem Zauberer Gandalf in J. R. R. Tolkiens Der Herr der Ringe?",
  "a": [
   "Mithrandir",
   "Celeborn",
   "Eärendil",
   "Glorfindel"
  ]
 },
 "q1996": {
  "q": "Unter welcher Londoner Adresse wohnt Arthur Conan Doyles Detektiv Sherlock Holmes?",
  "a": [
   "221B Baker Street",
   "10 Downing Street",
   "12 Grimmauld Place",
   "742 Evergreen Terrace"
  ]
 },
 "q1997": {
  "q": "Von welchem magischen Vogel stammt die Schwanzfeder in Harry Potters Zauberstab in J. K. Rowlings Romanen?",
  "a": [
   "Fawkes",
   "Hedwig",
   "Seidenschnabel",
   "Errol"
  ]
 },
 "q1998": {
  "q": "Welcher verarmte Kohlebergbau-Distrikt von Panem ist in Suzanne Collins' „Die Tribute von Panem“ die Heimat von Katniss Everdeen?",
  "a": [
   "Distrikt 12",
   "Distrikt 1",
   "Distrikt 4",
   "Distrikt 7"
  ]
 },
 "q1999": {
  "q": "Wie lautete der ursprüngliche Geburtsname des titelgebenden Millionärs in F. Scott Fitzgeralds Roman „Der große Gatsby“?",
  "a": [
   "James Gatz",
   "Nick Carraway",
   "Tom Buchanan",
   "George Wilson"
  ]
 },
 "q2000": {
  "q": "Wie viele Jahre verbringt Edmond Dantès in Alexandre Dumas' Roman „Der Graf von Monte Christo“ im Château d'If in Haft?",
  "a": [
   "14 Jahre",
   "7 Jahre",
   "20 Jahre",
   "25 Jahre"
  ]
 },
 "q2001": {
  "q": "Welche Nationalität besitzt Agatha Christies berühmter schnurrbärtiger Detektiv Hercule Poirot?",
  "a": [
   "Belgier",
   "Franzose",
   "Schweizer",
   "Kanadier"
  ]
 },
 "q2002": {
  "q": "Wie heißt das hagere, alte Pferd des titelgebenden Ritters in Miguel de Cervantes' Roman „Don Quijote“?",
  "a": [
   "Rosinante",
   "Babieca",
   "Bukephalos",
   "Schattenfell"
  ]
 },
 "q2003": {
  "q": "Wie heißt die gemütliche Hobbithöhle, die Frodo Beutlin in J. R. R. Tolkiens „Der Herr der Ringe“ erbt?",
  "a": [
   "Beutelsend",
   "Bruchtal",
   "Bree",
   "Gondolin"
  ]
 },
 "q2004": {
  "q": "Welchen Beruf übt Jonathan Harker aus, der englische Reisende, der in Bram Stokers Roman von 1897 Schloss Dracula besucht?",
  "a": [
   "Rechtsanwalt",
   "Arzt",
   "Journalist",
   "Archäologe"
  ]
 },
 "q2005": {
  "q": "An welcher amerikanischen Universität lehrt Robert Langdon in Dan Browns Roman „Sakrileg“ religiöse Ikonologie und Symbologie?",
  "a": [
   "Harvard University",
   "Yale University",
   "Princeton University",
   "Stanford University"
  ]
 },
 "q2006": {
  "q": "Wie lautet Jean Valjeans berühmte erste Häftlingsnummer im Bagno von Toulon in Victor Hugos Roman „Die Elenden“?",
  "a": [
   "24601",
   "19840",
   "11380",
   "45102"
  ]
 },
 "q2007": {
  "q": "Wie heißt Mr. Darcys prächtiges Anwesen in Derbyshire, das Elizabeth Bennet in Jane Austens „Stolz und Vorurteil“ besucht?",
  "a": [
   "Pemberley",
   "Longbourn",
   "Netherfield",
   "Rosings Park"
  ]
 },
 "q2008": {
  "q": "Was für ein Tier ist Herr Nilsson, das Haustier, das in Astrid Lindgrens Kinderbüchern bei Pippi Langstrumpf lebt?",
  "a": [
   "Affe",
   "Pferd",
   "Papagei",
   "Hund"
  ]
 },
 "q2009": {
  "q": "Warum nennt Daniel Defoes schiffbrüchiger Held Robinson Crusoe seinen geretteten Inselgefährten Freitag?",
  "a": [
   "Nach dem Wochentag ihrer Begegnung",
   "Nach seinem früheren Schiff",
   "Nach dem Monat des Schiffbruchs",
   "Nach einem Heiligen seiner Heimatstadt"
  ]
 },
 "q2010": {
  "q": "Aus welcher historischen Region im Südwesten Frankreichs reist d'Artagnan in Alexandre Dumas' „Die drei Musketiere“ nach Paris?",
  "a": [
   "Gascogne",
   "Normandie",
   "Bretagne",
   "Provence"
  ]
 },
 "q2011": {
  "q": "Wie heißt die geliebte Baumwollplantage der Familie O'Hara in Georgia in Margaret Mitchells Roman „Vom Winde verweht“?",
  "a": [
   "Tara",
   "Twelve Oaks",
   "Manderley",
   "Thornfield"
  ]
 },
 "q2012": {
  "q": "Von welchem Internat wurde der Jugendliche Holden Caulfield zu Beginn von J. D. Salingers „Der Fänger im Roggen“ gerade verwiesen?",
  "a": [
   "Pencey Prep",
   "Welton Academy",
   "Choate School",
   "Bayside High"
  ]
 },
 "q2013": {
  "q": "Aus welchem Material ist Kapitän Ahabs Beinprothese in Herman Melvilles Roman „Moby-Dick“ geschnitzt?",
  "a": [
   "Pottwal-Kieferknochen",
   "Eichen-Treibholz",
   "Gusseisen",
   "Elefantenstoßzahn"
  ]
 },
 "q2014": {
  "q": "Was ist Lisbeth Salanders Haupttätigkeit in Stieg Larssons Bestseller „Verblendung“?",
  "a": [
   "Freiberufliche Computerhackerin",
   "Gerichtsmedizinerin",
   "Strafverteidigerin",
   "Verdeckte Ermittlerin"
  ]
 },
 "q2015": {
  "q": "Auf welchem winzigen Asteroiden lebt der Titelheld in Antoine de Saint-Exupérys Erzählung „Der kleine Prinz“?",
  "a": [
   "Asteroid B 612",
   "Asteroid Vesta",
   "Asteroid Ceres",
   "Asteroid Eros"
  ]
 },
 "q2016": {
  "q": "Welchen Beruf übt Santiago, der junge andalusische Protagonist in Paulo Coelhos Roman „Der Alchimist“, ursprünglich aus?",
  "a": [
   "Schäfer",
   "Schmied",
   "Seemann",
   "Uhrmacher"
  ]
 },
 "q2017": {
  "q": "In welchem legendären englischen Wald leben Robin Hood und seine Gefährten in traditionellen Balladen und Abenteuerromanen?",
  "a": [
   "Sherwood Forest",
   "Fangorn-Wald",
   "New Forest",
   "Epping Forest"
  ]
 },
 "q2018": {
  "q": "Wie heißt Kapitän Nemos fortschrittliches elektrisches U-Boot in Jules Vernes Roman „20.000 Meilen unter dem Meer“?",
  "a": [
   "Nautilus",
   "Pequod",
   "Hispaniola",
   "Beagle"
  ]
 },
 "q2019": {
  "q": "In welcher Stadt in Maine macht das furchterregende Wesen Pennywise in Stephen Kings Roman „Es“ Jagd auf Kinder?",
  "a": [
   "Derry",
   "Castle Rock",
   "Salem's Lot",
   "Haven"
  ]
 },
 "q2020": {
  "q": "Welches Studienfach belegte der verarmte Mörder Rodion Raskolnikow vor seinem Studienabbruch in Fjodor Dostojewskis „Schuld und Sühne“?",
  "a": [
   "Rechtswissenschaft",
   "Medizin",
   "Mathematik",
   "Theologie"
  ]
 },
 "q2021": {
  "q": "In welcher Abteilung des Londoner Ministeriums für Wahrheit arbeitet Winston Smith in George Orwells dystopischem Roman „1984“?",
  "a": [
   "Registraturabteilung",
   "Zimmer 101",
   "Literaturabteilung",
   "Teleprogramm-Abteilung"
  ]
 },
 "q2022": {
  "q": "In welcher fiktiven Stadt in Alabama verteidigt der Anwalt Atticus Finch in Harper Lees Roman „Wer die Nachtigall stört“ Tom Robinson?",
  "a": [
   "Maycomb",
   "Macondo",
   "Jefferson",
   "Zenith"
  ]
 },
 "q2023": {
  "q": "Von welcher süßen Substanz versucht A. A. Milnes Bär Pu der Bär in den Geschichten aus dem Hundertmorgenwald ständig mehr zu bekommen?",
  "a": [
   "Honig",
   "Ahornsirup",
   "Orangenmarmelade",
   "Karamell"
  ]
 },
 "q2024": {
  "q": "Wie heißt die abgelegene kolumbianische Stadt, die José Arcadio Buendía in Gabriel García Márquez' „Hundert Jahre Einsamkeit“ gründet?",
  "a": [
   "Macondo",
   "Comala",
   "Santa Teresa",
   "Yoknapatawpha"
  ]
 },
 "q2025": {
  "q": "Welchen Beruf übt Gregor Samsa aus, bevor er in Franz Kafkas Erzählung „Die Verwandlung“ als ungeheures Ungeziefer erwacht?",
  "a": [
   "Handlungsreisender",
   "Bankangestellter",
   "Schullehrer",
   "Uhrmacher"
  ]
 },
 "q2026": {
  "q": "Wie heißt die Siamkatze von Holly Golightly in Truman Capotes Novelle „Frühstück bei Tiffany“ aus dem Jahr 1958?",
  "a": [
   "Kater",
   "Tiffany",
   "Fred",
   "Paul"
  ]
 },
 "q2027": {
  "q": "Welches Antibiotikum entdeckte Alexander Fleming 1928 zufällig, nachdem Schimmelpilz seine Petrischalen verunreinigt hatte?",
  "a": [
   "Penicillin",
   "Streptomycin",
   "Tetracyclin",
   "Amoxicillin"
  ]
 },
 "q2028": {
  "q": "Welches Küchengerät erfand Percy Spencer 1945, nachdem ein Radar-Magnetron einen Schokoriegel in seiner Tasche geschmolzen hatte?",
  "a": [
   "Mikrowellenherd",
   "Toaster",
   "Wasserkocher",
   "Induktionskochfeld"
  ]
 },
 "q2029": {
  "q": "Welche Strahlung entdeckte Wilhelm Röntgen 1895 zufällig bei Experimenten mit Kathodenstrahlröhren?",
  "a": [
   "Röntgenstrahlen",
   "Gammastrahlen",
   "Ultraviolettstrahlen",
   "Infrarotstrahlen"
  ]
 },
 "q2030": {
  "q": "Welchen Büroartikel entwickelten Spencer Silver und Art Fry bei 3M, nachdem sie eigentlich einen extrem starken Klebstoff suchten?",
  "a": [
   "Post-it-Haftnotizen",
   "Klebeband",
   "Tacker",
   "Büroklammer"
  ]
 },
 "q2031": {
  "q": "Welchen knusprigen Snack erfand Koch George Crum 1853 angeblich, nachdem ein Gast seine Bratkartoffeln als zu dick kritisiert hatte?",
  "a": [
   "Kartoffelchips",
   "Pommes frites",
   "Zwiebelringe",
   "Rösti"
  ]
 },
 "q2032": {
  "q": "Welchen Verschluss erfand der Schweizer Ingenieur George de Mestral in den 1940er-Jahren, nachdem er Kletten im Fell seines Hundes untersucht hatte?",
  "a": [
   "Klettverschluss",
   "Reißverschluss",
   "Druckknopf",
   "Sicherheitsnadel"
  ]
 },
 "q2033": {
  "q": "Welches antihaftende Fluorpolymer entdeckte Roy Plunkett 1938 zufällig, als er bei DuPont an Kühlgasen arbeitete?",
  "a": [
   "Teflon",
   "Nylon",
   "Kevlar",
   "Neopren"
  ]
 },
 "q2034": {
  "q": "Welche Frühstücksflocken erfanden John und Will Kellogg 1894 zufällig, nachdem sie gekochten Weizen stehen gelassen hatten?",
  "a": [
   "Cornflakes",
   "Haferbrei",
   "Müsli",
   "Granola"
  ]
 },
 "q2035": {
  "q": "Welches Medikament wurde in den 1990er-Jahren ursprünglich gegen Angina pectoris getestet, bevor seine unerwartete Nebenwirkung auffiel?",
  "a": [
   "Viagra",
   "Aspirin",
   "Ibuprofen",
   "Insulin"
  ]
 },
 "q2036": {
  "q": "Was entdeckten Arno Penzias und Robert Wilson 1964, als sich ein ständiges Rauschen ihrer Radioantenne nicht als Taubenkot erwies?",
  "a": [
   "Kosmische Hintergrundstrahlung",
   "Pulsare",
   "Sonnenwind",
   "Schwarze Löcher"
  ]
 },
 "q2037": {
  "q": "Welchen künstlichen Süßstoff entdeckte Constantin Fahlberg 1879, nachdem er vor dem Abendessen vergessen hatte, sich die Hände zu waschen?",
  "a": [
   "Saccharin",
   "Aspartam",
   "Sucralose",
   "Stevia"
  ]
 },
 "q2038": {
  "q": "Welches Verfahren zur Härtung von Kautschuk entdeckte Charles Goodyear 1839 zufällig, als ihm eine Kautschuk-Schwefel-Mischung auf einen heißen Ofen fiel?",
  "a": [
   "Vulkanisation",
   "Galvanisierung",
   "Pasteurisierung",
   "Polymerisation"
  ]
 },
 "q2039": {
  "q": "Welches klassische Kinderspielzeug entstand 1943, als Schiffsingenieur Richard James eine Torsionsfeder vom Regal stieß und sie hinablaufen sah?",
  "a": [
   "Slinky",
   "Jo-Jo",
   "Frisbee",
   "Hula-Hoop-Reifen"
  ]
 },
 "q2040": {
  "q": "Welche bunte Knetmasse wurde in den 1930er-Jahren ursprünglich erfunden, um Ruß von Tapeten zu reinigen?",
  "a": [
   "Play-Doh",
   "Plastilin",
   "Lego",
   "Silly Putty"
  ]
 },
 "q2041": {
  "q": "Welches medizinische Gerät erfand Wilson Greatbatch 1956, nachdem er versehentlich den falschen Widerstand in ein Herzton-Aufnahmegerät eingebaut hatte?",
  "a": [
   "Implantierbarer Herzschrittmacher",
   "Stethoskop",
   "Defibrillator",
   "Elektrokardiograf"
  ]
 },
 "q2042": {
  "q": "Welche gefrorene Süßigkeit erfand der 11-jährige Frank Epperson 1905 zufällig, als er einen Becher Limonade über Nacht draußen stehen ließ?",
  "a": [
   "Wassereis am Stiel",
   "Eiswaffel",
   "Slush-Eis",
   "Sorbet"
  ]
 },
 "q2043": {
  "q": "Welches Verpackungsmaterial schufen Alfred Fielding und Marc Chavannes 1957, nachdem sie zwei verschweißte Duschvorhänge nicht als Strukturtapete verkaufen konnten?",
  "a": [
   "Luftpolsterfolie",
   "Styropor",
   "Pappkarton",
   "Zellophan"
  ]
 },
 "q2044": {
  "q": "Welches chemische Element entdeckte Hennig Brand 1669, als er auf der Suche nach dem Stein der Weisen eimerweise menschlichen Urin einkochte?",
  "a": [
   "Phosphor",
   "Schwefel",
   "Kalium",
   "Natrium"
  ]
 },
 "q2045": {
  "q": "Welches physikalische Phänomen entdeckte Henri Becquerel 1896, als bewölktes Wetter ihn zwang, Uransalze bei Fotoplatten in einer Schublade zu lassen?",
  "a": [
   "Radioaktivität",
   "Photoelektrischer Effekt",
   "Supraleitung",
   "Elektromagnetismus"
  ]
 },
 "q2046": {
  "q": "Welches berühmte Erfrischungsgetränk schuf der Apotheker John Pemberton 1886, als er ein Heilmittel gegen Kopfschmerzen und Müdigkeit entwickeln wollte?",
  "a": [
   "Coca-Cola",
   "Pepsi",
   "Sprite",
   "Fanta"
  ]
 },
 "q2047": {
  "q": "Welchen extrem starken Klebstoff entdeckte Harry Coover 1942 zufällig, als er transparente Kunststoffvisiere für Gewehre herstellen wollte?",
  "a": [
   "Sekundenkleber",
   "Epoxidharz",
   "Holzleim",
   "Gummilösung"
  ]
 },
 "q2048": {
  "q": "Welches bruchsichere Material erfand der französische Chemiker Édouard Bénédictus 1903, nachdem ihm ein innen mit Cellulosenitrat beschichteter Glaskolben heruntergefallen war?",
  "a": [
   "Verbundsicherheitsglas",
   "Einscheibensicherheitsglas",
   "Glasfaser",
   "Plexiglas"
  ]
 },
 "q2049": {
  "q": "Welcher Blutverdünner wurde in den 1920er-Jahren entdeckt, nachdem Rinder in Nordamerika durch schimmeliges Steinklee-Heu verbluteten?",
  "a": [
   "Warfarin",
   "Heparin",
   "Aspirin",
   "Clopidogrel"
  ]
 },
 "q2050": {
  "q": "Welches Mittel gegen Haarausfall wurde in den 1970er-Jahren ursprünglich gegen Bluthochdruck entwickelt, bevor vermehrter Haarwuchs auffiel?",
  "a": [
   "Minoxidil",
   "Finasterid",
   "Biotin",
   "Ketoconazol"
  ]
 },
 "q2051": {
  "q": "Welchen ersten synthetischen Anilinfarbstoff stellte der 18-jährige William Henry Perkin 1856 zufällig her, als er Chinin synthetisieren wollte?",
  "a": [
   "Mauvein",
   "Indigo",
   "Preußischblau",
   "Alizarin"
  ]
 },
 "q2052": {
  "q": "Welche korrosionsbeständige Legierung entdeckte Harry Brearley 1913, als er mit Chrom die Abnutzung von Gewehrläufen verringern wollte?",
  "a": [
   "Edelstahl",
   "Bronze",
   "Messing",
   "Duraluminium"
  ]
 },
 "q2053": {
  "q": "Die endokrine Funktion welches Organs entdeckten Oskar Minkowski und Joseph von Mering 1889, als Fliegen den zuckerhaltigen Urin eines operierten Hundes umschwärmten?",
  "a": [
   "Bauchspeicheldrüse",
   "Schilddrüse",
   "Nebenniere",
   "Hypophyse"
  ]
 },
 "q2054": {
  "q": "Von welchem Narkosegas erkannte Horace Wells 1844 die schmerzstillende Wirkung, nachdem sich ein Bekannter bei einer Vorführung unbemerkt am Bein verletzt hatte?",
  "a": [
   "Lachgas",
   "Chloroform",
   "Diethylether",
   "Halothan"
  ]
 },
 "q2055": {
  "q": "Welche antike Textsammlung wurde 1945 nahe Nag Hammadi zufällig von ägyptischen Brüdern beim Graben nach Dünger entdeckt?",
  "a": [
   "Gnostische Evangelien",
   "Schriftrollen vom Toten Meer",
   "Gilgamesch-Epos",
   "Codex Hammurapi"
  ]
 },
 "q2056": {
  "q": "Welche Kohlenstoff-Modifikation entdeckten Robert Curl, Harold Kroto und Richard Smalley 1985 zufällig bei der Simulation der Chemie Roter Riesensterne?",
  "a": [
   "Buckminsterfulleren",
   "Graphen",
   "Lonsdaleit",
   "Carbin"
  ]
 },
 "q2057": {
  "q": "Welches muskelentspannende Nervengift setzte Alan Scott in den 1970er-Jahren gegen Schielen ein, nachdem er es zunächst an Affen getestet hatte?",
  "a": [
   "Botulinumtoxin",
   "Curare",
   "Tetrodotoxin",
   "Bungarotoxin"
  ]
 },
 "q2058": {
  "q": "Wenn 3 Katzen in 3 Minuten 3 Mäuse fangen, wie viele Mäuse fangen 6 gleich schnelle Katzen in 3 Minuten?",
  "a": [
   "6",
   "3",
   "9",
   "18"
  ]
 },
 "q2059": {
  "q": "Ein Bauer hat 17 Schafe und alle bis auf 9 laufen weg; wie viele bleiben?",
  "a": [
   "9",
   "8",
   "17",
   "26"
  ]
 },
 "q2060": {
  "q": "In einem Rennen überholen Sie die Person auf Platz 2; welchen Platz haben Sie unmittelbar danach?",
  "a": [
   "2",
   "1",
   "3",
   "4"
  ]
 },
 "q2061": {
  "q": "Eine Uhr schlägt 3-mal in 6 Sekunden mit gleichen Abständen; wie viele Sekunden vergehen vom ersten bis zum letzten von 6 Schlägen?",
  "a": [
   "15",
   "12",
   "18",
   "30"
  ]
 },
 "q2062": {
  "q": "Wie viele gerade Schnitte sind nötig, um ein Seil in 6 Stücke zu teilen, wenn jeder Schnitt nur durch 1 Stück geht?",
  "a": [
   "5",
   "6",
   "3",
   "7"
  ]
 },
 "q2063": {
  "q": "Eine Schnecke klettert tagsüber 3 Meter und rutscht nachts 2 Meter hinunter; an welchem Tag erreicht sie erstmals die Spitze einer 5 Meter hohen Mauer?",
  "a": [
   "3",
   "5",
   "4",
   "2"
  ]
 },
 "q2064": {
  "q": "Ein Schläger und ein Ball kosten zusammen 110 Münzen, wobei der Schläger 100 Münzen mehr kostet als der Ball; wie viele Münzen kostet der Ball?",
  "a": [
   "5",
   "10",
   "15",
   "20"
  ]
 },
 "q2065": {
  "q": "Wie viele Händeschütteln gibt es, wenn 5 Personen jeder anderen Person genau einmal die Hand geben?",
  "a": [
   "10",
   "20",
   "5",
   "15"
  ]
 },
 "q2066": {
  "q": "Die Anzahl der Seerosenblätter auf einem Teich verdoppelt sich jeden Tag; wenn der Teich am 20. Tag vollständig bedeckt ist, an welchem Tag war er halb bedeckt?",
  "a": [
   "19",
   "10",
   "18",
   "15"
  ]
 },
 "q2067": {
  "q": "In einer Schublade liegen nur rote und blaue Socken; wie viele müssen Sie mindestens blind herausnehmen, um sicher 2 gleichfarbige Socken zu haben?",
  "a": [
   "3",
   "2",
   "4",
   "5"
  ]
 },
 "q2068": {
  "q": "Wenn 5 Maschinen jeweils 1 Spielzeug in 5 Minuten herstellen, wie viele Minuten brauchen 100 gleiche Maschinen für 100 Spielzeuge?",
  "a": [
   "5",
   "100",
   "20",
   "500"
  ]
 },
 "q2069": {
  "q": "Zwei Väter und zwei Söhne teilen 3 Äpfel so auf, dass jede Person 1 ganzen Apfel bekommt; was ist die kleinstmögliche Anzahl an Personen?",
  "a": [
   "3",
   "4",
   "2",
   "5"
  ]
 },
 "q2070": {
  "q": "Eine Familie hat 4 Töchter und jede Tochter hat denselben einzigen Bruder; wie viele Kinder hat die Familie?",
  "a": [
   "5",
   "8",
   "4",
   "6"
  ]
 },
 "q2071": {
  "q": "Ein Würfel wird auf allen 6 Seiten bemalt und in 27 gleiche kleine Würfel zerschnitten; wie viele kleine Würfel haben genau 3 bemalte Seiten?",
  "a": [
   "8",
   "6",
   "12",
   "4"
  ]
 },
 "q2072": {
  "q": "Ein Rechteck hat einen Umfang von 20 Zentimetern und eine Breite von 4 Zentimetern; wie lang ist es in Zentimetern?",
  "a": [
   "6",
   "16",
   "5",
   "8"
  ]
 },
 "q2073": {
  "q": "Wenn 4 Personen jeweils eine Wand in 2 Stunden streichen können, wie viele Stunden brauchen sie für 4 getrennte Wände, wenn jede Person eine Wand streicht?",
  "a": [
   "2",
   "8",
   "4",
   "1"
  ]
 },
 "q2074": {
  "q": "Ein Beutel enthält 4 rote und 5 blaue Kugeln; wie viele Kugeln müssen Sie blind herausnehmen, um sicher mindestens 1 blaue zu haben?",
  "a": [
   "5",
   "4",
   "6",
   "2"
  ]
 },
 "q2075": {
  "q": "Ein Zug hat 8 Waggons und Sie gehen vom ersten bis zum letzten; wie viele Übergänge zwischen Waggons überqueren Sie?",
  "a": [
   "7",
   "8",
   "9",
   "6"
  ]
 },
 "q2076": {
  "q": "Wenn übermorgen Montag ist, welcher Tag war gestern?",
  "a": [
   "Freitag",
   "Samstag",
   "Sonntag",
   "Donnerstag"
  ]
 },
 "q2077": {
  "q": "Eine Person geht auf derselben geraden Straße 3 Kilometer nach Norden und dann 4 Kilometer nach Süden; wie viele Kilometer ist sie vom Ausgangspunkt entfernt?",
  "a": [
   "1",
   "7",
   "3",
   "4"
  ]
 },
 "q2078": {
  "q": "Ein quadratisches Blatt wird einmal in der Mitte gefaltet und mit einem Schnitt vollständig entlang der Falte zerschnitten; wie viele Stücke entstehen?",
  "a": [
   "2",
   "3",
   "4",
   "1"
  ]
 },
 "q2079": {
  "q": "Auf einer Feier trägt jede Person einen Hut oder einen Schal, wobei 8 einen Hut, 6 einen Schal und 3 beides tragen; wie viele Personen sind auf der Feier?",
  "a": [
   "11",
   "14",
   "17",
   "9"
  ]
 },
 "q2080": {
  "q": "Wenn 2 gleiche Kerzen jeweils in 4 Stunden vollständig abbrennen, wie viele Stunden brennen sie, wenn sie gleichzeitig angezündet werden?",
  "a": [
   "4",
   "8",
   "2",
   "6"
  ]
 },
 "q2081": {
  "q": "In einer Schachtel liegen 12 Eier; wenn Sie 3 Eier herausnehmen, wie viele Eier haben Sie?",
  "a": [
   "3",
   "9",
   "12",
   "15"
  ]
 },
 "q2082": {
  "q": "Ein Buch und ein Stift kosten zusammen 30 Münzen, und das Buch kostet doppelt so viel wie der Stift; wie viele Münzen kostet der Stift?",
  "a": [
   "10",
   "15",
   "20",
   "5"
  ]
 },
 "q2083": {
  "q": "Ein Vater ist 36 und seine Tochter 12 Jahre alt; in wie vielen Jahren wird er doppelt so alt sein wie sie?",
  "a": [
   "12",
   "6",
   "18",
   "24"
  ]
 },
 "q2084": {
  "q": "Eine Person blickt nach Norden, dreht sich nach rechts, dann noch einmal nach rechts und zuletzt nach links; in welche Richtung blickt sie?",
  "a": [
   "Osten",
   "Westen",
   "Norden",
   "Süden"
  ]
 },
 "q2085": {
  "q": "Ein Bauer setzt an jedes Ende eines geraden 30 Meter langen Zauns 1 Pfosten und dazwischen alle 5 Meter einen Pfosten; wie viele Pfosten braucht er?",
  "a": [
   "7",
   "6",
   "5",
   "8"
  ]
 },
 "q2086": {
  "q": "Eine Zahl wird verdoppelt und anschließend wird 6 addiert, sodass 20 entsteht; wie lautet die ursprüngliche Zahl?",
  "a": [
   "7",
   "13",
   "10",
   "8"
  ]
 },
 "q2087": {
  "q": "In einem Raum befinden sich 3 zunächst ausgeschaltete Schalter, von denen jeder eine andere vom Raum aus sichtbare Lampe steuert; wie viele Schalter müssen betätigt werden, damit genau 2 Lampen leuchten?",
  "a": [
   "2",
   "1",
   "3",
   "4"
  ]
 },
 "q2088": {
  "q": "Welcher sowjetische Staatschef gewann 2004 einen Grammy für die Erzählung eines Kinderalbums?",
  "a": [
   "Michail Gorbatschow",
   "Nikita Chruschtschow",
   "Leonid Breschnew",
   "Boris Jelzin"
  ]
 },
 "q2089": {
  "q": "Welcher britische Premierminister erhielt 1953 den Nobelpreis für Literatur?",
  "a": [
   "Winston Churchill",
   "Clement Attlee",
   "Anthony Eden",
   "Harold Macmillan"
  ]
 },
 "q2090": {
  "q": "Welcher ehemalige Ballon-d'Or-Gewinner war von 2018 bis 2024 Präsident von Liberia?",
  "a": [
   "George Weah",
   "Didier Drogba",
   "Samuel Eto'o",
   "Roger Milla"
  ]
 },
 "q2091": {
  "q": "In welchem wissenschaftlichen Fachgebiet promovierte die ehemalige Bundeskanzlerin Angela Merkel 1986?",
  "a": [
   "Quantenchemie",
   "Kernphysik",
   "Molekularbiologie",
   "Organische Geologie"
  ]
 },
 "q2092": {
  "q": "Welcher US-Präsident wurde in die National Wrestling Hall of Fame aufgenommen, nachdem er in seiner Jugend nur einen von rund 300 Kämpfen verloren hatte?",
  "a": [
   "Abraham Lincoln",
   "Theodore Roosevelt",
   "Andrew Jackson",
   "Ulysses S. Grant"
  ]
 },
 "q2093": {
  "q": "Welcher weltberühmte Konzertpianist und Komponist war 1919 Premierminister von Polen?",
  "a": [
   "Ignacy Jan Paderewski",
   "Frédéric Chopin",
   "Karol Szymanowski",
   "Arthur Rubinstein"
  ]
 },
 "q2094": {
  "q": "Welchen literarischen Hauptberuf übte Václav Havel aus, bevor er 1989 Präsident der Tschechoslowakei wurde?",
  "a": [
   "Dramatiker",
   "Science-Fiction-Autor",
   "Epischer Dichter",
   "Sportjournalist"
  ]
 },
 "q2095": {
  "q": "Welcher US-Präsident erhielt 1906 den Friedensnobelpreis für seine Vermittlung zur Beendigung des Russisch-Japanischen Krieges?",
  "a": [
   "Theodore Roosevelt",
   "Woodrow Wilson",
   "William Howard Taft",
   "William McKinley"
  ]
 },
 "q2096": {
  "q": "Was verlangte der junge Julius Caesar laut antiken römischen Historikern, als kilikische Piraten sein Lösegeld auf 20 Talente Silber festsetzten?",
  "a": [
   "Dass sie es auf 50 Talente erhöhen",
   "Dass sie ihn kostenlos freilassen",
   "Dass sie ihm 20 Talente zahlen",
   "Dass sie ihn gegen ein Schiff tauschen"
  ]
 },
 "q2097": {
  "q": "Auf welcher Mittelmeerinsel wurde der französische Kaiser Napoleon Bonaparte 1769 geboren?",
  "a": [
   "Korsika",
   "Sardinien",
   "Sizilien",
   "Elba"
  ]
 },
 "q2098": {
  "q": "In welchem heutigen Land wurde der sowjetische Staatschef Josef Stalin 1878 geboren?",
  "a": [
   "Georgien",
   "Russland",
   "Ukraine",
   "Armenien"
  ]
 },
 "q2099": {
  "q": "Welcher US-Präsident reichte 1973 einen offiziellen Sichtungsbericht ein, nachdem er 1969 in Georgia ein unidentifiziertes Flugobjekt beobachtet hatte?",
  "a": [
   "Jimmy Carter",
   "Gerald Ford",
   "Richard Nixon",
   "Ronald Reagan"
  ]
 },
 "q2100": {
  "q": "Wie lautete der gebürtige Vorname des indischen Unabhängigkeitsführers Mahatma Gandhi?",
  "a": [
   "Mohandas",
   "Jawaharlal",
   "Subhas",
   "Rabindranath"
  ]
 },
 "q2101": {
  "q": "Welcher südafrikanische Präsident hatte einen Gastauftritt am Ende von Spike Lees Biografiefilm „Malcolm X“ aus dem Jahr 1992?",
  "a": [
   "Nelson Mandela",
   "Thabo Mbeki",
   "F. W. de Klerk",
   "Desmond Tutu"
  ]
 },
 "q2102": {
  "q": "Welcher nordkoreanische Machthaber ließ 1978 den südkoreanischen Regisseur Shin Sang-ok entführen, um Monsterfilme wie „Pulgasari“ zu drehen?",
  "a": [
   "Kim Jong Il",
   "Kim Il Sung",
   "Kim Jong Un",
   "Pak Hon-yong"
  ]
 },
 "q2103": {
  "q": "Welcher europäische Kaiser musste sich 1807 bei einer Jagdgesellschaft in seine Kutsche zurückziehen, nachdem Hunderte zahme Kaninchen ihn bestürmt hatten?",
  "a": [
   "Napoleon Bonaparte",
   "Franz Joseph I.",
   "Wilhelm II.",
   "Alexander I."
  ]
 },
 "q2104": {
  "q": "Welcher australische Premierminister stellte 1954 in Oxford einen Weltrekord auf, indem er rund 1,4 Liter Bier in 11 Sekunden austrank?",
  "a": [
   "Bob Hawke",
   "Gough Whitlam",
   "Malcolm Fraser",
   "Paul Keating"
  ]
 },
 "q2105": {
  "q": "Welcher tschechische Schriftsteller, der das Wort „Roboter“ populär machte, veröffentlichte mehrbändige Gespräche mit Präsident Tomáš Garrigue Masaryk?",
  "a": [
   "Karel Čapek",
   "Jaroslav Hašek",
   "Milan Kundera",
   "Bohumil Hrabal"
  ]
 },
 "q2106": {
  "q": "Welcher britische Premierminister amtierte in zwei nicht aufeinanderfolgenden Amtszeiten von 1940 bis 1945 und von 1951 bis 1955?",
  "a": [
   "Winston Churchill",
   "Harold Wilson",
   "Stanley Baldwin",
   "Ramsay MacDonald"
  ]
 },
 "q2107": {
  "q": "Welcher US-Präsident wurde als einziger für vier aufeinanderfolgende Amtszeiten gewählt?",
  "a": [
   "Franklin D. Roosevelt",
   "George Washington",
   "Woodrow Wilson",
   "Dwight D. Eisenhower"
  ]
 },
 "q2108": {
  "q": "In welcher Einheit der britischen Armee ließ sich die spätere Königin Elisabeth II. im Zweiten Weltkrieg zur Fahrerin und Mechanikerin ausbilden?",
  "a": [
   "Auxiliary Territorial Service",
   "Royal Navy",
   "Royal Air Force",
   "Women's Royal Naval Service"
  ]
 },
 "q2109": {
  "q": "Unter welchem Spitznamen war die britische Premierministerin Margaret Thatcher während ihrer Amtszeit von 1979 bis 1990 weithin bekannt?",
  "a": [
   "Die Eiserne Lady",
   "Die Jungfrau von Orléans",
   "Die Königin der Schotten",
   "Der Silberfuchs"
  ]
 },
 "q2110": {
  "q": "An Bord welchen Verkehrsmittels legte Lyndon B. Johnson am 22. November 1963 den Amtseid als US-Präsident ab?",
  "a": [
   "Eines Flugzeugs",
   "Eines Schlachtschiffs",
   "Eines Panzerzugs",
   "Eines U-Boots"
  ]
 },
 "q2111": {
  "q": "Welcher sowjetische Außenminister prägte 1989 den humorvollen Begriff „Sinatra-Doktrin“ für den eigenen Weg der Warschauer-Pakt-Staaten?",
  "a": [
   "Eduard Schewardnadse",
   "Andrei Gromyko",
   "Wjatscheslaw Molotow",
   "Maxim Litwinow"
  ]
 },
 "q2112": {
  "q": "In welcher Stadt des Russischen Kaiserreiches wurde die israelische Premierministerin Golda Meir 1898 geboren?",
  "a": [
   "Kiew",
   "Odessa",
   "Minsk",
   "Vilnius"
  ]
 },
 "q2113": {
  "q": "Wer trat im August 1974 als erster US-Präsident von seinem Amt zurück?",
  "a": [
   "Richard Nixon",
   "Gerald Ford",
   "Lyndon B. Johnson",
   "Jimmy Carter"
  ]
 },
 "q2114": {
  "q": "Wie lautete der Geburtsname des Mongolenherrschers Dschingis Khan, bevor er 1206 zum Universalherrscher ausgerufen wurde?",
  "a": [
   "Temüdschin",
   "Kublai",
   "Ögedei",
   "Tschagatai"
  ]
 },
 "q2115": {
  "q": "Welcher haitianische Präsident trug den Spitznamen „Papa Doc“, weil er vor seiner politischen Laufbahn als Arzt gearbeitet hatte?",
  "a": [
   "François Duvalier",
   "Jean-Claude Duvalier",
   "Jean-Bertrand Aristide",
   "Henri Christophe"
  ]
 },
 "q2116": {
  "q": "Welcher Chemiker und zionistische Politiker wurde 1949 der erste Präsident Israels?",
  "a": [
   "Chaim Weizmann",
   "David Ben-Gurion",
   "Levi Eschkol",
   "Mosche Scharett"
  ]
 },
 "q2117": {
  "q": "Welcher kanadische Premierminister erhielt 1957 den Friedensnobelpreis für seine Rolle bei der Lösung der Sueskrise?",
  "a": [
   "Lester B. Pearson",
   "Pierre Trudeau",
   "John Diefenbaker",
   "Mackenzie King"
  ]
 },
 "q2118": {
  "q": "Welcher britische Nachkriegspremierminister führte die Labour-Regierung an, die 1948 den National Health Service gründete?",
  "a": [
   "Clement Attlee",
   "Harold Macmillan",
   "Anthony Eden",
   "Neville Chamberlain"
  ]
 },
 "q2119": {
  "q": "Welcher aktive Vulkan zerstörte im Jahr 79 n. Chr. die römische Stadt Pompeji?",
  "a": [
   "Vesuv",
   "Ätna",
   "Stromboli",
   "Olymp"
  ]
 },
 "q2120": {
  "q": "Wie nennt man geschmolzenes Gestein, solange es sich noch unter der Erdoberfläche befindet?",
  "a": [
   "Magma",
   "Lava",
   "Bimsstein",
   "Basalt"
  ]
 },
 "q2121": {
  "q": "Welche hufeisenförmige Zone rund um den Pazifischen Ozean enthält rund 75 % der aktiven Vulkane der Welt?",
  "a": [
   "Pazifischer Feuerring",
   "Marianengraben",
   "Mittelatlantischer Rücken",
   "Großer Afrikanischer Grabenbruch"
  ]
 },
 "q2122": {
  "q": "Welcher Schichtvulkan auf der Insel Honshu ist der höchste Berg Japans?",
  "a": [
   "Fuji",
   "Ontake",
   "Aso",
   "Sakurajima"
  ]
 },
 "q2123": {
  "q": "Wie heißt der riesige Schildvulkan auf dem Mars, der der größte bekannte Vulkan im Sonnensystem ist?",
  "a": [
   "Olympus Mons",
   "Tharsis Montes",
   "Elysium Mons",
   "Arsia Mons"
  ]
 },
 "q2124": {
  "q": "Welches poröse Vulkangestein, das aus schnell abkühlender schaumiger Lava entsteht, ist leicht genug, um auf Wasser zu schwimmen?",
  "a": [
   "Bimsstein",
   "Obsidian",
   "Basalt",
   "Granit"
  ]
 },
 "q2125": {
  "q": "Der Ausbruch welches indonesischen Vulkans im Jahr 1883 erzeugte eines der lautesten jemals in der modernen Geschichte aufgezeichneten Geräusche?",
  "a": [
   "Krakatau",
   "Tambora",
   "Merapi",
   "Agung"
  ]
 },
 "q2126": {
  "q": "Welcher Schildvulkan auf der Insel Hawaii ist nach Volumen und Fläche der größte aktive Vulkan der Erde?",
  "a": [
   "Mauna Loa",
   "Kilauea",
   "Mauna Kea",
   "Hualalai"
  ]
 },
 "q2127": {
  "q": "Welcher isländische Vulkan legte nach seinem Ausbruch im April 2010 den europäischen Flugverkehr tagelang lahm?",
  "a": [
   "Eyjafjallajökull",
   "Hekla",
   "Katla",
   "Grímsvötn"
  ]
 },
 "q2128": {
  "q": "Wie nennt man die große kesselartige Vertiefung, die nach der Entleerung einer Magmakammer bei einem Vulkanausbruch entsteht?",
  "a": [
   "Caldera",
   "Fumarole",
   "Lagergang",
   "Gesteinsgang"
  ]
 },
 "q2129": {
  "q": "Welcher Schichtvulkan im US-Bundesstaat Washington erlitt im Mai 1980 einen katastrophalen seitlichen Ausbruch?",
  "a": [
   "Mount St. Helens",
   "Mount Rainier",
   "Mount Hood",
   "Mount Shasta"
  ]
 },
 "q2130": {
  "q": "Der gewaltige Ausbruch welches indonesischen Vulkans im Jahr 1815 verursachte 1816 die globale Klimaanomalie, die als Jahr ohne Sommer bekannt wurde?",
  "a": [
   "Tambora",
   "Krakatau",
   "Pinatubo",
   "Toba"
  ]
 },
 "q2131": {
  "q": "Welcher sizilianische Vulkan ist der höchste aktive Vulkan Europas?",
  "a": [
   "Ätna",
   "Vesuv",
   "Stromboli",
   "Vulcano"
  ]
 },
 "q2132": {
  "q": "Wie nennt man den sich schnell bewegenden, zerstörerischen Strom aus heißem Gas und vulkanischem Material, der bei einem explosiven Ausbruch den Hang hinabrast?",
  "a": [
   "Pyroklastischer Strom",
   "Lahar",
   "Tephra",
   "Basaltflut"
  ]
 },
 "q2133": {
  "q": "Welche kleine Vulkaninsel im Tyrrhenischen Meer bricht seit über 2.000 Jahren nahezu ununterbrochen aus und trägt den Beinamen Leuchtturm des Mittelmeers?",
  "a": [
   "Stromboli",
   "Panarea",
   "Lipari",
   "Ischia"
  ]
 },
 "q2134": {
  "q": "Wie lautet der aus dem Indonesischen stammende geologische Fachbegriff für einen zerstörerischen Schlamm- oder Schuttstrom aus Vulkanasche und Wasser?",
  "a": [
   "Lahar",
   "Tuff",
   "Schlacke",
   "Pahoehoe"
  ]
 },
 "q2135": {
  "q": "Der Gipfel welches inaktiven Schichtvulkans in Ecuador ist aufgrund der Äquatorwulst der am weitesten vom Erdmittelpunkt entfernte Punkt?",
  "a": [
   "Chimborazo",
   "Cotopaxi",
   "Cayambe",
   "Antisana"
  ]
 },
 "q2136": {
  "q": "Welche Skala von 0 bis 8 misst die relative Explosivität von Vulkanausbrüchen hauptsächlich anhand des Auswurfvolumens und der Eruptionssäulenhöhe?",
  "a": [
   "Vulkanexplosivitätsindex",
   "Richterskala",
   "Mercalliskala",
   "Beaufortskala"
  ]
 },
 "q2137": {
  "q": "Welcher Berg an der Grenze zwischen Argentinien und Chile ist mit 6.893 Metern der höchste Vulkan der Welt über dem Meeresspiegel?",
  "a": [
   "Ojos del Salado",
   "Llullaillaco",
   "Cotopaxi",
   "Pico de Orizaba"
  ]
 },
 "q2138": {
  "q": "Welcher hawaiianische Begriff beschreibt glatte, wellige oder strickartige Basaltlavaströme?",
  "a": [
   "Pahoehoe",
   "Aa",
   "Tephra",
   "Ignimbrit"
  ]
 },
 "q2139": {
  "q": "Welcher Vulkan in der Demokratischen Republik Kongo ist dafür bekannt, einen der größten dauerhaften Lavaseen der Welt zu beherbergen?",
  "a": [
   "Nyiragongo",
   "Kamerunberg",
   "Kilimandscharo",
   "Erta Ale"
  ]
 },
 "q2140": {
  "q": "Welcher Jupitermond ist mit Hunderten aktiver Vulkane der geologisch aktivste Himmelskörper im Sonnensystem?",
  "a": [
   "Io",
   "Europa",
   "Ganymed",
   "Kallisto"
  ]
 },
 "q2141": {
  "q": "Welcher Vulkan auf der Karibikinsel Martinique zerstörte im Mai 1902 die Stadt Saint-Pierre und tötete fast 30.000 Menschen?",
  "a": [
   "Montagne Pelée",
   "La Soufrière",
   "Soufrière Hills",
   "Kick 'em Jenny"
  ]
 },
 "q2142": {
  "q": "Wie nennt man dünne Fäden aus vulkanischem Glas, die entstehen, wenn Wind geschmolzene Basaltlava in die Länge zieht, benannt nach einer hawaiianischen Gottheit?",
  "a": [
   "Peles Haar",
   "Peles Tränen",
   "Apachentränen",
   "Engelshaar"
  ]
 },
 "q2143": {
  "q": "Welcher unterseeische Vulkan etwa 30 Kilometer südöstlich der Insel Hawaii ist der jüngste Vulkan der Hawaii-Emperor-Tiefseekette?",
  "a": [
   "Kamaʻehuakanaloa",
   "Hualalai",
   "Kohala",
   "Haleakala"
  ]
 },
 "q2144": {
  "q": "Welche Vulkaninsel vor der Südküste Islands tauchte im November 1963 aus dem Atlantik auf und wurde für die ökologische Forschung zum UNESCO-Welterbe?",
  "a": [
   "Surtsey",
   "Heimaey",
   "Grímsey",
   "Viðey"
  ]
 },
 "q2145": {
  "q": "Welche nach einem römischen Geschichtsschreiber benannte Art von Vulkanausbruch zeichnet sich durch hohe Gas- und Aschesäulen aus, die bis in die Stratosphäre reichen?",
  "a": [
   "Plinianische Eruption",
   "Strombolianische Eruption",
   "Hawaiianische Eruption",
   "Surtseyanische Eruption"
  ]
 },
 "q2146": {
  "q": "Welches unterseeische Vulkanmassiv im nordwestlichen Pazifik östlich von Japan wurde 2013 als einer der größten Einzelvulkane der Erde identifiziert?",
  "a": [
   "Tamu-Massiv",
   "Shatsky-Schwelle",
   "Ontong-Java-Plateau",
   "Kerguelen-Plateau"
  ]
 },
 "q2147": {
  "q": "Welcher isländische Spaltenausbruch in den Jahren 1783–1784 setzte gewaltige Wolken aus Fluorwasserstoff und Schwefeldioxid frei und verursachte eine Hungersnot auf Island sowie Missernten in Europa?",
  "a": [
   "Laki",
   "Eldgjá",
   "Askja",
   "Krafla"
  ]
 },
 "q2148": {
  "q": "Welcher erloschene Vulkan auf St. Helena im Südatlantik ist der einzige bekannte Lebensraum des vom Aussterben bedrohten Riesenohrwurms Labidura herculeana?",
  "a": [
   "Mount Actaeon",
   "Diana's Peak",
   "High Knoll",
   "Flagstaff Hill"
  ]
 },
 "q2149": {
  "q": "Welche Hunderasse ist berühmt für ihr weißes Fell mit schwarzen oder braunen Flecken?",
  "a": [
   "Dalmatiner",
   "Beagle",
   "Pudel",
   "Boxer"
  ]
 },
 "q2150": {
  "q": "Welche kleine Hunderasse, die ursprünglich in Deutschland zur Dachsjagd gezüchtet wurde, hat einen langen Körper und sehr kurze Beine?",
  "a": [
   "Dackel",
   "Chihuahua",
   "Mops",
   "Zwergspitz"
  ]
 },
 "q2151": {
  "q": "Welche Rettungshunderasse aus den Schweizer und Italienischen Alpen wurde historisch von Mönchen im Hospiz auf dem Grossen St. Bernhard ausgebildet?",
  "a": [
   "Bernhardiner",
   "Siberian Husky",
   "Rottweiler",
   "Dobermann"
  ]
 },
 "q2152": {
  "q": "Welche kleinste anerkannte Hunderasse der Welt ist nach einem nordmexikanischen Bundesstaat benannt?",
  "a": [
   "Chihuahua",
   "Pekingese",
   "Malteser",
   "Shih Tzu"
  ]
 },
 "q2153": {
  "q": "Welche alte Hunderasse aus Nordchina zeichnet sich durch ihre blauschwarze Zunge und ihre löwenartige Mähne aus?",
  "a": [
   "Chow-Chow",
   "Samojede",
   "Akita",
   "Shar-Pei"
  ]
 },
 "q2154": {
  "q": "Welche schlanke Windhundrasse ist der schnellste Hund der Welt und kann Geschwindigkeiten von über 70 km/h erreichen?",
  "a": [
   "Greyhound",
   "Border Collie",
   "Golden Retriever",
   "Labrador Retriever"
  ]
 },
 "q2155": {
  "q": "Welche japanische Hunderasse vom Spitz-Typ wurde durch Hachiko, den treuen Hund am Bahnhof Shibuya, weltberühmt?",
  "a": [
   "Akita",
   "Shiba Inu",
   "Japan Chin",
   "Tosa"
  ]
 },
 "q2156": {
  "q": "Welche Hütehundrasse aus dem englisch-schottischen Grenzgebiet gilt bei Gehorsamkeitstests weithin als die intelligenteste Hunderasse?",
  "a": [
   "Border Collie",
   "Welsh Corgi",
   "Shetland Sheepdog",
   "Bobtail"
  ]
 },
 "q2157": {
  "q": "Welche kurzbeinige Hütehundrasse aus Wales wurde von Königin Elisabeth II. während ihrer gesamten Herrschaft besonders bevorzugt?",
  "a": [
   "Pembroke Welsh Corgi",
   "Cairn Terrier",
   "West Highland White Terrier",
   "Basset Hound"
  ]
 },
 "q2158": {
  "q": "Welche zentralafrikanische Jagdhunderasse ist dafür bekannt, nicht wie andere Hunde zu bellen, sondern einen jodelähnlichen Laut von sich zu geben?",
  "a": [
   "Basenji",
   "Rhodesian Ridgeback",
   "Saluki",
   "Afghanischer Windhund"
  ]
 },
 "q2159": {
  "q": "Welche schwere kanadische Wasserrettungshunderasse hat Schwimmhäute zwischen den Zehen und ist nach der östlichsten Provinz Kanadas benannt?",
  "a": [
   "Neufundländer",
   "Labrador Retriever",
   "Nova Scotia Duck Tolling Retriever",
   "Chesapeake Bay Retriever"
  ]
 },
 "q2160": {
  "q": "Welche riesige Hunderasse aus Irland, die historisch zur Wolfsjagd gezüchtet wurde, ist im Durchschnitt die größte aller anerkannten Hunderassen?",
  "a": [
   "Irischer Wolfshund",
   "Deutsche Dogge",
   "Scottish Deerhound",
   "Barsoi"
  ]
 },
 "q2161": {
  "q": "Welche weiße arktische Schlittenhunderasse ist nach den indigenen samojedischen Völkern Sibiriens benannt?",
  "a": [
   "Samojede",
   "Alaskan Malamute",
   "Siberian Husky",
   "American Eskimo Dog"
  ]
 },
 "q2162": {
  "q": "Welche afrikanische Jagdhunderasse ist sofort an einem Haarstreifen entlang der Wirbelsäule erkennbar, der in die entgegengesetzte Richtung wächst?",
  "a": [
   "Rhodesian Ridgeback",
   "Pharaonenhund",
   "Podenco Ibicenco",
   "Azawakh"
  ]
 },
 "q2163": {
  "q": "Welche schlanke Wachhunderasse wurde um 1890 in Thüringen von dem Steuereintreiber Karl Friedrich Louis Dobermann gezüchtet?",
  "a": [
   "Dobermann",
   "Rottweiler",
   "Boxer",
   "Weimaraner"
  ]
 },
 "q2164": {
  "q": "Welche ungarische Herdenschutzhunderasse ist berühmt für ihr schweres, weißes, zotteliges Schnürenfell?",
  "a": [
   "Komondor",
   "Kuvasz",
   "Magyar Vizsla",
   "Mudi"
  ]
 },
 "q2165": {
  "q": "Welche alte haarlose Hunderasse aus Mexiko ist nach dem aztekischen Gott Xolotl benannt?",
  "a": [
   "Xoloitzcuintle",
   "Peruanischer Nackthund",
   "Chinesischer Schopfhund",
   "American Hairless Terrier"
  ]
 },
 "q2166": {
  "q": "Welche kleine, schwanzlose Vorstehhundrasse stammt aus der Bretagne in Frankreich und wird oft den Settern und Spaniels zugeordnet?",
  "a": [
   "Epagneul Breton",
   "Magyar Vizsla",
   "English Springer Spaniel",
   "Deutsch Kurzhaar"
  ]
 },
 "q2167": {
  "q": "Welche hochgewachsene, schlanke Windhundrasse aus dem Nahen Osten gehört zu den ältesten domestizierten Hunderassen und wurde von Beduinen zur Gazellenjagd geschätzt?",
  "a": [
   "Saluki",
   "Whippet",
   "Italienisches Windspiel",
   "Sloughi"
  ]
 },
 "q2168": {
  "q": "Welche traditionelle bulgarische Herdenschutzhunderasse ist nach den nomadischen Karakatschanen-Hirten des Balkans benannt?",
  "a": [
   "Karakatschan",
   "Šarplaninac",
   "Tornjak",
   "Kaukasischer Owtscharka"
  ]
 },
 "q2169": {
  "q": "Welche norwegische Papageitaucher-Jagdhunderasse ist einzigartig dafür bekannt, sechs Zehen an jeder Pfote zu haben und den Kopf nach hinten bis zur Wirbelsäule biegen zu können?",
  "a": [
   "Norwegischer Lundehund",
   "Norwegischer Elchhund",
   "Finnenspitz",
   "Schwedischer Vallhund"
  ]
 },
 "q2170": {
  "q": "Welche seltene türkische Jagdhunderasse zeichnet sich durch ihre gespaltene Nase mit einer tiefen vertikalen Furche zwischen den Nasenlöchern aus?",
  "a": [
   "Çatalburun",
   "Kangal-Hirtenhund",
   "Akbash",
   "Anatolischer Hirtenhund"
  ]
 },
 "q2171": {
  "q": "Welcher rotbraune, kaninchenjagende Windhund ist der Nationalhund Maltas, wo er lokal als Kelb tal-Fenek bekannt ist?",
  "a": [
   "Pharaonenhund",
   "Cirneco dell’Etna",
   "Podenco Canario",
   "Podengo Português"
  ]
 },
 "q2172": {
  "q": "Welche seltene Herdenschutzhunderasse stammt aus dem Gebirge Serra da Estrela in Portugal?",
  "a": [
   "Cão da Serra da Estrela",
   "Cão de Castro Laboreiro",
   "Rafeiro do Alentejo",
   "Cão Fila de São Miguel"
  ]
 },
 "q2173": {
  "q": "Welche alte Windhundrasse, die von den Tuareg-Nomaden der Sahara gezüchtet wurde, ist nach einem Tal benannt, das sich über Mali und Niger erstreckt?",
  "a": [
   "Azawakh",
   "Sloughi",
   "Saluki",
   "Taigan"
  ]
 },
 "q2174": {
  "q": "Welche dicht behaarte Hunderasse vom Spitz-Typ aus den Niederlanden wurde historisch auf Kanalbooten gehalten und trägt den Spitznamen Lächelnder Holländer?",
  "a": [
   "Wolfsspitz",
   "Schipperke",
   "Hollandse Herder",
   "Stabyhoun"
  ]
 },
 "q2175": {
  "q": "Welche seltene Laufhundrasse aus den Bergen Kroatiens gehört zu den ältesten einheimischen Jagdhunderassen des Balkans?",
  "a": [
   "Istrischer kurzhaariger Laufhund",
   "Posavski Gonič",
   "Dalmatiner",
   "Tornjak"
  ]
 },
 "q2176": {
  "q": "Welche seltene alte Hunderasse aus Thailand zeichnet sich durch einen Haarkamm entlang des Rückens aus, der entgegengesetzt zum übrigen Fell wächst?",
  "a": [
   "Thai Ridgeback",
   "Thai Bangkaew Dog",
   "Phu Quoc Ridgeback",
   "Kintamani"
  ]
 },
 "q2177": {
  "q": "Welche seltene Wasserhundrasse aus den nördlichen Niederlanden wurde historisch von Fischern eingesetzt, um aus den Netzen gefallene Fische zu apportieren?",
  "a": [
   "Wetterhoun",
   "Stabyhoun",
   "Drentsche Patrijshond",
   "Nederlandse Kooikerhondje"
  ]
 },
 "q2178": {
  "q": "Welche seltene Hirtenhundrasse aus der Region Serra da Arrábida in Portugal ist auch als Portugiesischer Schäferhund bekannt?",
  "a": [
   "Cão da Serra de Aires",
   "Cão de Castro Laboreiro",
   "Rafeiro do Alentejo",
   "Perdigueiro Português"
  ]
 },
 "q2179": {
  "q": "Welche mittelgroße, weiß-orangefarbene Laufhundrasse aus Frankreich ist nach einer historischen Region im Osten Frankreichs benannt?",
  "a": [
   "Porcelaine",
   "Petit Basset Griffon Vendéen",
   "Billy",
   "Poitevin"
  ]
 },
 "q2180": {
  "q": "Welche seltene Sennenhundrasse aus dem Appenzellerland in der Schweiz gehört zu den vier Schweizer Sennenhundrassen und trägt ihre Rute geringelt über dem Rücken?",
  "a": [
   "Appenzeller Sennenhund",
   "Entlebucher Sennenhund",
   "Berner Sennenhund",
   "Grosser Schweizer Sennenhund"
  ]
 },
 "q2181": {
  "q": "Welche seltene Laufhundrasse aus dem Juragebirge entlang der französisch-schweizerischen Grenze ist eine der vier Varietäten des Schweizer Laufhunds?",
  "a": [
   "Jura Laufhund",
   "Berner Laufhund",
   "Luzerner Laufhund",
   "Schwyzer Laufhund"
  ]
 },
 "q2182": {
  "q": "Welche seltene Wasserhundrasse aus der Teilregion Romagna in Italien ist berühmt für ihren feinen Geruchssinn bei der Trüffelsuche?",
  "a": [
   "Lagotto Romagnolo",
   "Spinone Italiano",
   "Bracco Italiano",
   "Bergamasker Hirtenhund"
  ]
 },
 "q2183": {
  "q": "Welcher protobulgarische Herrscher gründete im Jahr 681 das Erste Bulgarische Reich südlich der Donau?",
  "a": [
   "Khan Asparuch",
   "Khan Krum",
   "Khan Kubrat",
   "Khan Terwel"
  ]
 },
 "q2184": {
  "q": "Welche Stadt diente von 681 bis 893 als erste Hauptstadt des Ersten Bulgarischen Reiches?",
  "a": [
   "Pliska",
   "Preslaw",
   "Tarnowo",
   "Ohrid"
  ]
 },
 "q2185": {
  "q": "Wer war der Gründer und Herrscher des Stammesverbandes Großbulgarien im 7. Jahrhundert?",
  "a": [
   "Khan Kubrat",
   "Khan Asparuch",
   "Khan Omurtag",
   "Khan Kardam"
  ]
 },
 "q2186": {
  "q": "Welche oberste Himmelsgottheit verehrten die heidnischen Protobulgaren vor ihrer Christianisierung?",
  "a": [
   "Tangra",
   "Perun",
   "Weles",
   "Zalmoxis"
  ]
 },
 "q2187": {
  "q": "Welches frühmittelalterliche Felsrelief in Nordostbulgarien zeigt einen Reiter, der einen Löwen mit einem Speer durchbohrt?",
  "a": [
   "Reiter von Madara",
   "Reiter von Pirin",
   "Krieger von Rila",
   "Lanzenreiter von Pliska"
  ]
 },
 "q2188": {
  "q": "Welcher bulgarische Herrscher des 9. Jahrhunderts erließ die ersten geschriebenen Gesetze Bulgariens und besiegte 811 Kaiser Nikephoros I.?",
  "a": [
   "Khan Krum",
   "Knjas Boris I.",
   "Khan Malamir",
   "Khan Presian"
  ]
 },
 "q2189": {
  "q": "Welcher bulgarische Herrscher verhalf dem byzantinischen Kaiser Justinian II. 705 wieder auf den Thron und half 717–718 bei der Verteidigung Konstantinopels gegen die Araber?",
  "a": [
   "Khan Terwel",
   "Khan Sewar",
   "Khan Kormisosch",
   "Khan Telerig"
  ]
 },
 "q2190": {
  "q": "Welcher bulgarische Herrscher des 9. Jahrhunderts schloss 815 den Dreißigjährigen Frieden mit Byzanz und ist für umfangreiche Bautätigkeiten in Pliska bekannt?",
  "a": [
   "Khan Omurtag",
   "Khan Winech",
   "Khan Sabin",
   "Khan Pagan"
  ]
 },
 "q2191": {
  "q": "In welchem befestigten Sumpfgebiet nahe dem Donaudelta besiegte der bulgarische Khan Asparuch, der Gründer des bulgarischen Staates, im Jahr 680 den byzantinischen Kaiser Konstantin IV.?",
  "a": [
   "Ongal",
   "Warbiza-Pass",
   "Anchialos",
   "Markellai"
  ]
 },
 "q2192": {
  "q": "Welchen Gegenstand benutzte der sterbende Khan Kubrat, Herrscher des Alten Großbulgarien, in der berühmten bulgarischen Legende, um seinen Söhnen die Kraft der Einigkeit zu zeigen?",
  "a": [
   "Ein Bündel Ruten",
   "Einen Köcher voller Pfeile",
   "Eine Garbe Weizen",
   "Eine Eisenkette"
  ]
 },
 "q2193": {
  "q": "Welcher protobulgarischen Herrscherdynastie entstammten Herrscher wie Kubrat, Asparuch und Terwel?",
  "a": [
   "Dulo",
   "Wokil",
   "Ugain",
   "Ermiar"
  ]
 },
 "q2194": {
  "q": "Welcher Sohn von Khan Kubrat führte eine Gruppe von Protobulgaren nach Norden und gründete Wolgabulgarien?",
  "a": [
   "Kotrag",
   "Batbajan",
   "Kuber",
   "Alzek"
  ]
 },
 "q2195": {
  "q": "Welcher Sohn von Khan Kubrat führte seine protobulgarischen Gefolgsleute nach Süditalien und ließ sich im Herzogtum Benevent nieder?",
  "a": [
   "Alzek",
   "Kotrag",
   "Batbajan",
   "Asparuch"
  ]
 },
 "q2196": {
  "q": "Welcher Sohn von Khan Kubrat führte Ende des 7. Jahrhunderts eine Gruppe von Protobulgaren nach Makedonien und ließ sich um Bitola nieder?",
  "a": [
   "Kuber",
   "Batbajan",
   "Kotrag",
   "Alzek"
  ]
 },
 "q2197": {
  "q": "Wer war der älteste Sohn von Khan Kubrat, der in den Stammlanden Großbulgariens blieb und sich den Chasaren unterwarf?",
  "a": [
   "Batbajan",
   "Asparuch",
   "Kotrag",
   "Kuber"
  ]
 },
 "q2198": {
  "q": "Welchen Titel trug der Stellvertreter des Herrschers und oberste Heerführer im Ersten Bulgarischen Reich?",
  "a": [
   "Kawchan",
   "Itschirgu-Boil",
   "Tarkan",
   "Bagatur"
  ]
 },
 "q2199": {
  "q": "Welchen Titel trug der dritthöchste Würdenträger im Ersten Bulgarischen Reich, der die Garnison der Hauptstadt befehligte?",
  "a": [
   "Itschirgu-Boil",
   "Kawchan",
   "Sera-Tarkan",
   "Kolobar"
  ]
 },
 "q2200": {
  "q": "Der Schwanz welches Tieres diente den frühen Protobulgaren als Kriegsbanner und Machtsymbol?",
  "a": [
   "Pferdeschwanz",
   "Wolfsschwanz",
   "Fuchsschwanz",
   "Wisentschwanz"
  ]
 },
 "q2201": {
  "q": "Wie viele Jahre umfasste ein vollständiger Zyklus im alten protobulgarischen Kalendersystem?",
  "a": [
   "12 Jahre",
   "7 Jahre",
   "10 Jahre",
   "19 Jahre"
  ]
 },
 "q2202": {
  "q": "Wie heißt die kurze mittelalterliche Chronik, die die Genealogie und Regierungsjahre der frühen bulgarischen Herrscher enthält?",
  "a": [
   "Bulgarische Fürstenliste",
   "Chronik von Pliska",
   "Annalen von Madara",
   "Buch der Dulo"
  ]
 },
 "q2203": {
  "q": "Wie hieß der heidnische Priester und Schamane bei den frühen Protobulgaren, der vor Schlachten Weissagungen durchführte?",
  "a": [
   "Kolobar",
   "Bagain",
   "Boil",
   "Tarkan"
  ]
 },
 "q2204": {
  "q": "In der Nähe welcher heutigen ukrainischen Ortschaft wurde 1912 der reiche Grabschatz aus dem 7. Jahrhundert entdeckt, der Khan Kubrat, dem Herrscher des Alten Großbulgarien, zugeschrieben wird?",
  "a": [
   "Mala Pereschtschepyna",
   "Trypillja",
   "Berestetschko",
   "Baturyn"
  ]
 },
 "q2205": {
  "q": "Welcher bulgarische Khan des 8. Jahrhunderts beendete eine schwere politische Krise in Bulgarien und stellte um 768–777 die Stabilität wieder her?",
  "a": [
   "Khan Telerig",
   "Khan Sabin",
   "Khan Umor",
   "Khan Toktu"
  ]
 },
 "q2206": {
  "q": "Welcher bulgarische Khan des 8. Jahrhunderts besiegte im Jahr 792 den byzantinischen Kaiser Konstantin VI. in der Schlacht von Markellai?",
  "a": [
   "Khan Kardam",
   "Khan Kormisosch",
   "Khan Winech",
   "Khan Telez"
  ]
 },
 "q2207": {
  "q": "Wer war der letzte protobulgarische Herrscher aus der Dulo-Dynastie vor dem Aufstieg des Wokil-Klans Mitte des 8. Jahrhunderts?",
  "a": [
   "Khan Sewar",
   "Khan Terwel",
   "Khan Kormisosch",
   "Khan Asparuch"
  ]
 },
 "q2208": {
  "q": "Was ließ der bulgarische Khan Krum byzantinischen Chroniken zufolge nach der Schlacht am Warbiza-Pass im Jahr 811 aus dem Schädel von Kaiser Nikephoros I. anfertigen?",
  "a": [
   "Einen silberbeschlagenen Trinkbecher",
   "Einen Kampfhelm",
   "Eine Zeremonientrommel",
   "Eine Königskrone"
  ]
 },
 "q2209": {
  "q": "In welcher Sprache wurden die meisten erhaltenen offiziellen Steininschriften der heidnischen protobulgarischen Khane verfasst?",
  "a": [
   "Griechisch",
   "Latein",
   "Altkirchenslawisch",
   "Arabisch"
  ]
 },
 "q2210": {
  "q": "Welcher Sammelbegriff wurde im Ersten Bulgarischen Reich für die Aristokraten und den Hochadel verwendet?",
  "a": [
   "Boilen",
   "Smerden",
   "Druschina",
   "Woiwoden"
  ]
 },
 "q2211": {
  "q": "Welcher Begriff bezeichnete bei den frühen Protobulgaren den niederen Militäradel, der den Boilen unterstand?",
  "a": [
   "Bagaine",
   "Kawchane",
   "Kolobare",
   "Knjasen"
  ]
 },
 "q2212": {
  "q": "Welcher bulgarische Herrscher des 9. Jahrhunderts schlug nach der Annahme des Christentums im Jahr 864 einen heidnischen Aufstand von 52 Boilen-Familien nieder?",
  "a": [
   "Boris I.",
   "Simeon I.",
   "Presian I.",
   "Omurtag"
  ]
 },
 "q2213": {
  "q": "In welcher Inschrift aus dem 9. Jahrhundert stellt Khan Omurtag fest, dass ein Mensch, selbst wenn er gut lebt, stirbt und ein anderer geboren wird?",
  "a": [
   "Inschrift von Tarnowo",
   "Inschrift von Madara",
   "Inschrift von Tschatalar",
   "Inschrift von Preslaw"
  ]
 },
 "q2214": {
  "q": "Welchen Titel verwendeten die frühen protobulgarischen Herrscher auf offiziellen Steininschriften vor der Annahme des Titels Knjas im Jahr 864?",
  "a": [
   "Kanasubigi",
   "Basileus",
   "Weliki Knjas",
   "Despot"
  ]
 },
 "q2215": {
  "q": "Welchen Titel verlieh der byzantinische Kaiser Justinian II. im Jahr 705 an den bulgarischen Khan Terwel, wodurch dieser ihn als erster ausländischer Herrscher erhielt?",
  "a": [
   "Caesar",
   "Augustus",
   "Patrikios",
   "Sebastokrator"
  ]
 },
 "q2216": {
  "q": "Wie heißt die traditionelle runde, tragbare Filzbehausung, die die frühen nomadischen Protobulgaren vor ihrer Sesshaftwerdung in Steinfestungen nutzten?",
  "a": [
   "Jurte",
   "Tipi",
   "Iglu",
   "Wigwam"
  ]
 },
 "q2217": {
  "q": "Welches hypothetische feuerähnliche Element wurde im 18. Jahrhundert bei der Verbrennung freigesetzt geglaubt?",
  "a": [
   "Phlogiston",
   "Caloricum",
   "Äther",
   "Ektoplasma"
  ]
 },
 "q2218": {
  "q": "Welcher berühmte paläoanthropologische Schwindel von 1912 in England kombinierte einen menschlichen Schädel mit einem Orang-Utan-Kiefer?",
  "a": [
   "Piltdown-Mensch",
   "Java-Mensch",
   "Peking-Mensch",
   "Nebraska-Mensch"
  ]
 },
 "q2219": {
  "q": "Welcher hypothetische Planet zwischen Merkur und Sonne wurde 1859 vorgeschlagen, um Merkurs Bahnunstimmigkeiten zu erklären?",
  "a": [
   "Vulkan",
   "Nibiru",
   "Phaeton",
   "Theia"
  ]
 },
 "q2220": {
  "q": "Welche illusorische Strahlungsart behauptete der französische Physiker Prosper-René Blondlot 1903 entdeckt zu haben?",
  "a": [
   "N-Strahlen",
   "T-Strahlen",
   "Z-Strahlen",
   "Deltastrahlen"
  ]
 },
 "q2221": {
  "q": "Welches unsichtbare Medium postulierten Physiker des 19. Jahrhunderts vor Einsteins spezieller Relativitätstheorie als Träger von Lichtwellen?",
  "a": [
   "Lichtäther",
   "Dunkle Materie",
   "Phlogiston",
   "Quantenschaum"
  ]
 },
 "q2222": {
  "q": "Welche umstrittene Kernreaktion bei Raumtemperatur behaupteten Martin Fleischmann und Stanley Pons 1989 erreicht zu haben?",
  "a": [
   "Kalte Fusion",
   "Myonen-katalysierte Fusion",
   "Blasenfusion",
   "Pyroelektrische Fusion"
  ]
 },
 "q2223": {
  "q": "Welche widerlegte medizinische Theorie des 19. Jahrhunderts besagte, dass Krankheiten wie Cholera durch giftige schlechte Luft verursacht wurden?",
  "a": [
   "Miasmentheorie",
   "Humoralpathologie",
   "Keimtheorie",
   "Urzeugung"
  ]
 },
 "q2224": {
  "q": "Welche anomale Form von polymerisiertem Wasser, über die sowjetische Wissenschaftler in den 1960er Jahren berichteten, erwies sich als verunreinigtes normales Wasser?",
  "a": [
   "Polywasser",
   "Schweres Wasser",
   "Hexagonales Wasser",
   "Deuteriertes Wasser"
  ]
 },
 "q2225": {
  "q": "Welche irrtümliche Beobachtung von Giovanni Schiaparelli im 19. Jahrhundert ließ viele glauben, auf dem Mars gäbe es künstliche Bewässerungsnetze?",
  "a": [
   "Marskanäle",
   "Marspyramiden",
   "Marsozeane",
   "Marskrater"
  ]
 },
 "q2226": {
  "q": "Welche diskreditierte Pseudowissenschaft des 19. Jahrhunderts behauptete, Persönlichkeitsmerkmale durch Ertasten von Schädelwölbungen zu bestimmen?",
  "a": [
   "Phrenologie",
   "Physiognomik",
   "Graphologie",
   "Handlesekunst"
  ]
 },
 "q2227": {
  "q": "Welches hypothetische Fluidum floss nach Ansicht des 18. Jahrhunderts bei der Wärmeübertragung von wärmeren zu kälteren Körpern?",
  "a": [
   "Caloricum",
   "Phlogiston",
   "Äther",
   "Ektoplasma"
  ]
 },
 "q2228": {
  "q": "Welchen winzigen, vollständig geformten Miniaturmenschen glaubten frühe Mikroskopiker in jeder Samenzelle zu erkennen?",
  "a": [
   "Homunkulus",
   "Golem",
   "Chimäre",
   "Zygote"
  ]
 },
 "q2229": {
  "q": "Von welchem arsenhaltigen Bakterium behaupteten von der NASA finanzierte Forscher 2010 umstritten, es könne Phosphor in seiner DNA durch Arsen ersetzen?",
  "a": [
   "GFAJ-1",
   "Escherichia coli",
   "Thermus aquaticus",
   "Deinococcus radiodurans"
  ]
 },
 "q2230": {
  "q": "Welcher 1922 in Nebraska gefundene fossile Zahn wurde kurzzeitig als erster Menschenaffe Nordamerikas gefeiert, bevor er als Pekari-Zahn erkannt wurde?",
  "a": [
   "Nebraska-Mensch",
   "Piltdown-Mensch",
   "Kind von Taung",
   "Heidelberg-Mensch"
  ]
 },
 "q2231": {
  "q": "Welche widerlegte biologische Theorie besagte, dass lebende Organismen regelmäßig aus unbelebter Materie wie verrottendem Fleisch entstehen?",
  "a": [
   "Urzeugung",
   "Panspermie",
   "Endosymbiose",
   "Punktualismus"
  ]
 },
 "q2232": {
  "q": "Welche vermeintlich neue Art pluripotenter Stammzellen, die 2014 von Haruko Obokata in Nature vorgestellt wurde, wurde nach gescheiterter Replikation zurückgezogen?",
  "a": [
   "STAP-Zellen",
   "iPS-Zellen",
   "HeLa-Zellen",
   "T-Zellen"
  ]
 },
 "q2233": {
  "q": "Welches CERN-Experiment von 2011 wurde später auf ein lockeres Glasfaserkabel zurückgeführt, nachdem es scheinbar überlichtschnelle Teilchen gezeigt hatte?",
  "a": [
   "OPERA",
   "ATLAS",
   "ALICE",
   "LHCb"
  ]
 },
 "q2234": {
  "q": "Welcher hypothetische versunkene Kontinent im Indischen Ozean wurde 1864 vorgeschlagen, um Lemurenfossilien auf Madagaskar und in Indien zu erklären?",
  "a": [
   "Lemuria",
   "Atlantis",
   "Mu",
   "Zealandia"
  ]
 },
 "q2235": {
  "q": "Welche paläontologische Fälschung von 1999 in China kombinierte fälschlicherweise den Körper eines Vogels mit dem Schwanz eines Dromaeosauriers?",
  "a": [
   "Archaeoraptor",
   "Archaeopteryx",
   "Microraptor",
   "Velociraptor"
  ]
 },
 "q2236": {
  "q": "Welche überholte geologische Theorie des 19. Jahrhunderts erklärte Gebirge als Falten, die beim Abkühlen und Schrumpfen der Erde wie bei einem trocknenden Apfel entstanden?",
  "a": [
   "Kontraktionstheorie",
   "Plattentektonik",
   "Kontinentaldrift",
   "Ozeanbodenspreizung"
  ]
 },
 "q2237": {
  "q": "Welche irrtümliche astronomische Entdeckung von 1991 um den Pulsar PSR B1829-10 wurde zurückgezogen, weil Forscher die elliptische Erdbahn vergessen hatten?",
  "a": [
   "Erster Exoplanet",
   "Erstes Schwarzes Loch",
   "Erster Quasar",
   "Erster Neutronenstern"
  ]
 },
 "q2238": {
  "q": "Welche Entdeckung des BICEP2-Teleskops von 2014 über das frühe Universum erwies sich später als durch interstellaren Staub der Milchstraße verursacht?",
  "a": [
   "Primordiale Gravitationswellen",
   "Kosmische Hintergrundstrahlung",
   "Beschleunigung der dunklen Energie",
   "Hawking-Strahlung"
  ]
 },
 "q2239": {
  "q": "Welche falsche Chromosomenzahl für den Menschen aus dem Jahr 1921 stand bis 1956 in Lehrbüchern, bevor Joe Hin Tjio bewies, dass es 46 sind?",
  "a": [
   "48",
   "44",
   "42",
   "50"
  ]
 },
 "q2240": {
  "q": "Welches vermeintlich neue Element im Seltenerdmineral Gadolinit wurde 1841 von Carl Mosander beansprucht, bevor es sich als Gemisch erwies?",
  "a": [
   "Didym",
   "Coronium",
   "Nebulium",
   "Alabamin"
  ]
 },
 "q2241": {
  "q": "Welches hypothetische chemische Element schlug William Huggins 1864 vor, um mysteriöse grüne Emissionslinien in planetarischen Nebeln zu erklären?",
  "a": [
   "Nebulium",
   "Coronium",
   "Helium",
   "Vulcanium"
  ]
 },
 "q2242": {
  "q": "Welche Phantominsel im Korallenmeer erschien auf Karten und in Google Earth, bis eine australische Expedition 2012 bewies, dass dort nur offener Ozean liegt?",
  "a": [
   "Sandy Island",
   "Bermeja",
   "Hy-Brasil",
   "Thule"
  ]
 },
 "q2243": {
  "q": "Welche vermeintliche Eigenschaft von Wasser behauptete der französische Immunologe Jacques Benveniste 1988, wodurch es nach extremer Verdünnung biologisch aktiv bleibe?",
  "a": [
   "Wassergedächtnis",
   "Polywasser",
   "Schweres Wasser",
   "Strukturiertes Wasser"
  ]
 },
 "q2244": {
  "q": "Von welchem großen Dinosaurier glaubte man lange, er habe wegen einer erweiterten Wirbelkanalhöhle ein zweites Gehirn in der Hüfte?",
  "a": [
   "Stegosaurus",
   "Tyrannosaurus",
   "Triceratops",
   "Velociraptor"
  ]
 },
 "q2245": {
  "q": "Welches irrtümliche Diagramm des deutschen Arztes David Hänig von 1901 führte zu dem Mythos, verschiedene Zungenbereiche schmeckten nur bestimmte Geschmäcker?",
  "a": [
   "Geschmackszonen der Zunge",
   "Homunkulus-Karte",
   "Phrenologie-Karte",
   "Dermatome"
  ]
 },
 "q2246": {
  "q": "Welcher 1879 entdeckte riesige Sauropode wurde 1903 für ungültig erklärt, bevor er 2015 wieder als eigene Gattung neben Apatosaurus anerkannt wurde?",
  "a": [
   "Brontosaurus",
   "Diplodocus",
   "Brachiosaurus",
   "Allosaurus"
  ]
 },
 "q2247": {
  "q": "Welcher vermeintliche Tiefsee-Urorganismus, den Thomas Henry Huxley 1868 benannte, erwies sich als chemischer Niederschlag aus Alkohol und Meerwasser?",
  "a": [
   "Bathybius haeckelii",
   "Pikaia gracilens",
   "Anomalocaris",
   "Hallucigenia"
  ]
 },
 "q2248": {
  "q": "In welcher Jahreszeit fliegen die meisten Zugvögel der Nordhalbkugel nach Süden?",
  "a": [
   "Herbst",
   "Frühling",
   "Sommer",
   "Winter"
  ]
 },
 "q2249": {
  "q": "Welche Vogelart unternimmt die längste jährliche Wanderung von der Arktis in die Antarktis und zurück?",
  "a": [
   "Küstenseeschwalbe",
   "Wanderalbatros",
   "Rauchschwalbe",
   "Kaiserpinguin"
  ]
 },
 "q2250": {
  "q": "Warum fliegen große Zugvögel wie Gänse oft in einer V-förmigen Formation?",
  "a": [
   "Um mithilfe von Luftströmungen Energie zu sparen",
   "Um Greifvögel abzuschrecken",
   "Um ihre Augen vor Sonnenlicht zu schützen",
   "Um ständigen Körperkontakt zu halten"
  ]
 },
 "q2251": {
  "q": "Welches unsichtbare planetare Feld nehmen viele Zugvögel wahr, um sich über weite Strecken zu orientieren?",
  "a": [
   "Das Erdmagnetfeld",
   "Gravitationalanomalien der Erde",
   "Atmosphärische Strahlungsgürtel",
   "Ozeanische elektrische Ströme"
  ]
 },
 "q2252": {
  "q": "Wie lautet der Fachbegriff für die starke Unruhe, die gekäfigte Zugvögel zur Zugzeit zeigen?",
  "a": [
   "Zugunruhe",
   "Torpor",
   "Ästivation",
   "Häutung"
  ]
 },
 "q2253": {
  "q": "Welcher Watvogel hält den Rekord für den längsten Nonstop-Flug ohne Nahrungsaufnahme über 13.000 km von Alaska nach Tasmanien?",
  "a": [
   "Pfuhlschnepfe",
   "Knutt",
   "Steinwälzer",
   "Sanderling"
  ]
 },
 "q2254": {
  "q": "Welcher große schwarz-weiße Zugvogel ist in Europa dafür bekannt, riesige Reisignester auf Dächern und Schornsteinen zu bauen?",
  "a": [
   "Weißstorch",
   "Höckerschwan",
   "Graureiher",
   "Kormoran"
  ]
 },
 "q2255": {
  "q": "Welche Zugvogel-Gänseart überfliegt den Himalaya in Höhen von über 8.000 Metern?",
  "a": [
   "Streifengans",
   "Kanadagans",
   "Graugans",
   "Schneegans"
  ]
 },
 "q2256": {
  "q": "Welche schmale Meerenge zwischen Spanien und Marokko ist ein wichtiger Engpass für segelnde Zugvögel?",
  "a": [
   "Straße von Gibraltar",
   "Straße von Messina",
   "Straße von Dover",
   "Bosporus"
  ]
 },
 "q2257": {
  "q": "Wie nennt man die rasche Gewichtszunahme und Fettanreicherung bei Vögeln unmittelbar vor dem Vogelzug?",
  "a": [
   "Hyperphagie",
   "Winterschlaf",
   "Mauser",
   "Brutparasitismus"
  ]
 },
 "q2258": {
  "q": "Welches lichtempfindliche Protein in der Netzhaut von Zugvögeln ermöglicht vermutlich die Quanten-Magnetorezeption?",
  "a": [
   "Cryptochrom",
   "Rhodopsin",
   "Melanin",
   "Hämoglobin"
  ]
 },
 "q2259": {
  "q": "Welcher antike griechische Philosoph nahm fälschlicherweise an, dass Schwalben im Winter unter Wasser im Schlamm überwintern?",
  "a": [
   "Aristoteles",
   "Platon",
   "Herodot",
   "Hippokrates"
  ]
 },
 "q2260": {
  "q": "1822 bewies ein in Deutschland geschossener Weißstorch den Vogelzug nach Afrika, weil was in seinem Hals steckte?",
  "a": [
   "Ein afrikanischer Speer",
   "Eine römische Goldmünze",
   "Ein Pharaonensiegel",
   "Eine ägyptische Papyrusrolle"
  ]
 },
 "q2261": {
  "q": "Welche aufsteigenden Warmluftsäulen nutzen große Zugvögel wie Adler und Störche, um ohne Flügelschlag an Höhe zu gewinnen?",
  "a": [
   "Thermik",
   "Jetstreams",
   "Passatwinde",
   "Katabatische Winde"
  ]
 },
 "q2262": {
  "q": "Welcher insektenfressende Vogel verbringt fast sein gesamtes Leben außerhalb der Brutzeit in der Luft und schläft sogar im Flug?",
  "a": [
   "Mauersegler",
   "Wanderfalke",
   "Rotkehlchen",
   "Schleiereule"
  ]
 },
 "q2263": {
  "q": "Wie schlafen viele ziehende Singvögel während mehrtägiger Nonstop-Flüge über Ozeane?",
  "a": [
   "Indem jeweils eine Gehirnhälfte ruht",
   "Indem sie nachts auf Meereswellen treiben",
   "Indem sie mit geschlossenen Augen gleiten",
   "Indem sie sich auf größere Vögel setzen"
  ]
 },
 "q2264": {
  "q": "Warum ziehen viele kleine Singvögel nachts statt tagsüber?",
  "a": [
   "Um Tagraubvögeln zu entgehen und kühlere Luft zu nutzen",
   "Weil ihre Flügel in warmer Luft nicht tragen",
   "Um nachtaktive Fledermäuse zu jagen",
   "Weil Mondlicht ihnen Vitamin D liefert"
  ]
 },
 "q2265": {
  "q": "Wie heißt die traditionelle ornithologische Methode, bei der einem Vogel ein kleiner nummerierter Metallring zur Zugforschung angelegt wird?",
  "a": [
   "Vogelberingung",
   "Falknereigeschüh",
   "Kupieren",
   "Tätowierung"
  ]
 },
 "q2266": {
  "q": "Welche bedeutende europäische Zugvogelroute verläuft entlang der Westküste des Schwarzen Meeres durch Bulgarien?",
  "a": [
   "Via Pontica",
   "Via Egnatia",
   "Via Appia",
   "Via Francigena"
  ]
 },
 "q2267": {
  "q": "Welche winzige Kolibriart fliegt über 800 km ohne Zwischenstopp über den Golf von Mexiko?",
  "a": [
   "Rubinkehlkolibri",
   "Bienenelfe",
   "Schwertschabelkolibri",
   "Riesenkolibri"
  ]
 },
 "q2268": {
  "q": "Wie nennt man Vögel, die zwischen Sommer und Winter Berghänge auf- und abwärts ziehen, statt nach Norden und Süden zu fliegen?",
  "a": [
   "Höhenzieher",
   "Pelagische Wanderer",
   "Invasionsvögel",
   "Standvögel"
  ]
 },
 "q2269": {
  "q": "Welcher große Greifvogel zieht jährlich von Europa ins Afrika südlich der Sahara fast ausschließlich durch Segeln in der Thermik?",
  "a": [
   "Schreiadler",
   "Schneeeule",
   "Eisvogel",
   "Papageitaucher"
  ]
 },
 "q2270": {
  "q": "Welchen Bereich des Nachthimmels nutzen nachtziehende Vögel auf der Nordhalbkugel als Drehzentrum für die Sternennavigation?",
  "a": [
   "Die Sterne rund um den Polarstern",
   "Den Orionnebel",
   "Das Zentrum der Milchstraße",
   "Das Kreuz des Südens"
  ]
 },
 "q2271": {
  "q": "Welcher Zugvogel Europas ist dafür bekannt, seine Eier in die Nester anderer Vogelarten zu legen?",
  "a": [
   "Kuckuck",
   "Stieglitz",
   "Rauchschwalbe",
   "Kohlmeise"
  ]
 },
 "q2272": {
  "q": "Wie lautet der Fachbegriff für die ausgeprägte Neigung von Zugvögeln, jedes Jahr an exakt denselben Brutplatz zurückzukehren?",
  "a": [
   "Philopatrie",
   "Allopatrie",
   "Sympatrie",
   "Polyandrie"
  ]
 },
 "q2273": {
  "q": "Welche inneren Organe verkleinern Langstreckenzieher wie Pfuhlschnepfen vor dem Abflug vorübergehend, um Gewicht und Energie zu sparen?",
  "a": [
   "Verdauungsorgane",
   "Herz und Lunge",
   "Gehirn und Augen",
   "Nieren und Milz"
  ]
 },
 "q2274": {
  "q": "Welcher große rosa Watvogel zieht zwischen Südeuropa und Afrika und verdankt seine Farbe Carotinoid-Pigmenten in seiner Nahrung?",
  "a": [
   "Rosaflamingo",
   "Rosalöffler",
   "Scharlachsichler",
   "Kurzschnabelgans"
  ]
 },
 "q2275": {
  "q": "Welches Flusstal in Nordamerika gibt dem zentralen Vogelzugkorridor von Kanada bis zum Golf von Mexiko seinen Namen?",
  "a": [
   "Mississippi",
   "Colorado",
   "Hudson",
   "Columbia"
  ]
 },
 "q2276": {
  "q": "Wie nennt man das Phänomen, bei dem Vögel durch Stürme oder Navigationsfehler weit abseits ihrer normalen Zugroute auftreten?",
  "a": [
   "Irrgast-Verhalten",
   "Echoortung",
   "Winterstarre",
   "Parthenogenese"
  ]
 },
 "q2277": {
  "q": "Welcher Seevogel fliegt jährlich in Achter-Schleifen über den gesamten Pazifik und legt dabei bis zu 64.000 km zurück?",
  "a": [
   "Dunkelsturmtaucher",
   "Prachtfregattvogel",
   "Blaufußtölpel",
   "Braunpelikan"
  ]
 },
 "q2278": {
  "q": "Welche Technologie ermöglicht es Meteorologen, riesige Schwärme nachtziehender Vögel auf Wetterkarten zu verfolgen?",
  "a": [
   "Doppler-Wetterradar",
   "Seismographen",
   "Sonarbojen",
   "Geigerzähler"
  ]
 },
 "q2279": {
  "q": "Welcher große nordamerikanische Schreitvogel ist dafür bekannt, dass ihm seine Zugroute von Piloten in Ultraleichtflugzeugen beigebracht wurde?",
  "a": [
   "Schreikranich",
   "Weißkopfseeadler",
   "Wildtruthahn",
   "Kalifornischer Kondor"
  ]
 },
 "q2280": {
  "q": "Warum stellen helle Stadtlichter eine große Bedrohung für nachtziehende Vögel dar?",
  "a": [
   "Sie verwirren die Vögel und führen zu Kollisionen mit Gebäuden",
   "Sie machen die Vögel auf einem Auge dauerhaft blind",
   "Sie locken nachts Schwärme von Adlern an",
   "Sie schmelzen die Wachsschicht der Schwungfedern"
  ]
 },
 "q2281": {
  "q": "Welcher ziehende Watvogel leidet unter starkem Bestandsrückgang durch die Überfischung von Pfeilschwanzkrebs-Eiern in der Delaware Bay?",
  "a": [
   "Knutt",
   "Stockente",
   "Kanadagans",
   "Höckerschwan"
  ]
 },
 "q2282": {
  "q": "Welcher dänische Lehrer begründete 1899 die moderne wissenschaftliche Vogelberingung mit nummerierten Aluminiumringen an Staren?",
  "a": [
   "Hans Christian Cornelius Mortensen",
   "Niels Bohr",
   "Tycho Brahe",
   "Ole Rømer"
  ]
 },
 "q2283": {
  "q": "Welches Gezeitenmeer zwischen China, Nordkorea und Südkorea dient als entscheidender Rastplatz auf dem Ostasiatisch-Australasiatischen Zugweg?",
  "a": [
   "Gelbes Meer",
   "Rotes Meer",
   "Ostsee",
   "Adriatisches Meer"
  ]
 },
 "q2284": {
  "q": "Wie nennt man in der Ornithologie Vögel, die nicht ziehen und das ganze Jahr über im selben Gebiet bleiben?",
  "a": [
   "Standvögel",
   "Pelagische Vögel",
   "Laufvögel",
   "Sperlingsvögel"
  ]
 },
 "q2285": {
  "q": "Welcher ziehende Greifvogel überquert auf seinem jährlichen Zug von Indien ins südliche Afrika den Indischen Ozean?",
  "a": [
   "Amurfalke",
   "Gerfalke",
   "Buntfalke",
   "Maorifalke"
  ]
 },
 "q2286": {
  "q": "In welcher deutschen Stadt wurde 1979 das UN-Übereinkommen zur Erhaltung der wandernden wildlebenden Tierarten unterzeichnet?",
  "a": [
   "Bonn",
   "München",
   "Hamburg",
   "Dresden"
  ]
 },
 "q2287": {
  "q": "Welche Großkatze ist das schnellste Landtier der Erde?",
  "a": [
   "Gepard",
   "Löwe",
   "Tiger",
   "Leopard"
  ]
 },
 "q2288": {
  "q": "Welche ist die größte Wildkatzenart der Welt?",
  "a": [
   "Tiger",
   "Löwe",
   "Jaguar",
   "Puma"
  ]
 },
 "q2289": {
  "q": "Welche Großkatze stammt aus Amerika und hat im Verhältnis zu ihrer Größe die stärkste Beißkraft?",
  "a": [
   "Jaguar",
   "Leopard",
   "Gepard",
   "Schneeleopard"
  ]
 },
 "q2290": {
  "q": "Welche Großkatzenart lebt als einzige in großen sozialen Gruppen, die Rudel genannt werden?",
  "a": [
   "Löwe",
   "Tiger",
   "Gepard",
   "Jaguar"
  ]
 },
 "q2291": {
  "q": "Welche Großkatze Zentralasiens ist für ihr dichtes rauchgraues Fell und ihre Unfähigkeit zu brüllen bekannt?",
  "a": [
   "Schneeleopard",
   "Nebelparder",
   "Amurleopard",
   "Eurasischer Luchs"
  ]
 },
 "q2292": {
  "q": "Wie nennt man einen dunkel gefärbten Leoparden oder Jaguar, dessen Farbe durch überschüssiges schwarzes Pigment entsteht?",
  "a": [
   "Schwarzer Panther",
   "Weißer Tiger",
   "Königsgepard",
   "Maltesertiger"
  ]
 },
 "q2293": {
  "q": "Welche Großkatze ist das einzige Mitglied der Familie der Katzen ohne vollständig einziehbare Krallen?",
  "a": [
   "Gepard",
   "Löwe",
   "Jaguar",
   "Puma"
  ]
 },
 "q2294": {
  "q": "Welche in Amerika heimische Großkatze ist auch als Berglöwe oder Silberlöwe bekannt?",
  "a": [
   "Puma",
   "Ozelot",
   "Jaguarundi",
   "Langschwanzkatze"
  ]
 },
 "q2295": {
  "q": "Wie heißt der hybride Nachkomme eines männlichen Löwen und eines weiblichen Tigers?",
  "a": [
   "Liger",
   "Töwe",
   "Leopon",
   "Jaglion"
  ]
 },
 "q2296": {
  "q": "Welche Tigerunterart ist im russischen Fernen Osten heimisch und gehört zu den größten Katzen der Erde?",
  "a": [
   "Sibirischer Tiger",
   "Bengaltiger",
   "Sumatra-Tiger",
   "Malaiischer Tiger"
  ]
 },
 "q2297": {
  "q": "Welche Gattung umfasst Löwe, Tiger, Jaguar, Leopard und Schneeleopard?",
  "a": [
   "Panthera",
   "Felis",
   "Acinonyx",
   "Lynx"
  ]
 },
 "q2298": {
  "q": "Welche große afrikanische Katze schleppt ihre Beute oft hoch auf Bäume, um sie vor Aasfressern zu schützen?",
  "a": [
   "Leopard",
   "Löwe",
   "Gepard",
   "Serval"
  ]
 },
 "q2299": {
  "q": "Welche Großkatze hat im Verhältnis zu ihrer Schädelgröße die längsten Eckzähne aller lebenden Katzen?",
  "a": [
   "Nebelparder",
   "Schneeleopard",
   "Jaguar",
   "Tiger"
  ]
 },
 "q2300": {
  "q": "Welche markante Gesichtszeichnung hilft Geparden, bei der Jagd die Blendung durch die Sonne zu verringern?",
  "a": [
   "Schwarze Tränenstreifen",
   "Weiße Augenbrauenflecken",
   "Goldene Wangenbüschel",
   "Rote Nasenstreifen"
  ]
 },
 "q2301": {
  "q": "In welchem indischen Nationalpark lebt die einzige verbliebene wilde Population Asiatischer Löwen?",
  "a": [
   "Gir-Nationalpark",
   "Jim-Corbett-Nationalpark",
   "Kaziranga-Nationalpark",
   "Ranthambore-Nationalpark"
  ]
 },
 "q2302": {
  "q": "Welche gestreifte Großkatze schwimmt im Gegensatz zu den meisten Katzen gerne und kühlt sich oft in Flüssen ab?",
  "a": [
   "Tiger",
   "Löwe",
   "Gepard",
   "Karakal"
  ]
 },
 "q2303": {
  "q": "Woran erkennt man optisch den Unterschied zwischen den Rosetten eines Jaguars und denen eines Leoparden?",
  "a": [
   "Jaguar-Rosetten haben Punkte innen",
   "Jaguar-Rosetten sind quadratisch",
   "Leoparden-Rosetten sind blau",
   "Leoparden-Rosetten bilden Streifen"
  ]
 },
 "q2304": {
  "q": "Welches einzigartige Merkmal der Haut eines Tigers bleibt sichtbar, selbst wenn sein gesamtes Fell abrasiert wird?",
  "a": [
   "Die Streifen sind in der Haut pigmentiert",
   "Seine Haut ist leuchtend orange",
   "Seine Haut ist mit Schuppen bedeckt",
   "Seine Haut wird komplett weiß"
  ]
 },
 "q2305": {
  "q": "Welche anatomische Anpassung im Rachen ermöglicht es Löwen, Tigern, Jaguaren und Leoparden zu brüllen?",
  "a": [
   "Ein unvollständig verknöchertes Zungenbein",
   "Ein doppelter Satz Stimmbänder",
   "Ein vergrößerter Schildknorpel",
   "Eine resonierende Nasenhöhle"
  ]
 },
 "q2306": {
  "q": "Welche Großkatze hält mit über 400 kg Gewicht den Guinness-Weltrekord für die größte lebende Katze?",
  "a": [
   "Liger",
   "Sibirischer Tiger",
   "Berberlöwe",
   "Töwe"
  ]
 },
 "q2307": {
  "q": "Welcher Körperteil eines Schneeleoparden ist fast so lang wie sein Rumpf und hilft ihm beim Balancieren auf Felsen?",
  "a": [
   "Sein Schwanz",
   "Seine Hinterbeine",
   "Sein Hals",
   "Seine Schnurrhaare"
  ]
 },
 "q2308": {
  "q": "Welche Lautäußerung kann ein Gepard erzeugen, die Vertreter der Gattung Panthera nicht beherrschen?",
  "a": [
   "Schnurren beim Ein- und Ausatmen",
   "Lautes Brüllen",
   "Heulen wie ein Wolf",
   "Singen wie ein Wal"
  ]
 },
 "q2309": {
  "q": "Was ist die biologische Hauptfunktion der dichten Mähne eines männlichen Löwen?",
  "a": [
   "Schutz des Halses und Signal für Gesundheit",
   "Tarnung im hohen Gras",
   "Fettspeicherung für den Winter",
   "Staubfilterung bei Sandstürmen"
  ]
 },
 "q2310": {
  "q": "Welche Großkatze hält mit über 4 Metern den Guinness-Weltrekord für den höchsten Vertikalsprung aus dem Stand?",
  "a": [
   "Puma",
   "Gepard",
   "Schneeleopard",
   "Tiger"
  ]
 },
 "q2311": {
  "q": "Warum gelten weiße Tiger nicht als eigene Tigerart oder Unterart?",
  "a": [
   "Ihre Farbe ist eine rezessive Genmutation",
   "Sie werden für Zoos gefärbt",
   "Sie sind Hybriden mit Schneeleoparden",
   "Ihr Fell bleicht im Sonnenlicht aus"
  ]
 },
 "q2312": {
  "q": "Wie tötet ein Jaguar oft große Beute, im Gegensatz zu den meisten Großkatzen, die sie an der Kehle ersticken?",
  "a": [
   "Durchbeißen des Schädels zwischen den Ohren",
   "Ertränken in tiefen Flüssen",
   "Zerquetschen des Brustkorbs mit den Pfoten",
   "Brechen des Schwanzknochens"
  ]
 },
 "q2313": {
  "q": "Welche prähistorische Säbelzahnkatzen-Gattung ist durch Tausende Fossilien aus den La Brea Tar Pits am besten bekannt?",
  "a": [
   "Smilodon",
   "Machairodus",
   "Homotherium",
   "Megantereon"
  ]
 },
 "q2314": {
  "q": "Wie lautet der wissenschaftliche Artname des Schneeleoparden nach seiner Neueinordnung in die Gattung Panthera?",
  "a": [
   "Panthera uncia",
   "Panthera pardus",
   "Panthera onca",
   "Panthera tigris"
  ]
 },
 "q2315": {
  "q": "Welche auf Borneo und Sumatra heimische Nebelparder-Art wurde 2006 als eigene Art vom Festland-Nebelparder getrennt?",
  "a": [
   "Sunda-Nebelparder",
   "Formosa-Nebelparder",
   "Indochina-Nebelparder",
   "Himalaya-Nebelparder"
  ]
 },
 "q2316": {
  "q": "Wie werden die beiden auffälligen weißen Flecken auf der Rückseite der Ohren eines Tigers von Biologen genannt?",
  "a": [
   "Augenflecken",
   "Mondflecken",
   "Sternzeichen",
   "Sonnenscheiben"
  ]
 },
 "q2317": {
  "q": "Welches seltene genetische Fellmuster bei Geparden führt dazu, dass ihre Flecken am Rücken zu langen dunklen Streifen verschmelzen?",
  "a": [
   "Königsgepard",
   "Maltesergepard",
   "Wollgepard",
   "Geistergepard"
  ]
 },
 "q2318": {
  "q": "Auf welcher Insel im Indischen Ozean lebte der flugunfähige Vogel Dodo?",
  "a": [
   "Mauritius",
   "Madagaskar",
   "Seychellen",
   "Sri Lanka"
  ]
 },
 "q2319": {
  "q": "Was für ein Tier war der ausgestorbene Beutelwolf, der auf Tasmanien lebte?",
  "a": [
   "Fleischfressendes Beuteltier",
   "Pflanzenfressendes Nagetier",
   "Meeressäugetier",
   "Flugunfähiger Vogel"
  ]
 },
 "q2320": {
  "q": "Mit welchem heute lebenden Tier war das Wollhaarmammut am engsten verwandt?",
  "a": [
   "Asiatischer Elefant",
   "Afrikanischer Waldelefant",
   "Breitmaulnashorn",
   "Flusspferd"
  ]
 },
 "q2321": {
  "q": "Welcher ausgestorbene riesige flugunfähige Vogel Neuseelands wurde von den Maori ausgerottet?",
  "a": [
   "Moa",
   "Kasuar",
   "Elefantenvogel",
   "Terrorvogel"
  ]
 },
 "q2322": {
  "q": "Welcher nordamerikanische Vogel zählte Milliarden Exemplare, bevor er 1914 ausstarb?",
  "a": [
   "Wandertaube",
   "Karolinasittich",
   "Riesenalk",
   "Elfenbeinspecht"
  ]
 },
 "q2323": {
  "q": "Welches ausgestorbene Raubtier der Eiszeit ist für seine verlängerten oberen Eckzähne bekannt?",
  "a": [
   "Smilodon",
   "Schreckenswolf",
   "Höhlenbär",
   "Kurznasenbär"
  ]
 },
 "q2324": {
  "q": "Welches große pflanzenfressende Meeressäugetier wurde 1741 im Beringmeer entdeckt und innerhalb von 27 Jahren ausgerottet?",
  "a": [
   "Stellers Seekuh",
   "Karibische Mönchsrobbe",
   "Chinesischer Flussdelfin",
   "Kalifornischer Schweinswal"
  ]
 },
 "q2325": {
  "q": "Welche ausgestorbene Unterart des Steppenzebras hatte nur auf der vorderen Körperhälfte Streifen?",
  "a": [
   "Quagga",
   "Tarpan",
   "Kaplöwe",
   "Blaubock"
  ]
 },
 "q2326": {
  "q": "Welcher riesige prähistorische Hai hatte Zähne mit einer Länge von über 15 Zentimetern?",
  "a": [
   "Megalodon",
   "Helicoprion",
   "Dunkleosteus",
   "Leedsichthys"
  ]
 },
 "q2327": {
  "q": "Welcher ausgestorbene flugunfähige Seevogel des Nordatlantiks wurde ursprünglich als Pinguin bezeichnet?",
  "a": [
   "Riesenalk",
   "Brillenscharbe",
   "Labradorente",
   "Rosenkopfente"
  ]
 },
 "q2328": {
  "q": "Welches ausgestorbene Riesenfaultier Südamerikas konnte eine Länge von bis zu 6 Metern erreichen?",
  "a": [
   "Megatherium",
   "Glyptodon",
   "Toxodon",
   "Macrauchenia"
  ]
 },
 "q2329": {
  "q": "Welches schwer gepanzerte prähistorische Säugetier und Verwandter heutiger Gürteltiere hatte einen autogroßen Panzer?",
  "a": [
   "Glyptodon",
   "Doedicurus",
   "Megatherium",
   "Chalicotherium"
  ]
 },
 "q2330": {
  "q": "Welche ausgestorbene Wildrindart war der Vorfahre des heutigen Hausrinds?",
  "a": [
   "Auerochse",
   "Wisent",
   "Steppenbison",
   "Gaur"
  ]
 },
 "q2331": {
  "q": "Welcher ausgestorbene Riesenhirsch Eurasiens hatte ein Geweih mit einer Spannweite von bis zu 3,65 Metern?",
  "a": [
   "Riesenhirsch",
   "Hirschelch",
   "Buschgeweihhirsch",
   "Sivatherium"
  ]
 },
 "q2332": {
  "q": "Welcher ausgestorbene flugunfähige Vogel Madagaskars legte Eier mit einem Volumen von rund 11 Litern?",
  "a": [
   "Elefantenvogel",
   "Moa",
   "Dodo",
   "Terrorvogel"
  ]
 },
 "q2333": {
  "q": "Welche Gruppe ausgestorbener Meeresgliederfüßer hatte segmentierte Körper und Facettenaugen aus Calcit?",
  "a": [
   "Trilobiten",
   "Ammoniten",
   "Eurypteriden",
   "Belemniten"
  ]
 },
 "q2334": {
  "q": "Welches ausgestorbene prähistorische Säugetier gilt mit bis zu 20 Tonnen als das größte Landsäugetier aller Zeiten?",
  "a": [
   "Paraceratherium",
   "Deinotherium",
   "Mastodon",
   "Elasmotherium"
  ]
 },
 "q2335": {
  "q": "Welcher gepanzerte Fisch des Devons hatte Knochenplatten statt Zähnen und eine Beißkraft, die mit heutigen Krokodilen konkurrierte?",
  "a": [
   "Dunkleosteus",
   "Quastenflosser",
   "Tiktaalik",
   "Acanthostega"
  ]
 },
 "q2336": {
  "q": "Welche ausgestorbene prähistorische Schlange, die in Kolumbien entdeckt wurde, konnte über 12 Meter lang werden?",
  "a": [
   "Titanoboa",
   "Gigantophis",
   "Madtsoia",
   "Wonambi"
  ]
 },
 "q2337": {
  "q": "Welches ausgestorbene kambrische Meeresraubtier hatte fünf Augen und einen langen flexiblen Rüssel?",
  "a": [
   "Opabinia",
   "Anomalocaris",
   "Hallucigenia",
   "Wiwaxia"
  ]
 },
 "q2338": {
  "q": "Welcher ausgestorbene nordamerikanische Vogel war die einzige im Osten der USA heimische Papageienart?",
  "a": [
   "Karolinasittich",
   "Wandertaube",
   "Elfenbeinspecht",
   "Heidehuhn"
  ]
 },
 "q2339": {
  "q": "Welcher ausgestorbene prähistorische Riesenpinguin Neuseelands wurde fast 1,8 Meter groß?",
  "a": [
   "Kumimanu",
   "Palaeeudyptes",
   "Anthropornis",
   "Icadyptes"
  ]
 },
 "q2340": {
  "q": "Welches ausgestorbene Nashorn des Pleistozäns hatte ein gewaltiges Einzelhorn auf der Stirn und lebte in Eurasien?",
  "a": [
   "Elasmotherium",
   "Wollnashorn",
   "Stephanorhinus",
   "Teleoceras"
  ]
 },
 "q2341": {
  "q": "Welches ausgestorbene prähistorische Säugetier hatte einen Rüssel und nach unten gebogene Stoßzähne am Unterkiefer?",
  "a": [
   "Deinotherium",
   "Mastodon",
   "Gomphotherium",
   "Platybelodon"
  ]
 },
 "q2342": {
  "q": "Welche ausgestorbene Wildpferdart durchstreifte bis ins späte 19. Jahrhundert die eurasischen Steppen?",
  "a": [
   "Tarpan",
   "Quagga",
   "Przewalski-Pferd",
   "Onager"
  ]
 },
 "q2343": {
  "q": "Welche ausgestorbene Gruppe flugunfähiger Raubvögel dominierte Südamerika während des Känozoikums?",
  "a": [
   "Phorusrhaciden",
   "Gastornithiden",
   "Dromornithiden",
   "Aepyornithiden"
  ]
 },
 "q2344": {
  "q": "Welches ausgestorbene prähistorische Säugetier hatte Krallenfüße statt Hufen, obwohl es mit Pferden und Nashörnern verwandt war?",
  "a": [
   "Chalicotherium",
   "Brontotherium",
   "Uintatherium",
   "Arsinoitherium"
  ]
 },
 "q2345": {
  "q": "Welches riesige prähistorische, libellenähnliche Insekt aus dem Karbon hatte eine Flügelspannweite von bis zu 70 Zentimetern?",
  "a": [
   "Meganeura",
   "Arthropleura",
   "Pulmonoscorpius",
   "Jaekelopterus"
  ]
 },
 "q2346": {
  "q": "Welcher ausgestorbene prähistorische Verwandte der Tausendfüßer aus dem Karbon konnte über 2,5 Meter lang werden?",
  "a": [
   "Arthropleura",
   "Meganeura",
   "Eurypterus",
   "Anomalocaris"
  ]
 },
 "q2347": {
  "q": "Welcher ausgestorbene prähistorische Hai hatte eine spiralförmige Zahnreihe im Unterkiefer, die einer Kreissäge ähnelte?",
  "a": [
   "Helicoprion",
   "Stethacanthus",
   "Hybodus",
   "Cladoselache"
  ]
 },
 "q2348": {
  "q": "Welcher ausgestorbene Riesenadler Neuseelands war der größte bekannte Adler und jagte den flugunfähigen Moa?",
  "a": [
   "Haastadler",
   "Pelagornis",
   "Argentavis",
   "Teratornis"
  ]
 },
 "q2349": {
  "q": "Welche Homininenart ist wegen früher Steinwerkzeuge als „Geschickter Mensch“ bekannt?",
  "a": [
   "Homo habilis",
   "Australopithecus afarensis",
   "Homo erectus",
   "Paranthropus boisei"
  ]
 },
 "q2350": {
  "q": "Wie heißt das berühmte, 3,2 Millionen Jahre alte Australopithecus-afarensis-Skelett, das 1974 in Äthiopien gefunden wurde?",
  "a": [
   "Lucy",
   "Taung-Kind",
   "Turkana-Junge",
   "Peking-Mensch"
  ]
 },
 "q2351": {
  "q": "Welche frühe Homininenart wanderte als erste in großem Maßstab aus Afrika nach Eurasien aus?",
  "a": [
   "Homo erectus",
   "Australopithecus anamensis",
   "Sahelanthropus tchadensis",
   "Ardipithecus ramidus"
  ]
 },
 "q2352": {
  "q": "Welche alte Homininenlinie wurde vor allem durch DNA aus einem Fingerknochen in der Denissowa-Höhle entdeckt?",
  "a": [
   "Denisova-Menschen",
   "Homo floresiensis",
   "Homo naledi",
   "Australopithecus sediba"
  ]
 },
 "q2353": {
  "q": "Welche ausgestorbene Homininenart von der indonesischen Insel Flores wird wegen ihrer geringen Körpergröße „Hobbit“ genannt?",
  "a": [
   "Homo floresiensis",
   "Homo luzonensis",
   "Homo heidelbergensis",
   "Homo antecessor"
  ]
 },
 "q2354": {
  "q": "Welcher Schädelfund eines spätmiozänen Homininen aus dem Tschad von 2001 trägt den Spitznamen „Toumaï“?",
  "a": [
   "Sahelanthropus tchadensis",
   "Orrorin tugenensis",
   "Australopithecus garhi",
   "Kenyanthropus platyops"
  ]
 },
 "q2355": {
  "q": "Welche Gattung früher Homininen umfasst „Lucy“ und lebte vor etwa 4 bis 2 Millionen Jahren in Afrika?",
  "a": [
   "Australopithecus",
   "Homo",
   "Pan",
   "Gorilla"
  ]
 },
 "q2356": {
  "q": "Welche robuste Australopithecinen-Gattung besaß einen ausgeprägten Scheitelkamm und kräftige Kauzähne für harte Kost?",
  "a": [
   "Paranthropus",
   "Homo",
   "Dryopithecus",
   "Sivapithecus"
  ]
 },
 "q2357": {
  "q": "Welcher ausgestorbene Verwandte des Menschen lebte bis vor etwa 40.000 Jahren in Europa und Westasien?",
  "a": [
   "Neandertaler",
   "Australopithecus",
   "Homo habilis",
   "Ramapithecus"
  ]
 },
 "q2358": {
  "q": "Welcher Paläoanthropologe entdeckte 1924 in Südafrika den Schädelfund „Taung-Kind“?",
  "a": [
   "Raymond Dart",
   "Louis Leakey",
   "Donald Johanson",
   "Eugene Dubois"
  ]
 },
 "q2359": {
  "q": "Welche frühe Steinwerkzeugkultur geht dem Acheuléen voraus und ist nach einer Schlucht in Tansania benannt?",
  "a": [
   "Oldowan",
   "Moustérien",
   "Aurignacien",
   "Magdalénien"
  ]
 },
 "q2360": {
  "q": "Welches 1984 am Turkana-See gefundene Homo-erectus-Skelett ist als „Turkana-Junge“ bekannt?",
  "a": [
   "KNM-WT 15000",
   "OH 5",
   "AL 288-1",
   "LH 4"
  ]
 },
 "q2361": {
  "q": "Welches Steinwerkzeug ist typisch für das Acheuléen, das von Homo erectus genutzt wurde?",
  "a": [
   "Faustkeil",
   "Mikrolith",
   "Harpune",
   "Steinschloss"
  ]
 },
 "q2362": {
  "q": "Welche Homininenart wurde 2015 anhand von Fossilien tief im Höhlensystem Rising Star in Südafrika beschrieben?",
  "a": [
   "Homo naledi",
   "Homo georgicus",
   "Homo rudolfensis",
   "Australopithecus africanus"
  ]
 },
 "q2363": {
  "q": "Welche frühe Homininenart aus Äthiopien ist rund 4,4 Millionen Jahre alt und durch den Fund „Ardi“ bekannt?",
  "a": [
   "Ardipithecus ramidus",
   "Australopithecus sediba",
   "Homo ergaster",
   "Paranthropus aethiopicus"
  ]
 },
 "q2364": {
  "q": "Welche alte Homininenart wurde 2019 anhand kleiner Fuß- und Zahnfossilien aus der Callao-Höhle auf den Philippinen beschrieben?",
  "a": [
   "Homo luzonensis",
   "Homo floresiensis",
   "Homo erectus",
   "Australopithecus bahrelghazali"
  ]
 },
 "q2365": {
  "q": "Welche paläoanthropologische Fundstätte im Ostafrikanischen Grabenbruch in Tansania lieferte berühmte Homininenfunde von Mary und Louis Leakey?",
  "a": [
   "Olduvai-Schlucht",
   "Laetoli",
   "Sterkfontein",
   "Swartkrans"
  ]
 },
 "q2366": {
  "q": "Welcher Fundort in Tansania ist für 3,66 Millionen Jahre alte Homininen-Fußspuren in vulkanischer Asche berühmt?",
  "a": [
   "Laetoli",
   "Hadar",
   "Kromdraai",
   "Zhoukoudian"
  ]
 },
 "q2367": {
  "q": "Welche Menschenaffenfamilie umfasst Menschen, Schimpansen, Bonobos, Gorillas und Orang-Utans?",
  "a": [
   "Hominidae",
   "Hylobatidae",
   "Cercopithecidae",
   "Lemuridae"
  ]
 },
 "q2368": {
  "q": "Welche ausgestorbene Homininenart aus Südafrika wurde 2010 anhand von Fossilien aus Malapa beschrieben?",
  "a": [
   "Australopithecus sediba",
   "Australopithecus anamensis",
   "Homo habilis",
   "Paranthropus robustus"
  ]
 },
 "q2369": {
  "q": "Welcher Anatom fand in den 1890er-Jahren auf Java frühe Homo-erectus-Fossilien und nannte sie „Pithecanthropus erectus“?",
  "a": [
   "Eugene Dubois",
   "Robert Broom",
   "Richard Leakey",
   "Carl von Linné"
  ]
 },
 "q2370": {
  "q": "Welche frühe Homininenart aus Kenia wurde 1995 von Meave Leakey und Kollegen als Australopithecus anamensis benannt?",
  "a": [
   "Australopithecus anamensis",
   "Australopithecus garhi",
   "Homo habilis",
   "Paranthropus boisei"
  ]
 },
 "q2371": {
  "q": "Welches Merkmal unterscheidet zweibeinige Homininen wie Australopithecus im Beckenbau von vierbeinigen Affen?",
  "a": [
   "Kurzes, breites Becken",
   "Langer, schmaler Schwanz",
   "Greiffuß hinten",
   "Verwachsenes Schlüsselbein"
  ]
 },
 "q2372": {
  "q": "Welche ausgestorbene Homininenart ist durch rund 1,8 Millionen Jahre alte Funde aus Dmanisi in Georgien bekannt?",
  "a": [
   "Homo erectus",
   "Homo sapiens",
   "Paranthropus robustus",
   "Ardipithecus kadabba"
  ]
 },
 "q2373": {
  "q": "Welche frühe Homininenart aus Kenia wurde 2000 in den Tugen Hills entdeckt und „Millennium-Mensch“ genannt?",
  "a": [
   "Orrorin tugenensis",
   "Sahelanthropus tchadensis",
   "Australopithecus garhi",
   "Homo rudolfensis"
  ]
 },
 "q2374": {
  "q": "Welche ausgestorbene Homininenart ist nach dem deutschen Neandertal benannt, wo ihre ersten erkannten Fossilien gefunden wurden?",
  "a": [
   "Homo neanderthalensis",
   "Homo heidelbergensis",
   "Homo antecessor",
   "Homo habilis"
  ]
 },
 "q2375": {
  "q": "Welcher Paläoanthropologe leitete 1974 die Expedition in Hadar, Äthiopien, bei der das „Lucy“-Skelett geborgen wurde?",
  "a": [
   "Donald Johanson",
   "Bernard Wood",
   "Ian Tattersall",
   "Chris Stringer"
  ]
 },
 "q2376": {
  "q": "Welche mittelpleistozäne Homininenart ist nach einer deutschen Universitätsstadt benannt, wo 1907 ein Unterkiefer gefunden wurde?",
  "a": [
   "Homo heidelbergensis",
   "Homo sapiens",
   "Homo erectus",
   "Homo habilis"
  ]
 },
 "q2377": {
  "q": "Welche ausgestorbene Homininenart wurde 1999 nach Funden im Mittleren Awash in Äthiopien mit einem Afar-Wort für „Überraschung“ benannt?",
  "a": [
   "Australopithecus garhi",
   "Australopithecus afarensis",
   "Paranthropus aethiopicus",
   "Homo ergaster"
  ]
 },
 "q2378": {
  "q": "Welche lebende Primatenart teilt den höchsten Anteil ihrer Kern-DNA-Sequenz mit dem Menschen?",
  "a": [
   "Bonobo",
   "Orang-Utan",
   "Gibbon",
   "Pavian"
  ]
 },
 "q2379": {
  "q": "Welche Homininen-Fundstätte in Südafrikas Wiege der Menschheit ist für Kalksteinhöhlen und den Schädelfund „Mrs. Ples“ bekannt?",
  "a": [
   "Sterkfontein",
   "Olduvai-Schlucht",
   "Hadar",
   "Dmanisi"
  ]
 },
 "q2380": {
  "q": "Welcher paläoanthropologische Fund von 1959 aus der Olduvai-Schlucht wurde ursprünglich Zinjanthropus boisei genannt?",
  "a": [
   "Paranthropus boisei",
   "Homo habilis",
   "Australopithecus africanus",
   "Homo erectus"
  ]
 },
 "q2381": {
  "q": "Welches Merkmal an der Schädelbasis verschob sich bei frühen Homininen im Vergleich zu Vierbeinern nach vorn?",
  "a": [
   "Lage des Foramen magnum",
   "Drittes Augenlid",
   "Bartenfurche",
   "Geweihrosenstock"
  ]
 },
 "q2382": {
  "q": "Welcher Genetiker leitete das Team zur Sequenzierung des Neandertaler-Genoms und erhielt 2022 den Medizin-Nobelpreis?",
  "a": [
   "Svante Pääbo",
   "Craig Venter",
   "Jennifer Doudna",
   "George Church"
  ]
 },
 "q2383": {
  "q": "Welche südafrikanische Höhlenfundstätte lieferte frühe Homo-Funde wie StW 53 und das Skelett „Little Foot“?",
  "a": [
   "Sterkfontein",
   "Taung",
   "Makapansgat",
   "Gladysvale"
  ]
 },
 "q2384": {
  "q": "Welche frühe Homininengattung umfasst Paranthropus aethiopicus, Paranthropus boisei und Paranthropus robustus?",
  "a": [
   "Paranthropus",
   "Homo",
   "Australopithecus",
   "Ardipithecus"
  ]
 },
 "q2385": {
  "q": "Welche evolutionäre Veränderung bei frühen Homininen verkleinerte die Eckzähne und verlagerte das Kauen aufs Mahlen?",
  "a": [
   "Parabolischer Zahnbogen",
   "Bartenfiltration",
   "Giftzähne",
   "Wiederkäuermagen"
  ]
 },
 "q2386": {
  "q": "Welche mittelpleistozäne Homininenart aus Gran Dolina in Atapuerca, Spanien, wurde 1997 benannt?",
  "a": [
   "Homo antecessor",
   "Homo heidelbergensis",
   "Homo sapiens",
   "Homo erectus"
  ]
 },
 "q2387": {
  "q": "Welcher Begriff bezeichnet die Vermischung zwischen archaischen Homininen wie Neandertalern und frühen modernen Menschen?",
  "a": [
   "Admixture",
   "Artbildung",
   "Allopatrie",
   "Aussterben"
  ]
 },
 "q2388": {
  "q": "Welche wichtige Homininen-Fundstätte in der Region Afar in Äthiopien lieferte „Lucy“ und viele Australopithecus-afarensis-Funde?",
  "a": [
   "Hadar",
   "Taung",
   "Swartkrans",
   "Zhoukoudian"
  ]
 },
 "q2389": {
  "q": "Welche frühe Homininenart wird teils für afrikanische Homo-erectus-Funde vor etwa 1,8 bis 1,4 Millionen Jahren verwendet?",
  "a": [
   "Homo ergaster",
   "Australopithecus sediba",
   "Paranthropus boisei",
   "Sahelanthropus tchadensis"
  ]
 },
 "q2390": {
  "q": "Welches Molekül trägt die genetischen Anweisungen in fast allen Lebewesen?",
  "a": [
   "DNA",
   "RNA",
   "ATP",
   "Glukose"
  ]
 },
 "q2391": {
  "q": "Welcher Naturforscher des 19. Jahrhunderts formulierte in Über die Entstehung der Arten die Evolutionstheorie durch natürliche Selektion?",
  "a": [
   "Charles Darwin",
   "Gregor Mendel",
   "Louis Pasteur",
   "Carl von Linné"
  ]
 },
 "q2392": {
  "q": "Welche Form hat ein typisches DNA-Molekül in lebenden Zellen normalerweise?",
  "a": [
   "Doppelhelix",
   "Einzelne gerade Kette",
   "Dreifachhelix",
   "Flacher Ring"
  ]
 },
 "q2393": {
  "q": "Welche Stickstoffbase paart sich bei der Standard-Basenpaarung der DNA mit Adenin?",
  "a": [
   "Thymin",
   "Cytosin",
   "Guanin",
   "Uracil"
  ]
 },
 "q2394": {
  "q": "Welcher österreichische Mönch stellte im 19. Jahrhundert durch Erbsenversuche die Grundgesetze der Vererbung auf?",
  "a": [
   "Gregor Mendel",
   "Charles Darwin",
   "Hugo de Vries",
   "Thomas Hunt Morgan"
  ]
 },
 "q2395": {
  "q": "Welche Inselgruppe im Pazifik inspirierte Charles Darwin bekanntermaßen zu seinen Beobachtungen über Finkenschnäbel und Evolution?",
  "a": [
   "Galapagosinseln",
   "Azoren",
   "Kanarische Inseln",
   "Hawaiische Inseln"
  ]
 },
 "q2396": {
  "q": "Welcher Begriff bezeichnet in der Evolutionsbiologie eine dauerhafte Veränderung der Nukleotidsequenz der DNA?",
  "a": [
   "Mutation",
   "Transkription",
   "Translation",
   "Replikation"
  ]
 },
 "q2397": {
  "q": "Welcher Begriff bezeichnet in der Evolutionsbiologie Strukturen verschiedener Arten mit gemeinsamem evolutionärem Ursprung?",
  "a": [
   "Homologe Strukturen",
   "Analoge Strukturen",
   "Rudimentäre Organe",
   "Konvergente Merkmale"
  ]
 },
 "q2398": {
  "q": "Welches Organell in tierischen Zellen enthält eigene ringförmige DNA, die vor allem von der Mutter vererbt wird?",
  "a": [
   "Mitochondrium",
   "Ribosom",
   "Golgi-Apparat",
   "Lysosom"
  ]
 },
 "q2399": {
  "q": "Welcher Prozess bildet in der Genetik anhand einer DNA-Vorlage einen komplementären RNA-Strang?",
  "a": [
   "Transkription",
   "Translation",
   "Crossing-over",
   "Mitose"
  ]
 },
 "q2400": {
  "q": "Welcher Begriff bezeichnet in der Genetik eine Sequenz aus drei Nukleotiden auf der Boten-RNA, die eine Aminosäure oder ein Stoppsignal festlegt?",
  "a": [
   "Codon",
   "Intron",
   "Promotor",
   "Telomer"
  ]
 },
 "q2401": {
  "q": "Welcher Begriff beschreibt in der Evolutionsbiologie die Entstehung neuer, eigenständiger Arten im Laufe der Zeit?",
  "a": [
   "Artbildung",
   "Anpassung",
   "Hybridisierung",
   "Domestikation"
  ]
 },
 "q2402": {
  "q": "Welcher Begriff beschreibt in der Evolutionsbiologie die unabhängige Entwicklung ähnlicher Merkmale bei nicht verwandten Linien?",
  "a": [
   "Konvergente Evolution",
   "Divergente Evolution",
   "Gendrift",
   "Genfluss"
  ]
 },
 "q2403": {
  "q": "Welcher Begriff beschreibt in der Populationsgenetik zufällige Schwankungen der Allelhäufigkeiten von Generation zu Generation?",
  "a": [
   "Gendrift",
   "Natürliche Selektion",
   "Künstliche Selektion",
   "Meiose"
  ]
 },
 "q2404": {
  "q": "Welches Enzym entwindet den DNA-Doppelstrang vor der Replikationsgabel?",
  "a": [
   "Helikase",
   "Ligase",
   "Amylase",
   "Katalase"
  ]
 },
 "q2405": {
  "q": "Welches Enzym verknüpft bei der DNA-Replikation Okazaki-Fragmente am Folgestrang?",
  "a": [
   "DNA-Ligase",
   "DNA-Polymerase",
   "Primase",
   "Topoisomerase"
  ]
 },
 "q2406": {
  "q": "Welcher Begriff bezeichnet in der Genetik die schützenden wiederholten Nukleotidsequenzen an den Enden linearer Chromosomen?",
  "a": [
   "Telomere",
   "Zentromere",
   "Plasmide",
   "Operons"
  ]
 },
 "q2407": {
  "q": "Welcher Begriff bezeichnet in der Molekularbiologie nichtcodierende DNA-Abschnitte, die beim RNA-Spleißen aus der Prä-mRNA entfernt werden?",
  "a": [
   "Introns",
   "Exons",
   "Ribozyme",
   "Anticodons"
  ]
 },
 "q2408": {
  "q": "Welcher Begriff beschreibt in der Evolutionsbiologie die rasche Aufspaltung einer Linie in viele an unterschiedliche Nischen angepasste Formen?",
  "a": [
   "Adaptive Radiation",
   "Flaschenhalseffekt",
   "Gründereffekt",
   "Allopatrische Drift"
  ]
 },
 "q2409": {
  "q": "Welcher Begriff bezeichnet in der Populationsgenetik einen starken Rückgang der Populationsgröße mit Verlust genetischer Vielfalt?",
  "a": [
   "Population-Flaschenhalseffekt",
   "Hardy-Weinberg-Gleichgewicht",
   "Pleiotropie",
   "Epistasie"
  ]
 },
 "q2410": {
  "q": "Welcher Begriff beschreibt in der Genetik den Einfluss eines einzelnen Gens auf mehrere scheinbar unabhängige Merkmale?",
  "a": [
   "Pleiotropie",
   "Kodominanz",
   "Epigenetik",
   "Translokation"
  ]
 },
 "q2411": {
  "q": "Welcher Begriff bezeichnet in der Genetik den Austausch einer einzelnen Base, der ein Codon in ein Stoppcodon verwandelt?",
  "a": [
   "Nonsense-Mutation",
   "Missense-Mutation",
   "Stumme Mutation",
   "Frameshift-Mutation"
  ]
 },
 "q2412": {
  "q": "Welcher Begriff beschreibt in der Evolutionsbiologie die Artbildung im selben geografischen Verbreitungsgebiet?",
  "a": [
   "Sympatrische Artbildung",
   "Allopatrische Artbildung",
   "Peripatrische Artbildung",
   "Parapatrische Artbildung"
  ]
 },
 "q2413": {
  "q": "Welcher Begriff bezeichnet in der Genetik die Weitergabe von Genmaterial außerhalb der Eltern-Nachkommen-Vererbung?",
  "a": [
   "Horizontaler Gentransfer",
   "Vertikaler Gentransfer",
   "Genetische Rekombination",
   "Meiotischer Drive"
  ]
 },
 "q2414": {
  "q": "Welcher Begriff beschreibt in der Evolutionsbiologie die allmähliche Anhäufung neutraler Mutationen über die Zeit?",
  "a": [
   "Neutrale Evolutionstheorie",
   "Punktuelles Gleichgewicht",
   "Saltationismus",
   "Orthogenese"
  ]
 },
 "q2415": {
  "q": "Welcher Begriff bezeichnet lange Phasen der Stabilität, unterbrochen von kurzen Schüben evolutionärer Veränderung?",
  "a": [
   "Punktuelles Gleichgewicht",
   "Phyletischer Gradualismus",
   "Genetische Assimilation",
   "Koevolution"
  ]
 },
 "q2416": {
  "q": "Welcher Begriff bezeichnet in der Genetik einen DNA-Abschnitt, der seine Position im Genom verändern kann?",
  "a": [
   "Transposon",
   "Zentromer",
   "Kinetochor",
   "Telomerase"
  ]
 },
 "q2417": {
  "q": "Welcher Begriff beschreibt die Wechselwirkung zwischen Allelen verschiedener Loci, wobei eines das andere überdeckt?",
  "a": [
   "Epistasie",
   "Pleiotropie",
   "Penetranz",
   "Expressivität"
  ]
 },
 "q2418": {
  "q": "Welcher Begriff bezeichnet in der evolutionären Entwicklungsbiologie Änderungen im zeitlichen Ablauf oder Tempo der Entwicklung?",
  "a": [
   "Heterochronie",
   "Heterotopie",
   "Allometrie",
   "Pädomorphose"
  ]
 },
 "q2419": {
  "q": "Welche Röntgenbeugungsaufnahme von DNA aus dem Jahr 1952 am King's College London zeigte ihre helikale Struktur?",
  "a": [
   "Foto 51",
   "Foto 19",
   "Foto 84",
   "Foto 33"
  ]
 },
 "q2420": {
  "q": "Welche chemische Bindung verknüpft benachbarte Nukleotide entlang eines einzelnen DNA-Strangs?",
  "a": [
   "Phosphodiesterbindung",
   "Peptidbindung",
   "Glykosidische Bindung",
   "Ionenbindung"
  ]
 },
 "q2421": {
  "q": "Welcher Begriff bezeichnet in der Genetik eine alternative Variante eines Gens an einem bestimmten Genort?",
  "a": [
   "Allel",
   "Karyotyp",
   "Phänotyp",
   "Zygote"
  ]
 },
 "q2422": {
  "q": "Welcher Begriff beschreibt in der Biologie beobachtbare Merkmale eines Organismus aus Genotyp und Umwelt?",
  "a": [
   "Phänotyp",
   "Genotyp",
   "Genom",
   "Haplotyp"
  ]
 },
 "q2423": {
  "q": "Welcher Begriff bezeichnet ein Merkmal, das seine ursprüngliche Funktion weitgehend oder ganz verloren hat?",
  "a": [
   "Rudimentäres Merkmal",
   "Adaptives Merkmal",
   "Abgeleitetes Merkmal",
   "Pleiotropes Merkmal"
  ]
 },
 "q2424": {
  "q": "Welcher Begriff beschreibt eine kleine Gruppe, die eine neue Population mit verringerter genetischer Vielfalt gründet?",
  "a": [
   "Gründereffekt",
   "Gendrift",
   "Genfluss",
   "Stabilisierende Selektion"
  ]
 },
 "q2425": {
  "q": "Welche Form der natürlichen Selektion begünstigt Mittelwerte und verengt die Merkmalsverteilung?",
  "a": [
   "Stabilisierende Selektion",
   "Direktionale Selektion",
   "Disruptive Selektion",
   "Balancierende Selektion"
  ]
 },
 "q2426": {
  "q": "Welche Form der natürlichen Selektion begünstigt Extreme an beiden Enden gegenüber Zwischenformen?",
  "a": [
   "Disruptive Selektion",
   "Stabilisierende Selektion",
   "Direktionale Selektion",
   "Sexuelle Selektion"
  ]
 },
 "q2427": {
  "q": "Welcher Begriff bezeichnet in der Genetik die genaue Position eines Gens oder einer DNA-Sequenz auf einem Chromosom?",
  "a": [
   "Locus",
   "Genotyp",
   "Codon",
   "Plasmid"
  ]
 },
 "q2428": {
  "q": "Welcher Begriff bezeichnet ein kleines ringförmiges DNA-Molekül in Bakterien, das sich unabhängig repliziert?",
  "a": [
   "Plasmid",
   "Cosmid",
   "Phagemid",
   "Zentrosom"
  ]
 },
 "q2429": {
  "q": "Welcher Begriff bezeichnet eine Gruppe von Allelen auf einem Chromosom, die meist gemeinsam vererbt werden?",
  "a": [
   "Haplotyp",
   "Karyotyp",
   "Idiogramm",
   "Replikon"
  ]
 },
 "q2430": {
  "q": "Welcher Begriff bezeichnet ein Merkmal, das für eine Funktion entstand und später für eine andere genutzt wurde?",
  "a": [
   "Exaptation",
   "Adaptation",
   "Homologie",
   "Konvergenz"
  ]
 },
 "q2431": {
  "q": "Welches Zuckermolekül bildet zusammen mit Phosphatgruppe und Base das Rückgrat eines DNA-Nukleotids?",
  "a": [
   "Desoxyribose",
   "Ribose",
   "Fructose",
   "Lactose"
  ]
 },
 "q2432": {
  "q": "Wie viele Wasserstoffbrückenbindungen bilden sich bei der Standard-DNA-Basenpaarung zwischen Cytosin und Guanin?",
  "a": [
   "3",
   "2",
   "1",
   "4"
  ]
 },
 "q2433": {
  "q": "Welcher Begriff bezeichnet in der Genetik die Gesamtheit des genetischen Materials eines Organismus?",
  "a": [
   "Genom",
   "Proteom",
   "Metabolom",
   "Transkriptom"
  ]
 },
 "q2434": {
  "q": "Welcher Begriff beschreibt ein Individuum mit zwei identischen Allelen an einem Genort?",
  "a": [
   "Homozygot",
   "Heterozygot",
   "Hemizygot",
   "Polyploid"
  ]
 },
 "q2435": {
  "q": "Welcher Begriff bezeichnet den Austausch von Genabschnitten zwischen homologen Chromosomen bei der Meiose?",
  "a": [
   "Crossing-over",
   "Genkonversion",
   "Non-Disjunction",
   "DNA-Methylierung"
  ]
 },
 "q2436": {
  "q": "Welcher Begriff bezeichnet den Austausch von Allelen zwischen Populationen durch Wanderung oder Kreuzung?",
  "a": [
   "Genfluss",
   "Gendrift",
   "Genetische Last",
   "Inzuchtdepression"
  ]
 },
 "q2437": {
  "q": "Welcher US-amerikanische Sänger des 20. Jahrhunderts war weithin als der King of Rock and Roll bekannt?",
  "a": [
   "Elvis Presley",
   "Frank Sinatra",
   "Nat King Cole",
   "Bing Crosby"
  ]
 },
 "q2438": {
  "q": "Welcher britische Rocksänger war bis zu seinem Tod 1991 Frontmann der Band Queen?",
  "a": [
   "Freddie Mercury",
   "David Bowie",
   "George Michael",
   "John Lennon"
  ]
 },
 "q2439": {
  "q": "Welcher jamaikanische Singer-Songwriter machte Reggae-Musik mit Liedern wie No Woman, No Cry weltweit bekannt?",
  "a": [
   "Bob Marley",
   "Peter Tosh",
   "Jimmy Cliff",
   "Desmond Dekker"
  ]
 },
 "q2440": {
  "q": "Welcher italienische Operntenor bildete zusammen mit Plácido Domingo und José Carreras Die Drei Tenöre?",
  "a": [
   "Luciano Pavarotti",
   "Enrico Caruso",
   "Andrea Bocelli",
   "Mario Lanza"
  ]
 },
 "q2441": {
  "q": "Welche französische Chansonsängerin wurde mit Liedern wie La Vie en rose zu einer internationalen Ikone?",
  "a": [
   "Édith Piaf",
   "Dalida",
   "Mireille Mathieu",
   "Françoise Hardy"
  ]
 },
 "q2442": {
  "q": "Welche US-amerikanische Sängerin gewann 18 Grammys und wurde weithin als Queen of Soul gefeiert?",
  "a": [
   "Aretha Franklin",
   "Tina Turner",
   "Diana Ross",
   "Ella Fitzgerald"
  ]
 },
 "q2443": {
  "q": "Welche US-amerikanische Sängerin nahm 1992 die meistverkaufte Coverversion von Dolly Partons I Will Always Love You auf?",
  "a": [
   "Whitney Houston",
   "Celine Dion",
   "Mariah Carey",
   "Toni Braxton"
  ]
 },
 "q2444": {
  "q": "Welcher US-amerikanische Sänger, genannt Ol' Blue Eyes, gewann einen Oscar für den Film Verdammt in alle Ewigkeit von 1953?",
  "a": [
   "Frank Sinatra",
   "Dean Martin",
   "Tony Bennett",
   "Perry Como"
  ]
 },
 "q2445": {
  "q": "Welcher US-amerikanische Country-Sänger, bekannt als Man in Black, nahm Live-Alben in den Gefängnissen Folsom und San Quentin auf?",
  "a": [
   "Johnny Cash",
   "Willie Nelson",
   "Waylon Jennings",
   "Hank Williams"
  ]
 },
 "q2446": {
  "q": "In welcher Stadt wurde die Opernsopranistin Maria Callas 1923 als Tochter griechischer Eltern geboren?",
  "a": [
   "New York City",
   "Athen",
   "Mailand",
   "Paris"
  ]
 },
 "q2447": {
  "q": "Welcher blinde US-amerikanische Sänger und Pianist wurde in den 1950er Jahren mit Hits wie What'd I Say zu einem Pionier der Soulmusik?",
  "a": [
   "Ray Charles",
   "Stevie Wonder",
   "Sam Cooke",
   "Otis Redding"
  ]
 },
 "q2448": {
  "q": "Wie lautete der Geburtsname des Queen-Sängers Freddie Mercury, bevor er seinen Nachnamen offiziell änderte?",
  "a": [
   "Farrokh Bulsara",
   "Farhad Bhutto",
   "Feroze Bomanji",
   "Farid Bharucha"
  ]
 },
 "q2449": {
  "q": "Welche US-amerikanische Jazzsängerin, genannt Lady Day, wurde durch das Lied Strange Fruit berühmt?",
  "a": [
   "Billie Holiday",
   "Sarah Vaughan",
   "Bessie Smith",
   "Dinah Washington"
  ]
 },
 "q2450": {
  "q": "Welcher italienische Operntenor des frühen 20. Jahrhunderts gehörte zu den ersten klassischen Sängern, die durch Schallplatten Weltruhm erlangten?",
  "a": [
   "Enrico Caruso",
   "Beniamino Gigli",
   "Tito Schipa",
   "Franco Corelli"
  ]
 },
 "q2451": {
  "q": "Welcher bulgarische Opernbass des 20. Jahrhunderts erlangte internationalen Ruhm für die Titelrolle in Mussorgskis Boris Godunow?",
  "a": [
   "Boris Christoff",
   "Dimiter Usunow",
   "Kaludi Kaludow",
   "Fjodor Schaljapin"
  ]
 },
 "q2452": {
  "q": "Wie lautete der Geburtsname des italienischen Kastratensängers Farinelli aus dem 18. Jahrhundert?",
  "a": [
   "Carlo Broschi",
   "Gaetano Majorano",
   "Francesco Bernardi",
   "Domenico Annibali"
  ]
 },
 "q2453": {
  "q": "Welcher bulgarische Popsänger komponierte und sang den patriotischen Klassiker Moja strana, moja Bulgarija von 1970?",
  "a": [
   "Emil Dimitrow",
   "Georgi Mintschew",
   "Bisser Kirow",
   "Boris Gudschunow"
  ]
 },
 "q2454": {
  "q": "Welche Sängerin des 20. Jahrhunderts wurde als Königin des Fado, eines traditionellen portugiesischen Musikstils, weltberühmt?",
  "a": [
   "Amália Rodrigues",
   "Cesária Évora",
   "Mercedes Sosa",
   "Chavela Vargas"
  ]
 },
 "q2455": {
  "q": "Wie lautete der Geburtsname der US-amerikanischen Sängerin und Pianistin Nina Simone, bevor sie in den 1950er Jahren ihren Künstlernamen annahm?",
  "a": [
   "Eunice Kathleen Waymon",
   "Eleanora Fagan",
   "Ruth Lee Jones",
   "Chloe Anthony Wofford"
  ]
 },
 "q2456": {
  "q": "Welche Staatsangehörigkeit besaß der französischsprachige Singer-Songwriter Jacques Brel, Schöpfer von Ne me quitte pas?",
  "a": [
   "Belgisch",
   "Französisch",
   "Schweizerisch",
   "Kanadisch"
  ]
 },
 "q2457": {
  "q": "Welches Land war die Heimat der Sängerin Umm Kulthum aus dem 20. Jahrhundert, die in der arabischen Welt als Stern des Ostens gefeiert wurde?",
  "a": [
   "Ägypten",
   "Libanon",
   "Syrien",
   "Marokko"
  ]
 },
 "q2458": {
  "q": "Welche japanische Sängerin des 20. Jahrhunderts, oft Königin der Shōwa-Zeit genannt, erhielt 1989 als erste Frau posthum den japanischen Volksehrenpreis?",
  "a": [
   "Hibari Misora",
   "Kyu Sakamoto",
   "Chiyoko Shimakura",
   "Teresa Teng"
  ]
 },
 "q2459": {
  "q": "In welcher französischen Stadt wurde der Tangosänger Carlos Gardel, eine Ikone der argentinischen Musik, im Jahr 1890 geboren?",
  "a": [
   "Toulouse",
   "Marseille",
   "Bordeaux",
   "Lyon"
  ]
 },
 "q2460": {
  "q": "In welcher russischen Stadt an der Wolga wurde der berühmte Opernbass Fjodor Schaljapin 1873 geboren?",
  "a": [
   "Kasan",
   "Samara",
   "Saratow",
   "Nischni Nowgorod"
  ]
 },
 "q2461": {
  "q": "Welcher US-amerikanische Folk-Rock-Sänger gewann in fünf aufeinanderfolgenden Jahrzehnten von den 1960er bis zu den 2000er Jahren Grammy Awards?",
  "a": [
   "Paul Simon",
   "Bob Dylan",
   "Joan Baez",
   "Pete Seeger"
  ]
 },
 "q2462": {
  "q": "Für welchen spanischen König sang der italienische Kastrat Farinelli ab 1737 fast zehn Jahre lang jede Nacht, um dessen Melancholie zu lindern?",
  "a": [
   "Philipp V.",
   "Karl III.",
   "Ferdinand VI.",
   "Karl IV."
  ]
 },
 "q2463": {
  "q": "Welcher französische Operntenor des 19. Jahrhunderts gilt als der erste, der 1837 ein hohes C mit Bruststimme statt im Falsett sang?",
  "a": [
   "Gilbert Duprez",
   "Adolphe Nourrit",
   "Jean de Reszke",
   "Giovanni Battista Rubini"
  ]
 },
 "q2464": {
  "q": "Unter welchem Pseudonym sang die elfjährige Sopranistin Maria Callas 1935 in einer New Yorker Radiosendung die Arie Un bel dì aus Madama Butterfly?",
  "a": [
   "Nina Foresti",
   "Elena Kalogeropoulou",
   "Sofia Meneghini",
   "Clara Serafin"
  ]
 },
 "q2465": {
  "q": "In welcher Oper fand am 24. Dezember 1920 der letzte öffentliche Auftritt des italienischen Tenors Enrico Caruso an der Metropolitan Opera statt?",
  "a": [
   "La Juive",
   "Pagliacci",
   "Aida",
   "Tosca"
  ]
 },
 "q2466": {
  "q": "Welcher Mitbegründer der Beatles schrieb und sang 1971 die Solo-Friedenshymne Imagine?",
  "a": [
   "John Lennon",
   "Paul McCartney",
   "George Harrison",
   "Ringo Starr"
  ]
 },
 "q2467": {
  "q": "Welcher US-amerikanische Popsänger veröffentlichte 1982 Thriller, das meistverkaufte Album aller Zeiten?",
  "a": [
   "Michael Jackson",
   "Prince",
   "Stevie Wonder",
   "Lionel Richie"
  ]
 },
 "q2468": {
  "q": "Welcher britische Rocksänger erschuf 1972 das fiktive Glam-Rock-Alter-Ego Ziggy Stardust?",
  "a": [
   "David Bowie",
   "Elton John",
   "Marc Bolan",
   "Rod Stewart"
  ]
 },
 "q2469": {
  "q": "Welcher US-amerikanische Funk- und Soulsänger war weithin als Godfather of Soul bekannt?",
  "a": [
   "James Brown",
   "Marvin Gaye",
   "Barry White",
   "Isaac Hayes"
  ]
 },
 "q2470": {
  "q": "Welcher US-amerikanische Jazztrompeter und Sänger nahm 1967 den Klassiker What a Wonderful World auf?",
  "a": [
   "Louis Armstrong",
   "Nat King Cole",
   "Miles Davis",
   "Chet Baker"
  ]
 },
 "q2471": {
  "q": "Welche US-amerikanische Jazzsängerin erhielt den Beinamen First Lady of Song und gewann 13 Grammy Awards?",
  "a": [
   "Ella Fitzgerald",
   "Billie Holiday",
   "Nina Simone",
   "Carmen McRae"
  ]
 },
 "q2472": {
  "q": "Welche Band führte die US-amerikanische Sängerin Janis Joplin an, bevor sie Ende der 1960er Jahre als Solokünstlerin berühmt wurde?",
  "a": [
   "Big Brother and the Holding Company",
   "Jefferson Airplane",
   "The Mamas and the Papas",
   "Creedence Clearwater Revival"
  ]
 },
 "q2473": {
  "q": "Welcher US-amerikanische Soulsänger nahm (Sittin' On) The Dock of the Bay nur wenige Tage vor seinem Tod bei einem Flugzeugabsturz 1967 auf?",
  "a": [
   "Otis Redding",
   "Sam Cooke",
   "Wilson Pickett",
   "Solomon Burke"
  ]
 },
 "q2474": {
  "q": "Welcher US-amerikanische Pop-Rock-Sänger, bekannt für seinen Stimmumfang über drei Oktaven und seine dunkle Sonnenbrille, nahm 1964 Oh, Pretty Woman auf?",
  "a": [
   "Roy Orbison",
   "Buddy Holly",
   "Gene Vincent",
   "Eddie Cochran"
  ]
 },
 "q2475": {
  "q": "Welches Wesen der griechischen Mythologie hat den Oberkörper eines Menschen und den Unterkörper eines Pferdes?",
  "a": [
   "Zentaur",
   "Minotaurus",
   "Satyr",
   "Greif"
  ]
 },
 "q2476": {
  "q": "Welcher mythische Vogel in altägyptischen und griechischen Legenden wird aus seiner eigenen Asche wiedergeboren?",
  "a": [
   "Phönix",
   "Roch",
   "Harpyie",
   "Sirene"
  ]
 },
 "q2477": {
  "q": "Welches Wesen der griechischen Mythologie hatte den Kopf eines Stiers und den Körper eines Mannes?",
  "a": [
   "Minotaurus",
   "Zentaur",
   "Zyklop",
   "Chimäre"
  ]
 },
 "q2478": {
  "q": "Wie viele Köpfe hat Zerberus, der Wachhund der Unterwelt in der griechischen Mythologie, traditionell?",
  "a": [
   "3",
   "2",
   "5",
   "7"
  ]
 },
 "q2479": {
  "q": "Welcher einäugige Riese sperrt Odysseus und seine Gefährten in Homers Odyssee in einer Höhle ein?",
  "a": [
   "Polyphem",
   "Typhon",
   "Argos",
   "Antaios"
  ]
 },
 "q2480": {
  "q": "Welches Fabelwesen hat in altägyptischen und griechischen Überlieferungen den Kopf eines Menschen und den Körper eines Löwen?",
  "a": [
   "Sphinx",
   "Mantikor",
   "Greif",
   "Basilisk"
  ]
 },
 "q2481": {
  "q": "Welches Fabelwesen hat Körper, Schwanz und Hinterbeine eines Löwen sowie Kopf und Flügel eines Adlers?",
  "a": [
   "Greif",
   "Hippogreif",
   "Wyvern",
   "Basilisk"
  ]
 },
 "q2482": {
  "q": "Welches riesige Seeungeheuer aus der skandinavischen Folklore soll ganze Schiffe unter die Wellen ziehen?",
  "a": [
   "Kraken",
   "Leviathan",
   "Skylla",
   "Charybdis"
  ]
 },
 "q2483": {
  "q": "Welches feuerspeiende Ungeheuer der griechischen Mythologie hatte den Kopf eines Löwen, den Körper einer Ziege und eine Schlange als Schwanz?",
  "a": [
   "Chimäre",
   "Mantikor",
   "Orthos",
   "Gorgone"
  ]
 },
 "q2484": {
  "q": "Auf welcher Art von Beinen steht die Hütte der Hexe Baba Jaga in der slawischen Folklore?",
  "a": [
   "Hühnerbeinen",
   "Ziegenhufen",
   "Bärentatzen",
   "Baumwurzeln"
  ]
 },
 "q2485": {
  "q": "Wie viele Beine hat Sleipnir, das mythische Ross des Gottes Odin in der nordischen Mythologie?",
  "a": [
   "8",
   "4",
   "6",
   "12"
  ]
 },
 "q2486": {
  "q": "Wie heißt in der japanischen Folklore der Wassergeist mit einem schildkrötenartigen Panzer und einer wassergefüllten Vertiefung auf dem Kopf?",
  "a": [
   "Kappa",
   "Tengu",
   "Kitsune",
   "Oni"
  ]
 },
 "q2487": {
  "q": "Welches Wesen in mittelalterlichen europäischen Bestiarien schlüpft der Sage nach aus einem Hahnenei, das von einer Kröte oder Schlange ausgebrütet wurde?",
  "a": [
   "Basilisk",
   "Mantikor",
   "Wyvern",
   "Salamander"
  ]
 },
 "q2488": {
  "q": "Wie heißen in der südslawischen Folklore die weiblichen Naturgeister, die auf Lichtungen tanzen und Sterbliche bestrafen, die sie stören?",
  "a": [
   "Samodiven",
   "Kikimoren",
   "Banshees",
   "Najaden"
  ]
 },
 "q2489": {
  "q": "Welcher weibliche Geist in der irischen Folklore ist dafür bekannt, durch Wehklagen einen Todesfall in einer Familie anzukündigen?",
  "a": [
   "Banshee",
   "Selkie",
   "Kelpie",
   "Pooka"
  ]
 },
 "q2490": {
  "q": "Welcher gestaltwandelnde Wassergeist der schottischen Folklore erscheint meist als Pferd an Seen und Flüssen?",
  "a": [
   "Kelpie",
   "Banshee",
   "Brownie",
   "Spriggan"
  ]
 },
 "q2491": {
  "q": "Welches Fabelwesen aus der schottischen und orkadischen Folklore lebt als Robbe im Meer, streift aber an Land seine Haut ab und wird menschlich?",
  "a": [
   "Selkie",
   "Kelpie",
   "Nixe",
   "Undine"
  ]
 },
 "q2492": {
  "q": "Wie heißt in der jüdischen Folklore das menschenähnliche Wesen, das aus Lehm oder Ton zum Leben erweckt wird?",
  "a": [
   "Golem",
   "Dibbuk",
   "Dschinn",
   "Ifrit"
  ]
 },
 "q2493": {
  "q": "Welches glückverheißende Huftier-Mischwesen der chinesischen Mythologie erscheint der Sage nach bei der Ankunft eines Weisen oder großen Herrschers?",
  "a": [
   "Qilin",
   "Bixie",
   "Taotie",
   "Pixiu"
  ]
 },
 "q2494": {
  "q": "Welches übernatürliche Bergwesen der japanischen Folklore wird traditionell mit einer langen Nase und Flügeln dargestellt?",
  "a": [
   "Tengu",
   "Kappa",
   "Tanuki",
   "Yuki-onna"
  ]
 },
 "q2495": {
  "q": "Wie viele Augen besaß der riesige Wächter Argos Panoptes in der griechischen Mythologie?",
  "a": [
   "100",
   "3",
   "12",
   "50"
  ]
 },
 "q2496": {
  "q": "Welches Fabelwesen persischen Ursprungs hat das Gesicht eines Menschen, den Körper eines Löwen und einen Schwanz mit giftigen Stacheln?",
  "a": [
   "Mantikor",
   "Simurgh",
   "Roch",
   "Greif"
  ]
 },
 "q2497": {
  "q": "Wie heißt in der nordischen Mythologie der gewaltige Wolf, dem bestimmt ist, Odin während Ragnarök zu töten?",
  "a": [
   "Fenrir",
   "Garm",
   "Skalli",
   "Hati"
  ]
 },
 "q2498": {
  "q": "Wie heißt in der US-amerikanischen Folklore das geflügelte Wesen mit Hufen, das angeblich in den Pine Barrens von New Jersey lebt?",
  "a": [
   "Jersey Devil",
   "Mothman",
   "Wendigo",
   "Chupacabra"
  ]
 },
 "q2499": {
  "q": "Wie heißt in der slawischen Folklore der schützende Waldgeist, der Reisende in die Irre führt und seine Größe an die Bäume anpasst?",
  "a": [
   "Leschij",
   "Wodjanoi",
   "Domowoi",
   "Bannik"
  ]
 },
 "q2500": {
  "q": "Wie heißt in der mesopotamischen Mythologie der geflügelte Stier oder Löwe mit Menschenkopf, der Palasttore bewachte?",
  "a": [
   "Lamassu",
   "Pazuzu",
   "Chumbaba",
   "Anzu"
  ]
 },
 "q2501": {
  "q": "Wie heißt in der nordischen Mythologie die Weltenschlange, die Midgard umschlingt und sich in den eigenen Schwanz beißt?",
  "a": [
   "Jörmungandr",
   "Nidhöggr",
   "Fafnir",
   "Ouroboros"
  ]
 },
 "q2502": {
  "q": "Wie heißen in der bulgarischen Folklore die drei weiblichen Schicksalsgeister, die ein Neugeborenes in der dritten Nacht besuchen, um sein Schicksal vorherzusagen?",
  "a": [
   "Orisnizi",
   "Samodiven",
   "Rusalken",
   "Vilen"
  ]
 },
 "q2503": {
  "q": "Welches Fabelwesen, ein Mischwesen aus Pferd und Adler, wurde von Ludovico Ariosto in seinem Epos Der rasende Roland erfunden?",
  "a": [
   "Hippogreif",
   "Pegasus",
   "Greif",
   "Peryton"
  ]
 },
 "q2504": {
  "q": "Welches von Jorge Luis Borges beschriebene Fabelwesen mit dem Körper eines Hirsches und Kopf und Flügeln eines Vogels wirft den Schatten eines Menschen?",
  "a": [
   "Peryton",
   "Bonnacon",
   "Katoblepas",
   "Amphisbaena"
  ]
 },
 "q2505": {
  "q": "Welche zwei Brüder schufen im 9. Jahrhundert das glagolitische Alphabet, um liturgische Texte für slawische Völker zu übersetzen?",
  "a": [
   "Kyrill und Method",
   "Boris und Gleb",
   "Wenzel und Boleslaw",
   "Mieszko und Kasimir"
  ]
 },
 "q2506": {
  "q": "Welcher Zweig der Slawen umfasst in der mittelalterlichen slawischen Geschichte Polen, Tschechen und Slowaken?",
  "a": [
   "Westslawen",
   "Südslawen",
   "Ostslawen",
   "Baltische Slawen"
  ]
 },
 "q2507": {
  "q": "Welcher Zweig der Slawen umfasst in der mittelalterlichen slawischen Geschichte Bulgaren, Serben, Kroaten und Slowenen?",
  "a": [
   "Südslawen",
   "Westslawen",
   "Ostslawen",
   "Nordische Slawen"
  ]
 },
 "q2508": {
  "q": "Welcher Zweig der Slawen umfasst in der mittelalterlichen slawischen Geschichte Russen, Ukrainer und Belarussen?",
  "a": [
   "Ostslawen",
   "Westslawen",
   "Südslawen",
   "Steppenslawen"
  ]
 },
 "q2509": {
  "q": "Welcher byzantinische Historiker des 6. Jahrhunderts schrieb in seinem Werk De Bello Gothico über frühe Slawen?",
  "a": [
   "Prokopios",
   "Herodot",
   "Strabon",
   "Plinius der Ältere"
  ]
 },
 "q2510": {
  "q": "Welches byzantinische Militärhandbuch vom Ende des 6. und Anfang des 7. Jahrhunderts beschreibt slawische Kriegführung und Siedlungen?",
  "a": [
   "Strategikon des Maurikios",
   "Taktika Leons",
   "De Administrando Imperio",
   "Chronographia des Psellos"
  ]
 },
 "q2511": {
  "q": "Welche ostslawische Chronik des 12. Jahrhunderts schildert die frühe Geschichte anhand der Erzählung über Rurik und die Waräger?",
  "a": [
   "Nestorchronik",
   "Galizisch-Wolynische Chronik",
   "Erste Nowgoroder Chronik",
   "Nikon-Chronik"
  ]
 },
 "q2512": {
  "q": "Welcher slawische Stammesbund in Mitteleuropa im 7. Jahrhundert wurde von dem fränkischen Kaufmann Samo angeführt?",
  "a": [
   "Samo-Reich",
   "Großmähren",
   "Fürstentum Nitra",
   "Sorbenmark"
  ]
 },
 "q2513": {
  "q": "Welcher mitteleuropäische slawische Staat lud im 9. Jahrhundert Kyrill und Method ein und übernahm die altkirchenslawische Liturgie?",
  "a": [
   "Großmähren",
   "Erstes Bulgarisches Reich",
   "Kiewer Rus",
   "Herzogtum Böhmen"
  ]
 },
 "q2514": {
  "q": "In welchem mittelalterlichen slawischen Reich wurden Preslaw und Ohrid wichtige Zentren slawischer Schriftkultur?",
  "a": [
   "Erstes Bulgarisches Reich",
   "Kiewer Rus",
   "Großmähren",
   "Königreich Polen"
  ]
 },
 "q2515": {
  "q": "Welches traditionelle slawische Frühlingsfest feiert die Ankunft der Wärme und beinhaltet oft das Verbrennen oder Versenken einer Winterpuppe?",
  "a": [
   "Masleniza",
   "Kupala-Nacht",
   "Koljada",
   "Raduniza"
  ]
 },
 "q2516": {
  "q": "Welches traditionelle slawische Sommersonnenwendfest umfasst Feuer, Sprünge über Flammen und schwimmende Blumenkränze?",
  "a": [
   "Kupala-Nacht",
   "Masleniza",
   "Koljada",
   "Semik"
  ]
 },
 "q2517": {
  "q": "Welches Wesen gilt in der slawischen Folklore traditionell als Haus- und Herdgeist im Inneren eines Hauses?",
  "a": [
   "Domowoi",
   "Leschi",
   "Rusalka",
   "Wodjanoi"
  ]
 },
 "q2518": {
  "q": "Welcher Naturgeist in der slawischen Folklore schützt Wälder und Wildtiere und kann Reisende im Wald irreleiten?",
  "a": [
   "Leschi",
   "Domowoi",
   "Wodjanoi",
   "Kikimora"
  ]
 },
 "q2519": {
  "q": "Welcher Wassergeist in der slawischen Folklore bewohnt Flüsse, Seen oder Teiche und herrscht über Wasserwesen?",
  "a": [
   "Wodjanoi",
   "Leschi",
   "Domowoi",
   "Poludniza"
  ]
 },
 "q2520": {
  "q": "Welche Gestalt der slawischen Folklore erscheint um die Mittagszeit auf Kornfeldern und prüft oder schadet Arbeitern in der Hitze?",
  "a": [
   "Poludniza",
   "Domowoi",
   "Leschi",
   "Bannik"
  ]
 },
 "q2521": {
  "q": "Welcher Herrscher des Herzogtums Böhmen im 10. Jahrhundert wird als Heiliger und Patron der böhmischen Länder verehrt?",
  "a": [
   "Wenzel I.",
   "Boleslaw I.",
   "Mieszko I.",
   "Bretislav I."
  ]
 },
 "q2522": {
  "q": "Welchem polnischen Herrscher der Piastendynastie aus dem 10. Jahrhundert wird die Einigung polnischer Gebiete und die Christianisierung 966 zugeschrieben?",
  "a": [
   "Mieszko I.",
   "Boleslaw I.",
   "Kasimir I.",
   "Wladyslaw I."
  ]
 },
 "q2523": {
  "q": "Welcher Herrscher der Kiewer Rus nahm um 988 das östliche Christentum an und leitete die Christianisierung der ostslawischen Länder ein?",
  "a": [
   "Wladimir der Große",
   "Oleg von Nowgorod",
   "Igor von Kiew",
   "Jaroslaw der Weise"
  ]
 },
 "q2524": {
  "q": "Welcher Herrscher des Ersten Bulgarischen Reiches förderte die Schulen von Preslaw und Ohrid zum Ausbau des Altkirchenslawischen?",
  "a": [
   "Simeon I.",
   "Khan Asparuh",
   "Khan Terwel",
   "Kalojan"
  ]
 },
 "q2525": {
  "q": "Welcher slawische Herrscher auf dem zentralen Balkan begründete im 12. Jahrhundert die serbische Dynastie der Nemanjići?",
  "a": [
   "Stefan Nemanja",
   "Stefan Dušan",
   "Lazar Hrebeljanović",
   "Milutin"
  ]
 },
 "q2526": {
  "q": "Welcher slawische Herrscher auf dem Balkan wurde 1346 zum Kaiser der Serben und Griechen gekrönt?",
  "a": [
   "Stefan Dušan",
   "Stefan Nemanja",
   "Tvrtko I.",
   "Vukašin Mrnjavčević"
  ]
 },
 "q2527": {
  "q": "Welcher slawische Herrscher wurde 1377 zum König von Bosnien gekrönt und weitete die Herrschaft an die Adria aus?",
  "a": [
   "Tvrtko I.",
   "Stefan Dušan",
   "Lazar Hrebeljanović",
   "Stjepan Tomašević"
  ]
 },
 "q2528": {
  "q": "Welche mittelalterliche Schlacht von 1410 endete mit dem Sieg verbündeter polnisch-litauischer und slawischer Truppen über den Deutschen Orden?",
  "a": [
   "Schlacht bei Tannenberg",
   "Schlacht bei Mohács",
   "Schlacht bei Warna",
   "Schlacht auf dem Amselfeld"
  ]
 },
 "q2529": {
  "q": "Welcher tschechische Religionsreformator und Gelehrte des 15. Jahrhunderts wurde 1415 in Konstanz auf dem Scheiterhaufen verbrannt?",
  "a": [
   "Jan Hus",
   "Petr Chelčický",
   "Jan Žižka",
   "Georg von Podiebrad"
  ]
 },
 "q2530": {
  "q": "Wie nennt man in slawischen Traditionen verzierte Ostereier, die mit Wachsreservierung bemalt werden?",
  "a": [
   "Pysanky",
   "Koljada",
   "Kupala",
   "Babka"
  ]
 },
 "q2531": {
  "q": "Welcher traditionelle slawische Volkstanz ist ein Kreis- oder Kettentanz mit Musik auf dem Balkan und in Mitteleuropa?",
  "a": [
   "Kolo",
   "Mazurka",
   "Polonaise",
   "Krakowiak"
  ]
 },
 "q2532": {
  "q": "Welcher polnische Volkstanz im Dreiertakt mit Betonung auf dem zweiten oder dritten Schlag inspirierte Werke von Fryderyk Chopin?",
  "a": [
   "Mazurka",
   "Kolo",
   "Hopak",
   "Kujawiak"
  ]
 },
 "q2533": {
  "q": "Welche altostslawische Versdichtung schildert den Feldzug Fürst Igors gegen die Polowzer und mahnt vor Zwietracht der Fürsten?",
  "a": [
   "Igorlied",
   "Sadonschtschina",
   "Lied von Fürst Igor",
   "Rede über Gesetz und Gnade"
  ]
 },
 "q2534": {
  "q": "Welche mittelalterliche slawische Republik an einer Handelsstadt am Wolchow wurde durch die Volksversammlung Wetsche regiert?",
  "a": [
   "Nowgoroder Republik",
   "Fürstentum Polozk",
   "Großfürstentum Twer",
   "Fürstentum Rjasan"
  ]
 },
 "q2535": {
  "q": "Welches westslawische Volk besiedelte einst Teile Ostdeutschlands und der Lausitz und bewahrte eine eigene slawische Sprache und Identität?",
  "a": [
   "Sorben",
   "Friesen",
   "Bayern",
   "Sachsen"
  ]
 },
 "q2536": {
  "q": "Welcher slawische Fürst von Unterpannonien im 9. Jahrhundert unterstützte Kyrill und Method in Blatnohrad mit Land und Schutz?",
  "a": [
   "Pribina",
   "Svatopluk I.",
   "Rastislav",
   "Mojmir I."
  ]
 },
 "q2537": {
  "q": "Welcher Herrscher Großmährens bat 862 um Missionare aus Konstantinopel und löste damit die Mission von Kyrill und Method aus?",
  "a": [
   "Rastislav",
   "Pribina",
   "Svatopluk I.",
   "Bořivoj I."
  ]
 },
 "q2538": {
  "q": "Welcher Schüler von Kyrill und Method aus dem 9. Jahrhundert prägte die Schule von Ohrid und gilt als Mitbegründer des kyrillischen Alphabets?",
  "a": [
   "Klemens von Ohrid",
   "Naum von Preslaw",
   "Angelarius",
   "Gorazd"
  ]
 },
 "q2539": {
  "q": "Welche politische und kulturelle Strömung strebte Einheit und gemeinsame Identität slawischer Völker an?",
  "a": [
   "Panslawismus",
   "Hanse",
   "Pantürkismus",
   "Austromarxismus"
  ]
 },
 "q2540": {
  "q": "Welcher europäische Staat des 20. Jahrhunderts vereinte mehrere südslawische Völker, bevor er in den frühen 1990er-Jahren zerfiel?",
  "a": [
   "Jugoslawien",
   "Tschechoslowakei",
   "Großfürstentum Litauen",
   "Polen-Litauen"
  ]
 },
 "q2541": {
  "q": "Welcher 1918 gegründete mitteleuropäische Staat vereinte Tschechen und Slowaken bis zur friedlichen Teilung 1993?",
  "a": [
   "Tschechoslowakei",
   "Jugoslawien",
   "Königreich Galizien",
   "Schlesische Herzogtümer"
  ]
 },
 "q2542": {
  "q": "Welche Union von 1569 verschmolz das Königreich Polen und das Großfürstentum Litauen zu einem Staat mit großer slawischer Bevölkerung?",
  "a": [
   "Union von Lublin",
   "Union von Krewo",
   "Vertrag von Perejaslaw",
   "Frieden von Brest"
  ]
 },
 "q2543": {
  "q": "Welches Abkommen von 1654 zwischen Saporoger Kosaken unter Bohdan Chmelnyzkyj und dem Zarentum Russland prägte die ostslawische Politik?",
  "a": [
   "Vertrag von Perejaslaw",
   "Vertrag von Andrussowo",
   "Vertrag von Hadjatsch",
   "Ewiger Frieden"
  ]
 },
 "q2544": {
  "q": "Wie heißt in slawischen Traditionen ein süßes Zopfbrot oder Gebäck, das traditionell zu Feiertagen und Ostern gebacken wird?",
  "a": [
   "Babka",
   "Pysanka",
   "Koljada",
   "Watrushka"
  ]
 },
 "q2545": {
  "q": "Welcher mittelalterliche slawische Fürst von Nowgorod besiegte 1240 schwedische Truppen an der Newa und erhielt seinen Beinamen?",
  "a": [
   "Alexander Newski",
   "Dmitri Donskoi",
   "Iwan Kalita",
   "Wsewolod Großes Nest"
  ]
 },
 "q2546": {
  "q": "Welche Schlacht von 1380 am Don endete mit dem Sieg der Truppen des Moskauer Fürsten über den Goldene-Horde-Feldherrn Mamai?",
  "a": [
   "Schlacht auf dem Kulikowo-Feld",
   "Schlacht an der Newa",
   "Schlacht auf dem Peipussee",
   "Schlacht an den Blauen Gewässern"
  ]
 },
 "q2547": {
  "q": "Wie nennt man in slawischen Traditionen das winterliche Singen und Brauchtum um Wintersonnenwende und Weihnachten?",
  "a": [
   "Koljada",
   "Masleniza",
   "Kupala",
   "Raduniza"
  ]
 },
 "q2548": {
  "q": "Wie heißt im slawischen Volksbrauch der Frühlingstag des Totengedenkens mit Besuchen an Gräbern und gemeinsamen Mahlzeiten?",
  "a": [
   "Raduniza",
   "Koljada",
   "Kupala",
   "Masleniza"
  ]
 },
 "q2549": {
  "q": "Welcher mittelalterliche slawische Heilige und Einsiedler gründete im 10. Jahrhundert das Rila-Kloster?",
  "a": [
   "Johannes von Rila",
   "Simeon I.",
   "Peter I.",
   "Samuil"
  ]
 },
 "q2550": {
  "q": "Welcher Herrscher des Ersten Bulgarischen Reiches schloss 927 Frieden mit Byzanz und wurde als Zar anerkannt?",
  "a": [
   "Peter I.",
   "Simeon I.",
   "Boris I.",
   "Kalojan"
  ]
 },
 "q2551": {
  "q": "Welcher Herrscher auf dem Balkan im 14. Jahrhundert regierte von Widin aus als letzter Herrscher der Schischman-Dynastie?",
  "a": [
   "Iwan Srazimir",
   "Iwan Alexander",
   "Iwan Schischman",
   "Michael Asen IV."
  ]
 },
 "q2552": {
  "q": "Welcher Herrscher der Kiewer Rus schuf die Rechtskodifikation namens Russkaja Prawda?",
  "a": [
   "Jaroslaw der Weise",
   "Wladimir Monomach",
   "Jaroslaw II.",
   "Mstislaw der Große"
  ]
 },
 "q2553": {
  "q": "Wer schrieb die Fantasy-Romanreihe, auf der die Fernsehserie Game of Thrones basiert?",
  "a": [
   "George R. R. Martin",
   "J. R. R. Tolkien",
   "Andrzej Sapkowski",
   "Robert Jordan"
  ]
 },
 "q2554": {
  "q": "Welcher US-amerikanische Fernsehsender strahlte die Fantasy-Serie Game of Thrones ursprünglich aus?",
  "a": [
   "HBO",
   "AMC",
   "Showtime",
   "Starz"
  ]
 },
 "q2555": {
  "q": "Wie viele Staffeln der Fernsehserie Game of Thrones wurden insgesamt veröffentlicht?",
  "a": [
   "8",
   "6",
   "7",
   "9"
  ]
 },
 "q2556": {
  "q": "Wie lautet das Motto des Hauses Stark in der Serie Game of Thrones?",
  "a": [
   "Der Winter naht",
   "Hört mich brüllen",
   "Feuer und Blut",
   "Unser ist der Zorn"
  ]
 },
 "q2557": {
  "q": "Welcher Schauspieler verkörperte Tyrion Lennister in der Fernsehserie Game of Thrones?",
  "a": [
   "Peter Dinklage",
   "Nikolaj Coster-Waldau",
   "Sean Bean",
   "Kit Harington"
  ]
 },
 "q2558": {
  "q": "Welche Schauspielerin spielte Daenerys Targaryen in der Fernsehserie Game of Thrones?",
  "a": [
   "Emilia Clarke",
   "Sophie Turner",
   "Lena Headey",
   "Maisie Williams"
  ]
 },
 "q2559": {
  "q": "Welcher Schauspieler spielte Jon Schnee in der Fernsehserie Game of Thrones?",
  "a": [
   "Kit Harington",
   "Richard Madden",
   "Alfie Allen",
   "Iwan Rheon"
  ]
 },
 "q2560": {
  "q": "Wie heißt der fiktive Kontinent, auf dem der Großteil der Handlung von Game of Thrones spielt?",
  "a": [
   "Westeros",
   "Essos",
   "Sothoryos",
   "Ulthos"
  ]
 },
 "q2561": {
  "q": "Wie viele Drachen schlüpfen für Daenerys Targaryen in der ersten Staffel von Game of Thrones?",
  "a": [
   "3",
   "2",
   "4",
   "5"
  ]
 },
 "q2562": {
  "q": "Wie heißt die Hauptstadt der Sieben Königslande in der Serie Game of Thrones?",
  "a": [
   "Königsmund",
   "Winterfell",
   "Drachenstein",
   "Rosengarten"
  ]
 },
 "q2563": {
  "q": "In welchem Jahr feierte die erste Staffel der Fernsehserie Game of Thrones Premiere?",
  "a": [
   "2011",
   "2009",
   "2013",
   "2015"
  ]
 },
 "q2564": {
  "q": "In welchem Jahr wurde die letzte Folge der Fernsehserie Game of Thrones ausgestrahlt?",
  "a": [
   "2019",
   "2017",
   "2018",
   "2020"
  ]
 },
 "q2565": {
  "q": "Welche kroatische Küstenstadt diente als Hauptdrehort für Königsmund in Game of Thrones?",
  "a": [
   "Dubrovnik",
   "Split",
   "Zadar",
   "Pula"
  ]
 },
 "q2566": {
  "q": "Wie heißt die riesige Eisbefestigung, die die Nordgrenze der Sieben Königslande in Game of Thrones schützt?",
  "a": [
   "Die Mauer",
   "Der Trident",
   "Hohenehr",
   "Die Zitadelle"
  ]
 },
 "q2567": {
  "q": "Welches Tier dient als Wappenzeichen des Hauses Stark in der Serie Game of Thrones?",
  "a": [
   "Schattenwolf",
   "Löwe",
   "Hirsch",
   "Krake"
  ]
 },
 "q2568": {
  "q": "Aus welchem seltenen, außergewöhnlich scharfen Metall werden Klingen geschmiedet, die Weiße Wanderer in Game of Thrones töten können?",
  "a": [
   "Valyrischer Stahl",
   "Mithril",
   "Adamantium",
   "Oreichalkos"
  ]
 },
 "q2569": {
  "q": "Welche Figur wird in der letzten Folge von Game of Thrones zum Herrscher der Sechs Königslande gekrönt?",
  "a": [
   "Bran Stark",
   "Jon Schnee",
   "Tyrion Lennister",
   "Sansa Stark"
  ]
 },
 "q2570": {
  "q": "Wer komponierte die Titelmusik für die Fernsehserie Game of Thrones?",
  "a": [
   "Ramin Djawadi",
   "Hans Zimmer",
   "Howard Shore",
   "Bear McCreary"
  ]
 },
 "q2571": {
  "q": "Wie heißt das schmale Schwert, das Arya Stark in der Serie Game of Thrones führt?",
  "a": [
   "Nadel",
   "Langklaue",
   "Eis",
   "Eidwahrer"
  ]
 },
 "q2572": {
  "q": "Welcher der drei Drachen von Daenerys Targaryen ist der größte und nach ihrem verstorbenen Ehemann benannt?",
  "a": [
   "Drogon",
   "Rhaegal",
   "Viserion",
   "Balerion"
  ]
 },
 "q2573": {
  "q": "Wer tötet den Nachtkönig während der Schlacht um Winterfell in der achten Staffel von Game of Thrones?",
  "a": [
   "Arya Stark",
   "Jon Schnee",
   "Daenerys Targaryen",
   "Theon Graufreud"
  ]
 },
 "q2574": {
  "q": "Welche leicht entzündliche grüne Flüssigkeit zerstört Stannis Baratheons Flotte in der Schlacht am Schwarzwasser in Game of Thrones?",
  "a": [
   "Seefeuer",
   "Drachenfeuer",
   "Griechisches Feuer",
   "Nachtschatten"
  ]
 },
 "q2575": {
  "q": "Welchen Titel trägt der oberste Berater des Monarchen der Sieben Königslande in Game of Thrones?",
  "a": [
   "Hand des Königs",
   "Meister der Münze",
   "Lord Kommandant",
   "Großmaester"
  ]
 },
 "q2576": {
  "q": "Wer entpuppt sich in der Fernsehserie Game of Thrones als Jon Schnees leiblicher Vater?",
  "a": [
   "Rhaegar Targaryen",
   "Eddard Stark",
   "Robert Baratheon",
   "Aerys Targaryen"
  ]
 },
 "q2577": {
  "q": "Wer waren die beiden Showrunner und Mitschöpfer der Fernsehserie Game of Thrones?",
  "a": [
   "David Benioff und D. B. Weiss",
   "Vince Gilligan und Peter Gould",
   "Damon Lindelof und Carlton Cuse",
   "Jonathan Nolan und Lisa Joy"
  ]
 },
 "q2578": {
  "q": "Wie heißt die geheime Gilde der gestaltwandelnden Assassinen in Braavos, die Arya Stark in Game of Thrones ausbildet?",
  "a": [
   "Männer ohne Gesicht",
   "Zweitgeborene",
   "Goldene Kompanie",
   "Unbefleckte"
  ]
 },
 "q2579": {
  "q": "Welche Figur wird auf ihrer eigenen Hochzeitsfeier in der vierten Staffel von Game of Thrones vergiftet, einem Ereignis namens Purpurne Hochzeit?",
  "a": [
   "Joffrey Baratheon",
   "Robb Stark",
   "Ramsay Bolton",
   "Tommen Baratheon"
  ]
 },
 "q2580": {
  "q": "Welcher Sprachwissenschaftler erschuf die Kunstsprachen Dothraki und Valyrisch für die Fernsehserie Game of Thrones?",
  "a": [
   "David J. Peterson",
   "Marc Okrand",
   "Paul Frommer",
   "L. L. Zamenhof"
  ]
 },
 "q2581": {
  "q": "Wie viele Folgen wurden insgesamt über alle acht Staffeln der Fernsehserie Game of Thrones ausgestrahlt?",
  "a": [
   "73",
   "67",
   "80",
   "60"
  ]
 },
 "q2582": {
  "q": "Wie lautet der Titel der allerersten Folge der Fernsehserie Game of Thrones?",
  "a": [
   "Der Winter naht",
   "Der Königsweg",
   "Feuer und Blut",
   "Valar Morghulis"
  ]
 },
 "q2583": {
  "q": "Welcher Schauspieler gewann vier Primetime Emmy Awards für seine Darstellung in der Fernsehserie Game of Thrones?",
  "a": [
   "Peter Dinklage",
   "Nikolaj Coster-Waldau",
   "Alfie Allen",
   "Charles Dance"
  ]
 },
 "q2584": {
  "q": "Wie lautet der Titel der allerletzten Folge der Fernsehserie Game of Thrones?",
  "a": [
   "Der Eiserne Thron",
   "Die Glocken",
   "Der Drache und der Wolf",
   "Die Winde des Winters"
  ]
 }
}