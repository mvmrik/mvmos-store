import hashlib, json, os, secrets, sqlite3, sys, uuid
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException, Header
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional

get_current_session = sys.modules["backend.auth"].get_current_session

_admin = APIRouter(prefix="/api/gamehub",     tags=["gamehub"])
_pub   = APIRouter(prefix="/api/pub/gamehub", tags=["gamehub-pub"])

# Combined router exposed to the loader
router = APIRouter()

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "apps", "gamehub", "data.db")
TOKEN_DAYS = 30
AVATAR_COLORS = ['#89b4fa','#a6e3a1','#f38ba8','#fab387','#f9e2af','#cba6f7','#94e2d5','#f5c2e7','#74c7ec','#eba0ac']

def _db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS players (
            id            TEXT PRIMARY KEY,
            username      TEXT UNIQUE NOT NULL,
            display_name  TEXT NOT NULL,
            avatar_color  TEXT NOT NULL DEFAULT '#89b4fa',
            password_hash TEXT,
            created_at    TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS gh_tokens (
            token      TEXT PRIMARY KEY,
            player_id  TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS game_sessions (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            game_id          TEXT NOT NULL,
            mode             TEXT NOT NULL DEFAULT 'multiplayer',
            played_at        TEXT NOT NULL,
            duration_seconds INTEGER,
            metadata         TEXT NOT NULL DEFAULT '{}'
        );
        CREATE TABLE IF NOT EXISTS session_players (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
            player_id  TEXT REFERENCES players(id) ON DELETE SET NULL,
            guest_name TEXT,
            score      REAL,
            rank       INTEGER,
            is_winner  INTEGER NOT NULL DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_sp_player  ON session_players(player_id);
        CREATE INDEX IF NOT EXISTS idx_sp_session ON session_players(session_id);
        CREATE INDEX IF NOT EXISTS idx_gs_game    ON game_sessions(game_id, played_at);
        CREATE INDEX IF NOT EXISTS idx_tok_player ON gh_tokens(player_id);
    """)
    conn.commit()
    # migrations
    pcols = {r[1] for r in conn.execute("PRAGMA table_info(players)").fetchall()}
    if "password_hash" not in pcols:
        conn.execute("ALTER TABLE players ADD COLUMN password_hash TEXT")
    gcols = {r[1] for r in conn.execute("PRAGMA table_info(game_sessions)").fetchall()}
    if "mode" not in gcols:
        conn.execute("ALTER TABLE game_sessions ADD COLUMN mode TEXT NOT NULL DEFAULT 'multiplayer'")
    conn.commit()
    return conn

# ── Password helpers ──────────────────────────────────────────

def _hash_pw(pw: str) -> str:
    salt = secrets.token_bytes(32)
    key  = hashlib.pbkdf2_hmac('sha256', pw.encode(), salt, 100000)
    return salt.hex() + ':' + key.hex()

def _verify_pw(stored: str, pw: str) -> bool:
    try:
        salt_hex, key_hex = stored.split(':')
        key = hashlib.pbkdf2_hmac('sha256', pw.encode(), bytes.fromhex(salt_hex), 100000)
        return secrets.compare_digest(key.hex(), key_hex)
    except Exception:
        return False

def _resolve_token(x_gh_token: Optional[str]) -> Optional[dict]:
    if not x_gh_token:
        return None
    now = datetime.now(timezone.utc).isoformat()
    with _db() as conn:
        row = conn.execute(
            "SELECT p.* FROM players p JOIN gh_tokens t ON t.player_id=p.id WHERE t.token=? AND t.expires_at>?",
            (x_gh_token, now)
        ).fetchone()
    return dict(row) if row else None

def _issue_token(player_id: str) -> str:
    token = secrets.token_urlsafe(32)
    now   = datetime.now(timezone.utc)
    exp   = (now + timedelta(days=TOKEN_DAYS)).isoformat()
    with _db() as conn:
        conn.execute("INSERT INTO gh_tokens(token,player_id,created_at,expires_at) VALUES(?,?,?,?)",
                     (token, player_id, now.isoformat(), exp))
        conn.commit()
    return token

# ── Public auth endpoints ─────────────────────────────────────

class RegisterBody(BaseModel):
    username:     str
    display_name: str
    password:     str
    avatar_color: str = '#89b4fa'

@_pub.post("/register")
async def register(body: RegisterBody):
    if len(body.password) < 4:
        raise HTTPException(400, detail="Password too short")
    pid  = str(uuid.uuid4())[:8]
    now  = datetime.now(timezone.utc).isoformat()
    try:
        with _db() as conn:
            conn.execute("INSERT INTO players(id,username,display_name,avatar_color,password_hash,created_at) VALUES(?,?,?,?,?,?)",
                         (pid, body.username.strip().lower(), body.display_name.strip(), body.avatar_color, _hash_pw(body.password), now))
            conn.commit()
    except sqlite3.IntegrityError:
        raise HTTPException(400, detail="Username already exists")
    token = _issue_token(pid)
    return JSONResponse({"token": token, "player": {"id": pid, "username": body.username.strip().lower(),
                          "display_name": body.display_name.strip(), "avatar_color": body.avatar_color}})

class LoginBody(BaseModel):
    username: str
    password: str

@_pub.post("/login")
async def login(body: LoginBody):
    with _db() as conn:
        row = conn.execute("SELECT * FROM players WHERE username=?", (body.username.strip().lower(),)).fetchone()
    if not row or not row["password_hash"] or not _verify_pw(row["password_hash"], body.password):
        raise HTTPException(401, detail="Invalid username or password")
    token = _issue_token(row["id"])
    return JSONResponse({"token": token, "player": {"id": row["id"], "username": row["username"],
                          "display_name": row["display_name"], "avatar_color": row["avatar_color"]}})

@_pub.post("/logout")
async def logout(x_gh_token: Optional[str] = Header(default=None)):
    if x_gh_token:
        with _db() as conn:
            conn.execute("DELETE FROM gh_tokens WHERE token=?", (x_gh_token,))
            conn.commit()
    return JSONResponse({"ok": True})

@_pub.get("/me")
async def me(x_gh_token: Optional[str] = Header(default=None)):
    p = _resolve_token(x_gh_token)
    if not p:
        raise HTTPException(401)
    return JSONResponse({"id": p["id"], "username": p["username"],
                         "display_name": p["display_name"], "avatar_color": p["avatar_color"]})

@_pub.get("/players")
async def players_public():
    with _db() as conn:
        rows = conn.execute("SELECT id,username,display_name,avatar_color FROM players ORDER BY display_name").fetchall()
    return JSONResponse([dict(r) for r in rows])

@_pub.get("/stats")
async def stats_public():
    return await _build_stats()

# ── Public session recording ──────────────────────────────────

class SessionPlayer(BaseModel):
    player_id:  Optional[str] = None
    guest_name: Optional[str] = None
    score:      Optional[float] = None
    rank:       Optional[int] = None
    is_winner:  bool = False

class SessionBody(BaseModel):
    game_id:          str
    mode:             str = 'multiplayer'
    players:          list[SessionPlayer]
    duration_seconds: Optional[int] = None
    metadata:         dict = {}

@_pub.post("/session")
async def record_session(body: SessionBody):
    now = datetime.now(timezone.utc).isoformat()
    with _db() as conn:
        cur = conn.execute(
            "INSERT INTO game_sessions(game_id,mode,played_at,duration_seconds,metadata) VALUES(?,?,?,?,?)",
            (body.game_id, body.mode, now, body.duration_seconds, json.dumps(body.metadata))
        )
        sid = cur.lastrowid
        for p in body.players:
            if not p.player_id and not p.guest_name:
                continue
            conn.execute(
                "INSERT INTO session_players(session_id,player_id,guest_name,score,rank,is_winner) VALUES(?,?,?,?,?,?)",
                (sid, p.player_id or None, p.guest_name or None, p.score, p.rank, 1 if p.is_winner else 0)
            )
        conn.commit()
    return JSONResponse({"ok": True, "session_id": sid})

# ── Admin player management (mvmOS session required) ─────────

@_admin.get("/players")
async def list_players(session=Depends(get_current_session)):
    with _db() as conn:
        rows = conn.execute("SELECT id,username,display_name,avatar_color,created_at FROM players ORDER BY display_name").fetchall()
    return JSONResponse([dict(r) for r in rows])

class PlayerBody(BaseModel):
    username:     str
    display_name: str
    avatar_color: str = '#89b4fa'
    password:     Optional[str] = None

@_admin.post("/players")
async def create_player(body: PlayerBody, session=Depends(get_current_session)):
    pid  = str(uuid.uuid4())[:8]
    now  = datetime.now(timezone.utc).isoformat()
    phash = _hash_pw(body.password) if body.password else None
    try:
        with _db() as conn:
            conn.execute("INSERT INTO players(id,username,display_name,avatar_color,password_hash,created_at) VALUES(?,?,?,?,?,?)",
                         (pid, body.username.strip().lower(), body.display_name.strip(), body.avatar_color, phash, now))
            conn.commit()
    except sqlite3.IntegrityError:
        raise HTTPException(400, detail="Username already exists")
    return JSONResponse({"id": pid})

@_admin.put("/players/{pid}")
async def update_player(pid: str, body: PlayerBody, session=Depends(get_current_session)):
    try:
        with _db() as conn:
            if body.password:
                conn.execute("UPDATE players SET username=?,display_name=?,avatar_color=?,password_hash=? WHERE id=?",
                             (body.username.strip().lower(), body.display_name.strip(), body.avatar_color, _hash_pw(body.password), pid))
            else:
                conn.execute("UPDATE players SET username=?,display_name=?,avatar_color=? WHERE id=?",
                             (body.username.strip().lower(), body.display_name.strip(), body.avatar_color, pid))
            conn.commit()
    except sqlite3.IntegrityError:
        raise HTTPException(400, detail="Username already exists")
    return JSONResponse({"ok": True})

@_admin.delete("/players/{pid}")
async def delete_player(pid: str, session=Depends(get_current_session)):
    with _db() as conn:
        conn.execute("DELETE FROM players WHERE id=?", (pid,))
        conn.commit()
    return JSONResponse({"ok": True})

@_admin.get("/stats")
async def get_stats(session=Depends(get_current_session)):
    return await _build_stats()

# ── Stats builder ─────────────────────────────────────────────

async def _build_stats():
    with _db() as conn:
        games   = [r["game_id"] for r in conn.execute("SELECT DISTINCT game_id FROM game_sessions ORDER BY game_id").fetchall()]
        players = {r["id"]: dict(r) for r in conn.execute("SELECT id,username,display_name,avatar_color FROM players").fetchall()}

        leaderboard = {}
        for game_id in games:
            rows = conn.execute("""
                SELECT sp.player_id, p.display_name, p.avatar_color,
                       COUNT(*) as played, SUM(sp.is_winner) as wins,
                       MAX(sp.score) as best_score, AVG(sp.score) as avg_score
                FROM session_players sp JOIN players p ON sp.player_id=p.id
                WHERE sp.player_id IS NOT NULL
                  AND sp.session_id IN (SELECT id FROM game_sessions WHERE game_id=?)
                GROUP BY sp.player_id ORDER BY wins DESC, avg_score DESC
            """, (game_id,)).fetchall()
            leaderboard[game_id] = [dict(r) for r in rows]

        recent = conn.execute("""
            SELECT id,game_id,mode,played_at,duration_seconds,metadata FROM game_sessions
            ORDER BY played_at DESC LIMIT 50
        """).fetchall()
        recent_out = []
        for gs in recent:
            sp = conn.execute("""
                SELECT sp.player_id,sp.guest_name,sp.score,sp.is_winner,p.display_name,p.avatar_color
                FROM session_players sp LEFT JOIN players p ON sp.player_id=p.id
                WHERE sp.session_id=? ORDER BY sp.rank,sp.score DESC
            """, (gs["id"],)).fetchall()
            recent_out.append({**dict(gs), "players": [dict(p) for p in sp]})

        h2h_rows = conn.execute("""
            SELECT a.player_id as p1, b.player_id as p2,
                   SUM(CASE WHEN a.is_winner=1 THEN 1 ELSE 0 END) as p1_wins,
                   SUM(CASE WHEN b.is_winner=1 THEN 1 ELSE 0 END) as p2_wins,
                   COUNT(*) as total
            FROM session_players a
            JOIN session_players b ON a.session_id=b.session_id AND a.player_id < b.player_id
            WHERE a.player_id IS NOT NULL AND b.player_id IS NOT NULL
            GROUP BY a.player_id, b.player_id
        """).fetchall()

    return JSONResponse({
        "games": games,
        "leaderboard": leaderboard,
        "recent": recent_out,
        "head2head": [dict(r) for r in h2h_rows],
        "players": list(players.values()),
    })

# Combine into single router for the loader
router.include_router(_admin)
router.include_router(_pub)
