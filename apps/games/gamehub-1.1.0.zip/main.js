const _gh18n = {
  en: {
    title:'Game Hub', players:'Players', sessions:'Sessions', leaderboard:'Leaderboard',
    add_player:'+ Add player', edit:'Edit', del:'Delete', del_confirm:'Delete this player?',
    username:'Username', display_name:'Display name', avatar_color:'Color',
    password:'Password', password_edit:'New password (leave blank to keep)',
    save:'Save', cancel:'Cancel', no_players:'No players yet.',
    no_sessions:'No sessions recorded yet.', no_stats:'No stats yet.',
    played:'played', wins:'wins', best:'best', avg:'avg',
    vs:'vs', winner:'Winner', guests:'guests',
    duration:'Duration', game:'Game', score:'Score',
    username_taken:'Username already taken.',
    sec:'s', min:'m',
  },
  bg: {
    title:'Game Hub', players:'Играчи', sessions:'Сесии', leaderboard:'Класация',
    add_player:'+ Добави играч', edit:'Редактирай', del:'Изтрий', del_confirm:'Изтриване на играча?',
    username:'Потребителско Ime', display_name:'Показвано Ime', avatar_color:'Цвят',
    password:'Парола', password_edit:'Нова парола (остави празно за без промяна)',
    save:'Запази', cancel:'Отказ', no_players:'Няма играчи.',
    no_sessions:'Няма записани сесии.', no_stats:'Няма статистики.',
    played:'изиграни', wins:'победи', best:'най-добър', avg:'средно',
    vs:'срещу', winner:'Победител', guests:'гости',
    duration:'Продължителност', game:'Игра', score:'Резултат',
    username_taken:'Потребителското ime вече съществува.',
    sec:'с', min:'м',
  },
};
function _ght(k) { const l=window.mvmOS?.lang||'en'; return (_gh18n[l]||_gh18n.en)[k]||k; }

const _GH_COLORS = ['#89b4fa','#a6e3a1','#f38ba8','#fab387','#f9e2af','#cba6f7','#94e2d5','#f5c2e7','#74c7ec','#eba0ac'];

mvmOS.registerApp({
  id: 'gamehub',
  name: _ght('title'),
  icon: '🎮',
  category: 'Games',

  launch() {
    mvmOS.createWindow({
      id: 'gamehub',
      title: '🎮 ' + _ght('title'),
      width: 860,
      height: 580,
      onMount(body) {
        body.style.cssText = 'display:flex;flex-direction:column;height:100%;overflow:hidden;font-family:var(--font,sans-serif);background:var(--bg);color:var(--fg)';

        const esc = s => String(s||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
        const btn = (bg) => `padding:4px 12px;border-radius:6px;border:none;cursor:pointer;font-size:13px;background:${bg||'var(--surface2)'};color:${bg?'#fff':'var(--fg)'}`;
        const inp = (w) => `padding:5px 8px;border-radius:6px;border:1px solid var(--border);background:var(--surface2);color:var(--fg);font-size:13px;${w?'width:'+w+';':'width:100%;'}box-sizing:border-box`;
        const fld = (label,inner) => `<label style="display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--fg2)">${label}${inner}</label>`;
        const fmtDur = s => !s?'—':s<60?s+_ght('sec'):Math.floor(s/60)+_ght('min')+(s%60?s%60+_ght('sec'):'');
        const fmtDate = s => new Date(s).toLocaleString(undefined,{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:false});

        let tab = 'players', players = [], stats = null;

        // ── shell ───────────────────────────────────────────────
        body.innerHTML = `
          <div style="display:flex;align-items:center;gap:8px;padding:8px 14px;border-bottom:1px solid var(--border);flex-shrink:0">
            <span style="font-weight:700;font-size:15px">🎮 ${_ght('title')}</span>
            <div style="flex:1"></div>
            ${['players','sessions','leaderboard'].map(t=>`<button id="gh-t-${t}" style="${btn()}">${_ght(t)}</button>`).join('')}
          </div>
          <div id="gh-body" style="flex:1;overflow-y:auto;padding:14px"></div>
        `;

        ['players','sessions','leaderboard'].forEach(t => {
          body.querySelector(`#gh-t-${t}`).onclick = () => { tab=t; renderTabs(); render(); };
        });

        function renderTabs() {
          ['players','sessions','leaderboard'].forEach(t => {
            const b = body.querySelector(`#gh-t-${t}`); if(!b) return;
            b.style.background = tab===t ? 'var(--accent)' : 'var(--surface2)';
            b.style.color      = tab===t ? '#fff' : 'var(--fg)';
          });
        }

        async function reload() {
          const pr = await fetch('/api/gamehub/players');
          players = pr.ok ? await pr.json() : [];
          const sr = await fetch('/api/gamehub/stats');
          stats = sr.ok ? await sr.json() : null;
          render();
        }

        function render() {
          renderTabs();
          if(tab==='players')     renderPlayers();
          else if(tab==='sessions')    renderSessions();
          else if(tab==='leaderboard') renderLeaderboard();
        }

        // ── Players tab ─────────────────────────────────────────
        function renderPlayers() {
          const c = body.querySelector('#gh-body');
          c.innerHTML = `<div style="display:flex;justify-content:flex-end;margin-bottom:12px"><button id="gh-add" style="${btn('var(--accent)')}">${_ght('add_player')}</button></div>`;
          if(!players.length) { c.innerHTML += `<div style="color:var(--fg2);text-align:center;margin-top:30px">${_ght('no_players')}</div>`; }
          else {
            const grid = document.createElement('div');
            grid.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px';
            players.forEach(p => {
              const card = document.createElement('div');
              card.style.cssText = 'background:var(--surface1);border-radius:8px;padding:14px;display:flex;flex-direction:column;gap:8px;cursor:pointer;transition:background .15s';
              card.onmouseenter = () => card.style.background = 'var(--surface2)';
              card.onmouseleave = () => card.style.background = 'var(--surface1)';
              card.addEventListener('click', e => { if(!e.target.closest('button')) showPlayerProfile(p); });
              const pstats = stats?.leaderboard ? Object.values(stats.leaderboard).flat().filter(s=>s.player_id===p.id) : [];
              const totalPlayed = pstats.reduce((a,s)=>a+(s.played||0),0);
              const totalWins   = pstats.reduce((a,s)=>a+(s.wins||0),0);
              card.innerHTML = `
                <div style="display:flex;align-items:center;gap:10px">
                  <div style="width:36px;height:36px;border-radius:50%;background:${esc(p.avatar_color)};display:flex;align-items:center;justify-content:center;font-weight:700;font-size:16px;color:#1e1e2e;flex-shrink:0">${esc(p.display_name[0]?.toUpperCase()||'?')}</div>
                  <div>
                    <div style="font-weight:600;font-size:14px">${esc(p.display_name)}</div>
                    <div style="font-size:11px;color:var(--fg2)">@${esc(p.username)}</div>
                  </div>
                </div>
                <div style="font-size:12px;color:var(--fg2)">${totalPlayed} ${_ght('played')} · ${totalWins} ${_ght('wins')}</div>
                <div style="display:flex;gap:6px">
                  <button class="gh-edit" data-id="${p.id}" style="${btn()};flex:1;font-size:12px">${_ght('edit')}</button>
                  <button class="gh-del"  data-id="${p.id}" style="${btn('#f38ba8')};font-size:12px">${_ght('del')}</button>
                </div>`;
              grid.appendChild(card);
            });
            c.appendChild(grid);
          }
          c.querySelector('#gh-add').onclick = () => showPlayerModal(null);
          c.querySelectorAll('.gh-edit').forEach(b => b.onclick = () => showPlayerModal(players.find(p=>p.id===b.dataset.id)));
          c.querySelectorAll('.gh-del').forEach(b => b.onclick = async () => {
            if(!confirm(_ght('del_confirm'))) return;
            await fetch(`/api/gamehub/players/${b.dataset.id}`,{method:'DELETE'});
            reload();
          });
        }

        // ── Player profile overlay ─────────────────────────────
        function showPlayerProfile(p) {
          const allSessions = (stats?.recent||[]).filter(s => s.players.some(sp=>sp.player_id===p.id));
          const games = [...new Set(allSessions.map(s=>s.game_id))].sort();

          const overlay = document.createElement('div');
          overlay.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,.55);backdrop-filter:blur(3px);z-index:50;display:flex;align-items:center;justify-content:center;padding:16px;box-sizing:border-box';
          overlay.innerHTML = `
            <div style="background:var(--bg);border:1px solid var(--border);border-radius:12px;width:100%;max-width:460px;max-height:100%;overflow-y:auto;display:flex;flex-direction:column">
              <div style="display:flex;align-items:center;gap:12px;padding:16px;border-bottom:1px solid var(--border);flex-shrink:0">
                <div style="width:48px;height:48px;border-radius:50%;background:${esc(p.avatar_color)};display:flex;align-items:center;justify-content:center;font-weight:700;font-size:22px;color:#1e1e2e;flex-shrink:0">${esc(p.display_name[0]?.toUpperCase()||'?')}</div>
                <div style="flex:1">
                  <div style="font-weight:700;font-size:16px">${esc(p.display_name)}</div>
                  <div style="font-size:12px;color:var(--fg2)">@${esc(p.username)}</div>
                </div>
                <button id="gh-prof-close" style="${btn()};padding:4px 10px;font-size:16px;line-height:1">✕</button>
              </div>
              ${games.length > 1 ? `
              <div style="padding:10px 16px;border-bottom:1px solid var(--border);flex-shrink:0;display:flex;align-items:center;gap:8px">
                <span style="font-size:12px;color:var(--fg2)">Game:</span>
                <select id="gh-prof-game" style="${inp('auto')};flex:1">
                  <option value="">All games</option>
                  ${games.map(g=>`<option value="${esc(g)}">${esc(g)}</option>`).join('')}
                </select>
              </div>` : ''}
              <div id="gh-prof-stats" style="display:flex;border-bottom:1px solid var(--border);flex-shrink:0"></div>
              <div style="padding:14px;display:flex;flex-direction:column;gap:6px" id="gh-prof-sessions"></div>
            </div>`;

          body.appendChild(overlay);
          overlay.querySelector('#gh-prof-close').onclick = () => overlay.remove();
          overlay.addEventListener('click', e => { if(e.target===overlay) overlay.remove(); });

          function renderProfile(gameFilter) {
            const filteredSessions = gameFilter
              ? allSessions.filter(s=>s.game_id===gameFilter)
              : allSessions;

            // stats from leaderboard for the filtered game(s)
            const pstats = stats?.leaderboard
              ? (gameFilter
                  ? (stats.leaderboard[gameFilter]||[]).filter(s=>s.player_id===p.id)
                  : Object.values(stats.leaderboard).flat().filter(s=>s.player_id===p.id))
              : [];
            const totalPlayed = pstats.reduce((a,s)=>a+(s.played||0),0);
            const totalWins   = pstats.reduce((a,s)=>a+(s.wins||0),0);

            const statsCols = [
              [totalPlayed, _ght('played')],
              [totalWins,   _ght('wins')],
              [filteredSessions.length, _ght('sessions')],
            ];
            if (gameFilter) {
              const bestScore = pstats.reduce((a,s)=>Math.max(a,s.best_score||0),0);
              statsCols.push([bestScore||'—', _ght('best')]);
            }

            const statsEl = overlay.querySelector('#gh-prof-stats');
            statsEl.innerHTML = statsCols.map(([v,l], i) => `
              <div style="flex:1;text-align:center;padding:12px 8px;${i<statsCols.length-1?'border-right:1px solid var(--border)':''}">
                <div style="font-size:20px;font-weight:700">${v}</div>
                <div style="font-size:11px;color:var(--fg2);margin-top:2px">${l}</div>
              </div>`).join('');

            const sc = overlay.querySelector('#gh-prof-sessions');
            sc.innerHTML = '';
            if (!filteredSessions.length) {
              sc.innerHTML = `<div style="color:var(--fg2);text-align:center;padding:20px">${_ght('no_sessions')}</div>`;
              return;
            }
            filteredSessions.forEach(s => {
              let meta = {};
              try { meta = JSON.parse(s.metadata||'{}'); } catch(_) {}
              const metaParts = [];
              if(meta.rounds!=null)         metaParts.push(`${meta.rounds} rounds`);
              if(meta.time_per_round!=null) metaParts.push(meta.time_per_round===0?'no limit':fmtDur(meta.time_per_round)+'/round');
              const modeLabel = s.mode==='singleplayer'?'👤':'👥';
              const myResult  = s.players.find(sp=>sp.player_id===p.id);
              const row = document.createElement('div');
              row.style.cssText = 'background:var(--surface1);border-radius:8px;padding:9px 12px;display:flex;align-items:center;gap:10px;cursor:pointer;transition:background .15s';
              row.onmouseenter = ()=>row.style.background='var(--surface2)';
              row.onmouseleave = ()=>row.style.background='var(--surface1)';
              row.innerHTML = `
                <div style="font-size:18px">🎮</div>
                <div style="flex:1;min-width:0">
                  <div style="font-size:13px;font-weight:600">${!gameFilter?esc(s.game_id)+' ':''}${modeLabel}</div>
                  ${metaParts.length?`<div style="font-size:11px;color:var(--fg2)">${metaParts.join(' · ')}</div>`:''}
                </div>
                <div style="text-align:right;flex-shrink:0">
                  ${myResult?.score!=null?`<div style="font-weight:700;font-size:14px">${myResult.score} pts</div>`:''}
                  ${myResult?.is_winner?`<div style="font-size:11px;color:#a6e3a1">🏆</div>`:''}
                  <div style="font-size:11px;color:var(--fg2)">${fmtDate(s.played_at)}</div>
                </div>`;
              row.addEventListener('click', () => showSessionDetail(s));
              sc.appendChild(row);
            });
          }

          renderProfile('');
          const sel = overlay.querySelector('#gh-prof-game');
          if (sel) sel.addEventListener('change', () => renderProfile(sel.value));
        }

        // ── Session detail overlay ──────────────────────────────
        function showSessionDetail(s) {
          let meta = {};
          try { meta = JSON.parse(s.metadata || '{}'); } catch(_) {}
          const modeLabel = s.mode === 'singleplayer' ? '👤 Single player' : '👥 Multiplayer';
          const sorted = s.players.slice().sort((a,b) => (b.score||0) - (a.score||0));
          const winner = sorted.find(p => p.is_winner);

          const metaRows = [];
          if (meta.rounds != null)         metaRows.push(['Rounds', meta.rounds]);
          if (meta.time_per_round != null) metaRows.push(['Time / round', meta.time_per_round === 0 ? 'No limit' : fmtDur(meta.time_per_round)]);
          if (s.duration_seconds)          metaRows.push(['Total time', fmtDur(s.duration_seconds)]);
          metaRows.push(['Mode', modeLabel]);
          metaRows.push(['Date', fmtDate(s.played_at)]);

          const overlay = document.createElement('div');
          overlay.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,.55);backdrop-filter:blur(3px);z-index:50;display:flex;align-items:center;justify-content:center;padding:16px;box-sizing:border-box';
          overlay.innerHTML = `
            <div style="background:var(--bg);border:1px solid var(--border);border-radius:12px;width:100%;max-width:420px;max-height:100%;overflow-y:auto;display:flex;flex-direction:column;gap:0">
              <div style="display:flex;align-items:center;gap:10px;padding:14px 16px;border-bottom:1px solid var(--border);flex-shrink:0">
                <span style="font-size:22px">🎮</span>
                <div style="flex:1">
                  <div style="font-weight:700;font-size:15px">${esc(s.game_id)}</div>
                  <div style="font-size:12px;color:var(--fg2)">${modeLabel}</div>
                </div>
                <button id="gh-det-close" style="${btn()};padding:4px 10px;font-size:16px;line-height:1">✕</button>
              </div>
              <div style="padding:14px 16px;display:flex;flex-direction:column;gap:14px">
                <table style="width:100%;border-collapse:collapse;font-size:13px">
                  ${metaRows.map(([k,v]) => `
                    <tr>
                      <td style="color:var(--fg2);padding:3px 0;width:46%">${esc(String(k))}</td>
                      <td style="font-weight:600;padding:3px 0">${esc(String(v))}</td>
                    </tr>`).join('')}
                </table>
                <div>
                  <div style="font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--fg2);margin-bottom:8px">Players</div>
                  ${sorted.map((p, i) => {
                    const name  = p.display_name || p.guest_name || '?';
                    const color = p.avatar_color || '#585b70';
                    const isWin = p.is_winner;
                    return `<div style="display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;margin-bottom:4px;background:${isWin ? 'rgba(166,227,161,.12)' : 'var(--surface1)'};${isWin ? 'outline:1px solid rgba(166,227,161,.4)' : ''}">
                      <span style="font-size:13px;color:var(--fg2);min-width:18px;text-align:right">${i+1}.</span>
                      <span style="width:28px;height:28px;border-radius:50%;background:${color};display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#1e1e2e;flex-shrink:0">${esc((name[0]||'?').toUpperCase())}</span>
                      <span style="flex:1;font-weight:600;font-size:13px">${esc(name)}${!p.player_id ? ' <span style="font-size:10px;color:var(--fg2)">(guest)</span>' : ''}</span>
                      ${p.score != null ? `<span style="font-weight:700;font-size:15px">${p.score}</span>` : ''}
                      ${isWin ? `<span style="font-size:14px" title="Winner">🏆</span>` : ''}
                    </div>`;
                  }).join('')}
                </div>
              </div>
            </div>`;
          body.appendChild(overlay);
          overlay.querySelector('#gh-det-close').onclick = () => overlay.remove();
          overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
        }

        // ── Sessions tab ────────────────────────────────────────
        function renderSessions() {
          const c = body.querySelector('#gh-body');
          const recent = stats?.recent || [];
          if(!recent.length) { c.innerHTML=`<div style="color:var(--fg2);text-align:center;margin-top:30px">${_ght('no_sessions')}</div>`; return; }
          c.innerHTML = '';
          recent.forEach(s => {
            const row = document.createElement('div');
            row.style.cssText = 'background:var(--surface1);border-radius:8px;padding:10px 14px;margin-bottom:8px;display:flex;align-items:center;gap:12px;cursor:pointer;transition:background .15s';
            row.onmouseenter = () => row.style.background = 'var(--surface2)';
            row.onmouseleave = () => row.style.background = 'var(--surface1)';
            const winner = s.players.find(p=>p.is_winner);
            const pnames = s.players.map(p => {
              const name = p.display_name || p.guest_name || '?';
              const color = p.avatar_color || '#585b70';
              return `<span style="display:inline-flex;align-items:center;gap:4px"><span style="width:8px;height:8px;border-radius:50%;background:${color};display:inline-block"></span>${esc(name)}${p.score!=null?` <span style="color:var(--fg2);font-size:11px">(${p.score})</span>`:''}</span>`;
            }).join('<span style="color:var(--fg2);padding:0 4px">·</span>');
            let meta = {};
            try { meta = JSON.parse(s.metadata || '{}'); } catch(_) {}
            const metaParts = [];
            if (meta.rounds != null)         metaParts.push(`${meta.rounds} rounds`);
            if (meta.time_per_round != null) metaParts.push(meta.time_per_round === 0 ? 'no limit' : fmtDur(meta.time_per_round) + '/round');
            const modeLabel = s.mode === 'singleplayer' ? '👤' : '👥';
            row.innerHTML = `
              <div style="font-size:20px">🎮</div>
              <div style="flex:1;min-width:0">
                <div style="font-size:13px;font-weight:600">${esc(s.game_id)} ${modeLabel}</div>
                ${metaParts.length ? `<div style="font-size:11px;color:var(--fg2);margin-top:1px">${metaParts.join(' · ')}</div>` : ''}
                <div style="font-size:12px;color:var(--fg2);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${pnames}</div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:12px;color:var(--fg2)">${fmtDate(s.played_at)}</div>
                ${s.duration_seconds?`<div style="font-size:11px;color:var(--fg2)">${fmtDur(s.duration_seconds)}</div>`:''}
                <div style="font-size:10px;color:var(--fg2);margin-top:3px">›</div>
              </div>`;
            row.addEventListener('click', () => showSessionDetail(s));
            c.appendChild(row);
          });
        }

        // ── Leaderboard tab ─────────────────────────────────────
        function renderLeaderboard() {
          const c = body.querySelector('#gh-body');
          if(!stats?.games?.length) { c.innerHTML=`<div style="color:var(--fg2);text-align:center;margin-top:30px">${_ght('no_stats')}</div>`; return; }
          c.innerHTML = '';
          stats.games.forEach(gameId => {
            const rows = stats.leaderboard[gameId] || [];
            if(!rows.length) return;
            const section = document.createElement('div');
            section.style.cssText = 'margin-bottom:20px';
            section.innerHTML = `<div style="font-weight:700;font-size:14px;margin-bottom:8px;color:var(--accent)">${esc(gameId)}</div>`;
            const tbl = document.createElement('table');
            tbl.style.cssText = 'width:100%;border-collapse:collapse;font-size:13px';
            tbl.innerHTML = `<thead><tr style="color:var(--fg2);font-size:11px;text-align:left">
              <th style="padding:4px 8px">#</th>
              <th style="padding:4px 8px">${_ght('display_name')}</th>
              <th style="padding:4px 8px;text-align:right">${_ght('played')}</th>
              <th style="padding:4px 8px;text-align:right">${_ght('wins')}</th>
              <th style="padding:4px 8px;text-align:right">${_ght('best')}</th>
              <th style="padding:4px 8px;text-align:right">${_ght('avg')}</th>
            </tr></thead>`;
            const tbody = document.createElement('tbody');
            rows.forEach((r,i) => {
              const tr = document.createElement('tr');
              tr.style.cssText = `background:${i%2?'var(--surface1)':'transparent'}`;
              tr.innerHTML = `
                <td style="padding:5px 8px;color:var(--fg2)">${i+1}</td>
                <td style="padding:5px 8px">
                  <span style="display:inline-flex;align-items:center;gap:6px">
                    <span style="width:10px;height:10px;border-radius:50%;background:${esc(r.avatar_color)};display:inline-block"></span>
                    ${esc(r.display_name)}
                  </span>
                </td>
                <td style="padding:5px 8px;text-align:right">${r.played}</td>
                <td style="padding:5px 8px;text-align:right;color:var(--accent)">${r.wins}</td>
                <td style="padding:5px 8px;text-align:right">${r.best_score!=null?Math.round(r.best_score*10)/10:'—'}</td>
                <td style="padding:5px 8px;text-align:right;color:var(--fg2)">${r.avg_score!=null?Math.round(r.avg_score*10)/10:'—'}</td>`;
              tbody.appendChild(tr);
            });
            tbl.appendChild(tbody);
            section.appendChild(tbl);
            c.appendChild(section);
          });

          // head2head
          const h2h = (stats.head2head||[]).filter(r=>r.p1_wins+r.p2_wins+r.draws>0);
          if(h2h.length) {
            const playerMap = Object.fromEntries((stats.players||[]).map(p=>[p.id,p]));
            const sec = document.createElement('div');
            sec.innerHTML = `<div style="font-weight:700;font-size:14px;margin-bottom:8px;color:var(--accent)">Head to Head</div>`;
            h2h.forEach(r => {
              const p1 = playerMap[r.p1], p2 = playerMap[r.p2];
              if(!p1||!p2) return;
              const row = document.createElement('div');
              row.style.cssText = 'display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--border)';
              row.innerHTML = `
                <span style="display:inline-flex;align-items:center;gap:4px;flex:1;justify-content:flex-end;font-size:13px">
                  <span style="width:9px;height:9px;border-radius:50%;background:${esc(p1.avatar_color)};display:inline-block"></span>
                  ${esc(p1.display_name)}
                </span>
                <span style="font-size:13px;font-weight:700;color:var(--accent);min-width:50px;text-align:center">${r.p1_wins} – ${r.p2_wins}</span>
                <span style="display:inline-flex;align-items:center;gap:4px;flex:1;font-size:13px">
                  <span style="width:9px;height:9px;border-radius:50%;background:${esc(p2.avatar_color)};display:inline-block"></span>
                  ${esc(p2.display_name)}
                </span>`;
              sec.appendChild(row);
            });
            c.appendChild(sec);
          }
        }

        // ── Player modal ────────────────────────────────────────
        function showPlayerModal(player) {
          const isNew = !player;
          const ov = document.createElement('div');
          ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:9999';
          const box = document.createElement('div');
          box.style.cssText = 'background:var(--surface1);border-radius:10px;padding:20px;width:360px;max-width:95vw;display:flex;flex-direction:column;gap:12px';

          let selColor = player?.avatar_color || _GH_COLORS[players.length % _GH_COLORS.length];

          box.innerHTML = `
            <div style="font-weight:700;font-size:16px">${isNew?_ght('add_player'):_ght('edit')}</div>
            ${fld(_ght('display_name'),`<input id="gh-dname" value="${esc(player?.display_name||'')}" style="${inp()}">`)}
            ${fld(_ght('username'),`<input id="gh-uname" value="${esc(player?.username||'')}" style="${inp()}">`)  }
            ${fld(isNew ? _ght('password') : _ght('password_edit'), `<input id="gh-pass" type="password" placeholder="${esc(isNew ? '' : _ght('password_edit'))}" style="${inp()}">`)}
            <div>
              <div style="font-size:12px;color:var(--fg2);margin-bottom:6px">${_ght('avatar_color')}</div>
              <div id="gh-colors" style="display:flex;gap:6px;flex-wrap:wrap"></div>
            </div>
            <div id="gh-err" style="font-size:12px;color:#f38ba8;display:none"></div>
            <div style="display:flex;gap:8px;justify-content:flex-end">
              <button id="gh-cancel" style="${btn()}">${_ght('cancel')}</button>
              <button id="gh-save"   style="${btn('var(--accent)')}">${_ght('save')}</button>
            </div>`;

          const colorsEl = box.querySelector('#gh-colors');
          function renderColors() {
            colorsEl.innerHTML = '';
            _GH_COLORS.forEach(c => {
              const dot = document.createElement('div');
              dot.style.cssText = `width:24px;height:24px;border-radius:50%;background:${c};cursor:pointer;border:2px solid ${c===selColor?'#fff':'transparent'};transition:border .1s`;
              dot.onclick = () => { selColor=c; renderColors(); };
              colorsEl.appendChild(dot);
            });
          }
          renderColors();

          box.querySelector('#gh-cancel').onclick = () => ov.remove();
          box.querySelector('#gh-save').onclick = async () => {
            const dname = box.querySelector('#gh-dname').value.trim();
            const uname = box.querySelector('#gh-uname').value.trim();
            const pass  = box.querySelector('#gh-pass').value;
            if(!dname||!uname) return;
            if(isNew && !pass) { const err=box.querySelector('#gh-err'); err.textContent='Password required'; err.style.display='block'; return; }
            const payload = {username:uname, display_name:dname, avatar_color:selColor};
            if(pass) payload.password = pass;
            const url  = isNew ? '/api/gamehub/players' : `/api/gamehub/players/${player.id}`;
            const res  = await fetch(url,{method:isNew?'POST':'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
            if(!res.ok) {
              const d = await res.json().catch(()=>({}));
              const err = box.querySelector('#gh-err');
              err.textContent = d.detail===`Username already exists` ? _ght('username_taken') : (d.detail||'Error');
              err.style.display='block';
              return;
            }
            ov.remove(); reload();
          };
          ov.appendChild(box);
          ov.onclick = e => { if(e.target===ov) ov.remove(); };
          document.body.appendChild(ov);
          setTimeout(()=>box.querySelector('#gh-dname')?.focus(),50);
        }

        reload();
      }
    });
  }
});
