// mvmOS App: FindYourself v1.2.0
const _fyi18n = {
  en: {
    title: 'FindYourself', play: 'Play', settings_btn: '⚙ Settings',
    no_api: 'Enter your Google Maps API key in App Settings to play.',
    round: 'Round', of: 'of', score: 'Score', time: 'Time',
    click_map: 'Click on the map to place your guess',
    reset_pos: 'Reset position', expand_map: 'Expand map', collapse_map: 'Collapse map',
    submit: 'Submit Guess', next_round: 'Next Round', see_result: 'See Result',
    finish: 'Finish Game', play_again: 'Play Again',
    distance: 'Distance', points: 'Points',
    result_title: 'Round Result',
    final_title: 'Game Over',
    total_score: 'Total Score',
    best: 'Best', rounds_label: 'rounds',
    rounds_count: 'Rounds', time_per_round: 'Time per round', no_limit: 'No limit',
    location_pts: 'Location', time_bonus: 'Time bonus', total_pts: 'Total',
    loading: 'Loading Street View…',
    no_sv: 'No Street View found nearby, trying another location…',
    singleplayer: 'Single player', multiplayer: 'Multiplayer',
    mp_share: 'Share this link with your friends:', copy_link: 'Copy link', copied: 'Copied!',
    host: 'Host', your_name: 'Your name', ready: 'Ready', waiting_host: 'Waiting for host…',
    players: 'Players', start_game: 'Start game', need_players: 'Waiting for players…',
    waiting_others: 'Waiting for other players…', times_up: "Time's up! Calculating…",
    next_round: 'Next Round', final_standings: 'Final Standings', winner: 'Winner',
    you: 'You', host_left: 'The host left the game.', enter_name: 'Enter your name to join',
    waiting_round: 'Waiting for the host to start the next round…',
  },
  bg: {
    title: 'FindYourself', play: 'Играй', settings_btn: '⚙ Настройки',
    no_api: 'Въведи Google Maps API ключ в App Settings за да играеш.',
    round: 'Рунд', of: 'от', score: 'Точки', time: 'Време',
    click_map: 'Кликни на картата за да отбележиш позицията си',
    submit: 'Потвърди', next_round: 'Следващ рунд', see_result: 'Виж резултата',
    finish: 'Приключи', play_again: 'Играй пак',
    distance: 'Разстояние', points: 'Точки',
    result_title: 'Резултат',
    final_title: 'Край на играта',
    total_score: 'Общо точки',
    best: 'Рекорд', rounds_label: 'рунда',
    reset_pos: 'Начална позиция', expand_map: 'Разшири картата', collapse_map: 'Свий картата',
    rounds_count: 'Брой рундове', time_per_round: 'Време за рунд', no_limit: 'Без време',
    location_pts: 'Локация', time_bonus: 'Бонус за време', total_pts: 'Общо',
    loading: 'Зареждане на Street View…',
    no_sv: 'Няма Street View наблизо, опитваме друга локация…',
    singleplayer: 'Сам', multiplayer: 'Мултиплеър',
    mp_share: 'Сподели този линк с приятелите си:', copy_link: 'Копирай линка', copied: 'Копирано!',
    host: 'Хост', your_name: 'Твоето име', ready: 'Готов', waiting_host: 'Чака хоста…',
    players: 'Играчи', start_game: 'Старт', need_players: 'Чака играчи…',
    waiting_others: 'Чака останалите играчи…', times_up: 'Времето изтече! Изчисляване…',
    next_round: 'Следващ рунд', final_standings: 'Крайно класиране', winner: 'Победител',
    you: 'Ти', host_left: 'Хостът напусна играта.', enter_name: 'Въведи име за да се присъединиш',
    waiting_round: 'Чака хоста да пусне следващия рунд…',
  },
};
function _fyt(key) { const l = window.mvmOS?.lang || 'en'; return (_fyi18n[l] || _fyi18n.en)[key] || key; }

mvmOS.registerApp({
  id: 'findyourself',
  name: 'FindYourself',
  icon: '🌍',
  category: 'Games',
  settings: [
    { key: 'api_key', label: 'Google Maps API Key', type: 'password', default: '' },
    { key: 'rounds',  label: 'Rounds per game',     type: 'number',  default: 5, min: 1, max: 10 },
    { key: 'time',    label: 'Time per round (sec, 0 = unlimited)', type: 'number', default: 60, min: 0 },
  ],
  launch(opts) {
    const isMP = opts?.multiplayer === true;
    const roomId = opts?.roomId;
    mvmOS.createWindow({
      id: 'findyourself',
      title: '🌍 FindYourself',
      icon: '🌍',
      width: 1000,
      height: 640,
      appSettings: true,
      onAppSettings() { AppStore.openWindow({ section: 'my-apps', appId: 'findyourself' }); },
      onMount(body) {
        body.style.padding = '0';
        body.style.overflow = 'hidden';
        if (isMP && roomId) {
          // Присъединил се играч (standalone страница) — без DB/i18nReady
          FY.joinMultiplayer(body, roomId);
        } else {
          (window.mvmOS?.i18nReady || Promise.resolve()).then(() => FY.mount(body));
        }
      },
    });
  },
});

const FY = (() => {
  // На standalone multiplayer страницата mvmOS.db липсва → _db = null (ползва се само от хоста)
  const _db = (typeof mvmOS !== 'undefined' && mvmOS.db) ? mvmOS.db('findyourself') : null;
  let _root = null;
  let _cfg = { api_key: '', rounds: 5, time: 60 };
  let _sv = null;       // Street View panorama
  let _map = null;      // guess map
  let _marker = null;   // player's guess marker
  let _guess = null;    // { lat, lng }
  let _actual = null;   // { lat, lng }
  let _round = 0;
  let _totalScore = 0;
  let _roundScores = [];
  let _locations = [];  // pre-generated coords for this game
  let _timerInterval = null;
  let _timeLeft = 0;
  let _roundStartTime = 0;  // ms timestamp когато рундът стане готов
  let _initPov = null;      // началната посока на гледане (за reset бутона)
  let _mapsLoaded = false;
  const _isMobile = window.matchMedia('(max-width:600px)').matches;

  // Game Hub state
  let _ghPlayer = null;
  let _ghGuestChosen = false;
  let _gameStartTime = 0;

  // ── Multiplayer state ────────────────────────────────────────────────────
  // _mp = null в single-player. В мултиплеър: { ws, roomId, playerIndex, isHost,
  //   roster:{idx→{name,color}}, phase, submitted:Set, guesses:{idx→guessObj},
  //   curLoc, curHeading, ended }
  let _mp = null;
  let _mpLeaving = false;
  const _PLAYER_COLORS = [
    '#89b4fa', '#f38ba8', '#a6e3a1', '#f9e2af',
    '#cba6f7', '#fab387', '#94e2d5', '#f5c2e7',
    '#74c7ec', '#eba0ac', '#b4befe', '#f2cdcd',
  ];
  function _playerColor(idx) { return _PLAYER_COLORS[idx % _PLAYER_COLORS.length]; }

  // ── Точкуване ──────────────────────────────────────────────────────────────
  const TIME_BONUS_MAX = 1000;     // макс бонус за време (5× по-малък от макс разстояние)
  const TIME_BONUS_WINDOW = 200;   // секунди до 0 бонус (5 точки/сек)
  function _timeBonus(elapsedSec) {
    const b = TIME_BONUS_MAX * (1 - elapsedSec / TIME_BONUS_WINDOW);
    return Math.max(0, Math.round(b));
  }

  // Размер на картата — стъпки в % от екрана (запомня се за цялата игра)
  const _MAP_PCTS = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
  let _mapPctIdx = 2;  // default 30%

  // ── Random locations ──────────────────────────────────────────────────────
  // Weighted list of land bounding boxes [minLat, maxLat, minLng, maxLng, weight]
  const _BOXES = [
    [35, 71, -10, 40, 25],   // Europe
    [25, 50, 60, 140, 20],   // Asia
    [-35, 37, -18, 52, 15],  // Africa
    [25, 50, -125, -65, 15], // North America
    [-55, 15, -82, -34, 10], // South America
    [-45, -10, 110, 155, 8], // Australia
    [0, 25, 100, 140, 7],    // SE Asia
  ];

  function _randomCoord() {
    const total = _BOXES.reduce((s, b) => s + b[4], 0);
    let r = Math.random() * total;
    for (const [minLat, maxLat, minLng, maxLng, w] of _BOXES) {
      r -= w;
      if (r <= 0) {
        return {
          lat: minLat + Math.random() * (maxLat - minLat),
          lng: minLng + Math.random() * (maxLng - minLng),
        };
      }
    }
    return { lat: Math.random() * 140 - 70, lng: Math.random() * 360 - 180 };
  }

  // ── Score calculation (GeoGuessr-style) ───────────────────────────────────
  function _calcScore(distKm) {
    if (distKm < 0.05) return 5000;
    return Math.round(5000 * Math.exp(-distKm / 2000));
  }

  function _distKm(a, b) {
    const R = 6371;
    const dLat = (b.lat - a.lat) * Math.PI / 180;
    const dLng = (b.lng - a.lng) * Math.PI / 180;
    const x = Math.sin(dLat/2)**2 + Math.cos(a.lat*Math.PI/180) * Math.cos(b.lat*Math.PI/180) * Math.sin(dLng/2)**2;
    return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1-x));
  }

  function _fmtDist(km) {
    if (km < 1) return Math.round(km * 1000) + ' m';
    if (km < 100) return km.toFixed(1) + ' km';
    return Math.round(km) + ' km';
  }

  function _fmtTime(s) {
    if (s < 60) return s + 's';
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  }

  // ── Game Hub helpers ─────────────────────────────────────────────────────

  function _loadGameHub(cb, errCb) {
    if (window.GameHub) { window.GameHub.init().then(cb); return; }
    const s = document.createElement('script');
    s.src = '/apps/gamehub/widget.js?v=2';
    s.onload  = () => window.GameHub?.init().then(cb) || cb();
    s.onerror = errCb || cb;
    document.head.appendChild(s);
  }

  function _avatar(player, size) {
    if (window.GameHub) return window.GameHub.renderAvatar(player, size);
    const color = (player && player.avatar_color) || '#585b70';
    const letter = ((player && player.display_name && player.display_name[0]) || '?').toUpperCase();
    return `<svg viewBox="0 0 100 100" width="${size}" height="${size}" style="border-radius:50%;display:block;flex-shrink:0" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="50" fill="${color}"/><text x="50" y="67" font-family="system-ui,sans-serif" font-size="54" font-weight="700" fill="#1e1e2e" text-anchor="middle">${letter}</text></svg>`;
  }

  function _renderGhSection(container, onReload, onUnlock) {
    if (!window.GameHub) { container.style.display = 'none'; return; }
    container.style.display = '';
    const p = window.GameHub.currentPlayer();
    _ghPlayer = p || null;
    if (p) {
      container.innerHTML = `
        <div style="display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.06);border-radius:8px;padding:8px 12px;width:100%;box-sizing:border-box">
          ${_avatar(p, 22)}
          <div style="flex:1;font-size:12px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${p.display_name}</div>
          <button id="fy-gh-out" style="border:none;background:none;color:#a6adc8;font-size:11px;cursor:pointer;padding:2px 6px;flex-shrink:0">Logout</button>
        </div>`;
      container.querySelector('#fy-gh-out').onclick = async () => {
        await window.GameHub.logout();
        _ghPlayer = null; _ghGuestChosen = false;
        onReload();
      };
      onUnlock?.();
    } else if (_ghGuestChosen) {
      container.innerHTML = `
        <div style="font-size:12px;color:#a6adc8;text-align:center">
          No stats (guest) · <span id="fy-gh-lnk" style="color:#89b4fa;cursor:pointer;text-decoration:underline">Log in</span>
        </div>`;
      container.querySelector('#fy-gh-lnk').onclick = () => { _ghGuestChosen = false; onReload(); };
      onUnlock?.();
    } else {
      window.GameHub.renderWidget(container, {
        guestText: 'Skip (no stats)',
        onReady(player) {
          if (player.is_guest) { _ghGuestChosen = true; _ghPlayer = null; }
          else                 { _ghPlayer = player; _ghGuestChosen = false; }
          onReload();
        },
      });
    }
  }

  function _recordGhSession(durationSeconds) {
    if (!_ghPlayer || !window.GameHub) return;
    window.GameHub.recordSession({
      game_id: 'findyourself',
      mode: 'singleplayer',
      players: [{ player_id: _ghPlayer.id, score: _totalScore, is_winner: true }],
      duration_seconds: durationSeconds,
      metadata: { rounds: _cfg.rounds, time_per_round: _cfg.time },
    }).catch(() => {});
  }

  function _recordMpSession(standings) {
    if (!window.GameHub) return;
    const winner = standings[0];
    window.GameHub.recordSession({
      game_id: 'findyourself',
      mode: 'multiplayer',
      players: standings.map(s => ({
        ...(s.gh_player_id ? { player_id: s.gh_player_id } : { guest_name: s.name }),
        score: s.total,
        is_winner: s === winner,
      })),
      metadata: { rounds: _cfg.rounds, time_per_round: _cfg.time },
    }).catch(() => {});
  }

  // ── Google Maps loader ────────────────────────────────────────────────────
  function _loadMaps(apiKey) {
    return new Promise((resolve, reject) => {
      if (_mapsLoaded && window.google?.maps) { resolve(); return; }
      if (window._fyMapsLoading) { window._fyMapsResolvers.push(resolve); return; }
      window._fyMapsLoading = true;
      window._fyMapsResolvers = [resolve];
      window._fyMapsCallback = () => {
        _mapsLoaded = true;
        window._fyMapsLoading = false;
        window._fyMapsResolvers.forEach(r => r());
      };
      const s = document.createElement('script');
      s.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&callback=_fyMapsCallback`;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  // ── Mount ─────────────────────────────────────────────────────────────────
  async function mount(body) {
    _root = body;
    await _initDb();
    await _loadCfg();
    _showSetup();
    window.addEventListener('settings-changed', async e => {
      if (e.detail?.app === 'findyourself') { await _loadCfg(); }
    });
  }

  async function _initDb() {
    await _db.run(`CREATE TABLE IF NOT EXISTS cfg (key TEXT PRIMARY KEY, value TEXT)`);
    await _db.run(`CREATE TABLE IF NOT EXISTS scores
      (id INTEGER PRIMARY KEY AUTOINCREMENT, total INTEGER, rounds INTEGER, date TEXT)`);
  }

  async function _loadCfg() {
    const rows = await _db.query('SELECT key, value FROM cfg');
    const s = {};
    rows.forEach(r => { try { s[r.key] = JSON.parse(r.value); } catch(_) { s[r.key] = r.value; } });
    _cfg = {
      api_key: s.api_key || '',
      rounds:  parseInt(s.rounds) || 5,
      time:    parseInt(s.time) || 60,
    };
  }

  // ── Setup screen ──────────────────────────────────────────────────────────
  async function _showSetup() {
    _stopTimer();
    const best = await _getBest();
    _root.innerHTML = `
      <div class="fy-root">
        <div class="fy-screen">
          <div style="font-size:3rem">🌍</div>
          <h1>${_fyt('title')}</h1>
          <p>Drop into a random Street View location anywhere in the world and guess where you are on the map.</p>
          ${best ? `<div style="font-size:.82rem;color:#a6adc8">${_fyt('best')}: <strong>${best.total}</strong> pts / ${best.rounds} ${_fyt('rounds_label')}</div>` : ''}
          ${!_cfg.api_key ? `
            <p style="color:#f38ba8;font-size:.82rem">${_fyt('no_api')}</p>
            <a href="https://console.cloud.google.com/apis/library/maps-backend.googleapis.com" target="_blank" style="font-size:.78rem;color:#89b4fa">Get API key from Google Cloud Console →</a>
            <button class="fy-btn secondary" onclick="AppStore?.openWindow({section:'my-apps',appId:'findyourself'})">${_fyt('settings_btn')}</button>
          ` : `
            <div class="fy-setup-opts">
              <label class="fy-setup-field">
                <span>${_fyt('rounds_count')}</span>
                <input type="number" id="fy-set-rounds" min="1" max="50" value="${_cfg.rounds}">
              </label>
              <label class="fy-setup-field">
                <span>${_fyt('time_per_round')}</span>
                <select id="fy-set-time">${_timeOptions(_cfg.time)}</select>
              </label>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center">
              <button class="fy-btn" id="fy-start">🌍 ${_fyt('singleplayer')}</button>
              <button class="fy-btn secondary" id="fy-start-mp">👥 ${_fyt('multiplayer')}</button>
            </div>
            <div id="fy-gh-section" style="width:280px"></div>
          `}
        </div>
      </div>`;
    const startBtn   = _root.querySelector('#fy-start');
    const startMpBtn = _root.querySelector('#fy-start-mp');
    if (startBtn)   startBtn.disabled   = true;
    if (startMpBtn) startMpBtn.disabled = true;

    const ghSection = _root.querySelector('#fy-gh-section');
    const _unlock = () => {
      if (startBtn)   startBtn.disabled   = false;
      if (startMpBtn) startMpBtn.disabled = false;
    };
    _loadGameHub(() => {
      if (!ghSection) return;
      _renderGhSection(ghSection, () => _showSetup(), _unlock);
    }, _unlock);

    _root.querySelector('#fy-start')?.addEventListener('click', _startGame);
    _root.querySelector('#fy-start-mp')?.addEventListener('click', () => { _readSetupOpts(); _mpHostLobby(); });
  }

  // Прочита избраните рундове/време от setup екрана в _cfg
  function _readSetupOpts() {
    const rEl = _root.querySelector('#fy-set-rounds');
    const tEl = _root.querySelector('#fy-set-time');
    if (rEl) _cfg.rounds = Math.min(50, Math.max(1, parseInt(rEl.value) || 5));
    if (tEl) { const t = parseInt(tEl.value); _cfg.time = isNaN(t) ? 60 : t; }
  }

  // Селект опции за време: 10-50s, после 1-10 мин, + без време
  function _timeOptions(selected) {
    const opts = [10, 20, 30, 40, 50];
    for (let m = 1; m <= 10; m++) opts.push(m * 60);
    let html = opts.map(s => {
      const label = s < 60 ? s + 's' : (s / 60) + ' min';
      return `<option value="${s}" ${s === selected ? 'selected' : ''}>${label}</option>`;
    }).join('');
    html += `<option value="0" ${selected === 0 ? 'selected' : ''}>${_fyt('no_limit')}</option>`;
    return html;
  }

  async function _getBest() {
    const rows = await _db.query('SELECT * FROM scores ORDER BY total DESC LIMIT 1');
    return rows[0] || null;
  }

  // ── Game ──────────────────────────────────────────────────────────────────
  async function _startGame() {
    _readSetupOpts();
    _gameStartTime = Date.now();
    _mapPctIdx = 2;  // ресет размер на картата за новата игра
    _round = 0;
    _totalScore = 0;
    _roundScores = [];
    _locations = Array.from({ length: _cfg.rounds }, _randomCoord);
    _root.innerHTML = `<div class="fy-root"><div class="fy-game" id="fy-game"></div></div>`;
    try {
      await _loadMaps(_cfg.api_key);
    } catch(e) {
      _root.innerHTML = `<div class="fy-root"><div class="fy-screen"><p style="color:#f38ba8">Failed to load Google Maps. Check your API key.</p><button class="fy-btn secondary" id="fy-back">← Back</button></div></div>`;
      _root.querySelector('#fy-back').addEventListener('click', _showSetup);
      return;
    }
    _nextRound();
  }

  // Шаблон на рунда (HUD + Street View + компас + карта). Преизползва се single + MP.
  function _buildRoundUI(gameEl) {
    gameEl.innerHTML = `
      <div class="fy-hud">
        <div class="fy-hud-pill">${_fyt('round')} <strong>${_round}</strong> ${_fyt('of')} <strong>${_cfg.rounds}</strong></div>
        <div class="fy-hud-pill">${_fyt('score')}: <strong id="fy-score-val">${_totalScore}</strong></div>
        <div class="fy-hud-pill fy-timer" id="fy-timer">${_cfg.time > 0 ? _fmtTime(_cfg.time) : '0:00'}</div>
      </div>
      <div id="fy-sv" class="fy-sv"></div>
      <div class="fy-map-wrap ${_isMobile ? 'fy-map-collapsed' : 'fy-map-mini'}" id="fy-map-wrap">
        <div id="fy-map" class="fy-map"></div>
        <div class="fy-map-thumb" id="fy-map-thumb"><span class="fy-map-thumb-ico">🗺</span></div>
        <div class="fy-map-timer" id="fy-map-timer">${_cfg.time > 0 ? _fmtTime(_cfg.time) : '0:00'}</div>
        <button class="fy-map-close-btn" id="fy-map-close" title="Close map">✕</button>
        <div class="fy-map-inner-controls" id="fy-map-inner-controls">
          ${!_isMobile ? `<button class="fy-map-btn" id="fy-zoom-cycle" title="Zoom map">⊞</button>` : ''}
          <button class="fy-map-btn" id="fy-map-reset" title="${_fyt('reset_pos')}">⌖</button>
          <button class="fy-guess-btn-map" id="fy-submit" disabled>${_fyt('submit')}</button>
        </div>
      </div>
      <div id="fy-sv-loading" style="position:absolute;inset:0;background:#1e1e2e;display:flex;align-items:center;justify-content:center;z-index:5;font-size:.9rem;color:#a6adc8">${_fyt('loading')}</div>
    `;
  }

  async function _nextRound() {
    _guess = null;
    _round++;
    const gameEl = _root.querySelector('#fy-game');
    if (!gameEl) return;
    _buildRoundUI(gameEl);
    await _loadRoundLocation(gameEl);
  }

  async function _loadRoundLocation(gameEl, attempt = 0) {
    if (attempt > 10) {
      const loading = gameEl.querySelector('#fy-sv-loading');
      if (loading) loading.textContent = 'Could not find Street View. Skipping round…';
      setTimeout(() => _submitGuess(true), 1500);
      return;
    }

    const coord = attempt === 0 ? _locations[_round - 1] : _randomCoord();
    if (attempt > 0) _locations[_round - 1] = coord;

    const svService = new google.maps.StreetViewService();
    svService.getPanorama({ location: coord, radius: 50000, source: google.maps.StreetViewSource.OUTDOOR }, (data, status) => {
      if (status !== 'OK') {
        _loadRoundLocation(gameEl, attempt + 1);
        return;
      }
      const actual = { lat: data.location.latLng.lat(), lng: data.location.latLng.lng() };
      _renderRound(gameEl, actual, Math.random() * 360);
    });
  }

  // Построява панорамата + картата + контролите + компаса за фиксирана локация и посока.
  // Преизползва се от single-player И multiplayer (споделена loc/heading за всички играчи).
  function _renderRound(gameEl, actual, heading) {
    _actual = actual;
    _initPov = { heading, pitch: 0 };

    const svEl = gameEl.querySelector('#fy-sv');
    _sv = new google.maps.StreetViewPanorama(svEl, {
      position: _actual,
      pov: _initPov,
      addressControl: false,
      showRoadLabels: false,
      motionTracking: false,
      motionTrackingControl: false,
      fullscreenControl: false,
    });

    const mapEl = gameEl.querySelector('#fy-map');
    _map = new google.maps.Map(mapEl, {
      zoom: 2,
      center: { lat: 20, lng: 0 },
      streetViewControl: false,
      fullscreenControl: false,
      mapTypeControl: false,
      zoomControl: false,
      gestureHandling: 'greedy',
      styles: [{ featureType: 'all', elementType: 'labels.text', stylers: [{ visibility: 'on' }] }],
    });
    _marker = null;
    _map.addListener('click', e => {
      _guess = { lat: e.latLng.lat(), lng: e.latLng.lng() };
      if (_marker) _marker.setMap(null);
      _marker = new google.maps.Marker({ position: _guess, map: _map, title: 'Your guess' });
      const btn = gameEl.querySelector('#fy-submit');
      if (btn) btn.disabled = false;
    });

    // ── Map open/close/zoom ──────────────────────────────────────────────
    const mapWrap = gameEl.querySelector('#fy-map-wrap');

    // Размер в % от екрана; затвореното (мини) състояние е фиксиран малък размер от CSS
    function _setMapPct(idx) {
      const p = _MAP_PCTS[idx];
      if (p >= 100) {
        mapWrap.style.width = 'calc(100% - 16px)';
        mapWrap.style.height = 'calc(100% - 70px)';
        mapWrap.classList.add('fy-map-full');
      } else {
        mapWrap.style.width = p + '%';
        mapWrap.style.height = p + '%';
        mapWrap.classList.remove('fy-map-full');
      }
      setTimeout(() => google.maps.event.trigger(_map, 'resize'), 10);
    }

    function _openMap() {
      if (_isMobile) {
        mapWrap.classList.remove('fy-map-collapsed');
        mapWrap.classList.add('fy-map-active');
      } else {
        mapWrap.classList.remove('fy-map-mini');
        mapWrap.classList.add('fy-map-active');
        _setMapPct(_mapPctIdx);
      }
      setTimeout(() => google.maps.event.trigger(_map, 'resize'), 260);
    }

    function _closeMap() {
      mapWrap.classList.remove('fy-map-active', 'fy-map-full');
      if (_isMobile) {
        mapWrap.classList.add('fy-map-collapsed');
      } else {
        mapWrap.classList.add('fy-map-mini');
        mapWrap.style.width = '';   // връща към фиксирания мини размер от CSS
        mapWrap.style.height = '';
      }
      setTimeout(() => google.maps.event.trigger(_map, 'resize'), 260);
    }

    // Клик на затворената карта (thumb overlay) → отваря
    gameEl.querySelector('#fy-map-thumb')?.addEventListener('click', e => { e.stopPropagation(); _openMap(); });

    // X бутон → затваря
    gameEl.querySelector('#fy-map-close')?.addEventListener('click', e => { e.stopPropagation(); _closeMap(); });

    // Zoom бутон (десктоп) → цикъл през % стъпките, запомня за цялата игра
    gameEl.querySelector('#fy-zoom-cycle')?.addEventListener('click', e => {
      e.stopPropagation();
      _mapPctIdx = (_mapPctIdx + 1) % _MAP_PCTS.length;
      _setMapPct(_mapPctIdx);
    });

    // Десктоп: клик извън картата (върху Street View) → затваря
    if (!_isMobile) {
      gameEl.addEventListener('click', e => {
        if (!mapWrap.classList.contains('fy-map-active')) return;
        if (mapWrap.contains(e.target)) return;
        _closeMap();
      }, true);
    }

    // Reset — връща Street View към началната посока
    gameEl.querySelector('#fy-map-reset')?.addEventListener('click', e => {
      e.stopPropagation();
      _sv.setPov(_initPov);
      _sv.setPosition(_actual);
    });


    const loading = gameEl.querySelector('#fy-sv-loading');
    if (loading) loading.remove();

    // Submit бутон — разклонение single vs multiplayer
    gameEl.querySelector('#fy-submit')?.addEventListener('click', () => {
      if (_mp) _mpSubmit(); else _submitGuess(false);
    });

    _startTimer(gameEl);
  }

  function _startTimer(gameEl) {
    _stopTimer();
    _roundStartTime = Date.now();
    const timed = _cfg.time > 0;
    _timeLeft = _cfg.time;
    _timerInterval = setInterval(() => {
      const el    = gameEl.querySelector('#fy-timer');
      const mapEl = gameEl.querySelector('#fy-map-timer');
      if (timed) {
        _timeLeft--;
        const txt = _fmtTime(Math.max(0, _timeLeft));
        const urgent = _timeLeft <= 10;
        if (el)    { el.textContent = txt;    el.classList.toggle('urgent', urgent); }
        if (mapEl) { mapEl.textContent = txt; mapEl.classList.toggle('urgent', urgent); }
        const liveTimer = gameEl.querySelector('#fy-live-timer');
        if (liveTimer) { liveTimer.textContent = txt; liveTimer.style.color = urgent ? '#f38ba8' : '#f9e2af'; }
        if (_timeLeft <= 0) { _stopTimer(); if (_mp) _mpTimeUp(); else _submitGuess(false); }
      } else {
        const elapsed = Math.floor((Date.now() - _roundStartTime) / 1000);
        const txt = _fmtTime(elapsed);
        if (el)    el.textContent = txt;
        if (mapEl) mapEl.textContent = txt;
      }
    }, 1000);
  }

  function _stopTimer() {
    if (_timerInterval) { clearInterval(_timerInterval); _timerInterval = null; }
  }

  function _submitGuess(noGuess = false) {
    _stopTimer();
    const gameEl = _root.querySelector('#fy-game');
    if (!gameEl) return;

    const elapsed = (Date.now() - _roundStartTime) / 1000;
    let dist = 0, distScore = 0, timeBonus = 0;
    if (!noGuess && _guess && _actual) {
      dist = _distKm(_guess, _actual);
      distScore = _calcScore(dist);
      timeBonus = _timeBonus(elapsed);
    }
    const score = distScore + timeBonus;
    _totalScore += score;
    _roundScores.push({ score, distScore, timeBonus, dist, actual: _actual, guess: _guess });

    // Show result overlay with map
    const isLast = _round >= _cfg.rounds;
    const overlay = document.createElement('div');
    overlay.className = 'fy-result-overlay';
    overlay.innerHTML = `
      <div class="fy-result-box">
        <h2>${_fyt('result_title')} — ${_fyt('round')} ${_round}/${_cfg.rounds}</h2>
        <div class="fy-result-score">+${score} ${_fyt('points')}</div>
        <div class="fy-result-dist">${noGuess || !_guess ? 'No guess — 0 points' : _fyt('distance') + ': ' + _fmtDist(dist)}</div>
        ${!noGuess && _guess ? `
        <div class="fy-result-breakdown">
          <span>${_fyt('location_pts')}: <strong>+${distScore}</strong></span>
          <span>${_fyt('time_bonus')} (${_fmtTime(Math.round(elapsed))}): <strong>+${timeBonus}</strong></span>
          <span>${_fyt('total_pts')}: <strong>${_totalScore}</strong></span>
        </div>` : ''}
        <div class="fy-result-map" id="fy-result-map"></div>
        <div class="fy-result-actions">
          <button class="fy-btn" id="fy-next">${isLast ? _fyt('finish') : _fyt('next_round')}</button>
        </div>
      </div>
    `;
    gameEl.appendChild(overlay);

    // Show result map with actual + guess lines
    setTimeout(() => {
      const resultMapEl = document.getElementById('fy-result-map');
      if (!resultMapEl || !_actual) return;
      const bounds = new google.maps.LatLngBounds();
      const rMap = new google.maps.Map(resultMapEl, {
        streetViewControl: false, fullscreenControl: false,
        mapTypeControl: false, zoomControl: false,
        gestureHandling: 'none',
      });
      // Actual location marker — pin shape
      new google.maps.Marker({
        position: _actual, map: rMap,
        icon: {
          path: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z',
          fillColor: '#f9e2af', fillOpacity: 1, strokeColor: '#1e1e2e', strokeWeight: 1.5,
          scale: 1.6, anchor: new google.maps.Point(12, 22),
        },
        title: 'Actual location', zIndex: 999,
      });
      bounds.extend(_actual);
      if (_guess) {
        new google.maps.Marker({
          position: _guess, map: rMap,
          icon: { path: google.maps.SymbolPath.CIRCLE, scale: 8, fillColor: '#f38ba8', fillOpacity: 1, strokeColor: '#fff', strokeWeight: 2 },
          title: 'Your guess',
        });
        new google.maps.Polyline({
          path: [_actual, _guess], map: rMap,
          strokeColor: '#f1fa8c', strokeOpacity: .8, strokeWeight: 2,
        });
        bounds.extend(_guess);
      }
      rMap.fitBounds(bounds, 40);
    }, 100);

    overlay.querySelector('#fy-next').addEventListener('click', () => {
      overlay.remove();
      if (isLast) _showFinal();
      else _nextRound();
    });
  }

  async function _showFinal() {
    _stopTimer();
    _recordGhSession(Math.round((Date.now() - _gameStartTime) / 1000));
    await _db.run('INSERT INTO scores (total, rounds, date) VALUES (?,?,?)',
      [_totalScore, _cfg.rounds, new Date().toISOString()]);

    const best = await _getBest();
    _root.innerHTML = `
      <div class="fy-root">
        <div class="fy-screen">
          <div style="font-size:2.5rem">🌍</div>
          <h1>${_fyt('final_title')}</h1>
          <div class="fy-result-score">${_totalScore} ${_fyt('points')}</div>
          <div class="fy-scores">
            ${_roundScores.map((r, i) => `
              <div class="fy-score-row">
                <span class="rank">${i+1}.</span>
                <span class="sname">${r.guess ? _fmtDist(r.dist) : 'No guess'}</span>
                <span class="spts">+${r.score}</span>
              </div>
            `).join('')}
          </div>
          ${best ? `<div style="font-size:.8rem;color:#a6adc8">${_fyt('best')}: <strong>${best.total}</strong> pts</div>` : ''}
          <div style="display:flex;gap:10px">
            <button class="fy-btn" id="fy-again">${_fyt('play_again')}</button>
            <button class="fy-btn secondary" id="fy-home">← Menu</button>
          </div>
        </div>
      </div>`;
    _root.querySelector('#fy-again').addEventListener('click', _startGame);
    _root.querySelector('#fy-home').addEventListener('click', _showSetup);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ── MULTIPLAYER ───────────────────────────────────────────────────────────
  // Host-authoritative: хостът генерира локацията на всеки рунд и компилира
  // резултатите. Краят на рунда е автоматичен (време изтекло ИЛИ всички дали
  // предположение). За всеки играч е като single-player, само с общи локации.
  // ══════════════════════════════════════════════════════════════════════════

  function _mpSend(obj) {
    try { if (_mp?.ws && _mp.ws.readyState === 1) _mp.ws.send(JSON.stringify(obj)); } catch(_) {}
  }

  function _mpConnect(roomId, name, isHost) {
    const ws = mvmOS.multiplayer.connect(roomId);
    _mp = {
      ws, roomId, name, isHost,
      playerIndex: -1,
      roster: {},          // idx → { name, color }
      totals: {},          // idx → cumulative (host authority)
      guesses: {},         // idx → { lat,lng,dist,distScore,timeBonus,score }
      curRound: 0,
      submittedSelf: false,
      ended: false,
      apiKey: _cfg.api_key || null,
      phase: null,
    };
    ws.onopen = () => {
      if (!isHost) {
        const ghId = (_ghPlayer && !_ghPlayer.is_guest) ? _ghPlayer.id : null;
        _mpSend({ type: 'hello', name, gh_player_id: ghId, avatar_svg: _ghPlayer?.avatar_svg || null });
      }
    };
    ws.onmessage = (e) => {
      let msg; try { msg = JSON.parse(e.data); } catch(_) { return; }
      if (msg.type === 'joined') {
        _mp.playerIndex = msg.player;
        if (isHost) {
          const hostGhId = (_ghPlayer && !_ghPlayer.is_guest) ? _ghPlayer.id : null;
          const hostName = _ghPlayer ? _ghPlayer.display_name : _fyt('host');
          _mp.roster[msg.player] = { name: hostName, color: _playerColor(msg.player), gh_player_id: hostGhId, avatar_svg: _ghPlayer?.avatar_svg || null };
          _mpRenderRoster(); _mpBroadcastLobby(); _mpUpdateStartBtn();
        }
      }
      if (_mp.phase) _mp.phase(msg);
    };
    ws.onclose = () => {
      if (_mpLeaving) return;
      _mpShowDisconnect();
    };
  }

  function _mpLeave() {
    _mpLeaving = true;
    _stopTimer();
    if (_mp?.ws) { try { _mp.ws.close(); } catch(_) {} }
    _mp = null;
    setTimeout(() => { _mpLeaving = false; }, 400);
  }

  // ── Host lobby ──────────────────────────────────────────────────────────
  async function _mpHostLobby() {
    let roomData;
    try { roomData = await mvmOS.multiplayer.createRoom('findyourself', { max_players: 64 }); } catch(_) {}
    if (!roomData?.roomId) { alert('Could not create room. Try again.'); return; }
    const { roomId, link } = roomData;

    _root.innerHTML = `
      <div class="fy-root"><div class="fy-screen fy-mp-lobby">
        <div style="font-size:2.4rem">👥</div>
        <h1>${_fyt('multiplayer')}</h1>
        <div style="font-size:.85rem;color:#a6adc8">${_cfg.rounds} ${_fyt('rounds_label')} · ${_cfg.time > 0 ? _fmtTime(_cfg.time) : _fyt('no_limit')}</div>
        <div style="font-size:.8rem;color:#a6adc8;margin-top:6px">${_fyt('mp_share')}</div>
        <div class="fy-mp-link" id="fy-mp-link">${link}</div>
        <button class="fy-btn secondary" id="fy-mp-copy">📋 ${_fyt('copy_link')}</button>
        <div id="fy-invite-wrap"></div>
        <div class="fy-mp-roster" id="fy-mp-roster"></div>
        <button class="fy-btn" id="fy-mp-start" disabled>${_fyt('need_players')}</button>
        <button class="fy-btn secondary" id="fy-mp-back">←</button>
      </div></div>`;

    const copyBtn = _root.querySelector('#fy-mp-copy');
    copyBtn.addEventListener('click', () => {
      navigator.clipboard?.writeText(link).catch(() => {});
      copyBtn.textContent = '✓ ' + _fyt('copied');
    });

    // Invite from Game Hub favourites
    _loadGameHub(async () => {
      if (!window.GameHub) return;
      const me = window.GameHub.currentPlayer();
      if (!me) return;
      const token = localStorage.getItem('gh_token');
      if (!token) return;

      let favs = [];
      try {
        const r = await fetch('/api/pub/gamehub/favourites', {headers:{'X-GH-Token':token}});
        if (r.ok) favs = (await r.json()).filter(f => f.id !== me.id);
      } catch(_) {}
      if (!favs.length) return;

      const wrap = _root.querySelector('#fy-invite-wrap');
      wrap.style.cssText = 'width:100%;max-width:340px;margin:6px 0;text-align:left';
      wrap.innerHTML = `
        <div style="font-size:.78rem;color:#a6adc8;margin-bottom:6px">🎮 Invite from Game Hub:</div>
        <div id="fy-fav-list" style="display:flex;flex-direction:column;gap:5px;margin-bottom:8px"></div>
        <button class="fy-btn secondary" id="fy-invite-send" style="width:100%;font-size:.82rem;padding:7px 0" disabled>Send invitations</button>
        <div id="fy-invite-status" style="font-size:.75rem;color:#a6adc8;text-align:center;margin-top:4px;min-height:16px"></div>`;

      const listEl = wrap.querySelector('#fy-fav-list');
      const sendBtn = wrap.querySelector('#fy-invite-send');
      const statusEl = wrap.querySelector('#fy-invite-status');
      const selected = new Set();
      // gh_player_id → fav object, populated after send
      const invitedFavs = new Map();

      function _refreshInviteStatus() {
        if (!invitedFavs.size) return;
        const joinedGhIds = new Set(Object.values(_mp.roster).map(p => p.gh_player_id).filter(Boolean));
        invitedFavs.forEach((f, ghId) => {
          const row = listEl.querySelector(`[data-fav-id="${f.id}"]`);
          if (!row) return;
          const ind = row.querySelector('.fav-status');
          if (ind) ind.textContent = joinedGhIds.has(ghId) ? '✅' : '⏳';
        });
      }
      // expose so _mp.phase can call it when someone joins
      _mp._refreshInviteStatus = _refreshInviteStatus;

      favs.forEach(f => {
        const row = document.createElement('div');
        row.dataset.favId = f.id;
        row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:6px 10px;border-radius:8px;background:rgba(255,255,255,.05);cursor:pointer;transition:background .12s';
        row.innerHTML = `
          <input type="checkbox" id="fav-cb-${f.id}" style="accent-color:#89b4fa;cursor:pointer;width:15px;height:15px;flex-shrink:0">
          ${_avatar(f, 22)}
          <span style="font-size:.83rem;font-weight:600;flex:1">${_esc(f.display_name||f.username||'?')}</span>`;
        const cb = row.querySelector('input');
        row.addEventListener('click', e => { if (e.target !== cb) cb.click(); });
        cb.addEventListener('change', () => {
          if (cb.checked) selected.add(f.id); else selected.delete(f.id);
          sendBtn.disabled = selected.size === 0;
          row.style.background = cb.checked ? 'rgba(137,180,250,.15)' : 'rgba(255,255,255,.05)';
        });
        listEl.appendChild(row);
      });

      sendBtn.addEventListener('click', async () => {
        sendBtn.disabled = true;
        statusEl.textContent = 'Sending…';
        try {
          const r = await fetch('/api/pub/gamehub/invite', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-GH-Token': token },
            body: JSON.stringify({ to_ids: [...selected], game_id: 'findyourself', room_url: link }),
          });
          if (r.ok) {
            statusEl.textContent = '';
            const rosterEl = _root.querySelector('#fy-mp-roster');
            if (rosterEl) rosterEl.style.display = 'none';
            // show only invited, replace checkboxes with status indicator
            favs.forEach(f => {
              const row = listEl.querySelector(`[data-fav-id="${f.id}"]`);
              if (!row) return;
              if (!selected.has(f.id)) { row.remove(); return; }
              invitedFavs.set(f.id, f);
              const cb = row.querySelector('input');
              if (cb) { const ind = document.createElement('span'); ind.className = 'fav-status'; ind.textContent = '⏳'; ind.style.cssText = 'font-size:14px;flex-shrink:0'; cb.replaceWith(ind); }
              row.style.background = 'rgba(255,255,255,.05)';
              row.style.cursor = 'default';
              row.onclick = null;
            });
            sendBtn.style.display = 'none';
            _refreshInviteStatus();
          } else {
            statusEl.textContent = 'Error sending invitations.';
            sendBtn.disabled = selected.size === 0;
          }
        } catch(_) {
          statusEl.textContent = 'Error sending invitations.';
          sendBtn.disabled = selected.size === 0;
        }
      });
    }, () => {});
    _root.querySelector('#fy-mp-back').addEventListener('click', () => {
      const token = localStorage.getItem('gh_token');
      if (token) fetch('/api/pub/gamehub/invites?room_url=' + encodeURIComponent(link), {method:'DELETE',headers:{'X-GH-Token':token}}).catch(()=>{});
      _mpLeave(); _showSetup();
    });
    _root.querySelector('#fy-mp-start').addEventListener('click', () => {
      if (_root.querySelector('#fy-mp-start').disabled) return;
      _mpHostStart();
    });

    _mpConnect(roomId, _fyt('host'), true);
    _mp.phase = (msg) => {
      if (msg.type === 'hello') {
        _mp.roster[msg.from] = { name: (msg.name || ('Player ' + msg.from)).slice(0, 20), color: _playerColor(msg.from), gh_player_id: msg.gh_player_id || null, avatar_svg: msg.avatar_svg || null };
        _mpRenderRoster(); _mpBroadcastLobby(); _mpUpdateStartBtn();
        _mp._refreshInviteStatus?.();
      } else if (msg.type === 'player_left') {
        delete _mp.roster[msg.player];
        _mpRenderRoster(); _mpBroadcastLobby(); _mpUpdateStartBtn();
      }
    };
  }

  function _mpUpdateStartBtn() {
    const btn = _root.querySelector('#fy-mp-start');
    if (!btn) return;
    const n = Object.keys(_mp.roster).length;
    if (n >= 2) { btn.disabled = false; btn.textContent = '▶ ' + _fyt('start_game') + ' (' + n + ')'; }
    else { btn.disabled = true; btn.textContent = _fyt('need_players'); }
  }

  function _mpRenderRoster(containerId = 'fy-mp-roster') {
    const el = _root.querySelector('#' + containerId);
    if (!el || el.style.display === 'none') return;
    const ids = Object.keys(_mp.roster).map(Number).sort((a, b) => a - b);
    el.innerHTML = `<div class="fy-mp-roster-title">${_fyt('players')}: ${ids.length}</div>` +
      ids.map(i => {
        const p = _mp.roster[i];
        const you = i === _mp.playerIndex ? ` (${_fyt('you')})` : '';
        const av = _avatar({ avatar_svg: p.avatar_svg, display_name: p.name, avatar_color: p.color }, 22);
        return `<div class="fy-mp-player">${av}<span style="margin-left:6px">${_esc(p.name)}${you}</span></div>`;
      }).join('');
  }

  function _mpBroadcastLobby() {
    const players = Object.keys(_mp.roster).map(Number).map(i => ({ i, name: _mp.roster[i].name, color: _mp.roster[i].color, avatar_svg: _mp.roster[i].avatar_svg || null }));
    _mpSend({ type: 'lobby', rounds: _cfg.rounds, time: _cfg.time, apiKey: _cfg.api_key, players });
  }

  async function _mpHostStart() {
    const btn = _root.querySelector('#fy-mp-start');
    if (btn) { btn.disabled = true; btn.textContent = '⏳ ' + _fyt('loading'); }
    // Cancel pending invites — game is starting, link will no longer accept new players meaningfully
    const _invLink = _root.querySelector('#fy-mp-link')?.textContent;
    const _invToken = localStorage.getItem('gh_token');
    if (_invLink && _invToken) fetch('/api/pub/gamehub/invites?room_url=' + encodeURIComponent(_invLink), {method:'DELETE',headers:{'X-GH-Token':_invToken}}).catch(()=>{});
    try { await _loadMaps(_cfg.api_key); } catch(_) { alert('Maps failed to load.'); return; }
    _round = 0; _totalScore = 0; _mp.totals = {};
    _mp.phase = _mpGameMsg;
    _mpStartRound(1);
  }

  // Host: намира валидна Street View локация, без да рендира
  function _mpResolveLocation(cb, attempt = 0) {
    if (attempt > 14) { cb(_randomCoord()); return; }
    const coord = _randomCoord();
    const svService = new google.maps.StreetViewService();
    svService.getPanorama({ location: coord, radius: 50000, source: google.maps.StreetViewSource.OUTDOOR }, (data, status) => {
      if (status !== 'OK') { _mpResolveLocation(cb, attempt + 1); return; }
      cb({ lat: data.location.latLng.lat(), lng: data.location.latLng.lng() });
    });
  }

  // Host: стартира рунд — резолва локация, праща round_start, рендира
  function _mpStartRound(round) {
    _mp.ended = false;
    _mp.guesses = {};
    _mp.submittedSelf = false;
    _guess = null;
    _round = round;
    _mp.curRound = round;
    _root.innerHTML = `<div class="fy-root"><div class="fy-game" id="fy-game"></div></div>`;
    const gameEl = _root.querySelector('#fy-game');
    _buildRoundUI(gameEl);
    _mpResolveLocation((loc) => {
      const heading = Math.random() * 360;
      _mp.curLoc = loc; _mp.curHeading = heading;
      _mpSend({ type: 'round_start', round, total: _cfg.rounds, time: _cfg.time, loc, heading, apiKey: _cfg.api_key });
      _renderRound(gameEl, loc, heading);
    });
  }

  // Guest/host: влиза в рунд по получена локация
  async function _mpEnterRound(msg) {
    _mp.ended = false;
    _mp.guesses = {};
    _mp.submittedSelf = false;
    _guess = null;
    _round = msg.round;
    _cfg.rounds = msg.total;
    _cfg.time = msg.time;
    if (msg.apiKey) _mp.apiKey = msg.apiKey;
    _mp.curRound = msg.round;
    _root.innerHTML = `<div class="fy-root"><div class="fy-game" id="fy-game"></div></div>`;
    const gameEl = _root.querySelector('#fy-game');
    _buildRoundUI(gameEl);
    try { await _loadMaps(_mp.apiKey); }
    catch(_) {
      gameEl.innerHTML = `<div class="fy-screen"><p style="color:#f38ba8">Failed to load Google Maps.</p></div>`;
      return;
    }
    _renderRound(gameEl, msg.loc, msg.heading);
  }

  // In-game message handler (host + guest)
  function _mpGameMsg(msg) {
    if (msg.type === 'guess') {
      _mp.guesses[msg.from] = { lat: msg.lat, lng: msg.lng, dist: msg.dist, distScore: msg.distScore, timeBonus: msg.timeBonus, score: msg.score };
      if (_root.querySelector('#fy-live')) _mpUpdateLive();
      if (_mp.isHost) _mpCheckRoundEnd();
    } else if (msg.type === 'round_start') {
      _mpEnterRound(msg);                 // guest получава нова локация
    } else if (msg.type === 'round_end') {
      _mpShowRoundEnd(msg);
    } else if (msg.type === 'game_over') {
      _mpShowGameOver(msg);
    } else if (msg.type === 'player_left') {
      _mpHandleLeave(msg);
    }
  }

  // Играч дава предположение (или таймерът свърши)
  function _mpSubmit() {
    if (_mp.submittedSelf) return;
    _mp.submittedSelf = true;
    if (_mp.isHost) _stopTimer();
    const elapsed = (Date.now() - _roundStartTime) / 1000;
    let dist = null, distScore = 0, timeBonus = 0;
    if (_guess && _actual) {
      dist = _distKm(_guess, _actual);
      distScore = _calcScore(dist);
      timeBonus = _timeBonus(elapsed);
    }
    const score = distScore + timeBonus;
    _mp.guesses[_mp.playerIndex] = { lat: _guess?.lat ?? null, lng: _guess?.lng ?? null, dist, distScore, timeBonus, score };
    _mpSend({ type: 'guess', round: _mp.curRound, lat: _guess?.lat ?? null, lng: _guess?.lng ?? null, dist, distScore, timeBonus, score });
    _mpShowLiveResults();
    if (_mp.isHost) _mpCheckRoundEnd();
  }

  function _mpTimeUp() {
    _mpSubmit();
    if (_mp.isHost) _mpEndRound();   // хостовият таймер е авторитетен за края
  }

  // Live results state (while waiting for others after submit)
  let _liveMap = null;
  let _liveMarkers = {};
  let _livePolylines = {};
  let _liveActual = null;

  function _mpShowLiveResults() {
    const gameEl = _root.querySelector('#fy-game');
    if (!gameEl) return;
    if (gameEl.querySelector('#fy-live')) { _mpUpdateLive(); return; }

    // remove Street View overlay, keep HUD
    const existing = gameEl.querySelector('.fy-wait-overlay');
    if (existing) existing.remove();

    _liveActual = _actual;
    _liveMap = null;
    _liveMarkers = {};
    _livePolylines = {};

    const total = Object.keys(_mp.roster).length;
    const done = Object.keys(_mp.guesses).length;

    const ov = document.createElement('div');
    ov.id = 'fy-live';
    ov.className = 'fy-result-overlay';
    ov.innerHTML = `
      <div class="fy-result-box fy-mp-result">
        <h2>${_fyt('result_title')} — ${_fyt('round')} ${_mp.curRound}/${_cfg.rounds}</h2>
        <div style="display:flex;align-items:center;justify-content:center;gap:12px;font-size:.78rem;color:#a6adc8;margin:-4px 0 4px">
          <span id="fy-live-status">${done}/${total} ${_fyt('waiting_others')}</span>
          ${_cfg.time > 0 ? `<span id="fy-live-timer" style="color:#f9e2af;font-weight:700">${_fmtTime(Math.max(0, _timeLeft))}</span>` : ''}
        </div>
        <div class="fy-result-map" id="fy-live-map"></div>
        <div class="fy-mp-scores" id="fy-live-scores"></div>
      </div>`;
    gameEl.appendChild(ov);

    _mpUpdateLiveScores();

    setTimeout(() => {
      const el = ov.querySelector('#fy-live-map');
      if (!el || !_liveActual) return;
      const bounds = new google.maps.LatLngBounds();
      _liveMap = new google.maps.Map(el, {
        streetViewControl: false, fullscreenControl: false,
        mapTypeControl: false, zoomControl: false, gestureHandling: 'greedy',
      });
      new google.maps.Marker({
        position: _liveActual, map: _liveMap,
        icon: {
          path: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z',
          fillColor: '#f9e2af', fillOpacity: 1, strokeColor: '#1e1e2e', strokeWeight: 1.5,
          scale: 1.8, anchor: new google.maps.Point(12, 22),
        },
        zIndex: 999,
      });
      bounds.extend(_liveActual);
      // draw all guesses known so far
      Object.entries(_mp.guesses).forEach(([idx, g]) => {
        _liveAddMarker(parseInt(idx), g, bounds);
      });
      if (bounds.isEmpty()) bounds.extend(_liveActual);
      _liveMap.fitBounds(bounds, 50);
    }, 100);
  }

  function _liveAddMarker(idx, g, bounds) {
    if (!_liveMap || g.lat == null) return;
    const p = _mp.roster[idx];
    if (!p) return;
    const pos = { lat: g.lat, lng: g.lng };
    const svgStr = _avatar({ avatar_svg: p.avatar_svg, display_name: p.name, avatar_color: p.color }, 28);
    const iconUrl = 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svgStr);
    if (_liveMarkers[idx]) _liveMarkers[idx].setMap(null);
    if (_livePolylines[idx]) _livePolylines[idx].setMap(null);
    _liveMarkers[idx] = new google.maps.Marker({
      position: pos, map: _liveMap,
      icon: { url: iconUrl, scaledSize: new google.maps.Size(28, 28), anchor: new google.maps.Point(14, 14) },
      title: p.name, zIndex: 10,
    });
    _livePolylines[idx] = new google.maps.Polyline({
      path: [pos, _liveActual], map: _liveMap,
      strokeColor: p.color, strokeOpacity: .55, strokeWeight: 2,
    });
    if (bounds) bounds.extend(pos);
  }

  function _mpUpdateLive() {
    const total = Object.keys(_mp.roster).length;
    const done = Object.keys(_mp.guesses).length;
    const statusEl = _root.querySelector('#fy-live-status');
    if (statusEl) statusEl.textContent = `${done}/${total} ${_fyt('waiting_others')}`;
    _mpUpdateLiveScores();
    // add newly arrived marker
    if (_liveMap) {
      Object.entries(_mp.guesses).forEach(([idx, g]) => {
        if (!_liveMarkers[parseInt(idx)]) _liveAddMarker(parseInt(idx), g, null);
      });
    }
  }

  function _mpUpdateLiveScores() {
    const el = _root.querySelector('#fy-live-scores');
    if (!el) return;
    const ids = Object.keys(_mp.roster).map(Number);
    // sort: guessed first (by score desc), then waiting
    const rows = ids.map(i => {
      const g = _mp.guesses[i];
      const p = _mp.roster[i];
      const prevTotal = (_mp.totals[i] || 0);
      return { i, p, g, prevTotal };
    }).sort((a, b) => {
      if (!!a.g !== !!b.g) return a.g ? -1 : 1;
      return (b.g?.score || 0) - (a.g?.score || 0);
    });
    el.innerHTML = rows.map(({ i, p, g }) => `
      <div class="fy-mp-score-row" data-player-i="${i}">
        ${_avatar({ avatar_svg: p.avatar_svg, display_name: p.name, avatar_color: p.color }, 22)}
        <span class="nm">${_esc(p.name)}${i === _mp.playerIndex ? ' (' + _fyt('you') + ')' : ''}</span>
        ${g
          ? `<span class="ds">${g.lat != null ? _fmtDist(g.dist) : '—'}</span><span class="rs">+${g.score}</span>`
          : `<span class="ds" style="color:#585b70">⏳</span>`
        }
        <span class="ts">${(_mp.totals[i] || 0) + (g?.score || 0)}</span>
      </div>`).join('');
  }

  // Host: проверява дали всички свързани са дали предположение
  function _mpCheckRoundEnd() {
    if (!_mp.isHost || _mp.ended) return;
    const ids = Object.keys(_mp.roster).map(Number);
    if (ids.length && ids.every(i => _mp.guesses[i] !== undefined)) _mpEndRound();
  }

  // Host: компилира и разпраща резултатите за рунда
  function _mpEndRound() {
    if (_mp.ended) return;
    _mp.ended = true;
    _stopTimer();
    const ids = Object.keys(_mp.roster).map(Number);
    const results = ids.map(i => {
      const g = _mp.guesses[i] || { lat: null, lng: null, dist: null, score: 0 };
      _mp.totals[i] = (_mp.totals[i] || 0) + (g.score || 0);
      return { i, name: _mp.roster[i].name, color: _mp.roster[i].color, avatar_svg: _mp.roster[i].avatar_svg || null, lat: g.lat, lng: g.lng, dist: g.dist, score: g.score || 0, total: _mp.totals[i] };
    });
    const payload = { type: 'round_end', round: _mp.curRound, actual: _actual, results };
    _mpSend(payload);
    _mpShowRoundEnd(payload);
  }

  // Всички: показва резултатна карта + таблица
  function _mpShowRoundEnd(msg) {
    _stopTimer();
    const gameEl = _root.querySelector('#fy-game');
    if (!gameEl) return;
    gameEl.querySelectorAll('#fy-wait, #fy-live, .fy-result-overlay').forEach(el => el.remove());
    _liveMap = null; _liveMarkers = {}; _livePolylines = {};

    // обнови собствените точки в HUD
    const me = msg.results.find(r => r.i === _mp.playerIndex);
    if (me) { _totalScore = me.total; const sv = gameEl.querySelector('#fy-score-val'); if (sv) sv.textContent = _totalScore; }

    const isLast = msg.round >= _cfg.rounds;
    const sortedByRound = msg.results.slice().sort((a, b) => b.score - a.score);
    // rank по общото (total) за числата вляво
    const sortedByTotal = msg.results.slice().sort((a, b) => b.total - a.total);
    const totalRank = {};
    sortedByTotal.forEach((r, idx) => { totalRank[r.i] = idx + 1; });

    const overlay = document.createElement('div');
    overlay.className = 'fy-result-overlay';
    overlay.innerHTML = `
      <div class="fy-result-box fy-mp-result">
        <h2>${_fyt('result_title')} — ${_fyt('round')} ${msg.round}/${_cfg.rounds}</h2>
        <div class="fy-result-map" id="fy-result-map"></div>
        <div class="fy-mp-scores">
          ${sortedByRound.map((r, idx) => `
            <div class="fy-mp-score-row${idx === 0 ? ' winner' : ''}" data-player-i="${r.i}" style="cursor:pointer">
              <span class="rank">${totalRank[r.i]}.</span>
              ${_avatar({ avatar_svg: r.avatar_svg, display_name: r.name, avatar_color: r.color }, 22)}
              <span class="nm">${_esc(r.name)}${r.i === _mp.playerIndex ? ' (' + _fyt('you') + ')' : ''}</span>
              <span class="ds">${r.lat != null ? _fmtDist(r.dist) : '—'}</span>
              <span class="rs">+${r.score}</span>
              <span class="ts">${r.total}</span>
            </div>`).join('')}
        </div>
        <div class="fy-mp-result-ctrl" id="fy-mp-result-ctrl"></div>
      </div>`;
    gameEl.appendChild(overlay);

    const ctrl = overlay.querySelector('#fy-mp-result-ctrl');
    if (_mp.isHost) {
      ctrl.innerHTML = `<button class="fy-btn" id="fy-mp-next">${isLast ? _fyt('finish') : _fyt('next_round')}</button>`;
      ctrl.querySelector('#fy-mp-next').addEventListener('click', () => {
        if (isLast) _mpGameOver();
        else _mpStartRound(_mp.curRound + 1);
      });
    } else {
      ctrl.innerHTML = `<div class="fy-mp-waitnext">${_fyt('waiting_round')}</div>`;
    }

    // резултатна карта с цветни линии + highlight при клик на ред
    const polylines = {};
    const markers = {};
    let highlightedI = null;

    setTimeout(() => {
      const el = document.getElementById('fy-result-map');
      if (!el || !msg.actual) return;
      const bounds = new google.maps.LatLngBounds();
      const rMap = new google.maps.Map(el, {
        streetViewControl: false, fullscreenControl: false,
        mapTypeControl: false, zoomControl: false, gestureHandling: 'greedy',
      });
      new google.maps.Marker({
        position: msg.actual, map: rMap,
        icon: {
          path: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z',
          fillColor: '#f9e2af', fillOpacity: 1, strokeColor: '#1e1e2e', strokeWeight: 1.5,
          scale: 1.8, anchor: new google.maps.Point(12, 22),
        },
        title: 'Actual location', zIndex: 999,
      });
      bounds.extend(msg.actual);
      msg.results.forEach(r => {
        if (r.lat == null) return;
        const pos = { lat: r.lat, lng: r.lng };
        const svgStr = _avatar({ avatar_svg: r.avatar_svg, display_name: r.name, avatar_color: r.color }, 28);
        const iconUrl = 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svgStr);
        markers[r.i] = new google.maps.Marker({
          position: pos, map: rMap,
          icon: { url: iconUrl, scaledSize: new google.maps.Size(28, 28), anchor: new google.maps.Point(14, 14) },
          title: r.name, zIndex: 10,
        });
        polylines[r.i] = new google.maps.Polyline({
          path: [pos, msg.actual], map: rMap,
          strokeColor: r.color, strokeOpacity: .55, strokeWeight: 2,
        });
        bounds.extend(pos);
      });
      rMap.fitBounds(bounds, 50);

      // Клик на ред → highlight
      overlay.querySelectorAll('.fy-mp-score-row[data-player-i]').forEach(row => {
        row.addEventListener('click', () => {
          const pi = parseInt(row.dataset.playerI);
          const isAlreadyHighlighted = highlightedI === pi;
          // Reset all
          Object.entries(polylines).forEach(([i, pl]) => {
            pl.setOptions({ strokeOpacity: .55, strokeWeight: 2, zIndex: 1 });
          });
          Object.entries(markers).forEach(([i, mk]) => {
            mk.setZIndex(10);
          });
          overlay.querySelectorAll('.fy-mp-score-row').forEach(r => r.classList.remove('highlighted'));
          if (isAlreadyHighlighted) {
            highlightedI = null;
          } else {
            highlightedI = pi;
            if (polylines[pi]) polylines[pi].setOptions({ strokeOpacity: 1, strokeWeight: 5, zIndex: 20 });
            if (markers[pi])   markers[pi].setZIndex(100);
            row.classList.add('highlighted');
          }
        });
      });
    }, 100);
  }

  // Host: край на играта
  function _mpGameOver() {
    const ids = Object.keys(_mp.roster).map(Number);
    const standings = ids.map(i => ({
      name: _mp.roster[i].name, color: _mp.roster[i].color,
      total: _mp.totals[i] || 0, gh_player_id: _mp.roster[i].gh_player_id || null,
      avatar_svg: _mp.roster[i].avatar_svg || null,
    })).sort((a, b) => b.total - a.total);
    _recordMpSession(standings);
    const payload = { type: 'game_over', standings };
    _mpSend(payload);
    _mpShowGameOver(payload);
  }

  function _mpShowGameOver(msg) {
    _stopTimer();
    const standings = msg.standings || [];
    const winner = standings[0];
    const hubUrl = window.location.origin;
    const isGuest = !_mp.isHost;

    _root.innerHTML = `
      <div class="fy-root"><div class="fy-screen">
        <div style="font-size:2.5rem">🏆</div>
        <h1>${_fyt('final_standings')}</h1>
        ${winner ? `<div class="fy-result-score" style="color:${winner.color}">${_fyt('winner')}: ${_esc(winner.name)}</div>` : ''}
        <div class="fy-mp-scores fy-mp-final">
          ${standings.map((s, i) => `
            <div class="fy-mp-score-row${i === 0 ? ' winner' : ''}">
              <span class="rank">${i + 1}.</span>
              ${_avatar({ avatar_svg: s.avatar_svg, display_name: s.name, avatar_color: s.color }, 22)}
              <span class="nm">${_esc(s.name)}</span>
              <span class="ts">${s.total}</span>
            </div>`).join('')}
        </div>
        ${_mp.isHost
          ? `<button class="fy-btn" id="fy-mp-menu">← ${_fyt('finish')}</button>`
          : (window.GameHub ? `<button class="fy-btn" id="fy-mp-back-hub">🏠 Game Hub</button>` : '')}
      </div></div>`;

    _root.querySelector('#fy-mp-menu')?.addEventListener('click', () => { _mpLeave(); _showSetup(); });
    _root.querySelector('#fy-mp-back-hub')?.addEventListener('click', () => { _mpLeave(); window.location.href = window.location.origin + '/apps/gamehub/public/'; });
  }

  function _mpHandleLeave(msg) {
    // хостът е индекс 0 — ако напусне, играта не може да продължи
    const wasHost = msg.player === 0 || (_mp.roster[msg.player] && _mp.roster[msg.player].isHost);
    delete _mp.roster[msg.player];
    delete _mp.guesses[msg.player];
    if (wasHost && !_mp.isHost) { _mpShowDisconnect(true); return; }
    _mpUpdateWaiting();
    if (_mp.isHost && !_mp.ended) _mpCheckRoundEnd();
  }

  function _mpShowDisconnect(hostLeft) {
    if (!_root) return;
    const isGuest = _mp && !_mp.isHost;
    const hubUrl = window.location.origin;
    _root.innerHTML = `
      <div class="fy-root"><div class="fy-screen">
        <div style="font-size:2.2rem">🔌</div>
        <p style="color:#f38ba8">${hostLeft ? _fyt('host_left') : _fyt('host_left')}</p>
        ${_mp && _mp.isHost
          ? `<button class="fy-btn" id="fy-dc-menu">←</button>`
          : (isGuest && window.GameHub) ? `<button class="fy-btn" id="fy-dc-back-hub">🏠 Game Hub</button>` : ''}
      </div></div>`;
    _root.querySelector('#fy-dc-menu')?.addEventListener('click', () => { _mpLeave(); _showSetup(); });
    _root.querySelector('#fy-dc-back-hub')?.addEventListener('click', () => { _mpLeave(); window.location.href = window.location.origin + '/apps/gamehub/public/'; });
  }

  // ── Guest entry (от standalone play страницата) ───────────────────────────
  function joinMultiplayer(body, roomId) {
    _root = body;
    // Standalone страницата не включва CSS-а на приложението — зареждаме го ръчно
    if (!document.getElementById('fy-style')) {
      const l = document.createElement('link');
      l.id = 'fy-style'; l.rel = 'stylesheet';
      l.href = '/apps/findyourself/style.css?v=' + Date.now();
      document.head.appendChild(l);
    }

    function _showNameInput() {
      body.innerHTML = `
        <div class="fy-root"><div class="fy-screen">
          <div style="font-size:2.5rem">🌍</div>
          <h1>${_fyt('multiplayer')}</h1>
          <div style="font-size:.85rem;color:#a6adc8">${_fyt('enter_name')}</div>
          <input id="fy-mp-name" class="fy-mp-name-input" maxlength="20" placeholder="${_fyt('your_name')}">
          <button class="fy-btn" id="fy-mp-join">▶ ${_fyt('ready')}</button>
        </div></div>`;
      const joinBtn = body.querySelector('#fy-mp-join');
      const nameInp = body.querySelector('#fy-mp-name');
      nameInp.addEventListener('keydown', e => { if (e.key === 'Enter') joinBtn.click(); });
      joinBtn.addEventListener('click', () => {
        const name = (nameInp.value || '').trim() || ('Player' + Math.floor(Math.random() * 1000));
        joinBtn.disabled = true;
        _mpConnect(roomId, name, false);
        _mp.phase = _mpGuestLobbyMsg;
        _mpShowGuestLobby(name);
      });
    }

    _loadGameHub(() => {
      body.innerHTML = `
        <div class="fy-root"><div class="fy-screen">
          <div style="font-size:2.5rem">🌍</div>
          <h1>${_fyt('multiplayer')}</h1>
          <div id="fy-gh-section" style="width:280px;margin:0 auto"></div>
        </div></div>`;
      const ghSection = body.querySelector('#fy-gh-section');
      window.GameHub.renderWidget(ghSection, {
        guestText: _fyt('your_name') + ' →',
        onReady(player) {
          if (player.is_guest) { _ghGuestChosen = true; _ghPlayer = null; }
          else                 { _ghPlayer = player; _ghGuestChosen = false; }
          const name = _ghPlayer ? _ghPlayer.display_name : (player.guest_name || ('Player' + Math.floor(Math.random() * 1000)));
          _mpConnect(roomId, name, false);
          _mp.phase = _mpGuestLobbyMsg;
          _mpShowGuestLobby(name);
        },
      });
    }, () => {
      // Game Hub not available — fall back to name input
      _showNameInput();
    });
  }

  function _mpShowGuestLobby(name) {
    _root.innerHTML = `
      <div class="fy-root"><div class="fy-screen fy-mp-lobby">
        <div style="font-size:2.4rem">👥</div>
        <h1>${_fyt('multiplayer')}</h1>
        <div id="fy-mp-info" style="font-size:.85rem;color:#a6adc8">${_fyt('waiting_host')}</div>
        <div class="fy-mp-roster" id="fy-mp-roster"></div>
        <div class="fy-mp-waitnext">⏳ ${_fyt('waiting_host')}</div>
      </div></div>`;
  }

  function _mpGuestLobbyMsg(msg) {
    if (msg.type === 'lobby') {
      _mp.apiKey = msg.apiKey || _mp.apiKey;
      _cfg.rounds = msg.rounds; _cfg.time = msg.time;
      _mp.roster = {};
      (msg.players || []).forEach(p => { _mp.roster[p.i] = { name: p.name, color: p.color, avatar_svg: p.avatar_svg || null }; });
      _mpRenderRoster();
      const info = _root.querySelector('#fy-mp-info');
      if (info) info.textContent = `${_cfg.rounds} ${_fyt('rounds_label')} · ${_cfg.time > 0 ? _fmtTime(_cfg.time) : _fyt('no_limit')}`;
      // предзареди картите докато чакаме
      if (_mp.apiKey) _loadMaps(_mp.apiKey).catch(() => {});
    } else if (msg.type === 'round_start') {
      _mp.phase = _mpGameMsg;
      _mpEnterRound(msg);
    } else if (msg.type === 'player_left') {
      if (msg.player === 0) { _mpShowDisconnect(true); return; }
      delete _mp.roster[msg.player];
      _mpRenderRoster();
    }
  }

  // прост HTML-escape за имена
  function _esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  }

  return { mount, joinMultiplayer };
})();
