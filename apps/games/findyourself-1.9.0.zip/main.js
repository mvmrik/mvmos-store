// mvmOS App: FindYourself v1.2.0
const _fyi18n = {
  en: {
    title: 'FindYourself', play: 'Play', settings_btn: '⚙ Settings',
    no_api: 'Enter your Google Maps API key in App Settings to play.',
    round: 'Round', of: 'of', score: 'Score', time: 'Time',
    click_map: 'Click on the map to place your guess',
    reset_pos: 'Reset position', expand_map: 'Expand map', collapse_map: 'Collapse map',
    submit: 'Submit Guess', next_round: 'Next Round', see_result: 'See Result',
    finish: 'Finish Game', play_again: 'Play Again',
    distance: 'Distance', points: 'Points',
    result_title: 'Round Result',
    final_title: 'Game Over',
    total_score: 'Total Score',
    best: 'Best', rounds_label: 'rounds',
    rounds_count: 'Rounds', time_per_round: 'Time per round', no_limit: 'No limit',
    location_pts: 'Location', time_bonus: 'Time bonus', total_pts: 'Total',
    loading: 'Loading Street View…',
    no_sv: 'No Street View found nearby, trying another location…',
    singleplayer: 'Single player', multiplayer: 'Multiplayer',
    mp_share: 'Share this link with your friends:', copy_link: 'Copy link', copied: 'Copied!',
    host: 'Host', your_name: 'Your name', ready: 'Ready', waiting_host: 'Waiting for host…',
    players: 'Players', start_game: 'Start game', need_players: 'Waiting for players…',
    waiting_others: 'Waiting for other players…', times_up: "Time's up! Calculating…",
    next_round: 'Next Round', final_standings: 'Final Standings', winner: 'Winner',
    you: 'You', final_standings: 'Final Standings', winner: 'Winner',
    mp_login: 'Log in to Game Hub to play multiplayer',
    open_games: 'Open games', no_open_games: 'No open games right now',
    create_game: 'Create game', join: 'Join', solo: 'Solo',
    players_waiting: 'players waiting', in_round: 'In round',
    start_game: 'Start game', preparing: 'Preparing round…',
    waiting_start: 'Waiting for someone to start…', waiting_round: 'Waiting for next round…',
    player_left_game: 'left the game',
    next_auto: 'Next round in',
    invite_players: 'Invite players', invite: 'Invite', invited: 'Invited ✓',
  },
  bg: {
    title: 'FindYourself', play: 'Играй', settings_btn: '⚙ Настройки',
    no_api: 'Въведи Google Maps API ключ в App Settings за да играеш.',
    round: 'Рунд', of: 'от', score: 'Точки', time: 'Време',
    click_map: 'Кликни на картата за да отбележиш позицията си',
    submit: 'Потвърди', next_round: 'Следващ рунд', see_result: 'Виж резултата',
    finish: 'Приключи', play_again: 'Играй пак',
    distance: 'Разстояние', points: 'Точки',
    result_title: 'Резултат',
    final_title: 'Край на играта',
    total_score: 'Общо точки',
    best: 'Рекорд', rounds_label: 'рунда',
    reset_pos: 'Начална позиция', expand_map: 'Разшири картата', collapse_map: 'Свий картата',
    rounds_count: 'Брой рундове', time_per_round: 'Време за рунд', no_limit: 'Без време',
    location_pts: 'Локация', time_bonus: 'Бонус за време', total_pts: 'Общо',
    loading: 'Зареждане на Street View…',
    no_sv: 'Няма Street View наблизо, опитваме друга локация…',
    singleplayer: 'Сам', multiplayer: 'Мултиплеър',
    mp_share: 'Сподели този линк с приятелите си:', copy_link: 'Копирай линка', copied: 'Копирано!',
    host: 'Хост', your_name: 'Твоето име', ready: 'Готов', waiting_host: 'Чака хоста…',
    players: 'Играчи', start_game: 'Старт', need_players: 'Чака играчи…',
    waiting_others: 'Чака останалите играчи…', times_up: 'Времето изтече! Изчисляване…',
    next_round: 'Следващ рунд', final_standings: 'Крайно класиране', winner: 'Победител',
    you: 'Ти', final_standings: 'Крайно класиране', winner: 'Победител',
    mp_login: 'Влез в Game Hub за мултиплеър',
    open_games: 'Отворени игри', no_open_games: 'Няма отворени игри',
    create_game: 'Създай игра', join: 'Присъедини се', solo: 'Сам',
    players_waiting: 'играча чакат', in_round: 'В рунд',
    start_game: 'Стартирай', preparing: 'Подготвяме рунда…',
    waiting_start: 'Чака някой да стартира…', waiting_round: 'Чака следващия рунд…',
    player_left_game: 'напусна играта',
    next_auto: 'Следващ рунд след',
    invite_players: 'Покани играчи', invite: 'Покани', invited: 'Поканен ✓',
  },
};
function _fyt(key) { const l = window.mvmOS?.lang || 'en'; return (_fyi18n[l] || _fyi18n.en)[key] || key; }

mvmOS.registerApp({
  id: 'findyourself',
  name: 'FindYourself',
  icon: '🌍',
  category: 'Games',
  settings: [
    { key: 'api_key', label: 'Google Maps API Key', type: 'password', default: '' },
    { key: 'rounds',  label: 'Rounds per game',     type: 'number',  default: 5, min: 1, max: 10 },
    { key: 'time',    label: 'Time per round (sec, 0 = unlimited)', type: 'number', default: 60, min: 0 },
  ],
  launch(opts) {
    const isMP   = opts?.multiplayer === true;
    const gameId = opts?.gameId;
    mvmOS.createWindow({
      id: 'findyourself',
      title: '🌍 FindYourself',
      icon: '🌍',
      width: 1000,
      height: 640,
      appSettings: true,
      onAppSettings() { AppStore.openWindow({ section: 'my-apps', appId: 'findyourself' }); },
      onMount(body) {
        body.style.padding = '0';
        body.style.overflow = 'hidden';
        if (isMP && gameId) {
          FY.joinMultiplayer(body, gameId);
        } else {
          (window.mvmOS?.i18nReady || Promise.resolve()).then(() => FY.mount(body));
        }
      },
    });
  },
});

const FY = (() => {
  // На standalone multiplayer страницата mvmOS.db липсва → _db = null (ползва се само от хоста)
  const _db = (typeof mvmOS !== 'undefined' && mvmOS.db) ? mvmOS.db('findyourself') : null;
  let _root = null;
  let _cfg = { api_key: '', rounds: 5, time: 60 };
  let _sv = null;       // Street View panorama
  let _map = null;      // guess map
  let _marker = null;   // player's guess marker
  let _guess = null;    // { lat, lng }
  let _actual = null;   // { lat, lng }
  let _round = 0;
  let _totalScore = 0;
  let _roundScores = [];
  let _locations = [];  // pre-generated coords for this game
  let _timerInterval = null;
  let _timeLeft = 0;
  let _roundStartTime = 0;  // ms timestamp когато рундът стане готов
  let _initPov = null;      // началната посока на гледане (за reset бутона)
  let _mapsLoaded = false;
  const _isMobile = window.matchMedia('(max-width:600px)').matches;

  // Game Hub state
  let _ghPlayer = null;
  let _ghGuestChosen = false;
  let _gameStartTime = 0;

  // ── Multiplayer state ────────────────────────────────────────────────────
  // _mp = null in single-player
  let _mp = null;   // { ws, gameId, myId, submitted, curLoc, curHeading, curRound, roundStartedAt }

  // ── Точкуване ──────────────────────────────────────────────────────────────
  const TIME_BONUS_MAX = 1000;     // макс бонус за време (5× по-малък от макс разстояние)
  const TIME_BONUS_WINDOW = 200;   // секунди до 0 бонус (5 точки/сек)
  function _timeBonus(elapsedSec) {
    const b = TIME_BONUS_MAX * (1 - elapsedSec / TIME_BONUS_WINDOW);
    return Math.max(0, Math.round(b));
  }

  // Размер на картата — стъпки в % от екрана (запомня се за цялата игра)
  const _MAP_PCTS = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
  let _mapPctIdx = 2;  // default 30%

  // ── Random locations ──────────────────────────────────────────────────────
  // Weighted list of land bounding boxes [minLat, maxLat, minLng, maxLng, weight]
  const _BOXES = [
    [35, 71, -10, 40, 25],   // Europe
    [25, 50, 60, 140, 20],   // Asia
    [-35, 37, -18, 52, 15],  // Africa
    [25, 50, -125, -65, 15], // North America
    [-55, 15, -82, -34, 10], // South America
    [-45, -10, 110, 155, 8], // Australia
    [0, 25, 100, 140, 7],    // SE Asia
  ];

  function _randomCoord() {
    const total = _BOXES.reduce((s, b) => s + b[4], 0);
    let r = Math.random() * total;
    for (const [minLat, maxLat, minLng, maxLng, w] of _BOXES) {
      r -= w;
      if (r <= 0) {
        return {
          lat: minLat + Math.random() * (maxLat - minLat),
          lng: minLng + Math.random() * (maxLng - minLng),
        };
      }
    }
    return { lat: Math.random() * 140 - 70, lng: Math.random() * 360 - 180 };
  }

  // ── Score calculation (GeoGuessr-style) ───────────────────────────────────
  function _calcScore(distKm) {
    if (distKm < 0.05) return 5000;
    return Math.round(5000 * Math.exp(-distKm / 2000));
  }

  function _distKm(a, b) {
    const R = 6371;
    const dLat = (b.lat - a.lat) * Math.PI / 180;
    const dLng = (b.lng - a.lng) * Math.PI / 180;
    const x = Math.sin(dLat/2)**2 + Math.cos(a.lat*Math.PI/180) * Math.cos(b.lat*Math.PI/180) * Math.sin(dLng/2)**2;
    return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1-x));
  }

  function _fmtDist(km) {
    if (km < 1) return Math.round(km * 1000) + ' m';
    if (km < 100) return km.toFixed(1) + ' km';
    return Math.round(km) + ' km';
  }

  function _fmtTime(s) {
    if (s < 60) return s + 's';
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  }

  // ── Game Hub helpers ─────────────────────────────────────────────────────

  function _loadGameHub(cb, errCb) {
    if (window.GameHub) { window.GameHub.init().then(cb); return; }
    const s = document.createElement('script');
    s.src = '/apps/gamehub/widget.js?v=2';
    s.onload  = () => window.GameHub?.init().then(cb) || cb();
    s.onerror = errCb || cb;
    document.head.appendChild(s);
  }

  function _avatar(player, size) {
    if (window.GameHub) return window.GameHub.renderAvatar(player, size);
    const color = (player && player.avatar_color) || '#585b70';
    const letter = ((player && player.display_name && player.display_name[0]) || '?').toUpperCase();
    return `<svg viewBox="0 0 100 100" width="${size}" height="${size}" style="border-radius:50%;display:block;flex-shrink:0" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="50" fill="${color}"/><text x="50" y="67" font-family="system-ui,sans-serif" font-size="54" font-weight="700" fill="#1e1e2e" text-anchor="middle">${letter}</text></svg>`;
  }

  function _renderGhSection(container, onReload, onUnlock) {
    if (!window.GameHub) { container.style.display = 'none'; return; }
    container.style.display = '';
    const p = window.GameHub.currentPlayer();
    _ghPlayer = p || null;
    if (p) {
      container.innerHTML = `
        <div style="display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.06);border-radius:8px;padding:8px 12px;width:100%;box-sizing:border-box">
          ${_avatar(p, 22)}
          <div style="flex:1;font-size:12px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${p.display_name}</div>
          <button id="fy-gh-out" style="border:none;background:none;color:#a6adc8;font-size:11px;cursor:pointer;padding:2px 6px;flex-shrink:0">Logout</button>
        </div>`;
      container.querySelector('#fy-gh-out').onclick = async () => {
        await window.GameHub.logout();
        _ghPlayer = null; _ghGuestChosen = false;
        onReload();
      };
      onUnlock?.();
    } else if (_ghGuestChosen) {
      container.innerHTML = `
        <div style="font-size:12px;color:#a6adc8;text-align:center">
          No stats (guest) · <span id="fy-gh-lnk" style="color:#89b4fa;cursor:pointer;text-decoration:underline">Log in</span>
        </div>`;
      container.querySelector('#fy-gh-lnk').onclick = () => { _ghGuestChosen = false; onReload(); };
      onUnlock?.();
    } else {
      window.GameHub.renderWidget(container, {
        guestText: 'Skip (no stats)',
        onReady(player) {
          if (player.is_guest) { _ghGuestChosen = true; _ghPlayer = null; }
          else                 { _ghPlayer = player; _ghGuestChosen = false; }
          onReload();
        },
      });
    }
  }

  function _recordGhSession(durationSeconds) {
    if (!_ghPlayer || !window.GameHub) return;
    window.GameHub.recordSession({
      game_id: 'findyourself',
      mode: 'singleplayer',
      players: [{ player_id: _ghPlayer.id, score: _totalScore, is_winner: true }],
      duration_seconds: durationSeconds,
      metadata: { rounds: _cfg.rounds, time_per_round: _cfg.time },
    }).catch(() => {});
  }

  function _recordMpSession(standings) {
    if (!window.GameHub) return;
    const winner = standings[0];
    window.GameHub.recordSession({
      game_id: 'findyourself',
      mode: 'multiplayer',
      players: standings.map(s => ({
        ...(s.gh_player_id ? { player_id: s.gh_player_id } : { guest_name: s.name }),
        score: s.total,
        is_winner: s === winner,
      })),
      metadata: { rounds: _cfg.rounds, time_per_round: _cfg.time },
    }).catch(() => {});
  }

  // ── Google Maps loader ────────────────────────────────────────────────────
  function _loadMaps(apiKey) {
    return new Promise((resolve, reject) => {
      if (_mapsLoaded && window.google?.maps) { resolve(); return; }
      if (window._fyMapsLoading) { window._fyMapsResolvers.push(resolve); return; }
      window._fyMapsLoading = true;
      window._fyMapsResolvers = [resolve];
      window._fyMapsCallback = () => {
        _mapsLoaded = true;
        window._fyMapsLoading = false;
        window._fyMapsResolvers.forEach(r => r());
      };
      const s = document.createElement('script');
      s.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&callback=_fyMapsCallback`;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  // ── Mount ─────────────────────────────────────────────────────────────────
  async function mount(body) {
    _root = body;
    await _initDb();
    await _loadCfg();
    _showSetup();
    window.addEventListener('settings-changed', async e => {
      if (e.detail?.app === 'findyourself') { await _loadCfg(); }
    });
  }

  async function _initDb() {
    await _db.run(`CREATE TABLE IF NOT EXISTS cfg (key TEXT PRIMARY KEY, value TEXT)`);
    await _db.run(`CREATE TABLE IF NOT EXISTS scores
      (id INTEGER PRIMARY KEY AUTOINCREMENT, total INTEGER, rounds INTEGER, date TEXT)`);
  }

  async function _loadCfg() {
    const rows = await _db.query('SELECT key, value FROM cfg');
    const s = {};
    rows.forEach(r => { try { s[r.key] = JSON.parse(r.value); } catch(_) { s[r.key] = r.value; } });
    _cfg = {
      api_key: s.api_key || '',
      rounds:  parseInt(s.rounds) || 5,
      time:    parseInt(s.time) || 60,
    };
  }

  // ── Setup screen ──────────────────────────────────────────────────────────
  async function _showSetup() {
    _stopTimer();
    const best = await _getBest();
    _root.innerHTML = `
      <div class="fy-root">
        <div class="fy-screen">
          <div style="font-size:3rem">🌍</div>
          <h1>${_fyt('title')}</h1>
          <p>Drop into a random Street View location anywhere in the world and guess where you are on the map.</p>
          ${best ? `<div style="font-size:.82rem;color:#a6adc8">${_fyt('best')}: <strong>${best.total}</strong> pts / ${best.rounds} ${_fyt('rounds_label')}</div>` : ''}
          ${!_cfg.api_key ? `
            <p style="color:#f38ba8;font-size:.82rem">${_fyt('no_api')}</p>
            <a href="https://console.cloud.google.com/apis/library/maps-backend.googleapis.com" target="_blank" style="font-size:.78rem;color:#89b4fa">Get API key from Google Cloud Console →</a>
            <button class="fy-btn secondary" onclick="AppStore?.openWindow({section:'my-apps',appId:'findyourself'})">${_fyt('settings_btn')}</button>
          ` : `
            <div class="fy-setup-opts">
              <label class="fy-setup-field">
                <span>${_fyt('rounds_count')}</span>
                <input type="number" id="fy-set-rounds" min="1" max="50" value="${_cfg.rounds}">
              </label>
              <label class="fy-setup-field">
                <span>${_fyt('time_per_round')}</span>
                <select id="fy-set-time">${_timeOptions(_cfg.time)}</select>
              </label>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center">
              <button class="fy-btn" id="fy-start">🌍 ${_fyt('singleplayer')}</button>
              <button class="fy-btn secondary" id="fy-start-mp" disabled>👥 ${_fyt('multiplayer')}</button>
            </div>
            <div id="fy-gh-section" style="width:280px"></div>
          `}
        </div>
      </div>`;
    const startBtn   = _root.querySelector('#fy-start');
    const startMpBtn = _root.querySelector('#fy-start-mp');
    if (startBtn) startBtn.disabled = true;

    const ghSection = _root.querySelector('#fy-gh-section');
    _loadGameHub(() => {
      if (!ghSection) return;
      _renderGhSection(ghSection, () => _showSetup(), () => {
        if (startBtn) startBtn.disabled = false;
        // MP only available when logged into Game Hub
        if (startMpBtn) startMpBtn.disabled = !(_ghPlayer && !_ghPlayer.is_guest);
      });
    }, () => {
      if (startBtn) startBtn.disabled = false;
    });

    _root.querySelector('#fy-start')?.addEventListener('click', _startGame);
    // Multiplayer now lives entirely in the Game Hub. The button opens the
    // public hub, where games are created, players invited and matches played.
    _root.querySelector('#fy-start-mp')?.addEventListener('click', () => {
      window.open('/apps/gamehub/public/', '_blank');
    });
  }

  // Прочита избраните рундове/време от setup екрана в _cfg
  function _readSetupOpts() {
    const rEl = _root.querySelector('#fy-set-rounds');
    const tEl = _root.querySelector('#fy-set-time');
    if (rEl) _cfg.rounds = Math.min(50, Math.max(1, parseInt(rEl.value) || 5));
    if (tEl) { const t = parseInt(tEl.value); _cfg.time = isNaN(t) ? 60 : t; }
  }

  // Селект опции за време: 10-50s, после 1-10 мин, + без време
  function _timeOptions(selected) {
    const opts = [10, 20, 30, 40, 50];
    for (let m = 1; m <= 10; m++) opts.push(m * 60);
    let html = opts.map(s => {
      const label = s < 60 ? s + 's' : (s / 60) + ' min';
      return `<option value="${s}" ${s === selected ? 'selected' : ''}>${label}</option>`;
    }).join('');
    html += `<option value="0" ${selected === 0 ? 'selected' : ''}>${_fyt('no_limit')}</option>`;
    return html;
  }

  async function _getBest() {
    const rows = await _db.query('SELECT * FROM scores ORDER BY total DESC LIMIT 1');
    return rows[0] || null;
  }

  // ── Game ──────────────────────────────────────────────────────────────────
  async function _startGame() {
    _readSetupOpts();
    _gameStartTime = Date.now();
    _mapPctIdx = 2;  // ресет размер на картата за новата игра
    _round = 0;
    _totalScore = 0;
    _roundScores = [];
    _locations = Array.from({ length: _cfg.rounds }, _randomCoord);
    _root.innerHTML = `<div class="fy-root"><div class="fy-game" id="fy-game"></div></div>`;
    try {
      await _loadMaps(_cfg.api_key);
    } catch(e) {
      _root.innerHTML = `<div class="fy-root"><div class="fy-screen"><p style="color:#f38ba8">Failed to load Google Maps. Check your API key.</p><button class="fy-btn secondary" id="fy-back">← Back</button></div></div>`;
      _root.querySelector('#fy-back').addEventListener('click', _showSetup);
      return;
    }
    _nextRound();
  }

  // Шаблон на рунда (HUD + Street View + компас + карта). Преизползва се single + MP.
  function _buildRoundUI(gameEl) {
    gameEl.innerHTML = `
      <div class="fy-hud">
        <div class="fy-hud-pill">${_fyt('round')} <strong>${_round}</strong> ${_fyt('of')} <strong>${_cfg.rounds}</strong></div>
        <div class="fy-hud-pill">${_fyt('score')}: <strong id="fy-score-val">${_totalScore}</strong></div>
        <div class="fy-hud-pill fy-timer" id="fy-timer">${_cfg.time > 0 ? _fmtTime(_cfg.time) : '0:00'}</div>
      </div>
      <div id="fy-sv" class="fy-sv"></div>
      <div class="fy-map-wrap ${_isMobile ? 'fy-map-collapsed' : 'fy-map-mini'}" id="fy-map-wrap">
        <div id="fy-map" class="fy-map"></div>
        <div class="fy-map-thumb" id="fy-map-thumb"><span class="fy-map-thumb-ico">🗺</span></div>
        <div class="fy-map-timer" id="fy-map-timer">${_cfg.time > 0 ? _fmtTime(_cfg.time) : '0:00'}</div>
        <button class="fy-map-close-btn" id="fy-map-close" title="Close map">✕</button>
        <div class="fy-map-inner-controls" id="fy-map-inner-controls">
          ${!_isMobile ? `<button class="fy-map-btn" id="fy-zoom-cycle" title="Zoom map">⊞</button>` : ''}
          <button class="fy-map-btn" id="fy-map-reset" title="${_fyt('reset_pos')}">⌖</button>
          <button class="fy-guess-btn-map" id="fy-submit" disabled>${_fyt('submit')}</button>
        </div>
      </div>
      <div id="fy-sv-loading" style="position:absolute;inset:0;background:#1e1e2e;display:flex;align-items:center;justify-content:center;z-index:5;font-size:.9rem;color:#a6adc8">${_fyt('loading')}</div>
    `;
  }

  async function _nextRound() {
    _guess = null;
    _round++;
    const gameEl = _root.querySelector('#fy-game');
    if (!gameEl) return;
    _buildRoundUI(gameEl);
    await _loadRoundLocation(gameEl);
  }

  async function _loadRoundLocation(gameEl, attempt = 0) {
    if (attempt > 10) {
      const loading = gameEl.querySelector('#fy-sv-loading');
      if (loading) loading.textContent = 'Could not find Street View. Skipping round…';
      setTimeout(() => _submitGuess(true), 1500);
      return;
    }

    const coord = attempt === 0 ? _locations[_round - 1] : _randomCoord();
    if (attempt > 0) _locations[_round - 1] = coord;

    const svService = new google.maps.StreetViewService();
    svService.getPanorama({ location: coord, radius: 50000, source: google.maps.StreetViewSource.OUTDOOR }, (data, status) => {
      if (status !== 'OK') {
        _loadRoundLocation(gameEl, attempt + 1);
        return;
      }
      const actual = { lat: data.location.latLng.lat(), lng: data.location.latLng.lng() };
      _renderRound(gameEl, actual, Math.random() * 360);
    });
  }

  // Построява панорамата + картата + контролите + компаса за фиксирана локация и посока.
  // Преизползва се от single-player И multiplayer (споделена loc/heading за всички играчи).
  function _renderRound(gameEl, actual, heading, alreadyElapsed) {
    _actual = actual;
    _initPov = { heading, pitch: 0 };

    const svEl = gameEl.querySelector('#fy-sv');
    _sv = new google.maps.StreetViewPanorama(svEl, {
      position: _actual,
      pov: _initPov,
      addressControl: false,
      showRoadLabels: false,
      motionTracking: false,
      motionTrackingControl: false,
      fullscreenControl: false,
    });

    const mapEl = gameEl.querySelector('#fy-map');
    _map = new google.maps.Map(mapEl, {
      zoom: 2,
      center: { lat: 20, lng: 0 },
      streetViewControl: false,
      fullscreenControl: false,
      mapTypeControl: false,
      zoomControl: false,
      gestureHandling: 'greedy',
      styles: [{ featureType: 'all', elementType: 'labels.text', stylers: [{ visibility: 'on' }] }],
    });
    _marker = null;
    _map.addListener('click', e => {
      _guess = { lat: e.latLng.lat(), lng: e.latLng.lng() };
      if (_marker) _marker.setMap(null);
      _marker = new google.maps.Marker({ position: _guess, map: _map, title: 'Your guess' });
      const btn = gameEl.querySelector('#fy-submit');
      if (btn) btn.disabled = false;
    });

    // ── Map open/close/zoom ──────────────────────────────────────────────
    const mapWrap = gameEl.querySelector('#fy-map-wrap');

    // Размер в % от екрана; затвореното (мини) състояние е фиксиран малък размер от CSS
    function _setMapPct(idx) {
      const p = _MAP_PCTS[idx];
      if (p >= 100) {
        mapWrap.style.width = 'calc(100% - 16px)';
        mapWrap.style.height = 'calc(100% - 70px)';
        mapWrap.classList.add('fy-map-full');
      } else {
        mapWrap.style.width = p + '%';
        mapWrap.style.height = p + '%';
        mapWrap.classList.remove('fy-map-full');
      }
      setTimeout(() => google.maps.event.trigger(_map, 'resize'), 10);
    }

    function _openMap() {
      if (_isMobile) {
        mapWrap.classList.remove('fy-map-collapsed');
        mapWrap.classList.add('fy-map-active');
      } else {
        mapWrap.classList.remove('fy-map-mini');
        mapWrap.classList.add('fy-map-active');
        _setMapPct(_mapPctIdx);
      }
      setTimeout(() => google.maps.event.trigger(_map, 'resize'), 260);
    }

    function _closeMap() {
      mapWrap.classList.remove('fy-map-active', 'fy-map-full');
      if (_isMobile) {
        mapWrap.classList.add('fy-map-collapsed');
      } else {
        mapWrap.classList.add('fy-map-mini');
        mapWrap.style.width = '';   // връща към фиксирания мини размер от CSS
        mapWrap.style.height = '';
      }
      setTimeout(() => google.maps.event.trigger(_map, 'resize'), 260);
    }

    // Клик на затворената карта (thumb overlay) → отваря
    gameEl.querySelector('#fy-map-thumb')?.addEventListener('click', e => { e.stopPropagation(); _openMap(); });

    // X бутон → затваря
    gameEl.querySelector('#fy-map-close')?.addEventListener('click', e => { e.stopPropagation(); _closeMap(); });

    // Zoom бутон (десктоп) → цикъл през % стъпките, запомня за цялата игра
    gameEl.querySelector('#fy-zoom-cycle')?.addEventListener('click', e => {
      e.stopPropagation();
      _mapPctIdx = (_mapPctIdx + 1) % _MAP_PCTS.length;
      _setMapPct(_mapPctIdx);
    });

    // Десктоп: клик извън картата (върху Street View) → затваря
    if (!_isMobile) {
      gameEl.addEventListener('click', e => {
        if (!mapWrap.classList.contains('fy-map-active')) return;
        if (mapWrap.contains(e.target)) return;
        _closeMap();
      }, true);
    }

    // Reset — връща Street View към началната посока
    gameEl.querySelector('#fy-map-reset')?.addEventListener('click', e => {
      e.stopPropagation();
      _sv.setPov(_initPov);
      _sv.setPosition(_actual);
    });


    const loading = gameEl.querySelector('#fy-sv-loading');
    if (loading) loading.remove();

    // Submit бутон — разклонение single vs multiplayer
    gameEl.querySelector('#fy-submit')?.addEventListener('click', () => {
      if (_mp) _mpSubmit(); else _submitGuess(false);
    });

    _startTimer(gameEl, alreadyElapsed);
  }

  function _startTimer(gameEl, alreadyElapsed) {
    _stopTimer();
    const elapsed = alreadyElapsed || 0;
    _roundStartTime = Date.now() - elapsed * 1000;
    const timed = _cfg.time > 0;
    _timeLeft = timed ? Math.max(0, _cfg.time - elapsed) : 0;
    _timerInterval = setInterval(() => {
      const el    = gameEl.querySelector('#fy-timer');
      const mapEl = gameEl.querySelector('#fy-map-timer');
      if (timed) {
        _timeLeft--;
        const txt = _fmtTime(Math.max(0, _timeLeft));
        const urgent = _timeLeft <= 10;
        if (el)    { el.textContent = txt;    el.classList.toggle('urgent', urgent); }
        if (mapEl) { mapEl.textContent = txt; mapEl.classList.toggle('urgent', urgent); }
        const liveTimer = gameEl.querySelector('#fy-live-timer');
        if (liveTimer) { liveTimer.textContent = txt; liveTimer.style.color = urgent ? '#f38ba8' : '#f9e2af'; }
        if (_timeLeft <= 0) { _stopTimer(); if (_mp) _mpTimeUp(); else _submitGuess(false); }
      } else {
        const elapsed = Math.floor((Date.now() - _roundStartTime) / 1000);
        const txt = _fmtTime(elapsed);
        if (el)    el.textContent = txt;
        if (mapEl) mapEl.textContent = txt;
      }
    }, 1000);
  }

  function _stopTimer() {
    if (_timerInterval) { clearInterval(_timerInterval); _timerInterval = null; }
  }

  function _submitGuess(noGuess = false) {
    _stopTimer();
    const gameEl = _root.querySelector('#fy-game');
    if (!gameEl) return;

    const elapsed = (Date.now() - _roundStartTime) / 1000;
    let dist = 0, distScore = 0, timeBonus = 0;
    if (!noGuess && _guess && _actual) {
      dist = _distKm(_guess, _actual);
      distScore = _calcScore(dist);
      timeBonus = _timeBonus(elapsed);
    }
    const score = distScore + timeBonus;
    _totalScore += score;
    _roundScores.push({ score, distScore, timeBonus, dist, actual: _actual, guess: _guess });

    // Show result overlay with map
    const isLast = _round >= _cfg.rounds;
    const overlay = document.createElement('div');
    overlay.className = 'fy-result-overlay';
    overlay.innerHTML = `
      <div class="fy-result-box">
        <h2>${_fyt('result_title')} — ${_fyt('round')} ${_round}/${_cfg.rounds}</h2>
        <div class="fy-result-score">+${score} ${_fyt('points')}</div>
        <div class="fy-result-dist">${noGuess || !_guess ? 'No guess — 0 points' : _fyt('distance') + ': ' + _fmtDist(dist)}</div>
        ${!noGuess && _guess ? `
        <div class="fy-result-breakdown">
          <span>${_fyt('location_pts')}: <strong>+${distScore}</strong></span>
          <span>${_fyt('time_bonus')} (${_fmtTime(Math.round(elapsed))}): <strong>+${timeBonus}</strong></span>
          <span>${_fyt('total_pts')}: <strong>${_totalScore}</strong></span>
        </div>` : ''}
        <div class="fy-result-map" id="fy-result-map"></div>
        <div class="fy-result-actions">
          <button class="fy-btn" id="fy-next">${isLast ? _fyt('finish') : _fyt('next_round')}</button>
        </div>
      </div>
    `;
    gameEl.appendChild(overlay);

    // Show result map with actual + guess lines
    setTimeout(() => {
      const resultMapEl = document.getElementById('fy-result-map');
      if (!resultMapEl || !_actual) return;
      const bounds = new google.maps.LatLngBounds();
      const rMap = new google.maps.Map(resultMapEl, {
        streetViewControl: false, fullscreenControl: false,
        mapTypeControl: false, zoomControl: false,
        gestureHandling: 'none',
      });
      // Actual location marker — pin shape
      new google.maps.Marker({
        position: _actual, map: rMap,
        icon: {
          path: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z',
          fillColor: '#f9e2af', fillOpacity: 1, strokeColor: '#1e1e2e', strokeWeight: 1.5,
          scale: 1.6, anchor: new google.maps.Point(12, 22),
        },
        title: 'Actual location', zIndex: 999,
      });
      bounds.extend(_actual);
      if (_guess) {
        new google.maps.Marker({
          position: _guess, map: rMap,
          icon: { path: google.maps.SymbolPath.CIRCLE, scale: 8, fillColor: '#f38ba8', fillOpacity: 1, strokeColor: '#fff', strokeWeight: 2 },
          title: 'Your guess',
        });
        new google.maps.Polyline({
          path: [_actual, _guess], map: rMap,
          strokeColor: '#f1fa8c', strokeOpacity: .8, strokeWeight: 2,
        });
        bounds.extend(_guess);
      }
      rMap.fitBounds(bounds, 40);
    }, 100);

    overlay.querySelector('#fy-next').addEventListener('click', () => {
      overlay.remove();
      if (isLast) _showFinal();
      else _nextRound();
    });
  }

  async function _showFinal() {
    _stopTimer();
    _recordGhSession(Math.round((Date.now() - _gameStartTime) / 1000));
    await _db.run('INSERT INTO scores (total, rounds, date) VALUES (?,?,?)',
      [_totalScore, _cfg.rounds, new Date().toISOString()]);

    const best = await _getBest();
    _root.innerHTML = `
      <div class="fy-root">
        <div class="fy-screen">
          <div style="font-size:2.5rem">🌍</div>
          <h1>${_fyt('final_title')}</h1>
          <div class="fy-result-score">${_totalScore} ${_fyt('points')}</div>
          <div class="fy-scores">
            ${_roundScores.map((r, i) => `
              <div class="fy-score-row">
                <span class="rank">${i+1}.</span>
                <span class="sname">${r.guess ? _fmtDist(r.dist) : 'No guess'}</span>
                <span class="spts">+${r.score}</span>
              </div>
            `).join('')}
          </div>
          ${best ? `<div style="font-size:.8rem;color:#a6adc8">${_fyt('best')}: <strong>${best.total}</strong> pts</div>` : ''}
          <div style="display:flex;gap:10px">
            <button class="fy-btn" id="fy-again">${_fyt('play_again')}</button>
            <button class="fy-btn secondary" id="fy-home">← Menu</button>
          </div>
        </div>
      </div>`;
    _root.querySelector('#fy-again').addEventListener('click', _startGame);
    _root.querySelector('#fy-home').addEventListener('click', _showSetup);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ── SERVER-AUTHORITATIVE MULTIPLAYER ─────────────────────────────────────
  // Game state lives on the server. Browser only renders and sends guesses.
  // ══════════════════════════════════════════════════════════════════════════

  const _MP_API = '/api/pub/findyourself';

  function _mpSend(obj) {
    try { if (_mp?.ws?.readyState === 1) _mp.ws.send(JSON.stringify(obj)); } catch(_) {}
  }

  function _mpLeave() {
    if (!_mp) return;
    _mp._leaving = true;
    _stopTimer();
    try { _mp.ws?.close(); } catch(_) {}
    _mp = null;
    _mpClearActive();
    document.getElementById('fy-reconnecting')?.remove();
  }

  function _ghToken() { return localStorage.getItem('gh_token') || ''; }

  // ── Game list ─────────────────────────────────────────────────────────────

  async function _mpShowList() {
    _root.innerHTML = `
      <div class="fy-root"><div class="fy-screen">
        <div style="font-size:2.4rem">👥</div>
        <h1>${_fyt('multiplayer')}</h1>
        <div style="font-size:.8rem;color:#a6adc8;margin-bottom:4px">${_fyt('open_games')}</div>
        <div id="fy-glist" style="width:100%;max-width:400px;min-height:60px;display:flex;flex-direction:column;gap:6px"></div>
        <div style="display:flex;gap:10px;margin-top:8px;flex-wrap:wrap;justify-content:center">
          <button class="fy-btn" id="fy-mp-create">+ ${_fyt('create_game')}</button>
          <button class="fy-btn secondary" id="fy-mp-back">←</button>
        </div>
      </div></div>`;
    _root.querySelector('#fy-mp-back').onclick = _showSetup;
    _root.querySelector('#fy-mp-create').onclick = _mpCreate;
    await _mpRefreshList();
  }

  async function _mpRefreshList() {
    const el = _root.querySelector('#fy-glist');
    if (!el) return;
    el.innerHTML = '<div style="font-size:.8rem;color:#a6adc8;text-align:center">⏳</div>';
    try {
      const r    = await fetch(`${_MP_API}/games`);
      const list = await r.json();
      if (!list.length) {
        el.innerHTML = `<div style="font-size:.8rem;color:#a6adc8;text-align:center">${_fyt('no_open_games')}</div>`;
        return;
      }
      el.innerHTML = list.map(g => `
        <div style="display:flex;align-items:center;gap:8px;background:#313244;padding:8px 12px;border-radius:8px">
          <div style="flex:1">
            <div style="font-size:.82rem;font-weight:600">${g.rounds_total} ${_fyt('rounds_label')} · ${g.time_per_round > 0 ? _fmtTime(g.time_per_round) : _fyt('no_limit')}</div>
            <div style="font-size:.75rem;color:#a6adc8">${g.player_count} ${_fyt('players_waiting')}</div>
          </div>
          <button class="fy-btn" style="padding:6px 14px;font-size:.82rem" data-join="${g.id}">${_fyt('join')}</button>
        </div>`).join('');
      el.querySelectorAll('[data-join]').forEach(btn => {
        btn.onclick = () => _mpJoinGame(btn.dataset.join);
      });
    } catch(e) {
      el.innerHTML = '<div style="font-size:.8rem;color:#f38ba8">Error loading games</div>';
    }
  }

  // ── Create game ───────────────────────────────────────────────────────────

  async function _mpCreate() {
    const token = _ghToken();
    if (!token) { _showSetup(); return; }
    const btn = _root.querySelector('#fy-mp-create');
    if (btn) { btn.disabled = true; btn.textContent = '⏳'; }
    try {
      const r = await fetch(`${_MP_API}/games`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gh_token: token, rounds: _cfg.rounds, time: _cfg.time, api_key: _cfg.api_key || '' }),
      });
      const data = await r.json();
      if (!data.game_id) throw new Error('no game_id');
      await _mpJoinGame(data.game_id);
    } catch(e) {
      if (btn) { btn.disabled = false; btn.textContent = '+ ' + _fyt('create_game'); }
      mvmOS.notify('FindYourself', 'Could not create game. Try again.');
    }
  }

  // ── Connect to game ───────────────────────────────────────────────────────

  async function _mpJoinGame(gameId) {
    const token = _ghToken();
    if (!token) { _showSetup(); return; }
    _root.innerHTML = `<div class="fy-root"><div class="fy-screen"><div style="font-size:1.8rem">🔄</div><p style="color:#a6adc8">Connecting…</p></div></div>`;
    _mp = { ws: null, gameId, myId: null, submitted: false, curRound: 0, _leaving: false, _reconnectAttempts: 0, _stateApiKey: '' };
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws    = new WebSocket(`${proto}://${location.host}${_MP_API}/games/${gameId}/ws`);
    _mp.ws = ws;
    ws.onopen    = () => ws.send(JSON.stringify({ type: 'join', gh_token: token }));
    ws.onmessage = (e) => { try { _mpHandleMsg(JSON.parse(e.data)); } catch(_) {} };
    ws.onclose   = (ev) => { if (!_mp || _mp._leaving) return; _mpHandleDisconnect(ev.code); };
    ws.onerror   = () => {};
  }

  // ── Message router ────────────────────────────────────────────────────────

  function _mpHandleMsg(msg) {
    if (!_mp) return;
    switch (msg.type) {
      case 'state':                return _mpHandleState(msg);
      case 'round_start':          return _mpEnterRound(msg);
      case 'round_end':            return _mpShowRoundEnd(msg);
      case 'guess_update':         return _mpHandleGuessUpdate(msg);
      case 'game_over':            return _mpShowGameOver(msg);
      case 'player_joined':
      case 'player_reconnected':
      case 'player_disconnected':  return _mpUpdateLobbyPlayer(msg);
      case 'error':
        mvmOS.notify('FindYourself', msg.message || 'Error');
        _mpLeave(); _showSetup();
        return;
    }
  }

  // ── Full state from server (on connect / reconnect) ───────────────────────

  function _mpHandleState(state) {
    if (!_mp) return;
    _mp.myId         = state.your_id;
    _mp._stateApiKey = state.api_key || '';
    _mp._creatorId   = state.creator_id || '';
    _mp.liveTotal    = (state.players || []).filter(p => !!p.connected).length || 1;
    _mp._reconnectAttempts = 0;
    const me = (state.players || []).find(p => p.gh_player_id === state.your_id);
    if (me) { _mp.myName = me.display_name; _mp.myAvatar = me.avatar_svg; _mp.myColor = me.avatar_color; }
    document.getElementById('fy-reconnecting')?.remove();

    if (state.status === 'waiting') {
      _mpShowLobby(state);
    } else if (state.status === 'playing') {
      if (state.location) {
        const myGuess = (state.guesses || []).find(g => g.gh_player_id === _mp.myId);
        _mp.submitted = !!myGuess;
        _mp.curRound  = state.round;
        if (_mp.submitted) {
          _mpShowWaiting();
        } else {
          _mpEnterRound({ round: state.round, total: state.total, time: state.time,
            lat: state.location.lat, lng: state.location.lng, heading: 0,
            api_key: state.api_key, round_started_at: state.round_started_at });
        }
      } else {
        _mpShowLobby(state);
      }
    } else {
      _showSetup();
    }
  }

  // ── Lobby ─────────────────────────────────────────────────────────────────

  function _mpShowLobby(state) {
    if (!_mp) return;
    const gameId    = _mp.gameId;
    const link      = `${location.origin}${_MP_API}/play/${gameId}`;
    const players   = state.players || [];
    const apiKey    = _cfg.api_key || _mp._stateApiKey;
    const rounds    = state.total || _cfg.rounds;
    const time      = state.time  != null ? state.time : _cfg.time;
    const isCreator = state.creator_id && String(state.creator_id) === String(_mp.myId);
    const connCount = (state.connected_count != null && state.connected_count > 0)
      ? state.connected_count
      : players.filter(p => !!p.connected).length;
    console.log('[FY lobby] connected_count:', state.connected_count, 'players:', players.length, 'connCount:', connCount, 'total:', state.total);

    _root.innerHTML = `
      <div class="fy-root" style="display:flex;flex-direction:column;height:100%">
        <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid #313244;flex-shrink:0">
          <span style="font-size:1.3rem">👥</span>
          <span style="font-weight:700;font-size:1rem">FindYourself — ${_fyt('multiplayer')}</span>
          <span style="font-size:.78rem;color:#a6adc8;margin-left:4px">${rounds} ${_fyt('rounds_label')} · ${time > 0 ? _fmtTime(time) : _fyt('no_limit')}</span>
          <div style="flex:1"></div>
          <button class="fy-btn secondary" id="fy-mp-back" style="padding:5px 12px;font-size:.8rem">←</button>
        </div>
        <div style="flex:1;min-height:0;display:grid;grid-template-columns:1fr 1fr;gap:0">
          <div style="border-right:1px solid #313244;display:flex;flex-direction:column;overflow:hidden">
            <div style="padding:12px 14px;font-size:.72rem;color:#a6adc8;text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid #313244">${_fyt('players')}</div>
            <div class="fy-mp-roster" id="fy-mp-roster" style="flex:1;overflow-y:auto;padding:10px 12px;display:flex;flex-direction:column;gap:5px;max-height:none"></div>
            <div style="padding:10px 14px;border-top:1px solid #313244;display:flex;flex-direction:column;gap:6px">
              <div id="fy-lobby-ctrl">
                ${isCreator
                  ? `<button class="fy-btn" id="fy-mp-start" style="width:100%"${(apiKey && connCount >= 2) ? '' : ' disabled'}>${_fyt('start_game')} (${connCount})</button>
                     ${!apiKey ? `<div style="font-size:.72rem;color:#a6adc8;text-align:center;margin-top:4px">${_fyt('no_api')}</div>`
                               : connCount < 2 ? `<div style="font-size:.72rem;color:#a6adc8;text-align:center;margin-top:4px">${_fyt('need_players')}</div>` : ''}`
                  : `<div style="font-size:.8rem;color:#a6adc8;text-align:center;padding:6px 0">${_fyt('waiting_start')}</div>`
                }
              </div>
              <button class="fy-btn secondary" id="fy-mp-copy" style="width:100%;font-size:.8rem">📋 ${_fyt('copy_link')}</button>
            </div>
          </div>
          <div style="display:flex;flex-direction:column;overflow:hidden">
            <div style="padding:12px 14px;font-size:.72rem;color:#a6adc8;text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid #313244">${_fyt('invite_players')}</div>
            <div id="fy-invite-section" style="flex:1;overflow-y:auto;padding:10px 12px">
              <div style="color:#a6adc8;font-size:.8rem;text-align:center;padding:20px 0">⏳</div>
            </div>
          </div>
        </div>
      </div>`;

    _mpRenderRoster(players);
    _mpSaveActive(gameId, link);
    _mpLoadInvites(link);

    const copyBtn = _root.querySelector('#fy-mp-copy');
    copyBtn.onclick = () => {
      navigator.clipboard?.writeText(link).catch(() => {});
      copyBtn.textContent = '✓ ' + _fyt('copied');
    };
    _root.querySelector('#fy-mp-back').onclick  = () => { _mpLeave(); _showSetup(); };
    _root.querySelector('#fy-mp-start')?.addEventListener('click', _mpStartGame);
  }

  function _mpRenderRoster(players) {
    const el = _root.querySelector('#fy-mp-roster');
    if (!el) return;
    el.innerHTML = `<div style="font-size:.78rem;color:#a6adc8;margin-bottom:4px">${_fyt('players')}: ${players.length}</div>` +
      players.map(p => {
        const you = p.gh_player_id === _mp?.myId ? ` (${_fyt('you')})` : '';
        const av  = _avatar({ avatar_svg: p.avatar_svg, display_name: p.display_name, avatar_color: p.avatar_color }, 22);
        const op  = p.connected === false ? ' style="opacity:.45"' : '';
        return `<div class="fy-mp-player" data-pid="${p.gh_player_id}"${op}>${av}<span style="margin-left:6px">${_esc(p.display_name)}${you}</span></div>`;
      }).join('');
  }

  async function _mpLoadInvites(link) {
    const el = _root.querySelector('#fy-invite-section');
    if (!el) return;
    const token = localStorage.getItem('gh_token');
    if (!token) {
      el.innerHTML = `<div style="font-size:.8rem;color:#a6adc8;text-align:center;padding:20px 8px">${_fyt('mp_login')}</div>`;
      return;
    }
    try {
      const r = await fetch('/api/pub/gamehub/players');
      if (!r.ok) { el.innerHTML = ''; return; }
      const all = await r.json();
      const myId = _mp?.myId;
      const others = all.filter(p => String(p.id) !== String(myId));
      if (!others.length) {
        el.innerHTML = `<div style="font-size:.8rem;color:#a6adc8;text-align:center;padding:20px 8px">${_fyt('no_open_games')}</div>`;
        return;
      }
      el.innerHTML = others.map(p => `
        <div style="display:flex;align-items:center;gap:7px;padding:5px 0;border-bottom:1px solid #313244">
          ${_avatar({ avatar_svg: p.avatar_svg, display_name: p.display_name, avatar_color: p.avatar_color }, 22)}
          <span style="flex:1;font-size:.82rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${_esc(p.display_name)}</span>
          <button class="fy-btn secondary" style="padding:4px 10px;font-size:.75rem;flex-shrink:0" data-pid="${p.id}">${_fyt('invite')}</button>
        </div>`).join('');
      el.querySelectorAll('[data-pid]').forEach(btn => {
        btn.onclick = async () => {
          btn.disabled = true; btn.textContent = '⏳';
          try {
            const gameId = _mp?.gameId;
            if (!gameId) { btn.disabled = false; btn.textContent = '✕'; return; }
            // 1. Add to game's allowed list
            const r1 = await fetch(`${_MP_API}/games/${gameId}/invite`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'X-GH-Token': token },
              body: JSON.stringify({ player_id: btn.dataset.pid }),
            });
            if (!r1.ok) { btn.disabled = false; btn.textContent = '✕'; return; }
            // 2. Send Hub notification
            const res = await fetch('/api/pub/gamehub/invite', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'X-GH-Token': token },
              body: JSON.stringify({ to_ids: [btn.dataset.pid], game_id: 'findyourself', room_url: link }),
            });
            btn.textContent = res.ok ? '✓' : '✕';
            if (!res.ok) setTimeout(() => { btn.disabled = false; btn.textContent = _fyt('invite'); }, 2000);
          } catch(_) { btn.disabled = false; btn.textContent = _fyt('invite'); }
        };
      });
    } catch(_) { el.innerHTML = ''; }
  }

  function _mpSaveActive(gameId, link) {
    try { localStorage.setItem('fy_active_game', JSON.stringify({ gameId, link, ts: Date.now() })); } catch(_) {}
  }

  function _mpClearActive() {
    try { localStorage.removeItem('fy_active_game'); } catch(_) {}
  }

  function _mpUpdateLobbyPlayer(msg) {
    const el = _root.querySelector('#fy-mp-roster');
    if (!el) return;
    const p = msg.player;
    if (!p) return;
    if (msg.type === 'player_joined' || msg.type === 'player_reconnected') {
      const existing = el.querySelector(`[data-pid="${p.gh_player_id}"]`);
      if (existing) {
        existing.style.opacity = '1';
      } else {
        const you = p.gh_player_id === _mp?.myId ? ` (${_fyt('you')})` : '';
        const av  = _avatar({ avatar_svg: p.avatar_svg, display_name: p.display_name, avatar_color: p.avatar_color }, 22);
        const row = document.createElement('div');
        row.className = 'fy-mp-player';
        row.dataset.pid = p.gh_player_id;
        row.innerHTML = `${av}<span style="margin-left:6px">${_esc(p.display_name)}${you}</span>`;
        el.appendChild(row);
        const ctr = el.querySelector('div');
        if (ctr) ctr.textContent = `${_fyt('players')}: ${el.querySelectorAll('.fy-mp-player').length}`;
      }
    } else if (msg.type === 'player_disconnected') {
      const row = el.querySelector(`[data-pid="${msg.gh_player_id}"]`);
      if (row) row.style.opacity = '0.4';
    }
    _mpUpdateStartBtn();
  }

  function _mpUpdateStartBtn() {
    const btn = _root.querySelector('#fy-mp-start');
    if (!btn) return;
    const connected = _root.querySelectorAll('#fy-mp-roster .fy-mp-player:not([style*="opacity"])').length;
    const count = Math.max(1, connected);
    btn.textContent = `${_fyt('start_game')} (${count})`;
    btn.disabled = count < 2;
  }

  // ── Start game (this browser resolves locations, POSTs to backend) ─────────

  async function _mpStartGame() {
    const apiKey = _cfg.api_key || _mp?._stateApiKey;
    if (!apiKey) return;

    const btn = _root.querySelector('#fy-mp-start');
    if (btn) { btn.disabled = true; btn.textContent = '⏳ ' + _fyt('preparing'); }

    try { await _loadMaps(apiKey); }
    catch(_) {
      if (btn) { btn.disabled = false; btn.textContent = _fyt('start_game'); }
      mvmOS.notify('FindYourself', 'Failed to load Google Maps. Check your API key.');
      return;
    }

    // Fetch game info to know how many rounds
    let rounds = _cfg.rounds;
    try {
      const r    = await fetch(`${_MP_API}/games`);
      const list = await r.json();
      const g    = list.find(x => x.id === _mp.gameId);
      if (g) rounds = g.rounds_total;
    } catch(_) {}

    const ctrl = _root.querySelector('#fy-lobby-ctrl');
    if (ctrl) ctrl.innerHTML = `<div style="font-size:.82rem;color:#a6adc8;text-align:center">${_fyt('preparing')} (0/${rounds})</div>`;

    const locations = [];
    for (let i = 0; i < rounds; i++) {
      try {
        const loc = await _resolveLocation();
        locations.push(loc);
        if (ctrl) ctrl.innerHTML = `<div style="font-size:.82rem;color:#a6adc8;text-align:center">${_fyt('preparing')} (${i+1}/${rounds})</div>`;
      } catch(_) {
        if (ctrl) ctrl.innerHTML = `<div style="color:#f38ba8;font-size:.82rem">Failed to resolve locations</div>`;
        return;
      }
    }

    try {
      const r = await fetch(`${_MP_API}/games/${_mp.gameId}/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gh_token: _ghToken(), locations }),
      });
      if (!r.ok) {
        const data = await r.json();
        if (data.error === 'already started') return;
        throw new Error(data.error || r.status);
      }
    } catch(e) {
      if (ctrl) ctrl.innerHTML = `<div style="color:#f38ba8;font-size:.82rem">Start failed: ${_esc(String(e))}</div>`;
    }
  }

  function _resolveLocation() {
    return new Promise((resolve, reject) => {
      let attempt = 0;
      function _try() {
        if (attempt++ > 14) { reject('no SV found'); return; }
        const coord = _randomCoord();
        const svc   = new google.maps.StreetViewService();
        svc.getPanorama({ location: coord, radius: 50000, source: google.maps.StreetViewSource.OUTDOOR }, (data, status) => {
          if (status !== 'OK') { _try(); return; }
          resolve({ lat: data.location.latLng.lat(), lng: data.location.latLng.lng(), heading: Math.random() * 360 });
        });
      }
      _try();
    });
  }

  // ── Round entry ───────────────────────────────────────────────────────────

  async function _mpEnterRound(msg) {
    if (!_mp) return;
    _stopTimer();
    _mp.submitted   = false;
    _mp.curRound    = msg.round;
    _mp.liveGuesses = {};
    _mp.curActual   = msg.actual || null;
    if (msg.player_count) _mp.liveTotal = msg.player_count;
    _round          = msg.round;
    _cfg.rounds     = msg.total;
    _cfg.time       = msg.time;
    _liveMap = null; _liveMarkers = {}; _livePolylines = {};

    _root.innerHTML = `<div class="fy-root"><div class="fy-game" id="fy-game"></div></div>`;
    const gameEl = _root.querySelector('#fy-game');
    const elapsedSecs = msg.round_started_at
      ? Math.floor(Date.now() / 1000 - msg.round_started_at)
      : 0;
    _buildRoundUI(gameEl);

    try { await _loadMaps(msg.api_key || _cfg.api_key || _mp._stateApiKey); }
    catch(_) {
      gameEl.innerHTML = `<div class="fy-screen"><p style="color:#f38ba8">Failed to load Google Maps.</p></div>`;
      return;
    }
    if (_cfg.time > 0 && elapsedSecs >= _cfg.time) {
      _mpTimeUp();
      return;
    }
    _renderRound(gameEl, { lat: msg.lat, lng: msg.lng }, msg.heading || 0, elapsedSecs);
  }

  function _mpShowWaiting() {
    let gameEl = _root.querySelector('#fy-game');
    if (!gameEl) {
      _root.innerHTML = `<div class="fy-root"><div class="fy-game" id="fy-game"></div></div>`;
      gameEl = _root.querySelector('#fy-game');
    }
    _root.querySelectorAll('.fy-result-overlay').forEach(el => el.remove());
    const ov = document.createElement('div');
    ov.className = 'fy-result-overlay';
    ov.innerHTML = `<div class="fy-result-box"><div style="color:#a6adc8;font-size:.95rem;text-align:center;padding:28px 16px">⏳ ${_fyt('waiting_others')}</div></div>`;
    gameEl.appendChild(ov);
  }

  // ── Submit guess ──────────────────────────────────────────────────────────

  let _liveMap = null, _liveMarkers = {}, _livePolylines = {};

  function _mpSubmit() {
    if (!_mp || _mp.submitted) return;
    _mp.submitted = true;
    _stopTimer();
    const myLat = _guess?.lat ?? null, myLng = _guess?.lng ?? null;
    _mpSend({ type: 'guess', lat: myLat, lng: myLng });
    if (!_mp.liveGuesses) _mp.liveGuesses = {};
    const myDist = (myLat != null && _mp.curActual)
      ? _distKm({ lat: myLat, lng: myLng }, _mp.curActual) : null;
    _mp.liveGuesses[_mp.myId] = { lat: myLat, lng: myLng, dist_km: myDist,
      display_name: _mp.myName, avatar_svg: _mp.myAvatar, avatar_color: _mp.myColor };
    _mpShowLiveMap();
  }

  function _mpTimeUp() {
    if (!_mp || _mp.submitted) return;
    _mp.submitted = true;
    _stopTimer();
    _mpSend({ type: 'guess', lat: null, lng: null });
    if (!_mp.liveGuesses) _mp.liveGuesses = {};
    _mp.liveGuesses[_mp.myId] = { lat: null, lng: null };
    _mpShowLiveMap();
  }

  function _mpShowLiveMap() {
    const gameEl = _root.querySelector('#fy-game');
    if (!gameEl) return;
    gameEl.querySelectorAll('.fy-result-overlay').forEach(el => el.remove());
    _liveMap = null; _liveMarkers = {}; _livePolylines = {};

    const total    = _mp.liveTotal || 1;
    const done     = Object.keys(_mp.liveGuesses || {}).length;
    const actual   = _mp.curActual;

    const ov = document.createElement('div');
    ov.id = 'fy-live';
    ov.className = 'fy-result-overlay';
    ov.innerHTML = `
      <div class="fy-result-box fy-mp-result">
        <h2>${_fyt('result_title')} — ${_fyt('round')} ${_mp.curRound}/${_cfg.rounds}</h2>
        <div style="text-align:center;font-size:.78rem;color:#a6adc8;margin-bottom:4px">
          <span id="fy-live-status">${done}/${total} ${_fyt('waiting_others')}</span>
        </div>
        <div class="fy-result-map" id="fy-live-map"></div>
        <div class="fy-mp-scores" id="fy-live-scores"></div>
      </div>`;
    gameEl.appendChild(ov);
    _mpUpdateLiveScores();

    if (actual && window.google) {
      setTimeout(() => {
        const el = document.getElementById('fy-live-map');
        if (!el) return;
        const bounds = new google.maps.LatLngBounds();
        _liveMap = new google.maps.Map(el, {
          streetViewControl: false, fullscreenControl: false,
          mapTypeControl: false, zoomControl: false, gestureHandling: 'greedy',
        });
        new google.maps.Marker({
          position: actual, map: _liveMap, zIndex: 999,
          icon: { path: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z', fillColor: '#f9e2af', fillOpacity: 1, strokeColor: '#1e1e2e', strokeWeight: 1.5, scale: 1.8, anchor: new google.maps.Point(12, 22) },
        });
        bounds.extend(actual);
        Object.entries(_mp.liveGuesses || {}).forEach(([pid, g]) => {
          _liveAddMarker(pid, g, bounds);
        });
        if (bounds.isEmpty()) bounds.extend(actual);
        _liveMap.fitBounds(bounds, 50);
      }, 100);
    }
  }

  function _liveAddMarker(pid, g, bounds) {
    if (!_liveMap || g.lat == null) return;
    const pos     = { lat: g.lat, lng: g.lng };
    const svgStr  = _avatar({ avatar_svg: g.avatar_svg, display_name: g.display_name, avatar_color: g.avatar_color }, 28);
    const iconUrl = 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svgStr);
    if (_liveMarkers[pid]) _liveMarkers[pid].setMap(null);
    if (_livePolylines[pid]) _livePolylines[pid].setMap(null);
    _liveMarkers[pid]   = new google.maps.Marker({ position: pos, map: _liveMap, title: g.display_name, zIndex: 10,
      icon: { url: iconUrl, scaledSize: new google.maps.Size(28, 28), anchor: new google.maps.Point(14, 14) } });
    _livePolylines[pid] = new google.maps.Polyline({ path: [pos, _mp.curActual], map: _liveMap,
      strokeColor: g.avatar_color || '#89b4fa', strokeOpacity: .55, strokeWeight: 2 });
    if (bounds) bounds.extend(pos);
  }

  function _mpUpdateLiveScores() {
    const el = _root.querySelector('#fy-live-scores');
    if (!el) return;
    const guesses  = _mp.liveGuesses || {};
    const total    = _mp.liveTotal || 1;
    const waiting  = total - Object.keys(guesses).length;
    el.innerHTML = Object.entries(guesses).map(([pid, g]) =>
      `<div class="fy-mp-score-row${pid === _mp.myId ? ' you' : ''}">
        ${_avatar({ avatar_svg: g.avatar_svg, display_name: g.display_name, avatar_color: g.avatar_color }, 22)}
        <span class="nm">${_esc(g.display_name || '?')}${pid === _mp.myId ? ' (' + _fyt('you') + ')' : ''}</span>
        <span class="ds">${g.lat != null ? _fmtDist(g.dist_km) : '—'}</span>
        <span class="rs">${g.lat != null ? '✓' : '—'}</span>
       </div>`).join('')
    + (waiting > 0 ? `<div style="font-size:.75rem;color:#a6adc8;text-align:center;padding:6px 0">⏳ ${waiting} ${_fyt('waiting_others')}</div>` : '');
  }

  function _mpHandleGuessUpdate(msg) {
    if (!_mp || !_mp.submitted) return;
    if (!_mp.liveGuesses) _mp.liveGuesses = {};
    const dist = (msg.lat != null && _mp.curActual)
      ? _distKm({ lat: msg.lat, lng: msg.lng }, _mp.curActual) : null;
    _mp.liveGuesses[msg.gh_player_id] = {
      lat: msg.lat, lng: msg.lng, dist_km: dist,
      display_name: msg.display_name, avatar_svg: msg.avatar_svg, avatar_color: msg.avatar_color,
    };
    const done = Object.keys(_mp.liveGuesses).length;
    const statusEl = _root.querySelector('#fy-live-status');
    if (statusEl) statusEl.textContent = `${done}/${_mp.liveTotal} ${_fyt('waiting_others')}`;
    _mpUpdateLiveScores();
    if (_liveMap && msg.lat != null) _liveAddMarker(msg.gh_player_id, _mp.liveGuesses[msg.gh_player_id], null);
  }

  // ── Round end ─────────────────────────────────────────────────────────────

  function _mpShowRoundEnd(msg) {
    if (!_mp) return;
    _stopTimer();
    if (msg.actual) _mp.curActual = msg.actual;
    const isLast    = msg.round >= msg.total;
    if (msg.creator_id) _mp._creatorId = msg.creator_id;
    const isCreator = _mp._creatorId && String(_mp._creatorId) === String(_mp.myId);
    const byScore   = (msg.results || []).slice().sort((a, b) => b.score - a.score);
    const byTotal   = (msg.results || []).slice().sort((a, b) => b.total - a.total);
    const totalRank = {}; byTotal.forEach((r, i) => { totalRank[r.gh_player_id] = i + 1; });

    const overlay = document.createElement('div');
    overlay.className = 'fy-result-overlay';
    overlay.innerHTML = `
      <div class="fy-result-box fy-mp-result">
        <h2>${_fyt('result_title')} — ${_fyt('round')} ${msg.round}/${msg.total}</h2>
        <div class="fy-result-map" id="fy-result-map"></div>
        <div class="fy-mp-scores">
          ${byScore.map((r, idx) => `
            <div class="fy-mp-score-row${idx === 0 ? ' winner' : ''}${r.gh_player_id === _mp.myId ? ' you' : ''}" data-pid="${r.gh_player_id}" style="cursor:pointer">
              <span class="rank">${totalRank[r.gh_player_id]}.</span>
              ${_avatar({ avatar_svg: r.avatar_svg, display_name: r.display_name, avatar_color: r.avatar_color }, 22)}
              <span class="nm">${_esc(r.display_name)}${r.gh_player_id === _mp.myId ? ' (' + _fyt('you') + ')' : ''}</span>
              <span class="ds">${r.lat != null ? _fmtDist(r.dist_km) : '—'}</span>
              <span class="rs">+${r.score}</span>
              <span class="ts">${r.total}</span>
            </div>`).join('')}
        </div>
        <div class="fy-mp-result-ctrl" id="fy-mp-result-ctrl"></div>
      </div>`;

    const gameEl = _root.querySelector('#fy-game');
    (gameEl || _root).querySelectorAll('.fy-result-overlay').forEach(el => el.remove());
    (gameEl || _root).appendChild(overlay);

    const ctrl = overlay.querySelector('#fy-mp-result-ctrl');
    if (!isLast) {
      if (isCreator) {
        ctrl.innerHTML = `<button class="fy-btn" id="fy-mp-next-now">${_fyt('next_round')} ▶</button>`;
        ctrl.querySelector('#fy-mp-next-now').addEventListener('click', () => {
          ctrl.querySelector('#fy-mp-next-now').disabled = true;
          _mpSend({ type: 'next_round' });
        });
      } else {
        ctrl.innerHTML = `<div class="fy-mp-waitnext">${_fyt('waiting_round')}</div>`;
      }
    }

    if (msg.actual && window.google) {
      setTimeout(() => {
        const mapEl = document.getElementById('fy-result-map');
        if (!mapEl) return;
        const bounds  = new google.maps.LatLngBounds();
        const rMap    = new google.maps.Map(mapEl, {
          streetViewControl: false, fullscreenControl: false,
          mapTypeControl: false, zoomControl: false, gestureHandling: 'greedy',
        });
        new google.maps.Marker({
          position: msg.actual, map: rMap,
          icon: { path: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z', fillColor: '#f9e2af', fillOpacity: 1, strokeColor: '#1e1e2e', strokeWeight: 1.5, scale: 1.8, anchor: new google.maps.Point(12, 22) },
          title: 'Actual location', zIndex: 999,
        });
        bounds.extend(msg.actual);
        const polylines = {}, markers = {};
        let highlighted = null;
        (msg.results || []).forEach(r => {
          if (r.lat == null) return;
          const pos    = { lat: r.lat, lng: r.lng };
          const svgStr = _avatar({ avatar_svg: r.avatar_svg, display_name: r.display_name, avatar_color: r.avatar_color }, 28);
          const iconUrl = 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svgStr);
          markers[r.gh_player_id] = new google.maps.Marker({
            position: pos, map: rMap, title: r.display_name, zIndex: 10,
            icon: { url: iconUrl, scaledSize: new google.maps.Size(28, 28), anchor: new google.maps.Point(14, 14) },
          });
          polylines[r.gh_player_id] = new google.maps.Polyline({
            path: [pos, msg.actual], map: rMap,
            strokeColor: r.avatar_color || '#89b4fa', strokeOpacity: .55, strokeWeight: 2,
          });
          bounds.extend(pos);
        });
        rMap.fitBounds(bounds, 50);

        // Клик на ред → highlight на линията и маркера
        overlay.querySelectorAll('.fy-mp-score-row[data-pid]').forEach(row => {
          row.addEventListener('click', () => {
            const pid = row.dataset.pid;
            const isAlready = highlighted === pid;
            Object.values(polylines).forEach(pl => pl.setOptions({ strokeOpacity: .55, strokeWeight: 2, zIndex: 1 }));
            Object.values(markers).forEach(mk => mk.setZIndex(10));
            overlay.querySelectorAll('.fy-mp-score-row').forEach(r => r.classList.remove('highlighted'));
            if (isAlready) {
              highlighted = null;
            } else {
              highlighted = pid;
              if (polylines[pid]) polylines[pid].setOptions({ strokeOpacity: 1, strokeWeight: 5, zIndex: 20 });
              if (markers[pid])   markers[pid].setZIndex(100);
              row.classList.add('highlighted');
            }
          });
        });
      }, 100);
    }
  }

  // ── Game over ─────────────────────────────────────────────────────────────

  function _mpShowGameOver(msg) {
    if (!_mp) return;
    _stopTimer();
    _mpClearActive();
    const standings = msg.standings || [];
    const winner    = standings[0];
    _root.innerHTML = `
      <div class="fy-root"><div class="fy-screen">
        <div style="font-size:2.5rem">🏆</div>
        <h1>${_fyt('final_standings')}</h1>
        ${winner ? `<div class="fy-result-score" style="color:${winner.avatar_color || '#89b4fa'}">${_fyt('winner')}: ${_esc(winner.display_name)}</div>` : ''}
        <div class="fy-mp-scores fy-mp-final">
          ${standings.map((s, i) => `
            <div class="fy-mp-score-row${i === 0 ? ' winner' : ''}${s.gh_player_id === _mp.myId ? ' you' : ''}">
              <span class="rank">${i + 1}.</span>
              ${_avatar({ avatar_svg: s.avatar_svg, display_name: s.display_name, avatar_color: s.avatar_color }, 22)}
              <span class="nm">${_esc(s.display_name)}</span>
              <span class="ts">${s.total_score}</span>
            </div>`).join('')}
        </div>
        <div style="display:flex;gap:10px">
          <button class="fy-btn" id="fy-mp-playagain">👥 ${_fyt('multiplayer')}</button>
          <button class="fy-btn secondary" id="fy-mp-home">← Menu</button>
        </div>
      </div></div>`;
    _root.querySelector('#fy-mp-playagain').onclick = () => { _mpLeave(); _mpShowList(); };
    _root.querySelector('#fy-mp-home').onclick      = () => { _mpLeave(); _showSetup(); };
  }

  // ── Disconnect / reconnect ────────────────────────────────────────────────

  function _mpHandleDisconnect(code) {
    if (code === 4004) { _mpLeave(); _showSetup(); mvmOS.notify('FindYourself', 'Game not found.'); return; }

    _mp._reconnectAttempts = (_mp._reconnectAttempts || 0) + 1;
    if (_mp._reconnectAttempts > 5) {
      document.getElementById('fy-reconnecting')?.remove();
      _mpLeave();
      _root.innerHTML = `<div class="fy-root"><div class="fy-screen"><div style="font-size:2rem">🔌</div><p style="color:#f38ba8">Connection lost.</p><button class="fy-btn" id="fy-dc-home" style="margin-top:12px">← Menu</button></div></div>`;
      _root.querySelector('#fy-dc-home').addEventListener('click', _showSetup);
      return;
    }

    let ov = document.getElementById('fy-reconnecting');
    if (!ov) {
      ov = document.createElement('div');
      ov.id = 'fy-reconnecting';
      ov.style.cssText = 'position:fixed;inset:0;background:rgba(30,30,46,.88);display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:9999;gap:10px';
      ov.innerHTML = `<div style="font-size:2rem">🔄</div><div style="color:#cdd6f4;font-size:.95rem;font-weight:600">Reconnecting…</div><div id="fy-rc-att" style="color:#a6adc8;font-size:.8rem"></div>`;
      document.body.appendChild(ov);
    }
    ov.querySelector('#fy-rc-att').textContent = `Attempt ${_mp._reconnectAttempts}/5…`;

    const gameId   = _mp.gameId;
    const attempts = _mp._reconnectAttempts;
    const delay    = Math.min(1500 * attempts, 5000);

    setTimeout(() => {
      if (!_mp || _mp.gameId !== gameId) return;
      const proto = location.protocol === 'https:' ? 'wss' : 'ws';
      const ws    = new WebSocket(`${proto}://${location.host}${_MP_API}/games/${gameId}/ws`);
      _mp.ws      = ws;
      _mp._leaving = false;
      ws.onopen    = () => ws.send(JSON.stringify({ type: 'join', gh_token: _ghToken() }));
      ws.onmessage = (e) => { try { _mpHandleMsg(JSON.parse(e.data)); } catch(_) {} };
      ws.onclose   = (ev) => { if (!_mp || _mp._leaving) return; _mpHandleDisconnect(ev.code); };
      ws.onerror   = () => {};
    }, delay);
  }

  // ── Standalone page entry (public URL) ───────────────────────────────────

  function joinMultiplayer(body, gameId) {
    _root = body;
    if (!document.getElementById('fy-style')) {
      const l = document.createElement('link');
      l.id = 'fy-style'; l.rel = 'stylesheet';
      l.href = '/apps/findyourself/style.css?v=' + Date.now();
      document.head.appendChild(l);
    }
    body.innerHTML = `
      <div class="fy-root"><div class="fy-screen">
        <div style="font-size:2.5rem">🌍</div>
        <h1>FindYourself</h1>
        <div id="fy-mp-ghlogin" style="width:100%;max-width:300px"></div>
      </div></div>`;
    const ghEl = body.querySelector('#fy-mp-ghlogin');
    _loadGameHub(() => {
      if (!window.GameHub) { _showMpLoginMsg(ghEl); return; }
      window.GameHub.renderWidget(ghEl, {
        guestText: null,
        onReady(player) {
          if (player.is_guest) { _showMpLoginMsg(ghEl); return; }
          _ghPlayer = player;
          _mpJoinGame(gameId);
        },
      });
    }, () => _showMpLoginMsg(ghEl));
  }

  function _showMpLoginMsg(el) {
    if (el) el.innerHTML = `<p style="color:#f38ba8;font-size:.85rem;text-align:center">${_fyt('mp_login')}</p>`;
  }


  // прост HTML-escape за имена
  function _esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  }

  return { mount, joinMultiplayer };
})();
