import os
from fastapi import APIRouter
from fastapi.responses import FileResponse

router = APIRouter(tags=["gamehub-public"])

_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "..", "apps", "gamehub", "public")


@router.get("/")
async def public_index():
    return FileResponse(os.path.join(_DIR, "index.html"))
