// Sudofall — Tetris meets Sudoku

mvmOS.registerApp({
  id: 'sudofall',
  name: 'Sudofall',
  icon: '🔢',
  category: 'Games',
  launch() {
    mvmOS.createWindow({
      id: 'sudofall',
      title: '🔢 Sudofall',
      width: 520,
      height: 660,
      minWidth: 380,
      minHeight: 520,
      onMount(body) {
        body.style.cssText = 'padding:0;overflow:hidden;display:flex;flex-direction:column;height:100%;background:var(--surface,#1e1e2e)';
        SudofallGame.init(body);
      }
    });
  }
});

const _sf18n = {
  en: {
    score: 'Score', drop: 'DROP', next: 'Next', time: 'Time',
    new_game: '↺ New', game_over: 'Game Over!', final_score: 'Final Score:',
    time_label: 'Time:', play_again: 'Play Again', joker_title: 'Joker — choose a number',
  },
  bg: {
    score: 'Точки', drop: 'ПУСНИ', next: 'Следващо', time: 'Време',
    new_game: '↺ Ново', game_over: 'Край на играта!', final_score: 'Резултат:',
    time_label: 'Време:', play_again: 'Играй пак', joker_title: 'Джокер — избери число',
  },
};
const SudofallGame = (() => {
  const t = k => { const lang = window.mvmOS?.lang || 'en'; return (_sf18n[lang] || _sf18n.en)[k] || k; };

  let grid = [];
  let current = 0;
  let next = 0;
  let score = 0;
  let gameOver = false;
  let animating = false;
  let elapsed = 0;
  let _timerInterval = null;

  function newNum() { return Math.floor(Math.random() * 10); } // 0-9, 0 = joker

  function _showJokerPicker() {
    return new Promise(resolve => {
      const overlay = document.createElement('div');
      overlay.style.cssText = 'position:absolute;inset:0;z-index:50;background:rgba(0,0,0,.7);display:flex;align-items:center;justify-content:center;border-radius:8px';
      overlay.innerHTML = `
        <div style="background:var(--surface,#1e1e2e);border:1px solid var(--border,#45475a);border-radius:10px;padding:16px;text-align:center">
          <div style="font-size:.8rem;color:var(--text-dim,#a6adc8);margin-bottom:10px;letter-spacing:.05em;text-transform:uppercase">${t('joker_title')}</div>
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px">
            ${[1,2,3,4,5,6,7,8,9].map(n => `
              <div data-n="${n}" style="
                width:44px;height:44px;border-radius:8px;
                display:flex;align-items:center;justify-content:center;
                font-size:1.3rem;font-weight:700;color:#1e1e2e;
                background:${COLORS[n]};cursor:pointer;
                transition:transform .1s,opacity .1s;
              ">${n}</div>
            `).join('')}
          </div>
        </div>`;
      _body.appendChild(overlay);
      overlay.querySelectorAll('[data-n]').forEach(el => {
        el.addEventListener('mouseenter', () => el.style.transform = 'scale(1.15)');
        el.addEventListener('mouseleave', () => el.style.transform = '');
        el.addEventListener('click', () => {
          overlay.remove();
          resolve(+el.dataset.n);
        });
      });
    });
  }

  function _formatTime(s) {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${String(sec).padStart(2, '0')}`;
  }

  function _startTimer() {
    if (_timerInterval) clearInterval(_timerInterval);
    _timerInterval = setInterval(() => {
      if (gameOver) return;
      elapsed++;
      if (_timerEl) _timerEl.textContent = _formatTime(elapsed);
      // Every 10 seconds — deduct 1 point
      if (elapsed % 10 === 0) {
        score--;
        if (_scoreEl) _scoreEl.textContent = score;
      }
    }, 1000);
  }

  function _resolveJoker() {
    // Called when user clicks the current number tile while it's 0
    if (current !== 0) return;
    _showJokerPicker().then(n => {
      current = n;
      render();
    });
  }

  function initState() {
    grid = Array.from({length: 9}, () => Array(9).fill(0));
    current = newNum();
    // ensure current is not joker at start
    while (current === 0) current = newNum();
    next = newNum();
    score = 0;
    gameOver = false;
    animating = false;
    elapsed = 0;
    if (_timerEl) _timerEl.textContent = '0:00';
    _startTimer();
  }

  function dropRow(col) {
    for (let r = 8; r >= 0; r--) {
      if (grid[r][col] === 0) return r;
    }
    return -1;
  }

  // Check if placing `num` at (row, col) is valid sudoku-wise
  function isValid(row, col, num) {
    // Check row
    for (let c = 0; c < 9; c++) if (grid[row][c] === num) return false;
    // Check column
    for (let r = 0; r < 9; r++) if (grid[r][col] === num) return false;
    // Check 3x3 box
    const br = Math.floor(row / 3) * 3;
    const bc = Math.floor(col / 3) * 3;
    for (let r = br; r < br+3; r++)
      for (let c = bc; c < bc+3; c++)
        if (grid[r][c] === num) return false;
    return true;
  }

  // Find the lowest empty row in column (tetris-style drop)
  function dropRow(col) {
    for (let r = 8; r >= 0; r--) {
      if (grid[r][col] === 0) return r;
    }
    return -1; // column full
  }

  // Would placing `num` at (row, col) create a conflict?
  function wouldConflict(row, col, num) {
    for (let c = 0; c < 9; c++) if (c !== col && grid[row][c] === num) return true;
    for (let r = 0; r < 9; r++) if (r !== row && grid[r][col] === num) return true;
    const br = Math.floor(row/3)*3, bc = Math.floor(col/3)*3;
    for (let r = br; r < br+3; r++)
      for (let c = bc; c < bc+3; c++)
        if ((r !== row || c !== col) && grid[r][c] === num) return true;
    return false;
  }

  // Find all existing conflicts in the grid (cells that violate sudoku rules)
  function findGridConflicts() {
    const conflicted = new Set();
    for (let r = 0; r < 9; r++) {
      for (let c = 0; c < 9; c++) {
        const val = grid[r][c];
        if (!val) continue;
        for (let c2 = 0; c2 < 9; c2++)
          if (c2 !== c && grid[r][c2] === val) { conflicted.add(`${r},${c}`); break; }
        for (let r2 = 0; r2 < 9; r2++)
          if (r2 !== r && grid[r2][c] === val) { conflicted.add(`${r},${c}`); break; }
        const br = Math.floor(r/3)*3, bc = Math.floor(c/3)*3;
        outer: for (let r2 = br; r2 < br+3; r2++)
          for (let c2 = bc; c2 < bc+3; c2++)
            if ((r2 !== r || c2 !== c) && grid[r2][c2] === val) { conflicted.add(`${r},${c}`); break outer; }
      }
    }
    return conflicted;
  }

  // Can drop if column is not full. Returns 'warn' if would create conflict, 'valid' otherwise.
  // Returns false also if current is joker (0) — must pick first.
  function canDropInCol(col) {
    if (current === 0) return false;
    const row = dropRow(col);
    if (row < 0) return false; // column full
    return wouldConflict(row, col, current) ? 'warn' : 'valid';
  }

  function findClears() {
    const toRemove = new Set();
    let cleared = 0;

    for (let r = 0; r < 9; r++) {
      const vals = grid[r].filter(v => v !== 0);
      if (vals.length === 9 && new Set(vals).size === 9) {
        for (let c = 0; c < 9; c++) toRemove.add(`${r},${c}`);
        cleared++;
      }
    }
    for (let c = 0; c < 9; c++) {
      const vals = grid.map(r => r[c]).filter(v => v !== 0);
      if (vals.length === 9 && new Set(vals).size === 9) {
        for (let r = 0; r < 9; r++) toRemove.add(`${r},${c}`);
        cleared++;
      }
    }
    for (let br = 0; br < 3; br++) {
      for (let bc = 0; bc < 3; bc++) {
        const vals = [];
        for (let r = br*3; r < br*3+3; r++)
          for (let c = bc*3; c < bc*3+3; c++)
            if (grid[r][c] !== 0) vals.push(grid[r][c]);
        if (vals.length === 9 && new Set(vals).size === 9) {
          for (let r = br*3; r < br*3+3; r++)
            for (let c = bc*3; c < bc*3+3; c++)
              toRemove.add(`${r},${c}`);
          cleared++;
        }
      }
    }
    return { toRemove, cleared };
  }

  // Apply gravity — numbers fall down in each column
  function applyGravity() {
    for (let c = 0; c < 9; c++) {
      const vals = [];
      for (let r = 0; r < 9; r++) if (grid[r][c] !== 0) vals.push(grid[r][c]);
      for (let r = 0; r < 9; r++) grid[r][c] = 0;
      for (let i = 0; i < vals.length; i++) grid[9 - vals.length + i][c] = vals[i];
    }
  }

  function gridFull() {
    for (let r = 0; r < 9; r++)
      for (let c = 0; c < 9; c++)
        if (grid[r][c] === 0) return false;
    return true;
  }

  const COLORS = {
    1: '#f38ba8', 2: '#fab387', 3: '#f9e2af',
    4: '#a6e3a1', 5: '#94e2d5', 6: '#89dceb',
    7: '#89b4fa', 8: '#b4befe', 9: '#cba6f7',
  };

  let _body = null;
  let _cells = [];
  let _dropCells = [];
  let _scoreEl = null;
  let _currentEl = null;
  let _nextEl = null;
  let _timerEl = null;
  let _msgEl = null;
  let _goScore = null;
  let _goTime = null;
  let _dragCol = -1;

  function render() {
    if (!_body) return;

    _scoreEl.textContent = score;

    _currentEl.textContent = current === 0 ? '?' : current;
    _currentEl.style.background = current === 0 ? 'linear-gradient(135deg,#f38ba8,#fab387,#f9e2af,#a6e3a1,#89b4fa,#cba6f7)' : COLORS[current];
    _currentEl.style.cursor = current === 0 ? 'pointer' : 'grab';
    _currentEl.style.animation = current === 0 ? 'sf-pulse .8s ease-in-out infinite alternate' : '';

    _nextEl.textContent = next === 0 ? '0' : next;
    _nextEl.style.background = next === 0 ? 'linear-gradient(135deg,#f38ba8,#fab387,#f9e2af,#a6e3a1,#89b4fa,#cba6f7)' : COLORS[next];

    _dropCells.forEach((el, c) => {
      const mode = canDropInCol(c);
      if (!mode) {
        // Column full
        el.style.background = 'rgba(255,255,255,.04)';
        el.style.borderColor = 'var(--border,#45475a)';
        el.style.color = 'var(--text-dim,#6c7086)';
        el.style.cursor = 'not-allowed';
        el.style.opacity = '.25';
        el.style.textShadow = '';
        el.textContent = '▼';
      } else if (mode === 'warn') {
        // Will create conflict — orange warning
        el.style.background = c === _dragCol ? 'rgba(250,179,135,.3)' : 'rgba(250,179,135,.08)';
        el.style.borderColor = '#fab387';
        el.style.color = '#fab387';
        el.style.cursor = 'pointer';
        el.style.opacity = '1';
        el.style.textShadow = '';
        el.textContent = '⚠';
      } else {
        // Normal drop
        el.style.background = c === _dragCol ? COLORS[current] + '55' : 'rgba(255,255,255,.04)';
        el.style.borderColor = c === _dragCol ? COLORS[current] : 'var(--border,#45475a)';
        el.style.color = 'var(--text-dim,#6c7086)';
        el.style.cursor = 'pointer';
        el.style.opacity = '1';
        el.style.textShadow = '';
        el.textContent = '▼';
      }
    });

    const conflicts = findGridConflicts();

    for (let r = 0; r < 9; r++) {
      for (let c = 0; c < 9; c++) {
        const val = grid[r][c];
        const el = _cells[r][c];
        el.textContent = val || '';
        if (val) {
          const isConflict = conflicts.has(`${r},${c}`);
          if (isConflict) {
            const col = COLORS[val];
            el.style.background = `repeating-linear-gradient(
              45deg,
              ${col},
              ${col} 4px,
              #1e1e2e 4px,
              #1e1e2e 8px
            )`;
            el.style.color = '#fff';
            el.style.textShadow = '0 0 3px rgba(0,0,0,.8)';
            el.style.outline = `2px solid ${col}`;
            el.style.outlineOffset = '-2px';
          } else {
            el.style.background = COLORS[val];
            el.style.color = '#1e1e2e';
            el.style.textShadow = '';
            el.style.outline = '';
          }
        } else {
          el.style.background = 'rgba(255,255,255,.03)';
          el.style.color = 'transparent';
          el.style.textShadow = '';
          el.style.outline = '';
        }
      }
    }

    if (gameOver) {
      _msgEl.style.display = 'flex';
      _goScore.textContent = `${t('final_score')} ${score}`;
      if (_goTime) _goTime.textContent = `${t('time_label')} ${_formatTime(elapsed)}`;
    } else {
      _msgEl.style.display = 'none';
    }
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function placeNumber(col) {
    if (animating || gameOver) return;
    const mode = canDropInCol(col);
    if (!mode) return;

    animating = true;

    const row = dropRow(col);
    if (row < 0) { animating = false; return; }

    // Fall animation
    for (let r = 0; r <= row; r++) {
      const el = _cells[r][col];
      el.textContent = current;
      el.style.background = COLORS[current];
      el.style.color = '#1e1e2e';
      el.style.transform = 'scale(1.05)';
      await sleep(50);
      if (r < row) {
        el.textContent = grid[r][col] || '';
        el.style.background = grid[r][col] ? COLORS[grid[r][col]] : 'rgba(255,255,255,.03)';
        el.style.color = grid[r][col] ? '#1e1e2e' : 'transparent';
        el.style.transform = '';
      }
    }

    grid[row][col] = current;

    // +1 point if no conflict, 0 if conflict
    if (!wouldConflict(row, col, current)) score++;

    const landed = _cells[row][col];
    landed.style.transition = 'transform .1s';
    landed.style.transform = 'scale(1.18)';
    await sleep(110);
    landed.style.transform = '';
    landed.style.transition = '';

    // Check clears + gravity loop
    let iterations = 0;
    while (iterations++ < 10) {
      const { toRemove, cleared } = findClears();
      if (toRemove.size === 0) break;
      score += cleared * 9;

      // Flash cleared cells
      toRemove.forEach(key => {
        const [r, c] = key.split(',').map(Number);
        _cells[r][c].style.transition = 'background .1s, transform .1s';
        _cells[r][c].style.background = '#f9e2af';
        _cells[r][c].style.transform = 'scale(1.1)';
      });
      await sleep(180);

      // Fade out
      toRemove.forEach(key => {
        const [r, c] = key.split(',').map(Number);
        _cells[r][c].style.transition = 'opacity .12s, transform .12s';
        _cells[r][c].style.opacity = '0';
        _cells[r][c].style.transform = 'scale(0.7)';
        grid[r][c] = 0;
      });
      await sleep(130);

      applyGravity();
      render();

      toRemove.forEach(key => {
        const [r, c] = key.split(',').map(Number);
        _cells[r][c].style.transition = '';
        _cells[r][c].style.opacity = '';
        _cells[r][c].style.transform = '';
      });

      await sleep(80);
    }

    current = next;
    next = newNum();
    animating = false;

    if (gridFull()) gameOver = true;
    render();

    // If new current is joker, show picker immediately
    // If joker, wait for user to click the tile
  }

  function init(body) {
    _body = body;
    initState();

    body.innerHTML = `
      <style>
        @keyframes sf-pulse { from { transform: scale(1); } to { transform: scale(1.12); } }
      </style>
      <div style="display:flex;flex-direction:column;height:100%;padding:6px 8px;box-sizing:border-box;gap:6px;position:relative">

        <!-- Header -->
        <div style="display:flex;align-items:center;justify-content:space-between;flex-shrink:0">
          <div>
            <div style="font-size:.7rem;color:var(--text-dim,#a6adc8);text-transform:uppercase;letter-spacing:.05em">${t('score')}</div>
            <div id="sf-score" style="font-size:1.5rem;font-weight:700;color:var(--text,#cdd6f4);line-height:1">0</div>
          </div>
          <div style="display:flex;align-items:center;gap:10px">
            <div style="text-align:center">
              <div style="font-size:.7rem;color:var(--text-dim,#a6adc8);margin-bottom:3px">${t('drop')}</div>
              <div id="sf-current" style="width:38px;height:38px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1.4rem;font-weight:700;color:#1e1e2e;cursor:grab;box-shadow:0 2px 8px rgba(0,0,0,.4);transition:background .2s"></div>
            </div>
            <div style="text-align:center">
              <div style="font-size:.7rem;color:var(--text-dim,#a6adc8);margin-bottom:3px">${t('next')}</div>
              <div id="sf-next" style="width:28px;height:28px;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:1rem;font-weight:700;color:#1e1e2e;opacity:.75;transition:background .2s"></div>
            </div>
            <div style="text-align:center">
              <div style="font-size:.7rem;color:var(--text-dim,#a6adc8);margin-bottom:3px">${t('time')}</div>
              <div id="sf-timer" style="font-size:1rem;font-weight:700;color:var(--text,#cdd6f4);min-width:36px;text-align:center">0:00</div>
            </div>
          </div>
          <button id="sf-restart" style="padding:5px 14px;font-size:.8rem;background:var(--surface2,#313244);border:1px solid var(--border,#45475a);border-radius:6px;color:var(--text,#cdd6f4);cursor:pointer">${t('new_game')}</button>
        </div>

        <!-- Grid container -->
        <div style="flex:1;min-height:0;display:flex;justify-content:center;align-items:flex-start;overflow:hidden" id="sf-grid-container">
          <div id="sf-grid-wrap">

            <!-- Drop row -->
            <div id="sf-drop-row" style="display:grid;grid-template-columns:repeat(9,1fr);gap:2px;margin-bottom:3px;height:9%"></div>

            <!-- Main grid -->
            <div id="sf-grid" style="display:grid;grid-template-columns:repeat(9,1fr);grid-template-rows:repeat(9,1fr);gap:2px;height:91%"></div>
          </div>
        </div>

        <!-- Game over -->
        <div id="sf-gameover" style="display:none;position:absolute;inset:0;background:rgba(0,0,0,.8);z-index:10;flex-direction:column;align-items:center;justify-content:center;gap:16px;border-radius:8px">
          <div style="font-size:1.8rem;font-weight:700;color:#f9e2af">${t('game_over')}</div>
          <div id="sf-go-score" style="font-size:1.1rem;color:var(--text,#cdd6f4)"></div>
          <div id="sf-go-time" style="font-size:.9rem;color:var(--text-dim,#a6adc8)"></div>
          <button id="sf-play-again" style="padding:10px 28px;background:var(--accent,#6366f1);border:none;border-radius:8px;color:#fff;font-size:1rem;font-weight:600;cursor:pointer">${t('play_again')}</button>
        </div>
      </div>
    `;

    _scoreEl = body.querySelector('#sf-score');
    _currentEl = body.querySelector('#sf-current');
    _nextEl = body.querySelector('#sf-next');
    _timerEl = body.querySelector('#sf-timer');
    _msgEl = body.querySelector('#sf-gameover');
    _goScore = body.querySelector('#sf-go-score');
    _goTime = body.querySelector('#sf-go-time');

    // Build drop row
    const dropRow_ = body.querySelector('#sf-drop-row');
    _dropCells = [];
    for (let c = 0; c < 9; c++) {
      const el = document.createElement('div');
      el.style.cssText = `
        display:flex;align-items:center;justify-content:center;
        border-radius:4px;border:2px dashed var(--border,#45475a);
        font-size:.7rem;color:var(--text-dim,#6c7086);
        transition:background .15s,border-color .15s;
        user-select:none;
      `;
      el.textContent = '▼';

      el.addEventListener('click', () => { if (!animating && !gameOver) placeNumber(c); });
      el.addEventListener('dragover', e => { e.preventDefault(); _dragCol = c; render(); });
      el.addEventListener('dragleave', () => { _dragCol = -1; render(); });
      el.addEventListener('drop', e => { e.preventDefault(); _dragCol = -1; placeNumber(c); render(); });
      el.addEventListener('touchend', e => { e.preventDefault(); if (!animating && !gameOver) placeNumber(c); });

      _dropCells.push(el);
      dropRow_.appendChild(el);
    }

    // Build main grid
    const gridEl = body.querySelector('#sf-grid');
    _cells = [];
    for (let r = 0; r < 9; r++) {
      _cells.push([]);
      for (let c = 0; c < 9; c++) {
        const el = document.createElement('div');
        // Box borders via margin
        const mt = r % 3 === 0 && r !== 0 ? '3px' : '0';
        const ml = c % 3 === 0 && c !== 0 ? '3px' : '0';
        el.style.cssText = `
          display:flex;align-items:center;justify-content:center;
          border-radius:3px;
          font-size:clamp(.8rem,3vw,1.1rem);font-weight:700;
          transition:background .12s,transform .12s;
          margin-top:${mt};margin-left:${ml};
        `;
        _cells[r].push(el);
        gridEl.appendChild(el);
      }
    }

    // Click on current tile — for joker picker
    _currentEl.addEventListener('click', () => { if (current === 0) _resolveJoker(); });

    // Draggable current number
    _currentEl.draggable = true;
    _currentEl.addEventListener('dragstart', e => {
      e.dataTransfer.setData('text/plain', 'sudofall');
      e.dataTransfer.effectAllowed = 'copy';
    });

    // Touch drag on current number
    let touchStartX = 0;
    _currentEl.addEventListener('touchstart', e => {
      touchStartX = e.touches[0].clientX;
    }, {passive: true});

    body.querySelector('#sf-restart').addEventListener('click', () => { initState(); render(); });
    body.querySelector('#sf-play-again').addEventListener('click', () => { initState(); render(); });

    // Responsive grid sizing — fit inside available space
    const gridContainer = body.querySelector('#sf-grid-container');
    const gridWrap = body.querySelector('#sf-grid-wrap');
    function _resizeGrid() {
      const availW = gridContainer.clientWidth;
      const availH = gridContainer.clientHeight;
      // grid aspect ratio is 9 wide : 10 tall (9 cols + drop row)
      let h = availH;
      let w = h * 9 / 10;
      if (w > availW) { w = availW; h = w * 10 / 9; }
      gridWrap.style.width = w + 'px';
      gridWrap.style.height = h + 'px';
      // Set font size based on cell size (grid is 9 cols, 91% of height for cells)
      const cellSize = w / 9;
      const fs = Math.round(cellSize * 0.52);
      _cells.forEach(row => row.forEach(el => el.style.fontSize = fs + 'px'));
    }
    _resizeGrid();
    new ResizeObserver(_resizeGrid).observe(gridContainer);

    render();
  }

  return { init };
})();
