// Sudofall — Tetris meets Sudoku

mvmOS.registerApp({
  id: 'sudofall',
  name: 'Sudofall',
  icon: '🔢',
  category: 'Games',
  launch() {
    mvmOS.createWindow({
      id: 'sudofall',
      title: '🔢 Sudofall',
      width: 520,
      height: 660,
      minWidth: 380,
      minHeight: 520,
      onMount(body) {
        body.style.cssText = 'padding:0;overflow:hidden;display:flex;flex-direction:column;height:100%;background:var(--surface,#1e1e2e)';
        SudofallGame.init(body);
      }
    });
  }
});

const SudofallGame = (() => {

  let grid = [];
  let current = 0;
  let next = 0;
  let score = 0;
  let gameOver = false;
  let animating = false;
  let elapsed = 0;  // seconds since game start
  let _timerInterval = null;

  function newNum() { return Math.floor(Math.random() * 9) + 1; }

  function _formatTime(s) {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${String(sec).padStart(2, '0')}`;
  }

  function _startTimer() {
    if (_timerInterval) clearInterval(_timerInterval);
    _timerInterval = setInterval(() => {
      if (gameOver) return;
      elapsed++;
      if (_timerEl) _timerEl.textContent = _formatTime(elapsed);
    }, 1000);
  }

  function initState() {
    grid = Array.from({length: 9}, () => Array(9).fill(0));
    current = newNum();
    next = newNum();
    score = 0;
    gameOver = false;
    animating = false;
    elapsed = 0;
    if (_timerEl) _timerEl.textContent = '0:00';
    _startTimer();
  }

  function dropRow(col) {
    for (let r = 8; r >= 0; r--) {
      if (grid[r][col] === 0) return r;
    }
    return -1;
  }

  // Check if placing `num` at (row, col) is valid sudoku-wise
  function isValid(row, col, num) {
    // Check row
    for (let c = 0; c < 9; c++) if (grid[row][c] === num) return false;
    // Check column
    for (let r = 0; r < 9; r++) if (grid[r][col] === num) return false;
    // Check 3x3 box
    const br = Math.floor(row / 3) * 3;
    const bc = Math.floor(col / 3) * 3;
    for (let r = br; r < br+3; r++)
      for (let c = bc; c < bc+3; c++)
        if (grid[r][c] === num) return false;
    return true;
  }

  // Find the lowest valid row in column for current number
  function validDropRow(col) {
    for (let r = 8; r >= 0; r--) {
      if (grid[r][col] !== 0) continue;
      const hasSupport = r === 8 || grid[r+1][col] !== 0;
      if (!hasSupport) continue;
      if (isValid(r, col, current)) return r;
    }
    return -1;
  }

  // Find the highest (topmost) same number in column for explosion
  function explosionRow(col) {
    for (let r = 0; r < 9; r++) {
      if (grid[r][col] === current) return r;
    }
    return -1;
  }

  // Find all existing conflicts in the grid (cells that violate sudoku rules)
  // Returns a Set of "row,col" strings that are in conflict
  function findGridConflicts() {
    const conflicted = new Set();
    for (let r = 0; r < 9; r++) {
      for (let c = 0; c < 9; c++) {
        const val = grid[r][c];
        if (!val) continue;
        // Check row
        for (let c2 = 0; c2 < 9; c2++) {
          if (c2 !== c && grid[r][c2] === val) { conflicted.add(`${r},${c}`); break; }
        }
        // Check col
        for (let r2 = 0; r2 < 9; r2++) {
          if (r2 !== r && grid[r2][c] === val) { conflicted.add(`${r},${c}`); break; }
        }
        // Check box
        const br = Math.floor(r/3)*3, bc = Math.floor(c/3)*3;
        outer: for (let r2 = br; r2 < br+3; r2++)
          for (let c2 = bc; c2 < bc+3; c2++)
            if ((r2 !== r || c2 !== c) && grid[r2][c2] === val) { conflicted.add(`${r},${c}`); break outer; }
      }
    }
    return conflicted;
  }

  // Can we place current number in this column? 'valid' | 'explode' | false
  // If there are existing conflicts in the grid with the current number,
  // only allow explosion on those conflicted columns, forbid everything else.
  function canDropInCol(col) {
    const conflicts = findGridConflicts();
    const conflictedNums = new Set([...conflicts].map(k => grid[+k.split(',')[0]][+k.split(',')[1]]));

    if (conflicts.size > 0 && conflictedNums.has(current)) {
      // Current number matches a conflicted number — only allow explosion on conflicted cells of that value
      const hasConflictInCol = [...conflicts].some(k => {
        const [r, c] = k.split(',').map(Number);
        return c === col && grid[r][c] === current;
      });
      if (hasConflictInCol && explosionRow(col) >= 0) return 'explode';
      return false;
    }

    // Normal logic
    if (validDropRow(col) >= 0) return 'valid';
    if (explosionRow(col) >= 0) return 'explode';
    return false;
  }

  function canPlace() {
    for (let c = 0; c < 9; c++) if (canDropInCol(c)) return true;
    return false;
  }

  function findClears() {
    const toRemove = new Set();
    let cleared = 0;

    for (let r = 0; r < 9; r++) {
      const vals = grid[r].filter(v => v !== 0);
      if (vals.length === 9 && new Set(vals).size === 9) {
        for (let c = 0; c < 9; c++) toRemove.add(`${r},${c}`);
        cleared++;
      }
    }
    for (let c = 0; c < 9; c++) {
      const vals = grid.map(r => r[c]).filter(v => v !== 0);
      if (vals.length === 9 && new Set(vals).size === 9) {
        for (let r = 0; r < 9; r++) toRemove.add(`${r},${c}`);
        cleared++;
      }
    }
    for (let br = 0; br < 3; br++) {
      for (let bc = 0; bc < 3; bc++) {
        const vals = [];
        for (let r = br*3; r < br*3+3; r++)
          for (let c = bc*3; c < bc*3+3; c++)
            if (grid[r][c] !== 0) vals.push(grid[r][c]);
        if (vals.length === 9 && new Set(vals).size === 9) {
          for (let r = br*3; r < br*3+3; r++)
            for (let c = bc*3; c < bc*3+3; c++)
              toRemove.add(`${r},${c}`);
          cleared++;
        }
      }
    }
    return { toRemove, cleared };
  }

  // Apply gravity — numbers fall down in each column
  function applyGravity() {
    for (let c = 0; c < 9; c++) {
      const vals = [];
      for (let r = 0; r < 9; r++) if (grid[r][c] !== 0) vals.push(grid[r][c]);
      for (let r = 0; r < 9; r++) grid[r][c] = 0;
      for (let i = 0; i < vals.length; i++) grid[9 - vals.length + i][c] = vals[i];
    }
  }

  // After gravity, check only cells that landed on top of existing cells.
  // A cell at (r,c) is a conflict if it's invalid per sudoku rules given what's below/around it.
  // Only remove cells that violate — prefer keeping the lower cell (it was there first).
  function removeConflicts() {
    const conflicts = new Set();
    for (let c = 0; c < 9; c++) {
      for (let r = 0; r < 9; r++) {
        const val = grid[r][c];
        if (!val || conflicts.has(`${r},${c}`)) continue;
        // Check row — if duplicate exists, mark the one higher up (smaller r = fell later)
        for (let c2 = c+1; c2 < 9; c2++) {
          if (grid[r][c2] === val) {
            conflicts.add(`${r},${c}`); // mark current (higher or equal)
          }
        }
        // Check col — mark upper one (smaller r)
        for (let r2 = r+1; r2 < 9; r2++) {
          if (grid[r2][c] === val) {
            conflicts.add(`${r},${c}`); break;
          }
        }
        // Check 3x3 — mark upper-left one
        const br = Math.floor(r/3)*3, bc = Math.floor(c/3)*3;
        for (let r2 = br; r2 < br+3; r2++)
          for (let c2 = bc; c2 < bc+3; c2++)
            if ((r2 > r || (r2 === r && c2 > c)) && grid[r2][c2] === val)
              conflicts.add(`${r},${c}`);
      }
    }
    conflicts.forEach(key => {
      const [r, c] = key.split(',').map(Number);
      grid[r][c] = 0;
    });
    return conflicts;
  }

  async function resolveConflictsLoop() {
    let iterations = 0;
    while (iterations++ < 10) {
      const conflicts = removeConflicts();
      if (conflicts.size === 0) break;

      // Flash white → shrink → disappear
      conflicts.forEach(key => {
        const [r, c] = key.split(',').map(Number);
        _cells[r][c].style.transition = 'background .08s';
        _cells[r][c].style.background = '#ffffff';
        _cells[r][c].style.transform = 'scale(1.2)';
      });
      await sleep(80);
      conflicts.forEach(key => {
        const [r, c] = key.split(',').map(Number);
        _cells[r][c].style.transition = 'transform .12s, opacity .12s';
        _cells[r][c].style.transform = 'scale(0)';
        _cells[r][c].style.opacity = '0';
      });
      await sleep(130);
      applyGravity();
      render();
      conflicts.forEach(key => {
        const [r, c] = key.split(',').map(Number);
        _cells[r][c].style.transition = '';
        _cells[r][c].style.opacity = '';
        _cells[r][c].style.transform = '';
      });
      await sleep(80);
    }
  }

  function checkAndClear() {
    const { toRemove, cleared } = findClears();
    if (toRemove.size > 0) {
      toRemove.forEach(key => {
        const [r, c] = key.split(',').map(Number);
        grid[r][c] = 0;
      });
      score += cleared * 9;
    }
    return toRemove;
  }

  const COLORS = {
    1: '#f38ba8', 2: '#fab387', 3: '#f9e2af',
    4: '#a6e3a1', 5: '#94e2d5', 6: '#89dceb',
    7: '#89b4fa', 8: '#b4befe', 9: '#cba6f7',
  };

  let _body = null;
  let _cells = [];
  let _dropCells = [];
  let _scoreEl = null;
  let _currentEl = null;
  let _nextEl = null;
  let _timerEl = null;
  let _msgEl = null;
  let _goScore = null;
  let _goTime = null;
  let _dragCol = -1;

  function render() {
    if (!_body) return;

    _scoreEl.textContent = score;

    _currentEl.textContent = current;
    _currentEl.style.background = COLORS[current];

    _nextEl.textContent = next;
    _nextEl.style.background = COLORS[next];

    _dropCells.forEach((el, c) => {
      const mode = canDropInCol(c);
      if (!mode) {
        // Full or no options
        el.style.background = 'rgba(255,255,255,.04)';
        el.style.borderColor = 'var(--border,#45475a)';
        el.style.color = 'var(--text-dim,#6c7086)';
        el.style.cursor = 'not-allowed';
        el.style.opacity = '.25';
        el.textContent = '▼';
      } else if (mode === 'explode') {
        // Orange — explosion only
        el.style.background = c === _dragCol ? 'rgba(250,179,135,.3)' : 'rgba(250,179,135,.1)';
        el.style.borderColor = '#fab387';
        el.style.color = '#fab387';
        el.style.cursor = 'pointer';
        el.style.opacity = '1';
        el.textContent = '💥';
      } else {
        // Green — normal drop
        el.style.background = c === _dragCol ? COLORS[current] + '55' : 'rgba(255,255,255,.04)';
        el.style.borderColor = c === _dragCol ? COLORS[current] : 'var(--border,#45475a)';
        el.style.color = 'var(--text-dim,#6c7086)';
        el.style.cursor = 'pointer';
        el.style.opacity = '1';
        el.textContent = '▼';
      }
    });

    const conflicts = findGridConflicts();

    for (let r = 0; r < 9; r++) {
      for (let c = 0; c < 9; c++) {
        const val = grid[r][c];
        const el = _cells[r][c];
        el.textContent = val || '';
        if (val) {
          const isConflict = conflicts.has(`${r},${c}`);
          if (isConflict) {
            const col = COLORS[val];
            el.style.background = `repeating-linear-gradient(
              45deg,
              ${col},
              ${col} 4px,
              #1e1e2e 4px,
              #1e1e2e 8px
            )`;
            el.style.color = '#fff';
            el.style.textShadow = '0 0 3px rgba(0,0,0,.8)';
            el.style.outline = `2px solid ${col}`;
            el.style.outlineOffset = '-2px';
          } else {
            el.style.background = COLORS[val];
            el.style.color = '#1e1e2e';
            el.style.textShadow = '';
            el.style.outline = '';
          }
        } else {
          el.style.background = 'rgba(255,255,255,.03)';
          el.style.color = 'transparent';
          el.style.textShadow = '';
          el.style.outline = '';
        }
      }
    }

    if (gameOver) {
      _msgEl.style.display = 'flex';
      _goScore.textContent = `Final Score: ${score}`;
      if (_goTime) _goTime.textContent = `Time: ${_formatTime(elapsed)}`;
    } else {
      _msgEl.style.display = 'none';
    }
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function placeNumber(col) {
    if (animating || gameOver) return;
    const mode = canDropInCol(col);
    if (!mode) return;

    animating = true;

    if (mode === 'explode') {
      const targetRow = explosionRow(col);

      // Drop animation
      for (let r = 0; r <= targetRow; r++) {
        const el = _cells[r][col];
        el.textContent = current;
        el.style.background = COLORS[current];
        el.style.color = '#1e1e2e';
        el.style.transform = 'scale(1.05)';
        await sleep(50);
        if (r < targetRow) {
          el.textContent = grid[r][col] || '';
          el.style.background = grid[r][col] ? COLORS[grid[r][col]] : 'rgba(255,255,255,.03)';
          el.style.color = grid[r][col] ? '#1e1e2e' : 'transparent';
          el.style.transform = '';
        }
      }

      // Explosion — flash white, shrink, disappear
      const expEl = _cells[targetRow][col];
      expEl.textContent = '';
      expEl.style.background = '#ffffff';
      expEl.style.transform = 'scale(1.3)';
      await sleep(80);
      expEl.style.transition = 'transform .12s, opacity .12s';
      expEl.style.transform = 'scale(0)';
      expEl.style.opacity = '0';
      await sleep(130);

      // Penalty for explosion
      score -= 1;

      // Update grid
      grid[targetRow][col] = 0;
      for (let r = targetRow; r > 0; r--) grid[r][col] = grid[r-1][col];
      grid[0][col] = 0;

      // Animate gravity — cells slide down
      for (let r = targetRow; r > 0; r--) {
        const el = _cells[r][col];
        el.style.transition = 'none';
        el.style.transform = 'translateY(-100%)';
        el.style.opacity = '1';
      }
      // Force reflow
      _cells[0][col].offsetHeight;
      for (let r = targetRow; r > 0; r--) {
        const el = _cells[r][col];
        el.style.transition = 'transform .18s ease-in';
        el.style.transform = '';
      }
      await sleep(200);

      // Clean up all styles in column
      for (let r = 0; r <= targetRow; r++) {
        const el = _cells[r][col];
        el.style.transition = '';
        el.style.transform = '';
        el.style.opacity = '';
      }

      render();

      animating = false;
      current = next;
      next = newNum();
      if (!canPlace()) gameOver = true;
      render();
      return;
    }

    const row = validDropRow(col);
    if (row < 0) { animating = false; return; }

    // Fall animation — smooth drop
    for (let r = 0; r <= row; r++) {
      const el = _cells[r][col];
      el.textContent = current;
      el.style.background = COLORS[current];
      el.style.color = '#1e1e2e';
      el.style.transform = 'scale(1.05)';
      await sleep(50);
      if (r < row) {
        el.textContent = '';
        el.style.background = 'rgba(255,255,255,.03)';
        el.style.color = 'transparent';
        el.style.transform = '';
      }
    }

    grid[row][col] = current;
    const landed = _cells[row][col];
    landed.style.transition = 'transform .1s';
    landed.style.transform = 'scale(1.18)';
    await sleep(110);
    landed.style.transform = '';
    landed.style.transition = '';

    // Check clears, gravity, conflict resolution — loop until stable
    let anyCleared = false;
    let iterations = 0;
    while (iterations++ < 10) {
      const { toRemove, cleared } = findClears();
      if (toRemove.size === 0) break;
      anyCleared = true;
      score += cleared * 9;

      // Flash cleared cells
      toRemove.forEach(key => {
        const [r, c] = key.split(',').map(Number);
        _cells[r][c].style.transition = 'background .1s, transform .1s';
        _cells[r][c].style.background = '#f9e2af';
        _cells[r][c].style.transform = 'scale(1.1)';
      });
      await sleep(180);

      // Fade out
      toRemove.forEach(key => {
        const [r, c] = key.split(',').map(Number);
        _cells[r][c].style.transition = 'opacity .12s, transform .12s';
        _cells[r][c].style.opacity = '0';
        _cells[r][c].style.transform = 'scale(0.7)';
        grid[r][c] = 0;
      });
      await sleep(130);

      // Apply gravity
      applyGravity();
      render();

      // Clean up fade styles
      toRemove.forEach(key => {
        const [r, c] = key.split(',').map(Number);
        _cells[r][c].style.transition = '';
        _cells[r][c].style.opacity = '';
        _cells[r][c].style.transform = '';
      });

      await sleep(80);
    }

    current = next;
    next = newNum();
    animating = false;

    if (!canPlace()) gameOver = true;
    render();
  }

  function init(body) {
    _body = body;
    initState();

    body.innerHTML = `
      <div style="display:flex;flex-direction:column;height:100%;padding:6px 8px;box-sizing:border-box;gap:6px;position:relative">

        <!-- Header -->
        <div style="display:flex;align-items:center;justify-content:space-between;flex-shrink:0">
          <div>
            <div style="font-size:.7rem;color:var(--text-dim,#a6adc8);text-transform:uppercase;letter-spacing:.05em">Score</div>
            <div id="sf-score" style="font-size:1.5rem;font-weight:700;color:var(--text,#cdd6f4);line-height:1">0</div>
          </div>
          <div style="display:flex;align-items:center;gap:10px">
            <div style="text-align:center">
              <div style="font-size:.7rem;color:var(--text-dim,#a6adc8);margin-bottom:3px">DROP</div>
              <div id="sf-current" style="width:38px;height:38px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1.4rem;font-weight:700;color:#1e1e2e;cursor:grab;box-shadow:0 2px 8px rgba(0,0,0,.4);transition:background .2s"></div>
            </div>
            <div style="text-align:center">
              <div style="font-size:.7rem;color:var(--text-dim,#a6adc8);margin-bottom:3px">Next</div>
              <div id="sf-next" style="width:28px;height:28px;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:1rem;font-weight:700;color:#1e1e2e;opacity:.75;transition:background .2s"></div>
            </div>
            <div style="text-align:center">
              <div style="font-size:.7rem;color:var(--text-dim,#a6adc8);margin-bottom:3px">Time</div>
              <div id="sf-timer" style="font-size:1rem;font-weight:700;color:var(--text,#cdd6f4);min-width:36px;text-align:center">0:00</div>
            </div>
          </div>
          <button id="sf-restart" style="padding:5px 14px;font-size:.8rem;background:var(--surface2,#313244);border:1px solid var(--border,#45475a);border-radius:6px;color:var(--text,#cdd6f4);cursor:pointer">↺ New</button>
        </div>

        <!-- Grid container -->
        <div style="flex:1;min-height:0;display:flex;justify-content:center;align-items:flex-start;overflow:hidden" id="sf-grid-container">
          <div id="sf-grid-wrap">

            <!-- Drop row -->
            <div id="sf-drop-row" style="display:grid;grid-template-columns:repeat(9,1fr);gap:2px;margin-bottom:3px;height:9%"></div>

            <!-- Main grid -->
            <div id="sf-grid" style="display:grid;grid-template-columns:repeat(9,1fr);grid-template-rows:repeat(9,1fr);gap:2px;height:91%"></div>
          </div>
        </div>

        <!-- Game over -->
        <div id="sf-gameover" style="display:none;position:absolute;inset:0;background:rgba(0,0,0,.8);z-index:10;flex-direction:column;align-items:center;justify-content:center;gap:16px;border-radius:8px">
          <div style="font-size:1.8rem;font-weight:700;color:#f9e2af">Game Over!</div>
          <div id="sf-go-score" style="font-size:1.1rem;color:var(--text,#cdd6f4)"></div>
          <div id="sf-go-time" style="font-size:.9rem;color:var(--text-dim,#a6adc8)"></div>
          <button id="sf-play-again" style="padding:10px 28px;background:var(--accent,#6366f1);border:none;border-radius:8px;color:#fff;font-size:1rem;font-weight:600;cursor:pointer">Play Again</button>
        </div>
      </div>
    `;

    _scoreEl = body.querySelector('#sf-score');
    _currentEl = body.querySelector('#sf-current');
    _nextEl = body.querySelector('#sf-next');
    _timerEl = body.querySelector('#sf-timer');
    _msgEl = body.querySelector('#sf-gameover');
    _goScore = body.querySelector('#sf-go-score');
    _goTime = body.querySelector('#sf-go-time');

    // Build drop row
    const dropRow_ = body.querySelector('#sf-drop-row');
    _dropCells = [];
    for (let c = 0; c < 9; c++) {
      const el = document.createElement('div');
      el.style.cssText = `
        display:flex;align-items:center;justify-content:center;
        border-radius:4px;border:2px dashed var(--border,#45475a);
        font-size:.7rem;color:var(--text-dim,#6c7086);
        transition:background .15s,border-color .15s;
        user-select:none;
      `;
      el.textContent = '▼';

      el.addEventListener('click', () => { if (!animating && !gameOver) placeNumber(c); });
      el.addEventListener('dragover', e => { e.preventDefault(); _dragCol = c; render(); });
      el.addEventListener('dragleave', () => { _dragCol = -1; render(); });
      el.addEventListener('drop', e => { e.preventDefault(); _dragCol = -1; placeNumber(c); render(); });
      el.addEventListener('touchend', e => { e.preventDefault(); if (!animating && !gameOver) placeNumber(c); });

      _dropCells.push(el);
      dropRow_.appendChild(el);
    }

    // Build main grid
    const gridEl = body.querySelector('#sf-grid');
    _cells = [];
    for (let r = 0; r < 9; r++) {
      _cells.push([]);
      for (let c = 0; c < 9; c++) {
        const el = document.createElement('div');
        // Box borders via margin
        const mt = r % 3 === 0 && r !== 0 ? '3px' : '0';
        const ml = c % 3 === 0 && c !== 0 ? '3px' : '0';
        el.style.cssText = `
          display:flex;align-items:center;justify-content:center;
          border-radius:3px;
          font-size:clamp(.8rem,3vw,1.1rem);font-weight:700;
          transition:background .12s,transform .12s;
          margin-top:${mt};margin-left:${ml};
        `;
        _cells[r].push(el);
        gridEl.appendChild(el);
      }
    }

    // Draggable current number
    _currentEl.draggable = true;
    _currentEl.addEventListener('dragstart', e => {
      e.dataTransfer.setData('text/plain', 'sudofall');
      e.dataTransfer.effectAllowed = 'copy';
    });

    // Touch drag on current number
    let touchStartX = 0;
    _currentEl.addEventListener('touchstart', e => {
      touchStartX = e.touches[0].clientX;
    }, {passive: true});

    body.querySelector('#sf-restart').addEventListener('click', () => { initState(); render(); });
    body.querySelector('#sf-play-again').addEventListener('click', () => { initState(); render(); });

    // Responsive grid sizing — fit inside available space
    const gridContainer = body.querySelector('#sf-grid-container');
    const gridWrap = body.querySelector('#sf-grid-wrap');
    function _resizeGrid() {
      const availW = gridContainer.clientWidth;
      const availH = gridContainer.clientHeight;
      // grid aspect ratio is 9 wide : 10 tall (9 cols + drop row)
      let h = availH;
      let w = h * 9 / 10;
      if (w > availW) { w = availW; h = w * 10 / 9; }
      gridWrap.style.width = w + 'px';
      gridWrap.style.height = h + 'px';
      // Set font size based on cell size (grid is 9 cols, 91% of height for cells)
      const cellSize = w / 9;
      const fs = Math.round(cellSize * 0.52);
      _cells.forEach(row => row.forEach(el => el.style.fontSize = fs + 'px'));
    }
    _resizeGrid();
    new ResizeObserver(_resizeGrid).observe(gridContainer);

    render();
  }

  return { init };
})();
