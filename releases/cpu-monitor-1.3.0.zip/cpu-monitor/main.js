// mvmOS Widget: CPU Monitor v1.3.0
const _cpuMon18n = {
  en: { label: 'CPU Monitor', title: 'CPU USAGE', load: 'Load avg' },
  bg: { label: 'CPU Монитор', title: 'CPU НАТОВАРВАНЕ', load: 'Средно натоварване' },
};
function _cpuMont(key) { const lang = window.mvmOS?.lang || 'en'; return (_cpuMon18n[lang] || _cpuMon18n.en)[key] || key; }

mvmOS.registerWidget({
  id: 'cpu-monitor',
  type: 'desktop',
  defaultX: 20,
  defaultY: 60,
  init(container) {
    function render() {
      const W = 220;
      container.innerHTML = `
        <div style="width:${W}px;background:var(--surface,rgba(17,17,27,.88));border:1px solid var(--border,rgba(255,255,255,.08));border-radius:10px;padding:12px;box-shadow:0 8px 32px rgba(0,0,0,.5)">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <span style="font-size:.72rem;font-weight:700;color:var(--text,#cdd6f4);letter-spacing:.06em">${_cpuMont('title')}</span>
            <span id="cpu-mon-pct" style="font-size:1.1rem;font-weight:700;color:#89b4fa">—</span>
          </div>
          <canvas id="cpu-mon-canvas" width="${W - 24}" height="70" style="display:block;border-radius:4px"></canvas>
          <div style="display:flex;justify-content:space-between;margin-top:8px">
            <span style="font-size:.68rem;color:var(--text-dim,#585b70)">${_cpuMont('load')}</span>
            <span id="cpu-mon-load" style="font-size:.68rem;color:var(--text,#a6adc8)">—</span>
          </div>
        </div>
      `;

      const canvas = container.querySelector('#cpu-mon-canvas');
      const ctx = canvas.getContext('2d');
      const history = new Array(canvas.width).fill(0);

      function draw(pct) {
        history.push(pct);
        if (history.length > canvas.width) history.shift();
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        ctx.strokeStyle = 'rgba(255,255,255,.04)';
        ctx.lineWidth = 1;
        [25, 50, 75].forEach(y => {
          const py = canvas.height - (y / 100 * canvas.height);
          ctx.beginPath(); ctx.moveTo(0, py); ctx.lineTo(canvas.width, py); ctx.stroke();
        });

        const color = pct > 85 ? '#f38ba8' : pct > 60 ? '#f9e2af' : '#89b4fa';
        const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
        grad.addColorStop(0, pct > 85 ? 'rgba(243,139,168,.5)' : pct > 60 ? 'rgba(249,226,175,.4)' : 'rgba(137,180,250,.4)');
        grad.addColorStop(1, 'rgba(137,180,250,.02)');

        ctx.beginPath();
        history.forEach((v, i) => {
          const x = i, y = canvas.height - (v / 100 * canvas.height);
          i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        });
        ctx.lineTo(canvas.width, canvas.height);
        ctx.lineTo(0, canvas.height);
        ctx.closePath();
        ctx.fillStyle = grad;
        ctx.fill();

        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = 1.5;
        history.forEach((v, i) => {
          const x = i, y = canvas.height - (v / 100 * canvas.height);
          i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        });
        ctx.stroke();
      }

      mvmOS.onResources(d => {
        const pct = d.cpu_pct ?? 0;
        const pctEl = container.querySelector('#cpu-mon-pct');
        if (!pctEl) return;
        pctEl.textContent = pct + '%';
        pctEl.style.color = pct > 85 ? '#f38ba8' : pct > 60 ? '#f9e2af' : '#89b4fa';
        const loadEl = container.querySelector('#cpu-mon-load');
        if (loadEl && d.load) loadEl.textContent = `${d.load['1']} · ${d.load['5']} · ${d.load['15']}`;
        draw(pct);
      });
    }

    render();
    window.mvmOS?.onLangChange(() => render());
  }
});
